const CACHE_NAME = 'sales-crm-v6';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.png',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/icon.png',
  '/app-icon.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return Promise.allSettled(
        STATIC_ASSETS.map((url) =>
          fetch(url, { cache: 'no-cache' })
            .then((res) => {
              if (res.ok) return cache.put(url, res);
            })
            .catch(() => {})
        )
      );
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', (event) => {
  // 1. Only handle GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  const url = new URL(event.request.url);

  // 2. Ignore non-HTTP/HTTPS schemes
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // 3. Ignore API routes and dev-internal endpoints
  if (
    url.pathname.startsWith('/api/') ||
    url.pathname.includes('/@vite') ||
    url.pathname.includes('/@fs') ||
    url.pathname.includes('/node_modules/') ||
    url.pathname.includes('__vite') ||
    url.pathname.includes('hot-update')
  ) {
    return;
  }

  // 4. HTML Navigation requests: Network-first (no-cache), fallback to cached HTML
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request, { cache: 'no-cache' })
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone)).catch(() => {});
          }
          return networkResponse;
        })
        .catch(async () => {
          const cached = await caches.match(event.request);
          if (cached) return cached;
          const indexCached = await caches.match('/index.html');
          if (indexCached) return indexCached;
          const rootCached = await caches.match('/');
          if (rootCached) return rootCached;
          return new Response(
            '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><title>Sales CRM</title></head><body><p style="text-align:center;padding:2rem;font-family:sans-serif;">جاري تشغيل التطبيق في وضع عدم الاتصال...</p><script>window.location.reload();</script></body></html>',
            { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          );
        })
    );
    return;
  }

  // 5. Assets (JS, CSS, Images, Fonts): Cache-first, never cache HTML fallback as JS/CSS
  const isScriptOrStyle = /\.(js|mjs|css)$/i.test(url.pathname);
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        const cachedType = (cachedResponse.headers.get('content-type') || '').toLowerCase();
        if (!isScriptOrStyle || !cachedType.includes('text/html')) {
          return cachedResponse;
        }
      }
      return fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && (networkResponse.status === 200 || networkResponse.status === 0)) {
            const contentType = (networkResponse.headers.get('content-type') || '').toLowerCase();
            // Prevent poisoning JS/CSS cache entries with HTML error/fallback pages
            if (!isScriptOrStyle || !contentType.includes('text/html')) {
              const clone = networkResponse.clone();
              caches
                .open(CACHE_NAME)
                .then((cache) => {
                  cache.put(event.request, clone);
                })
                .catch(() => {});
            }
          }
          return networkResponse;
        })
        .catch(() => {
          return new Response('', { status: 404, statusText: 'Offline Asset Not Cached' });
        });
    })
  );
});

