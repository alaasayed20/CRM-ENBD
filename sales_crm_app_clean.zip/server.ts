import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.disable('x-powered-by');
app.set('trust proxy', 1);

// ============================================================================
// SECURITY HEADERS (iFrame-compatible for AI Studio preview & PWA)
// ============================================================================
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), payment=(), usb=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  next();
});

// Tight default JSON body parser for regular endpoints
app.use(express.json({ limit: '100kb' }));

// ============================================================================
// SIGNED IN-MEMORY SESSION TOKEN (HMAC-SHA256) & SAME-ORIGIN + RATE LIMITING
// ============================================================================
const SESSION_SECRET =
  process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 24
    ? process.env.SESSION_SECRET
    : crypto.randomBytes(32).toString('hex');

const SESSION_TTL_MS = 15 * 60 * 1000; // 15 minutes

function signSessionToken(nonce: string, exp: number): string {
  const payload = Buffer.from(JSON.stringify({ n: nonce, exp }), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token: string): boolean {
  try {
    const parts = token.split('.');
    if (parts.length !== 2) return false;
    const [payload, sig] = parts;
    const expectedSig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expectedSig, 'utf8');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;

    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!decoded || typeof decoded.exp !== 'number' || decoded.exp < Date.now()) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

function getExpectedHost(req: express.Request): string {
  const forwardedHost = req.headers['x-forwarded-host'];
  const raw = Array.isArray(forwardedHost) ? forwardedHost[0] : (forwardedHost || req.headers.host || '');
  return String(raw).split(',')[0].trim().toLowerCase();
}

function isSameOriginRequest(req: express.Request): boolean {
  const expectedHost = getExpectedHost(req);
  if (!expectedHost) return false;

  const origin = req.headers.origin;
  const referer = req.headers.referer;

  if (typeof origin === 'string' && origin.trim()) {
    try {
      const originHost = new URL(origin).host.toLowerCase();
      return originHost === expectedHost;
    } catch {
      return false;
    }
  }

  if (typeof referer === 'string' && referer.trim()) {
    try {
      const refHost = new URL(referer).host.toLowerCase();
      return refHost === expectedHost;
    } catch {
      return false;
    }
  }

  // Non-browser or same-origin requests without Origin/Referer must still match Host + custom header
  return req.headers['x-requested-with'] === 'SalesCRM-Client';
}

function getClientIp(req: express.Request): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.trim()) {
    return fwd.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || 'unknown';
}

interface RateBucket {
  timestamps: number[];
}

function createSlidingWindowRateLimiter(maxRequests: number, windowMs: number) {
  const buckets = new Map<string, RateBucket>();

  // Periodic cleanup to keep memory bounded
  const timer = setInterval(() => {
    const cutoff = Date.now() - windowMs;
    for (const [key, bucket] of buckets.entries()) {
      bucket.timestamps = bucket.timestamps.filter((ts) => ts > cutoff);
      if (bucket.timestamps.length === 0) buckets.delete(key);
    }
  }, Math.max(60_000, windowMs));
  timer.unref?.();

  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const now = Date.now();
    const cutoff = now - windowMs;
    const key = `${getClientIp(req)}:${req.path}`;
    const bucket = buckets.get(key) || { timestamps: [] };
    bucket.timestamps = bucket.timestamps.filter((ts) => ts > cutoff);

    if (bucket.timestamps.length >= maxRequests) {
      const retryAfterSec = Math.max(1, Math.ceil((bucket.timestamps[0] + windowMs - now) / 1000));
      res.setHeader('Retry-After', String(retryAfterSec));
      return res.status(429).json({
        error: 'تم تجاوز الحد المسموح للطلبات مؤقتاً. يرجى المحاولة بعد قليل.',
      });
    }

    bucket.timestamps.push(now);
    buckets.set(key, bucket);
    next();
  };
}

const sessionRateLimiter = createSlidingWindowRateLimiter(30, 10 * 60 * 1000);
const scanRateLimiter = createSlidingWindowRateLimiter(15, 10 * 60 * 1000);

// Strict same-origin check middleware for protected API routes
const requireSameOriginClient: express.RequestHandler = (req, res, next) => {
  if (req.headers['x-requested-with'] !== 'SalesCRM-Client' || !isSameOriginRequest(req)) {
    return res.status(403).json({ error: 'طلب غير مصرح به من مصدر خارجي' });
  }
  next();
};

const requireScanAuth: express.RequestHandler = (req, res, next) => {
  const authHeader = req.headers.authorization || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'رمز جلسة المسح مطلوب للمتابعة' });
  }
  const token = authHeader.slice(7).trim();
  if (!verifySessionToken(token)) {
    return res.status(401).json({ error: 'انتهت صلاحية جلسة المسح أو الرمز غير صالح' });
  }
  next();
};

// ============================================================================
// PUBLIC PWA MANIFEST & SERVICE WORKER HANDLERS (Scoped CORS only for PWA assets)
// ============================================================================
const handleManifest = (_req: express.Request, res: express.Response) => {
  const manifestPath = path.join(process.cwd(), 'public', 'manifest.json');
  res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.sendFile(manifestPath);
};

app.get('/manifest.json', handleManifest);
app.get('/manifest.webmanifest', handleManifest);
app.get('/site.webmanifest', handleManifest);

const handleSw = (_req: express.Request, res: express.Response) => {
  const swPath = path.join(process.cwd(), 'public', 'sw.js');
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Service-Worker-Allowed', '/');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.sendFile(swPath);
};

app.get('/sw.js', handleSw);
app.get('/service-worker.js', handleSw);

// ============================================================================
// GEMINI CLIENT (Lazy-loaded so dev server boots immediately on port 3000)
// ============================================================================
let genaiModulePromise: Promise<typeof import('@google/genai')> | null = null;
let aiClient: InstanceType<(typeof import('@google/genai'))['GoogleGenAI']> | null = null;

async function getGeminiSdk(): Promise<typeof import('@google/genai')> {
  if (!genaiModulePromise) {
    genaiModulePromise = import('@google/genai');
  }
  return genaiModulePromise;
}

async function getGeminiClient() {
  const { GoogleGenAI } = await getGeminiSdk();
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY_UNCONFIGURED');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

const ALLOWED_IMAGE_MIMES = new Set(['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/heic']);
const MAX_IMAGE_BASE64_CHARS = 8_400_000; // ~6MB decoded image cap

// Health check endpoint (minimal surface)
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});

// Mint short-lived in-memory signed session token for same-origin AI scan calls
app.post('/api/auth/session', sessionRateLimiter, requireSameOriginClient, (_req, res) => {
  const nonce = crypto.randomBytes(16).toString('hex');
  const exp = Date.now() + SESSION_TTL_MS;
  const token = signSessionToken(nonce, exp);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ token, expiresInMs: SESSION_TTL_MS });
});

// Protected API Route for scanning customer card/document/table image
app.post(
  '/api/scan-customer',
  scanRateLimiter,
  requireSameOriginClient,
  requireScanAuth,
  express.json({ limit: '9mb' }),
  async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg' } = req.body || {};
      if (typeof imageBase64 !== 'string' || !imageBase64.trim()) {
        return res.status(400).json({ error: 'صورة العميل مطلوبة للمسح' });
      }

      const normalizedMime = String(mimeType || 'image/jpeg').trim().toLowerCase();
      if (!ALLOWED_IMAGE_MIMES.has(normalizedMime)) {
        return res.status(400).json({ error: 'صيغة الصورة غير مدعومة (يُسمح بـ JPEG / PNG / WEBP فقط)' });
      }

      const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '').trim();
      if (cleanBase64.length < 32 || cleanBase64.length > MAX_IMAGE_BASE64_CHARS) {
        return res.status(413).json({ error: 'حجم الصورة يتجاوز الحد الآمن المسموح به (6 ميجابايت)' });
      }

      if (!/^[A-Za-z0-9+/=\r\n]+$/.test(cleanBase64)) {
        return res.status(400).json({ error: 'تنسيق بيانات الصورة غير صالح' });
      }

      const [{ Type }, ai] = await Promise.all([getGeminiSdk(), getGeminiClient()]);

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType: normalizedMime === 'image/jpg' ? 'image/jpeg' : normalizedMime,
              },
            },
            {
              text: `أنت مساعد خبير قراءة واستخراج بيانات العملاء لصالح تطبيق المبيعات Sales CRM.
قم بقراءة الصورة المرفقة بدقة عالية واستخرج جميع العملاء المذكورين فيها كقائمة في المصفوفة (customers).
لكل عميل استخرج الحقول التالية:
1. name: اسم العميل
2. phone: رقم الجوال (أرقام فقط بدون مسافات)
3. idNumber: رقم الهوية أو الإقامة إن وجد
4. email: البريد الإلكتروني إن وجد
5. productType: 'visa' أو 'finance' (الافتراضي 'visa')
6. salary: الراتب برقم مجرد إن وجد
7. cardTypeName: نوع البطاقة الائتمانية إن وجد
8. amount: المبلغ المطلوب للتمويل برقم مجرد إن وجد
9. financeType: 'salary_transfer' أو 'no_salary_transfer'
10. financeRate: النسبة المئوية للتمويل كعدد مجرد إن وجد
11. notes: الوظيفة أو الملاحظات`,
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              customers: {
                type: Type.ARRAY,
                description: 'قائمة العملاء المكتشفة في الصورة',
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: 'اسم العميل' },
                    phone: { type: Type.STRING, description: 'رقم الجوال' },
                    idNumber: { type: Type.STRING, description: 'رقم الهوية الوطنية أو الإقامة (10 أرقام)' },
                    email: { type: Type.STRING, description: 'البريد الإلكتروني' },
                    productType: { type: Type.STRING, description: "نوع المنتج: 'visa' أو 'finance'" },
                    salary: { type: Type.NUMBER, description: 'الراتب إن وجد' },
                    cardTypeName: { type: Type.STRING, description: 'نوع البطاقة الائتمانية إن وجد' },
                    amount: { type: Type.NUMBER, description: 'المبلغ إن وجد' },
                    financeType: { type: Type.STRING, description: "نوع التمويل: 'salary_transfer' أو 'no_salary_transfer'" },
                    financeRate: { type: Type.NUMBER, description: 'النسبة المئوية للتمويل' },
                    notes: { type: Type.STRING, description: 'الوظيفة أو الملاحظات' },
                  },
                },
              },
            },
          },
        },
      });

      const resultText = response.text || '{}';
      const parsedData = JSON.parse(resultText);

      res.setHeader('Cache-Control', 'no-store');
      res.json({ success: true, data: parsedData });
    } catch (error: any) {
      console.error('Customer Scanner Error:', error?.message || 'Unknown error');
      const errMsg = String(error?.message || '');
      if (errMsg === 'GEMINI_API_KEY_UNCONFIGURED') {
        return res.status(503).json({
          error: 'خدمة المسح الذكي غير مفعّلة حالياً على الخادم. يمكنك إضافة العملاء يدوياً بكل سهولة.',
        });
      }
      if (
        errMsg.includes('429') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('quota')
      ) {
        return res.status(429).json({
          error: 'خدمة المسح الذكي وصلت للحد اليومي مؤقتاً. يمكنك إضافة بيانات العملاء يدوياً.',
        });
      }
      return res.status(500).json({
        error: 'تعذر تحليل الصورة حالياً. يرجى المحاولة مرة أخرى أو الإدخال يدوياً.',
      });
    }
  }
);

async function startServer() {
  const distPath = path.resolve(process.cwd(), 'dist');
  const indexHtmlPath = path.join(distPath, 'index.html');
  const isProduction =
    process.env.NODE_ENV === 'production' ||
    (process.env.NODE_ENV !== 'development' && fs.existsSync(indexHtmlPath));

  const httpServer = http.createServer(app);
  let viteServer: { close: () => Promise<void> } | null = null;

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        // Attach HMR to the existing HTTP server (or disable) so Vite never binds extra port 24678
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    viteServer = vite;
    app.use(vite.middlewares);
  } else {
    // Hashed build assets: long-lived immutable cache, and strict 404 if an old chunk hash is requested
    app.use(
      '/assets',
      express.static(path.join(distPath, 'assets'), {
        immutable: true,
        maxAge: '1y',
        fallthrough: true,
      })
    );
    app.use('/assets', (_req, res) => {
      res.setHeader('Cache-Control', 'no-store');
      res.status(404).type('text/plain').send('Asset not found');
    });

    // Serve remaining static files from dist with no-cache for HTML documents
    app.use(
      express.static(distPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
          }
        },
      })
    );

    // SPA fallback for client routes only (never return HTML for missing static assets or API routes)
    const STATIC_EXT_REGEX = /\.(js|mjs|cjs|css|map|png|jpe?g|gif|svg|ico|webp|woff2?|ttf|eot|json|webmanifest)$/i;
    app.get('*', (req, res) => {
      if (req.path.startsWith('/api/') || STATIC_EXT_REGEX.test(req.path)) {
        res.setHeader('Cache-Control', 'no-store');
        return res.status(404).type('text/plain').send('Not found');
      }
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(indexHtmlPath);
    });
  }

  let shuttingDown = false;
  const shutdown = async () => {
    if (shuttingDown) return;
    shuttingDown = true;
    try {
      await viteServer?.close();
    } catch {
      // Ignore Vite close errors
    }
    httpServer.close(() => {
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 2000).unref();
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT} [mode: ${isProduction ? 'production-static' : 'vite-dev'}]`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
