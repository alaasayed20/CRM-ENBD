import fs from 'fs';
import path from 'path';
import { Resvg } from '@resvg/resvg-js';

const svgPath = path.resolve('public/app-icon.svg');
const svg = fs.readFileSync(svgPath, 'utf8');

const targets = [
  { file: 'public/pwa-512x512.png', size: 512 },
  { file: 'public/pwa-192x192.png', size: 192 },
  { file: 'public/icon.png', size: 512 },
  { file: 'public/apple-touch-icon.png', size: 180 },
  { file: 'public/favicon.png', size: 64 },
];

for (const target of targets) {
  const resvg = new Resvg(svg, {
    fitTo: {
      mode: 'width',
      value: target.size,
    },
  });
  const pngData = resvg.render();
  const pngBuffer = pngData.asPng();
  fs.writeFileSync(path.resolve(target.file), pngBuffer);
  console.log(`Generated ${target.file} (${target.size}x${target.size}, ${pngBuffer.length} bytes)`);
}

console.log('All shortcut and app icons generated successfully!');
