#!/usr/bin/env python3
import os
import sys
import zipfile
import tarfile
import time

# Base directories
ROOT_DIR = os.path.abspath(os.getcwd())
PUBLIC_DIR = os.path.join(ROOT_DIR, 'public')
OUTPUT_ZIP_CLEAN = os.path.join(PUBLIC_DIR, 'sales_crm_app_clean.zip')
OUTPUT_ZIP_PROJECT = os.path.join(PUBLIC_DIR, 'sales-crm-project.zip')
OUTPUT_TAR_GZ = os.path.join(PUBLIC_DIR, 'sales-crm-project.tar.gz')

# Excluded paths and extensions
EXCLUDE_DIRS = {
    'node_modules',
    'dist',
    '.git',
    '.aistudio',
    '__pycache__',
    '.cache',
    '.temp',
    '.vscode'
}

EXCLUDE_EXTENSIONS = {
    '.zip',
    '.tar.gz',
    '.tgz',
    '.lock',
    '.log'
}

EXCLUDE_FILES = {
    'bun.lock',
    '.DS_Store',
    'Thumbs.db'
}

# Collect all valid files to include
files_to_include = []

# Include specific root files
root_files = [
    'index.html',
    'package.json',
    'tsconfig.json',
    'vite.config.ts',
    'server.ts',
    'capacitor.config.json',
    'metadata.json',
    'ANDROID_GITHUB_BUILD.md',
    '.env.example',
    '.gitignore'
]

for rf in root_files:
    full_path = os.path.join(ROOT_DIR, rf)
    if os.path.isfile(full_path):
        files_to_include.append((full_path, rf))

# Add README.md for instructions
readme_content = """# Sales CRM - نظام إدارة المبيعات والبطاقات

نظام مبيعات متكامل لمتابعة العملاء والبطاقات الائتمانية والتمويل مع دعم العمل بدون إنترنت كلياً (PWA & Offline) وبناء نسخة Android APK عبر GitHub Actions.

## المتطلبات الأساسية
- Node.js (v20 or higher)
- npm

## طريقة التشغيل:
1. قم بفك ضغط الملف في مجلد على جهازك.
2. افتح سطر الأوامر داخل المجلد ونفذ:
   ```bash
   npm install
   ```
3. لتشغيل خادم التطوير:
   ```bash
   npm run dev
   ```
4. لبناء نسخة الإنتاج:
   ```bash
   npm run build
   ```

## بناء نسخة Android APK عبر GitHub:
ارفع الملفات (بما فيها مجلد `.github/workflows`) إلى مستودع في GitHub، وسيتم بناء ملف `.apk` تلقائياً ونشره في قسم **Releases**. راجع ملف `ANDROID_GITHUB_BUILD.md` للتفاصيل.
"""

temp_readme = os.path.join(ROOT_DIR, 'README_TEMP.md')
with open(temp_readme, 'w', encoding='utf-8') as f:
    f.write(readme_content)
files_to_include.append((temp_readme, 'README.md'))

# Collect src/, public/, scripts/, and .github/
for folder_name in ['src', 'public', 'scripts', '.github']:
    folder_path = os.path.join(ROOT_DIR, folder_name)
    if not os.path.isdir(folder_path):
        continue
    for root, dirs, files in os.walk(folder_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for file in files:
            if file in EXCLUDE_FILES or any(file.endswith(ext) for ext in EXCLUDE_EXTENSIONS):
                continue
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, ROOT_DIR)
            files_to_include.append((full_path, rel_path))

print(f"Total files collected for archive: {len(files_to_include)}")

# Ensure public dir exists
os.makedirs(PUBLIC_DIR, exist_ok=True)

# Remove old archives to avoid any partial corruption
for old_file in [OUTPUT_ZIP_CLEAN, OUTPUT_ZIP_PROJECT, OUTPUT_TAR_GZ]:
    if os.path.exists(old_file):
        try:
            os.remove(old_file)
            print(f"Removed old archive: {old_file}")
        except Exception as e:
            print(f"Warning removing {old_file}: {e}")

# Function to write standard, mobile-compatible ZIP archive
def write_zip(target_path):
    # Using strict standard ZIP with allowZip64=False for maximum mobile compatibility
    with zipfile.ZipFile(target_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=False) as zf:
        for full_path, rel_path in files_to_include:
            # Normalize path with forward slashes for Android/iOS/Windows compatibility
            norm_rel_path = rel_path.replace('\\', '/')
            
            # Read data and get file stats
            with open(full_path, 'rb') as f:
                data = f.read()
            
            # Use current fixed timestamp for reproducibility
            dt = time.localtime(os.path.getmtime(full_path))
            date_time = (dt.tm_year, dt.tm_mon, dt.tm_mday, dt.tm_hour, dt.tm_min, dt.tm_sec)
            if date_time[0] < 1980:
                date_time = (2026, 1, 1, 0, 0, 0)
            
            zinfo = zipfile.ZipInfo(filename=norm_rel_path, date_time=date_time)
            # Set UTF-8 bit flag (bit 11: 0x800)
            zinfo.flag_bits |= 0x800
            # Set POSIX permissions 0o644 (regular file rw-r--r--)
            zinfo.external_attr = 0o644 << 16
            zinfo.compress_type = zipfile.ZIP_DEFLATED
            
            zf.writestr(zinfo, data)
            
    print(f"Wrote {target_path} ({os.path.getsize(target_path)} bytes)")

# Write both ZIP outputs
write_zip(OUTPUT_ZIP_CLEAN)
write_zip(OUTPUT_ZIP_PROJECT)

# Also write clean TAR.GZ for Linux/Server users
with tarfile.open(OUTPUT_TAR_GZ, 'w:gz') as tar:
    for full_path, rel_path in files_to_include:
        norm_rel_path = rel_path.replace('\\', '/')
        tar.add(full_path, arcname=norm_rel_path)
print(f"Wrote {OUTPUT_TAR_GZ} ({os.path.getsize(OUTPUT_TAR_GZ)} bytes)")

# Clean up temp readme
if os.path.exists(temp_readme):
    os.remove(temp_readme)

# Verify ZIP integrity
for zip_path in [OUTPUT_ZIP_CLEAN, OUTPUT_ZIP_PROJECT]:
    with zipfile.ZipFile(zip_path, 'r') as zf:
        test_result = zf.testzip()
        if test_result is not None:
            print(f"ERROR: Corrupted file in {zip_path}: {test_result}", file=sys.stderr)
            sys.exit(1)
        print(f"Integrity check PASSED for {zip_path} ({len(zf.namelist())} files verified)")

print("All archives built and verified successfully!")
