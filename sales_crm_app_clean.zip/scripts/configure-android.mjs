import fs from 'node:fs';
import path from 'node:path';

const rootDir = process.cwd();
const androidDir = path.join(rootDir, 'android');
const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
const buildGradlePath = path.join(androidDir, 'app', 'build.gradle');
const resDir = path.join(androidDir, 'app', 'src', 'main', 'res');

if (!fs.existsSync(androidDir)) {
  console.error('❌ android/ directory not found. Run "npx cap add android" first.');
  process.exit(1);
}

// 1. Patch AndroidManifest.xml with camera, vibrate, internet permissions & Call/WhatsApp queries
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');

  const permissionsToEnsure = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.CAMERA" />',
    '<uses-permission android:name="android.permission.VIBRATE" />',
  ];

  for (const perm of permissionsToEnsure) {
    if (!manifest.includes(perm)) {
      manifest = manifest.replace(
        '</manifest>',
        `    ${perm}\n</manifest>`
      );
    }
  }

  // Optional camera hardware feature so tablets/devices without autofocus remain compatible
  const cameraFeature = '<uses-feature android:name="android.hardware.camera" android:required="false" />';
  if (!manifest.includes('android.hardware.camera')) {
    manifest = manifest.replace(
      '</manifest>',
      `    ${cameraFeature}\n</manifest>`
    );
  }

  // Android 11+ <queries> so tel: dialer and WhatsApp deep links resolve properly
  if (!manifest.includes('<queries>')) {
    const queriesBlock = `    <queries>
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <package android:name="com.whatsapp" />
        <package android:name="com.whatsapp.w4b" />
    </queries>`;
    manifest = manifest.replace('</manifest>', `${queriesBlock}\n</manifest>`);
  }

  fs.writeFileSync(manifestPath, manifest, 'utf8');
  console.log('✅ Patched AndroidManifest.xml permissions and deep-link queries.');
}

// 2. Patch app/build.gradle versionCode & versionName dynamically from CI or package.json
if (fs.existsSync(buildGradlePath)) {
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  const runNumber = Number.parseInt(process.env.GITHUB_RUN_NUMBER || '1', 10);
  const safeVersionCode = Number.isFinite(runNumber) && runNumber > 0 ? runNumber : 1;
  const versionName = process.env.APP_VERSION_NAME || `1.0.${safeVersionCode}`;

  gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${safeVersionCode}`);
  gradle = gradle.replace(/versionName\s+"[^"]*"/, `versionName "${versionName}"`);

  // Ensure release APK uses debug signing automatically if no custom keystore is configured,
  // or uses custom keystore env vars when supplied in GitHub Secrets
  const keystorePath = process.env.ANDROID_KEYSTORE_PATH;
  if (keystorePath && fs.existsSync(keystorePath) && !gradle.includes('signingConfigs')) {
    const signingBlock = `
    signingConfigs {
        release {
            storeFile file("${keystorePath.replace(/\\/g, '/')}")
            storePassword System.getenv("ANDROID_KEYSTORE_PASSWORD")
            keyAlias System.getenv("ANDROID_KEY_ALIAS")
            keyPassword System.getenv("ANDROID_KEY_PASSWORD")
        }
    }
`;
    gradle = gradle.replace('buildTypes {', `${signingBlock}\n    buildTypes {`);
    gradle = gradle.replace(
      /release\s*\{/,
      'release {\n            signingConfig signingConfigs.release'
    );
  }

  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
  console.log(`✅ Updated Android versionCode=${safeVersionCode}, versionName=${versionName}.`);
}

// 3. Copy Sales CRM app icons into Android launcher mipmap directories
const icon512 = path.join(rootDir, 'public', 'pwa-512x512.png');
const icon192 = path.join(rootDir, 'public', 'pwa-192x192.png');
const fallbackIcon = path.join(rootDir, 'public', 'icon.png');

const highResIcon = fs.existsSync(icon512)
  ? icon512
  : fs.existsSync(fallbackIcon)
    ? fallbackIcon
    : icon192;

const medResIcon = fs.existsSync(icon192) ? icon192 : highResIcon;

if (highResIcon && fs.existsSync(highResIcon) && fs.existsSync(resDir)) {
  const mipmapTargets = [
    { folder: 'mipmap-mdpi', src: medResIcon },
    { folder: 'mipmap-hdpi', src: medResIcon },
    { folder: 'mipmap-xhdpi', src: highResIcon },
    { folder: 'mipmap-xxhdpi', src: highResIcon },
    { folder: 'mipmap-xxxhdpi', src: highResIcon },
  ];

  for (const { folder, src } of mipmapTargets) {
    const targetFolder = path.join(resDir, folder);
    if (!fs.existsSync(targetFolder)) continue;

    for (const fileName of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
      const dest = path.join(targetFolder, fileName);
      fs.copyFileSync(src, dest);
    }
  }

  // Also ensure adaptive icon background color matches Sales CRM dark navy (#070e1c)
  const bgValuesPath = path.join(resDir, 'values', 'ic_launcher_background.xml');
  if (fs.existsSync(bgValuesPath)) {
    fs.writeFileSync(
      bgValuesPath,
      `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#070e1c</color>\n</resources>\n`,
      'utf8'
    );
  }

  console.log('✅ Applied Sales CRM app icons to Android launcher resources.');
}
