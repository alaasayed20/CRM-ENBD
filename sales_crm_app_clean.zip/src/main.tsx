import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { recoverFromStaleChunk } from './utils/lazyWithRetry.ts';
import { initNativeAndroidRuntime, isNativeCapacitor } from './utils/nativeMobile.ts';
import './index.css';

// Initialize Android/iOS native StatusBar & hardware Back button when packaged with Capacitor
void initNativeAndroidRuntime();

// Auto-recover seamlessly if Vite detects a stale dynamic chunk after a new build
if (typeof window !== 'undefined') {
  window.addEventListener('vite:preloadError', (event) => {
    event.preventDefault();
    recoverFromStaleChunk();
  });
}

// Register Service Worker only in standalone web production (never inside Capacitor native APK or iframes)
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  if (import.meta.env.PROD && window.self === window.top && !isNativeCapacitor()) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js', { scope: '/' })
        .then((registration) => {
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  window.dispatchEvent(new CustomEvent('app-update-available'));
                }
              });
            }
          });
          window.dispatchEvent(new CustomEvent('app-offline-ready'));
        })
        .catch((err) => {
          console.warn('SW registration info:', err);
        });
    });
  } else {
    navigator.serviceWorker
      .getRegistrations()
      .then((regs) => Promise.all(regs.map((reg) => reg.unregister())))
      .catch(() => {});
    if ('caches' in window) {
      caches
        .keys()
        .then((keys) => Promise.all(keys.map((k) => caches.delete(k))))
        .catch(() => {});
    }
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);
