import React, { useState, useEffect } from 'react';
import { db, calculatePoints, calculateCardPoints, logOperation } from '../db/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useToast } from '../components/Toast';
import { CheckCircle2, DollarSign, Award, X } from 'lucide-react';
import type { Customer } from '../types';

interface ActivateModalProps {
  customer: Customer;
  onClose: () => void;
  onSuccess: () => void;
}

export const ActivateModal: React.FC<ActivateModalProps> = ({ customer, onClose, onSuccess }) => {
  const [salary, setSalary] = useState<string>(customer.salary ? String(customer.salary) : '');
  const [pointsInput, setPointsInput] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const { currentUser } = useAuth();
  const { t, language, formatNumber, dir } = useLanguage();
  const { showToast } = useToast();

  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) || [];
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) || [];
  const cardType = cardTypes.find((ct) => ct.id === customer.cardTypeId);

  const numSalary = parseFloat(salary) || 0;
  const basePoints = cardType && typeof cardType.points === 'number' ? cardType.points : 0;

  const autoCalculatedPoints = basePoints > 0
    ? calculateCardPoints(basePoints, numSalary, customer.productType || 'visa', salaryTiers)
    : calculatePoints(numSalary);

  useEffect(() => {
    setPointsInput(String(autoCalculatedPoints));
  }, [autoCalculatedPoints]);

  const finalPoints = pointsInput !== '' ? Number(pointsInput) : autoCalculatedPoints;

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!numSalary || numSalary <= 0) {
      showToast(language === 'ar' ? 'الراتب مطلوب لتفعيل البطاقة وحساب النقاط' : 'Salary is required to activate card and calculate points', 'error');
      return;
    }

    setSubmitting(true);
    try {
      if (!customer.id) return;

      const updates = {
        status: 'تم التفعيل' as const,
        salary: numSalary,
        points: finalPoints,
        activatedAt: new Date(),
        updatedAt: new Date()
      };

      await db.customers.update(customer.id, updates);

      // Log points entry
      const now = new Date();
      await db.pointsLog.add({
        customerId: customer.id,
        salesRepId: currentUser?.id,
        points: finalPoints,
        reason: language === 'ar' ? `تفعيل بطاقة Visa (${customer.orderNumber || ''})` : `Visa Card Activation (${customer.orderNumber || ''})`,
        month: now.getMonth() + 1,
        year: now.getFullYear(),
        timestamp: now
      });

      await logOperation(
        'ACTIVATE',
        'customers',
        customer.id,
        customer,
        { ...customer, ...updates },
        currentUser?.id
      );

      showToast(language === 'ar' ? `تم تفعيل البطاقة بنجاح! تم كسب ${formatNumber(finalPoints)} نقطة 🏆` : `Card activated successfully! Earned ${formatNumber(finalPoints)} points 🏆`);
      onSuccess();
      onClose();
    } catch (err) {
      console.error('Activation error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء التفعيل' : 'Error during activation', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-3 sm:p-4 overflow-x-hidden">
      <div className={`bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-sm min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto overflow-x-hidden ${dir === 'rtl' ? 'text-right' : 'text-left'} animate-in fade-in slide-in-from-bottom-4`}>
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-white">{t('activateCardTitle', 'تفعيل بطاقة Visa')}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-slate-800/60 p-3 rounded-xl space-y-1">
          <div className="text-xs text-slate-400 font-medium">{t('customerName')}:</div>
          <div className="text-sm font-bold text-white">{customer.name}</div>
          {customer.orderNumber && (
            <div className="text-xs font-mono text-sky-400">{t('orderNumber')}: #{customer.orderNumber}</div>
          )}
        </div>

        <form onSubmit={handleActivate} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              {language === 'ar' ? 'الراتب الشهري (إلزامي لتأكيد التفعيل)' : 'Monthly Salary (Required for Activation)'} <span className="text-rose-400">*</span>
            </label>
            <div className="relative">
              <input
                type="number"
                step="any"
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                placeholder="15000"
                min="0"
                required
                className={`w-full bg-slate-800 border border-slate-700 rounded-xl py-2.5 ${dir === 'rtl' ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} text-slate-100 text-sm font-bold focus:outline-none focus:border-emerald-500 dir-ltr`}
              />
              <DollarSign className={`w-4 h-4 text-slate-400 absolute ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'} top-1/2 -translate-y-1/2`} />
            </div>
          </div>

          <div className="bg-emerald-500/10 border border-emerald-500/30 p-3.5 rounded-xl space-y-2">
            <div className="text-xs text-emerald-400 font-bold flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Award className="w-4 h-4" />
                <span>{language === 'ar' ? 'النقاط المكتسبة لهذا التفعيل' : 'Points Earned for this Activation'}</span>
              </span>
              <span className="text-[10px] text-emerald-300/80 font-normal">{language === 'ar' ? '(يمكنك تعديلها بحرية)' : '(Editable)'}</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                step="any"
                value={pointsInput}
                onChange={(e) => setPointsInput(e.target.value)}
                min="0"
                className="w-full bg-slate-800 border border-emerald-500/60 rounded-xl py-2 px-3 text-center text-2xl font-black text-emerald-300 focus:outline-none focus:border-emerald-400 font-mono"
              />
              <span className="text-xs font-bold text-emerald-400 shrink-0">{t('pointsUnit')}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg shadow-emerald-500/20 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{submitting ? t('loading') : (language === 'ar' ? 'تأكيد التفعيل وكسب النقاط' : 'Confirm Activation & Earn Points')}</span>
          </button>
        </form>
      </div>
    </div>
  );
};

