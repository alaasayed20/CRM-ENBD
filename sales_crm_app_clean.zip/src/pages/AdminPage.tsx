import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logOperation, deleteCustomerCascading, bulkDeleteCustomersCascading, DEFAULT_SALARY_TIERS, generateDemoData, clearDemoData, wipeAllDataAndPrepareFreshCleanVersion } from '../db/db';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { useLanguage } from '../context/LanguageContext';
import { Users, CreditCard, MessageSquare, Target, Award, ScrollText, Calculator, Database, ShieldAlert, Plus, Trash2, Edit3, X, Check, UserX, Search, CheckSquare, Square, AlertTriangle, Filter, RotateCcw, Percent, Tag, Calendar, RefreshCw, Sparkles, Share2, Copy, ShieldCheck, CheckCircle2, ExternalLink, Globe } from 'lucide-react';
import type { User, CardType, MessageTemplate, Customer, SalaryTier, StatusConfig } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import { PersonalFinanceRatesModal } from '../components/PersonalFinanceRatesModal';
import { checkAndApplyMonthRollover } from '../utils/monthRollover';
import { getStatusTranslation, getProductTypeLabel } from '../utils/translations';
import { triggerHaptic } from '../utils/haptics';
import { getPublicBaseAppUrl, generateTrialLink, buildTrialWhatsAppMessage } from '../utils/shareUtils';
import { hashPassword, sanitizePlainText, safeOpenExternal, buildSafeWhatsAppHref } from '../utils/security';

export const AdminPage: React.FC = () => {
  const { isAdmin, currentUser, settings, updateSettingsState } = useAuth();
  const { showToast } = useToast();
  const { t, formatNumber, formatCurrency, dir, language } = useLanguage();

  const [activeModal, setActiveModal] = useState<string | null>(null);

  // Users & Database data
  const users = useLiveQuery(() => db.users.toArray(), []) || [];
  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) || [];
  const templates = useLiveQuery(() => db.messageTemplates.toArray(), []) || [];
  const pointsLog = useLiveQuery(() => db.pointsLog.toArray(), []) || [];
  const operationsLog = useLiveQuery(() => db.operationsLog.reverse().limit(50).toArray(), []) || [];
  const backups = useLiveQuery(() => db.backups.toArray(), []) || [];
  const customers = useLiveQuery(() => db.customers.reverse().toArray(), []) || [];
  const tasksCount = useLiveQuery(() => db.tasks.count(), []) || 0;

  // Customer Management & Delete states
  const [custSearch, setCustSearch] = useState('');
  const [selectedCustIds, setSelectedCustIds] = useState<number[]>([]);
  const [filterProduct, setFilterProduct] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Trial Client Invitation States
  const [trialClientName, setTrialClientName] = useState('');
  const [trialClientPhone, setTrialClientPhone] = useState('');
  const [customTrialBaseUrl, setCustomTrialBaseUrl] = useState('');
  const [showCustomUrlInput, setShowCustomUrlInput] = useState(false);
  const [useCloudSharedPreview, setUseCloudSharedPreview] = useState(false);

  const handleWipeAllDataForFreshVersion = () => {
    triggerHaptic('warning');
    setConfirmConfig({
      isOpen: true,
      title: '⚠️ تفريغ كافة البيانات لتسليم نسخة فارغة للعميل',
      message: `هل أنت متأكد من رغبتك في تفريغ ومسح جميع بيانات وسجلات العملاء (${customers.length}) والمهام (${tasksCount}) وسجلات النقاط بالكامل؟ سيتم تجهيز التطبيق كنسخة جديدة وفارغة 100% جاهزة للإرسال مع بقاء إعداداتك وقوالبك وبطاقاتك محفوظة.`,
      onConfirm: async () => {
        try {
          await wipeAllDataAndPrepareFreshCleanVersion(currentUser?.id);
          setSelectedCustIds([]);
          triggerHaptic('success');
          showToast('تم تفريغ كافة البيانات بنجاح! التطبيق جاهز الآن للتسليم كنسخة جديدة ونظيفة بالكامل 🧹✨', 'success');
          setActiveModal(null);
        } catch (err) {
          console.error('Wipe data error:', err);
          showToast('حدث خطأ أثناء تفريغ البيانات', 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const currentGeneratedTrialLink = generateTrialLink(trialClientName, customTrialBaseUrl, useCloudSharedPreview);


  const handleSendTrialLinkWhatsApp = () => {
    triggerHaptic('success');
    const name = trialClientName.trim() || (language === 'ar' ? 'عزيزي المشترك' : 'Valued Client');
    const trialLink = currentGeneratedTrialLink;
    const message = buildTrialWhatsAppMessage(name, trialLink);

    if (navigator.clipboard) {
      navigator.clipboard.writeText(message);
      showToast(language === 'ar' ? 'تم نسخ رسالة الدعوة الثنائية ورابط التجربة بنجاح 📋' : 'Bilingual trial invitation copied successfully 📋', 'success');
    }

    const phone = (trialClientPhone || '').replace(/[^0-9]/g, '');
    if (phone) {
      safeOpenExternal(buildSafeWhatsAppHref(phone, message));
    } else {
      showToast(language === 'ar' ? 'تم نسخ الرسالة بالعربية والإنجليزية! يمكنك لصقها وإرسالها للعميل.' : 'Bilingual message copied! Paste to send to client.', 'info');
    }
  };

  // Form states for modals
  const [newUsername, setNewUsername] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<'admin' | 'sales'>('sales');

  const [newCardName, setNewCardName] = useState('');
  const [newCardPoints, setNewCardPoints] = useState<number | ''>(4250);

  const [editingCardId, setEditingCardId] = useState<number | null>(null);
  const [editingCardName, setEditingCardName] = useState('');
  const [editingCardPoints, setEditingCardPoints] = useState<number | ''>(4250);

  const [editingTemplateId, setEditingTemplateId] = useState<number | null>(null);
  const [newTemplateName, setNewTemplateName] = useState('');
  const [newTemplateContent, setNewTemplateContent] = useState('');
  const [newTemplateType, setNewTemplateType] = useState('general');
  const [templateSearch, setTemplateSearch] = useState('');

  const [targetInput, setTargetInput] = useState<number>(settings.monthlyTarget || 500);

  // Statuses State & Handlers
  const statuses = useLiveQuery(() => db.statuses.orderBy('order').toArray(), []) || [];
  const [newStatusName, setNewStatusName] = useState('');
  const [newStatusColor, setNewStatusColor] = useState('indigo');

  // Confirmation Modal State
  const [confirmConfig, setConfirmConfig] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void } | null>(null);

  // Salary Tiers States & Handlers
  const salaryTiers = useLiveQuery(() => db.salaryTiers.orderBy('minSalary').toArray(), []) || [];
  const [editingTierId, setEditingTierId] = useState<number | null>(null);
  const [minSalaryInput, setMinSalaryInput] = useState<number | ''>(15001);
  const [maxSalaryInput, setMaxSalaryInput] = useState<number | ''>(30000);
  const [percentageInput, setPercentageInput] = useState<number | ''>(1.25);
  const [appliesToVisaOnlyInput, setAppliesToVisaOnlyInput] = useState<boolean>(true);
  const [tierDescInput, setTierDescInput] = useState<string>('');
  const [showTierForm, setShowTierForm] = useState<boolean>(false);

  const handleStartEditTier = (tier: SalaryTier) => {
    if (!tier.id) return;
    setEditingTierId(tier.id);
    setMinSalaryInput(tier.minSalary);
    setMaxSalaryInput(tier.maxSalary);
    setPercentageInput(tier.percentage);
    setAppliesToVisaOnlyInput(tier.appliesToVisaOnly ?? true);
    setTierDescInput(tier.description || '');
    setShowTierForm(true);
  };

  const handleStartNewTier = () => {
    setEditingTierId(null);
    setMinSalaryInput(15001);
    setMaxSalaryInput(30000);
    setPercentageInput(1.25);
    setAppliesToVisaOnlyInput(true);
    setTierDescInput('');
    setShowTierForm(true);
  };

  const handleSaveSalaryTier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (minSalaryInput === '' || maxSalaryInput === '' || percentageInput === '') {
      showToast(t('fillRequiredFields', 'يرجى تعبئة جميع الحقول المطلوبة'), 'error');
      return;
    }
    const numMin = Number(minSalaryInput);
    const numMax = Number(maxSalaryInput);
    const numPct = Number(percentageInput);

    if (numMin > numMax) {
      showToast(t('minSalaryMustBeLess', 'الحد الأدنى للراتب يجب أن يكون أقل من الحد الأقصى'), 'error');
      return;
    }

    try {
      const defaultDesc = `${language === 'en' ? 'Salary from' : 'راتب من'} ${formatNumber(numMin)} ${language === 'en' ? 'to' : 'إلى'} ${formatNumber(numMax)} ${t('currencySar', 'ر.س')} (${numPct}%)`;
      if (editingTierId) {
        await db.salaryTiers.update(editingTierId, {
          minSalary: numMin,
          maxSalary: numMax,
          percentage: numPct,
          appliesToVisaOnly: appliesToVisaOnlyInput,
          description: tierDescInput.trim() || defaultDesc
        });
        await logOperation('UPDATE_SALARY_TIER', 'salaryTiers', editingTierId, null, { minSalary: numMin, maxSalary: numMax, percentage: numPct }, currentUser?.id);
        showToast(t('salaryTierUpdatedSuccess', 'تم تحديث شريحة الراتب والنسبة المئوية بنجاح ⚡'), 'success');
      } else {
        const id = await db.salaryTiers.add({
          minSalary: numMin,
          maxSalary: numMax,
          percentage: numPct,
          appliesToVisaOnly: appliesToVisaOnlyInput,
          description: tierDescInput.trim() || defaultDesc,
          createdAt: new Date()
        });
        await logOperation('CREATE_SALARY_TIER', 'salaryTiers', id, null, { minSalary: numMin, maxSalary: numMax, percentage: numPct }, currentUser?.id);
        showToast(t('salaryTierAddedSuccess', 'تمت إضافة شريحة الراتب والنسبة المئوية بنجاح ✨'), 'success');
      }

      setEditingTierId(null);
      setShowTierForm(false);
    } catch (err) {
      console.error('Error saving salary tier:', err);
      showToast(t('error', 'حدث خطأ أثناء حفظ شريحة الراتب'), 'error');
    }
  };

  const handleDeleteSalaryTier = (id?: number) => {
    if (!id) return;
    setConfirmConfig({
      isOpen: true,
      title: t('confirmDeleteTier', 'حذف شريحة الراتب'),
      message: t('confirmDeleteTier', 'هل أنت متأكد من حذف هذه الشريحة؟'),
      onConfirm: async () => {
        try {
          await db.salaryTiers.delete(id);
          await logOperation('DELETE_SALARY_TIER', 'salaryTiers', id, null, null, currentUser?.id);
          showToast(t('salaryTierDeletedSuccess', 'تم حذف شريحة الراتب بنجاح 🗑️'), 'success');
        } catch (err) {
          console.error('Error deleting salary tier:', err);
          showToast(t('error', 'حدث خطأ أثناء حذف الشريحة'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleResetSalaryTiers = () => {
    setConfirmConfig({
      isOpen: true,
      title: t('restoreDefaultTiers', 'إعادة ضبط شرائح الرواتب'),
      message: t('restoreDefaultTiers', 'هل تريد إعادة ضبط شرائح الرواتب والنسب إلى القيم الافتراضية؟'),
      onConfirm: async () => {
        try {
          await db.salaryTiers.clear();
          await db.salaryTiers.bulkAdd(DEFAULT_SALARY_TIERS as SalaryTier[]);
          showToast(t('salaryTiersResetSuccess', 'تمت إعادة ضبط الشرائح والنسب الافتراضية بنجاح 🔄'), 'success');
        } catch (err) {
          console.error('Error resetting salary tiers:', err);
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  if (!isAdmin) {
    return (
      <div className="p-8 text-center text-rose-400 font-bold space-y-2">
        <ShieldAlert className="w-12 h-12 mx-auto stroke-1" />
        <div>{t('unauthorizedAdmin', 'غير مصرح بالوصول إلى هذه الصفحة')}</div>
      </div>
    );
  }

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUsername = sanitizePlainText(newUsername, 40);
    const cleanPassword = newUserPassword.trim();
    if (!cleanUsername || !cleanPassword) return;
    if (cleanPassword.length < 6) {
      showToast(t('passwordLengthError', 'كلمة المرور يجب أن تكون 6 أرقام/رموز على الأقل'), 'error');
      return;
    }

    try {
      const existing = await db.users.where('username').equals(cleanUsername).first();
      if (existing) {
        showToast(language === 'ar' ? 'اسم المستخدم مسجل مسبقاً' : 'Username already exists', 'warning');
        return;
      }

      const hashedPassword = await hashPassword(cleanPassword);
      const newUser: User = {
        username: cleanUsername,
        password: hashedPassword,
        role: newUserRole,
        permissions: newUserRole === 'admin' ? 'all' : 'limited',
        createdAt: new Date()
      };

      const id = await db.users.add(newUser);
      await logOperation('CREATE', 'users', id, null, { username: cleanUsername, role: newUserRole }, currentUser?.id);
      showToast(t('userAddedSuccess', 'تمت إضافة المستخدم وتشفير كلمة المرور بنجاح 🔐'));
      setNewUsername('');
      setNewUserPassword('');
    } catch (err) {
      console.error('Add user error:', err);
    }
  };

  const handleDeleteUser = (userId?: number) => {
    if (!userId) return;
    const u = users.find(x => x.id === userId);
    if (u?.username === 'admin') {
      showToast(t('cannotDeleteMainAdmin', 'لا يمكن حذف المستخدم الرئيسي admin'), 'error');
      return;
    }

    setConfirmConfig({
      isOpen: true,
      title: t('deleteUserConfirmTitle', 'حذف المستخدم'),
      message: `${t('deleteUserConfirmMsg', 'هل أنت متأكد من حذف المستخدم')} "${u?.username}"؟`,
      onConfirm: async () => {
        try {
          await db.users.delete(userId);
          await logOperation('DELETE', 'users', userId, u, null, currentUser?.id);
          showToast(t('userDeletedSuccess', 'تم حذف المستخدم بنجاح 🗑️'), 'success');
        } catch (err) {
          console.error('Delete user error:', err);
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleAddCardType = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardName.trim()) return;

    try {
      const pts = typeof newCardPoints === 'number' ? newCardPoints : 4250;
      const newCt: Omit<CardType, 'id'> = {
        name: newCardName.trim(),
        type: newCardName.trim(),
        pointsFormula: 'custom',
        points: pts,
        isCustom: true,
        createdAt: new Date()
      };

      await db.cardTypes.add(newCt as CardType);
      showToast(t('cardTypeAddedSuccess', 'تمت إضافة نوع البطاقة والنقاط المحددة بنجاح'));
      setNewCardName('');
      setNewCardPoints(4250);
    } catch (err) {
      console.error('Card type add error:', err);
    }
  };

  const handleStartEditCard = (ct: CardType) => {
    if (!ct.id) return;
    setEditingCardId(ct.id);
    setEditingCardName(ct.name);
    setEditingCardPoints(typeof ct.points === 'number' ? ct.points : 4250);
  };

  const handleUpdateCardType = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCardId || !editingCardName.trim()) return;

    try {
      const pts = typeof editingCardPoints === 'number' ? editingCardPoints : 50;
      await db.cardTypes.update(editingCardId, {
        name: editingCardName.trim(),
        type: editingCardName.trim(),
        points: pts
      });
      showToast(t('cardTypeUpdatedSuccess', 'تم تحديث بيانات ونقاط البطاقة بنجاح'));
      setEditingCardId(null);
    } catch (err) {
      console.error('Card update error:', err);
    }
  };

  const handleDeleteCardType = (id?: number) => {
    if (!id) return;
    setConfirmConfig({
      isOpen: true,
      title: t('confirmDeleteCardType', 'حذف نوع البطاقة'),
      message: t('confirmDeleteCardType', 'هل أنت متأكد من حذف نوع البطاقة هذا؟'),
      onConfirm: async () => {
        try {
          await db.cardTypes.delete(id);
          showToast(t('cardTypeDeletedSuccess', 'تم حذف نوع البطاقة بنجاح 🗑️'), 'success');
        } catch (err) {
          console.error('Card type delete error:', err);
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleAddStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStatusName.trim()) return;
    try {
      const maxOrder = statuses.length > 0 ? Math.max(...statuses.map(s => s.order || 0)) : 0;
      await db.statuses.add({
        name: newStatusName.trim(),
        color: newStatusColor,
        order: maxOrder + 1,
        isCustom: true
      });
      showToast(t('statusAddedSuccess', 'تمت إضافة الحالة الجديدة بنجاح ✨'), 'success');
      setNewStatusName('');
    } catch (err) {
      console.error('Add status error:', err);
      showToast(t('errorAddingStatus', 'حدث خطأ أثناء إضافة الحالة'), 'error');
    }
  };

  const handleDeleteStatus = (id?: number, name?: string) => {
    if (!id) return;
    setConfirmConfig({
      isOpen: true,
      title: t('deleteStatusConfirmTitle', 'حذف حالة العمل'),
      message: `${t('deleteStatusConfirmMsg', 'هل أنت متأكد من حذف حالة العمل')} "${name}"؟`,
      onConfirm: async () => {
        try {
          await db.statuses.delete(id);
          showToast(t('statusDeletedSuccess', 'تم حذف الحالة بنجاح 🗑️'), 'success');
        } catch (err) {
          console.error('Delete status error:', err);
          showToast(t('errorDeletingStatus', 'حدث خطأ أثناء حذف الحالة'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTemplateName.trim() || !newTemplateContent.trim()) {
      showToast(t('fillRequiredFields', 'يرجى إدخال اسم ومحتوى القالب'), 'error');
      return;
    }

    try {
      if (editingTemplateId) {
        await db.messageTemplates.update(editingTemplateId, {
          name: newTemplateName.trim(),
          content: newTemplateContent.trim(),
          type: newTemplateType || 'general',
        });
        showToast(t('templateSaveSuccess', 'تم حفظ القالب بنجاح ✨'), 'success');
      } else {
        const newTpl: Omit<MessageTemplate, 'id'> = {
          name: newTemplateName.trim(),
          content: newTemplateContent.trim(),
          type: newTemplateType || 'general',
          createdAt: new Date()
        };
        await db.messageTemplates.add(newTpl as MessageTemplate);
        showToast(t('templateSaveSuccess', 'تمت إضافة القالب بنجاح ✨'), 'success');
      }
      handleCancelEditTemplate();
    } catch (err) {
      console.error('Template save error:', err);
      showToast(t('error', 'حدث خطأ أثناء حفظ القالب'), 'error');
    }
  };

  const handleStartEditTemplate = (tpl: MessageTemplate) => {
    if (!tpl.id) return;
    setEditingTemplateId(tpl.id);
    setNewTemplateName(tpl.name);
    setNewTemplateContent(tpl.content);
    setNewTemplateType(tpl.type || 'general');
  };

  const handleCancelEditTemplate = () => {
    setEditingTemplateId(null);
    setNewTemplateName('');
    setNewTemplateContent('');
    setNewTemplateType('general');
  };

  const handleDeleteTemplate = (id?: number, name?: string) => {
    if (!id) return;
    setConfirmConfig({
      isOpen: true,
      title: t('confirmDeleteTemplateTitle', 'تأكيد حذف القالب'),
      message: `${t('confirmDeleteTemplateMsg', 'هل أنت متأكد من رغبتك في حذف القالب')} "${name || ''}"؟`,
      onConfirm: async () => {
        try {
          await db.messageTemplates.delete(id);
          showToast(t('templateDeleteSuccess', 'تم حذف القالب بنجاح 🗑️'), 'success');
          if (editingTemplateId === id) {
            handleCancelEditTemplate();
          }
        } catch (err) {
          console.error('Delete template error:', err);
          showToast(t('error', 'حدث خطأ أثناء حذف القالب'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleSaveTarget = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettingsState('monthlyTarget', Number(targetInput));
    showToast(t('targetUpdatedSuccess', 'تم تحديث الهدف الشهري بنجاح'));
    setActiveModal(null);
  };

  // Customer Management & Deletion handlers
  const handleDeleteSingleCustomer = (id?: number, name?: string) => {
    if (!id) return;
    setConfirmConfig({
      isOpen: true,
      title: t('deleteCustomerConfirmTitle', 'تأكيد حذف العميل'),
      message: `${t('deleteCustomerConfirmMsg', 'هل أنت متأكد من حذف العميل')} "${name}"؟`,
      onConfirm: async () => {
        try {
          await deleteCustomerCascading(id, currentUser?.id);
          setSelectedCustIds(prev => prev.filter(i => i !== id));
          showToast(t('customersDeletedSuccess', 'تم حذف العميل بنجاح 🗑️').replace('{count}', '1'), 'success');
        } catch (err) {
          console.error('Customer delete error:', err);
          showToast(t('error', 'حدث خطأ أثناء حذف العميل'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleDeleteSelectedCustomers = () => {
    if (selectedCustIds.length === 0) return;
    setConfirmConfig({
      isOpen: true,
      title: t('deleteSelectedCustomersConfirmTitle', 'تأكيد حذف العملاء المحددين'),
      message: t('deleteSelectedCustomersConfirmMsg', 'هل أنت متأكد من حذف العملاء المحددين وجميع متعلقاتهم؟').replace('{count}', String(selectedCustIds.length)),
      onConfirm: async () => {
        try {
          await bulkDeleteCustomersCascading(selectedCustIds, currentUser?.id);
          showToast(t('customersDeletedSuccess', 'تم حذف العملاء المحددين بنجاح 🗑️').replace('{count}', String(selectedCustIds.length)), 'success');
          setSelectedCustIds([]);
        } catch (err) {
          console.error('Batch delete error:', err);
          showToast(t('error', 'حدث خطأ أثناء حذف العملاء المحددين'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const handleDeleteAllCustomers = () => {
    if (customers.length === 0) return;
    setConfirmConfig({
      isOpen: true,
      title: t('deleteAllCustomersConfirmTitle', '⚠️ تحذير عالي الخطورة: مسح السجلات'),
      message: t('deleteAllCustomersConfirmMsg', 'هل أنت متأكد حقاً من حذف جميع العملاء وسجلاتهم؟').replace('{count}', String(customers.length)),
      onConfirm: async () => {
        try {
          const total = customers.length;
          await db.customers.clear();
          await db.tasks.clear();
          await db.pointsLog.clear();
          await logOperation('DELETE_ALL_CUSTOMERS_AND_TASKS', 'customers', null, { total }, null, currentUser?.id);
          setSelectedCustIds([]);
          showToast(t('allCustomersDeletedSuccess', 'تم حذف جميع العملاء بنجاح 🗑️').replace('{count}', String(total)), 'success');
        } catch (err) {
          console.error('Delete all customers error:', err);
          showToast(t('error', 'حدث خطأ أثناء حذف قاعدة بيانات العملاء والمهام'), 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const filteredCustomersForDelete = customers.filter(c => {
    const q = custSearch.trim().toLowerCase();
    const matchesSearch = !q || c.name.toLowerCase().includes(q) || c.phone.includes(q) || (c.orderNumber && c.orderNumber.toLowerCase().includes(q));
    const matchesProd = filterProduct === 'all' || c.productType === filterProduct;
    const matchesStat = filterStatus === 'all' || c.status === filterStatus;
    return matchesSearch && matchesProd && matchesStat;
  });

  const isAllFilteredSelected = filteredCustomersForDelete.length > 0 && filteredCustomersForDelete.every(c => c.id && selectedCustIds.includes(c.id));

  const toggleSelectAllFiltered = () => {
    if (isAllFilteredSelected) {
      const filteredIds = new Set(filteredCustomersForDelete.map(c => c.id).filter(Boolean));
      setSelectedCustIds(prev => prev.filter(id => !filteredIds.has(id)));
    } else {
      const idsToAdd = filteredCustomersForDelete.map(c => c.id).filter((id): id is number => id !== undefined);
      setSelectedCustIds(prev => Array.from(new Set([...prev, ...idsToAdd])));
    }
  };

  const [isRolloverRunning, setIsRolloverRunning] = useState(false);

  const handleManualRollover = async () => {
    setIsRolloverRunning(true);
    try {
      await checkAndApplyMonthRollover(true);
      showToast(t('newMonthStartedSuccess', 'تم بدء الشهر الجديد وتصفير الإنجازات وترحيل العملاء بنجاح 🗓️'), 'success');
      setActiveModal(null);
    } catch (err) {
      console.error('Manual rollover error:', err);
      showToast(t('error', 'حدث خطأ أثناء ترحيل بداية الشهر'), 'error');
    } finally {
      setIsRolloverRunning(false);
    }
  };

  const adminSections = [
    { id: 'trialInvite', title: t('trialInviteSectionTitle', 'إرسال رابط تجربة 14 يوم'), icon: <Share2 className="w-6 h-6 text-emerald-400" />, desc: t('trialInviteSectionDesc', 'دعوة عميل لتجربة المبيعات (بدون لوحة المسؤول)') },
    { id: 'wipeCleanVersion', title: 'تفريغ البيانات لتسليم نسخة جديدة', icon: <Trash2 className="w-6 h-6 text-rose-500" />, desc: 'مسح العملاء وتجهيز نسخة فارغة للعميل 🧹' },
    { id: 'monthRollover', title: t('monthRolloverTitle', 'بداية شهر جديد وتصفير الأهداف'), icon: <Calendar className="w-6 h-6 text-amber-400" />, desc: t('monthRolloverDesc', 'حفظ المفعلين، ترحيل المعلقين وتصفير الأرقام') },
    { id: 'demoData', title: t('demoDataTitle', 'إضافة / استعادة البيانات التجريبية'), icon: <Sparkles className="w-6 h-6 text-yellow-400" />, desc: t('demoDataDesc', 'توليد عينات للعملاء المحتملين والمؤجلين والشهر السابق') },
    { id: 'deleteCustomers', title: t('deleteCustomersTitle', 'إدارة وحذف العملاء'), icon: <UserX className="w-6 h-6 text-rose-500" />, desc: t('registeredCustomersCount', '{count} عميل مسجل').replace('{count}', formatNumber(customers.length)) },
    { id: 'statuses', title: t('statusesTitle', 'إدارة حالات العمل والمراحل'), icon: <Tag className="w-6 h-6 text-cyan-400" />, desc: t('customStatusesCount', '{count} حالات مخصصة').replace('{count}', formatNumber(statuses.length)) },
    { id: 'users', title: t('userManagement', 'إدارة المستخدمين'), icon: <Users className="w-6 h-6 text-sky-400" />, desc: `${formatNumber(users.length)} ${t('usersUnit', 'مستخدمين')}` },
    { id: 'cardTypes', title: t('cardTypesTitle', 'أنواع بطاقات Visa'), icon: <CreditCard className="w-6 h-6 text-emerald-400" />, desc: `${formatNumber(cardTypes.length)} ${t('typesUnit', 'أنواع')}` },
    { id: 'templates', title: t('whatsappTemplatesTitle', 'قوالب واتساب'), icon: <MessageSquare className="w-6 h-6 text-amber-400" />, desc: `${formatNumber(templates.length)} ${t('templatesUnit', 'قوالب')}` },
    { id: 'target', title: t('monthlyTargetTitle', 'الهدف الشهري'), icon: <Target className="w-6 h-6 text-rose-400" />, desc: `${formatNumber(settings.monthlyTarget || 500)} ${t('pointsUnit')}` },
    { id: 'points', title: t('pointsLogTitle', 'سجل النقاط'), icon: <Award className="w-6 h-6 text-purple-400" />, desc: `${formatNumber(pointsLog.length)} ${t('operationsUnit', 'عملية')}` },
    { id: 'operations', title: t('auditTrailTitle', 'سجل تدقيق العمليات'), icon: <ScrollText className="w-6 h-6 text-slate-400" />, desc: `${formatNumber(operationsLog.length)} ${t('recordsUnit', 'سجلات')}` },
    { id: 'financeRates', title: t('personalFinanceRatesTitle', 'نسب التمويل الشخصي والمرابحة'), icon: <Percent className="w-6 h-6 text-emerald-400" />, desc: t('personalFinanceRatesDesc', 'هوامش الربح وشجرة القرارات الفورية 💰') },
    { id: 'formula', title: t('salaryTiersTitle', 'شرائح الرواتب والنسب المئوية'), icon: <Calculator className="w-6 h-6 text-teal-400" />, desc: t('cardTiersVisaOnlyDesc', '{count} شرائح (عملاء البطاقات فقط)').replace('{count}', formatNumber(salaryTiers.length)) },
    { id: 'backups', title: t('backupsTitle', 'نقاط الاستعادة'), icon: <Database className="w-6 h-6 text-indigo-400" />, desc: `${formatNumber(backups.length)} ${t('copiesUnit', 'نسخ')}` }
  ];

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-24 pt-2 px-3 sm:px-4" dir={dir}>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 sm:gap-3 min-w-0">
        {adminSections.map((s) => (
          <button
            key={s.id}
            onClick={() => setActiveModal(s.id)}
            className={`bento-card p-3.5 sm:p-4 w-full min-w-0 bg-zinc-900 border-zinc-800 hover:border-zinc-700 rounded-2xl transition-all hover:scale-[1.02] active:scale-98 shadow-xl flex flex-col justify-between ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="glow-top" />
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 bg-zinc-950 rounded-xl border border-zinc-800 shrink-0">{s.icon}</div>
            </div>
            <div className="min-w-0 w-full">
              <div className="font-bold text-xs text-white mb-0.5 break-words">{s.title}</div>
              <div className="text-[10px] text-zinc-500 font-mono break-words">{s.desc}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Client 14-Day Safe Trial Link Modal */}
      {activeModal === 'trialInvite' && (
        <div 
          className="fixed inset-0 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto overflow-x-hidden animate-fadeIn touch-pan-y" 
          dir={dir}
          onClick={(e) => {
            if (e.target === e.currentTarget) setActiveModal(null);
          }}
        >
          <div className="relative w-full max-w-lg min-w-0 bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col max-h-[88vh] sm:max-h-[86vh] overflow-hidden my-auto">
            {/* Modal Sticky Header */}
            <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/95 backdrop-blur-md sticky top-0 z-20 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">{t('sendTrialLinkTitle', 'إرسال رابط تجربة 14 يوم للعميل')}</h3>
                  <p className="text-[10px] text-zinc-400">{t('sendTrialLinkSubtitle', 'دعوة آمنة لمندوبي ومسؤولي المبيعات')}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-800/80 hover:bg-zinc-700 transition-all"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Modal Body (Touch Smooth Scroll) */}
            <div className="flex-1 overflow-y-auto overscroll-contain p-4 sm:p-5 space-y-3.5 text-start">
              {/* Security Guarantee Notice */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-300">
                <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold">حماية تامة للوحة التحكم والبيانات 🔒</p>
                  <p className="text-[11px] text-emerald-300/80">
                    الرابط مخصص فقط لنسخة المندوب والمبيعات. يتم حجب لوحة تحكم الأدمن ومولد التراخيص تلقائياً ولا يمكن للعميل الوصول إليها.
                  </p>
                </div>
              </div>

              {/* Data status and Clean wipe helper */}
              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400 font-medium">حالة البيانات الحالية بالجهاز:</span>
                  <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded-full ${customers.length === 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'}`}>
                    {customers.length === 0 ? 'نسخة فارغة ونظيفة (0 عملاء)' : `${customers.length} عميل مسجل`}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-2 pt-1 border-t border-zinc-900">
                  <p className="text-[11px] text-zinc-400 leading-tight">
                    {customers.length === 0 
                      ? 'النسخة فارغة ومجهزة لإرسالها للعميل للبدء فوراً.' 
                      : 'يمكنك تفريغ جميع العملاء والمهام الحالية لتسليم نسخة فارغة ونظيفة.'}
                  </p>
                  {customers.length > 0 && (
                    <button
                      type="button"
                      onClick={handleWipeAllDataForFreshVersion}
                      className="px-2.5 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold rounded-lg text-[10px] shrink-0 flex items-center gap-1 active:scale-95 transition-all"
                    >
                      <Trash2 className="w-3 h-3 text-rose-400" />
                      <span>تفريغ البيانات الآن 🧹</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">{t('clientName', 'اسم العميل / المشترك')}</label>
                  <input
                    type="text"
                    value={trialClientName}
                    onChange={(e) => setTrialClientName(e.target.value)}
                    placeholder="مثال: أحمد محمد (مندوب مبيعات)"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">{t('clientPhone', 'رقم واتساب العميل')}</label>
                  <input
                    type="tel"
                    value={trialClientPhone}
                    onChange={(e) => setTrialClientPhone(e.target.value)}
                    placeholder="05xxxxxxxx أو +9665xxxxxxxx"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Clarification about AI Studio Sandbox vs Public URLs */}
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-[11px] text-amber-300 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <span>⚠️ هام لنشر الرابط للعملاء دون طلب تسجيل دخول:</span>
                  </p>
                  <p className="text-amber-200/90 leading-relaxed">
                    روابط بيئة التطوير (ais-dev-) تكون محمية بحسابك. لفتح الرابط لدى أي شخص خارجياً:
                  </p>
                  <ul className="list-disc list-inside text-[10px] text-amber-300/80 space-y-0.5">
                    <li>اضغط على زر <b>Share</b> أعلى منصة AI Studio لمشاركة الرابط العام.</li>
                    <li>أو اضغط على <b>Deploy to Cloud Run</b> لنشر التطبيق كرابط دائم ومستقل.</li>
                    <li>أو ضع رابط موقعك/دومينك المنشور في خيار <b>استخدام دومين مخصص</b> بالأسفل.</li>
                  </ul>
                </div>

                {/* Live Link Preview & Direct Testing Box */}
                <div className="p-3.5 bg-zinc-950 border border-emerald-500/40 rounded-2xl space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-emerald-400" />
                      <span>رابط التجربة المباشر (جاهز للاختبار والإرسال):</span>
                    </span>
                  </div>

                  {/* Source Selection Tabs */}
                  <div className="grid grid-cols-2 gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-xl text-[11px]">
                    <button
                      type="button"
                      onClick={() => {
                        setUseCloudSharedPreview(false);
                        setShowCustomUrlInput(false);
                      }}
                      className={`py-1.5 px-2 rounded-lg font-bold transition-all text-center ${!useCloudSharedPreview && !showCustomUrlInput ? 'bg-emerald-500 text-slate-950 shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
                    >
                      ⚡ الرابط النشط المباشر
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUseCloudSharedPreview(true);
                        setShowCustomUrlInput(false);
                      }}
                      className={`py-1.5 px-2 rounded-lg font-bold transition-all text-center ${useCloudSharedPreview && !showCustomUrlInput ? 'bg-indigo-600 text-white shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
                    >
                      ☁️ رابط المشاركة السحابي
                    </button>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => setShowCustomUrlInput(!showCustomUrlInput)}
                      className="text-[10px] text-zinc-400 hover:text-emerald-300 underline"
                    >
                      {showCustomUrlInput ? 'إخفاء تخصيص الدومين' : '⚙️ استخدام دومين خارجي مخصص'}
                    </button>
                  </div>

                  {showCustomUrlInput && (
                    <div className="pt-1">
                      <label className="block text-[10px] text-zinc-400 mb-0.5">رابط النشر أو الدومين المخصص الخاص بك (Custom Base URL):</label>
                      <input
                        type="url"
                        value={customTrialBaseUrl}
                        onChange={(e) => setCustomTrialBaseUrl(e.target.value)}
                        placeholder="https://your-crm-domain.com"
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  )}

                  {useCloudSharedPreview && (
                    <div className="p-2 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-[10px] text-indigo-300">
                      💡 تنبيه: رابط المشاركة السحابي (ais-pre-) يتطلب الضغط على زر <b>Share</b> في أعلى المنصة لتفعيله خارجياً، أو يمكنك استخدام <b>الرابط النشط المباشر ⚡</b> للاختبار الفوري دون 404.
                    </div>
                  )}

                  <div className="p-2.5 bg-zinc-900/90 border border-zinc-800 rounded-xl text-[11px] font-mono text-zinc-200 break-all select-all leading-relaxed">
                    {currentGeneratedTrialLink}
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText(currentGeneratedTrialLink);
                          showToast(language === 'ar' ? 'تم نسخ الرابط المباشر 📋' : 'Direct trial link copied 📋', 'success');
                        }
                      }}
                      className="py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold rounded-xl text-xs border border-zinc-700 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      <Copy className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'ar' ? 'نسخ الرابط فقط' : 'Copy Link Only'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('medium');
                        safeOpenExternal(currentGeneratedTrialLink);
                      }}
                      className="py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs border border-emerald-400 shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'اختبار وفتح الرابط 🌐' : 'Test & Open Link'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Sticky Action Footer (Always visible & easily accessible) */}
            <div className="p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 sticky bottom-0 z-20 shrink-0 space-y-2">
              <button
                type="button"
                onClick={handleSendTrialLinkWhatsApp}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>{language === 'ar' ? 'إرسال دعوة تجربة 14 يوم (نسخة نظيفة) عبر واتساب 📲' : 'Send 14-Day Clean Trial Invite on WhatsApp 📲'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Wipe Clean Version Modal */}
      {activeModal === 'wipeCleanVersion' && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 z-50 overflow-x-hidden animate-fadeIn" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-rose-500/20 text-rose-400">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">تفريغ البيانات لتسليم نسخة جديدة ونظيفة</h3>
                  <p className="text-[10px] text-zinc-400">تجهيز نسخة فارغة تماماً للمشترك الجديد</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-start gap-2.5 text-xs text-amber-300">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0 text-amber-400" />
              <div className="space-y-1 leading-relaxed">
                <p className="font-bold">ماذا يحدث عند تفريغ البيانات؟</p>
                <ul className="text-[11px] text-amber-300/85 list-disc list-inside space-y-0.5">
                  <li>مسح كافة بيانات العملاء المسجلين والطلبات الحالية ({customers.length}).</li>
                  <li>مسح كافة التذكيرات والمهام وسجلات النقاط والتدقيق.</li>
                  <li><strong>الحفاظ التام</strong> على المستخدمين، الصلاحيات، أنواع البطاقات، شرائح الرواتب، وقوالب الواتساب.</li>
                </ul>
              </div>
            </div>

            <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl flex items-center justify-between">
              <span className="text-xs text-zinc-400 font-medium">عدد العملاء المسجلين حالياً:</span>
              <span className="font-mono font-bold text-xs text-rose-400 px-2.5 py-1 rounded-full bg-rose-500/10 border border-rose-500/20">
                {customers.length} عميل
              </span>
            </div>

            <div className="pt-2 border-t border-zinc-800 space-y-2">
              <button
                type="button"
                onClick={handleWipeAllDataForFreshVersion}
                className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-600/20 active:scale-98 transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>تفريغ ومسح كافة البيانات الآن (تجهيز نسخة فارغة) 🧹</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl text-xs"
              >
                إلغاء وإغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Statuses Management Modal */}
      {activeModal === 'statuses' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 z-50 overflow-x-hidden animate-fadeIn" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Tag className="w-4 h-4 text-cyan-400" />
                <span>{t('statusesTitle', 'إدارة حالات العمل والمراحل')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddStatus} className="space-y-2.5 bg-zinc-950/60 p-3 rounded-2xl border border-zinc-800 shrink-0">
              <div className="text-xs font-bold text-cyan-400">{t('addNewStatus', 'إضافة حالة جديدة')}</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={t('statusNamePlaceholder', 'اسم الحالة (مثال: قيد التدقيق)')}
                  value={newStatusName}
                  onChange={(e) => setNewStatusName(e.target.value)}
                  required
                  className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-cyan-500"
                />
                <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1 shadow-md shadow-cyan-600/20">
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('add', 'إضافة')}</span>
                </button>
              </div>
            </form>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              <div className="text-[11px] font-bold text-zinc-400">{t('availableStatusesInSystem', 'الحالات الحالية المتاحة في النظام:')}</div>
              {statuses.map((s) => (
                <div key={s.id || s.name} className="p-3 bg-zinc-950/60 border border-zinc-800/80 rounded-2xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                    <span className="font-bold text-white">{getStatusTranslation(s.name, language)}</span>
                    {s.isCustom && <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">{t('customBadge', 'مخصصة')}</span>}
                  </div>

                  <button
                    onClick={() => handleDeleteStatus(s.id, s.name)}
                    className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                    title={t('deleteStatus', 'حذف الحالة')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Month Rollover Modal */}
      {activeModal === 'monthRollover' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>{t('monthRolloverTitle', 'بداية شهر جديد وتصفير الأهداف')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 overflow-y-auto pr-1">
              <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-2xl text-xs space-y-2">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>{t('monthRolloverRulesTitle', 'آلية تدوير وقواعد بداية الشهر الجديد:')}</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-zinc-300 text-[11px] leading-relaxed">
                  <li>{t('ruleArchiveActivated', 'حفظ العملاء المفعلين: يتم الاحتفاظ بجميع العملاء الذين تم تفعيلهم في الشهر السابق كأرشيف وإحصائيات لشهرهم.')}</li>
                  <li>{t('ruleRolloverPending', 'ترحيل العملاء النشطين: يتم ترحيل العملاء قيد المتابعة والمعلقين إلى الشهر الحالي للعمل عليهم دون فقدانهم.')}</li>
                  <li>{t('ruleResetTarget', 'تصفير الإنجازات والهدف: يتم تصفير نقاط الشهر والمبيعات المحققة لبدء شريط تقدم جديد للهدف الشهري.')}</li>
                </ul>
              </div>

              <div className="grid grid-cols-2 gap-2 bg-zinc-950/60 p-3 rounded-2xl border border-zinc-800">
                <div className="bg-zinc-900/80 p-2.5 rounded-xl border border-zinc-800 text-center">
                  <div className="text-[10px] text-zinc-400">{t('activatedArchivedCustomers', 'عملاء مفعلون (مؤرشفون)')}</div>
                  <div className="text-sm font-black text-emerald-400 font-mono">
                    {formatNumber(customers.filter(c => c.status === 'تم التفعيل' || c.status === 'مكتمل' || c.status === 'تم التنفيذ').length)}
                  </div>
                </div>
                <div className="bg-zinc-900/80 p-2.5 rounded-xl border border-zinc-800 text-center">
                  <div className="text-[10px] text-zinc-400">{t('rolledOverActiveCustomers', 'عملاء مُرَحَّلون (نشطون)')}</div>
                  <div className="text-sm font-black text-sky-400 font-mono">
                    {formatNumber(customers.filter(c => c.status !== 'تم التفعيل' && c.status !== 'مكتمل' && c.status !== 'تم التنفيذ').length)}
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-zinc-400 bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                {t('currentRegisteredMonthCycle', 'الدورة الشهرية الحالية المسجلة:')} <span className="text-amber-400 font-mono font-bold">{settings.lastActiveMonth || t('notRegistered', 'غير مسجلة')}</span>
              </div>
            </div>

            <div className="pt-2 shrink-0 flex gap-2">
              <button
                type="button"
                onClick={handleManualRollover}
                disabled={isRolloverRunning}
                className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-black py-3 rounded-xl text-xs transition-all shadow-lg shadow-amber-500/20 active:scale-98 flex items-center justify-center gap-2"
              >
                {isRolloverRunning ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Calendar className="w-4 h-4" />
                )}
                <span>{t('startNewMonthNow', 'بدء شهر جديد الآن وتصفير الأرقام')}</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="px-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-3 rounded-xl text-xs transition-colors"
              >
                {t('cancel', 'إلغاء')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Demo Data Modal */}
      {activeModal === 'demoData' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                <span>{t('demoDataTitle', 'إضافة / استعادة البيانات التجريبية')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
              <p>{t('demoDataExplanation', 'سيتم توليد عينات بيانات توضيحية تغطي كافة الأقسام والمراحل التالية:')}</p>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-zinc-400 bg-zinc-950/80 p-3 rounded-xl border border-zinc-800">
                <li>{t('demoPotential', 'عملاء محتملون: متابعة جديدة، استفسارات تمويل، وبطاقات Visa')}</li>
                <li>{t('demoPending', 'عملاء معلقون ومؤجلون: بانتظار مستندات أو تأجيل تواصل')}</li>
                <li>{t('demoCurrentMonth', 'عملاء الشهر الحالي: تم تفعيلهم وإضافتهم للهدف الحالي')}</li>
                <li>{t('demoPreviousMonthArchive', 'تقرير الأرشيف للشهر السابق: سجل مفعلين وإحصائيات شهر كامل سابق')}</li>
              </ul>
            </div>

            <div className="flex flex-col gap-2 pt-2 border-t border-zinc-800 shrink-0">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    await generateDemoData(true);
                    showToast(t('demoDataGeneratedSuccess', 'تم إدراج البيانات التجريبية وتقارير الشهر السابق بنجاح ✨'), 'success');
                    setActiveModal(null);
                  }}
                  className="bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-black font-extrabold py-3 rounded-xl text-xs transition-colors shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{t('generateDemoDataBtn', 'توليد البيانات الآن')}</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await clearDemoData();
                    showToast(t('demoDataClearedSuccess', 'تم إزالة كافة البيانات التجريبية بنجاح 🗑️'), 'info');
                    setActiveModal(null);
                  }}
                  className="bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold py-3 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{t('clearDemoDataBtn', 'حذف البيانات التجريبية')}</span>
                </button>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-2.5 rounded-xl text-xs transition-colors mt-1"
              >
                {t('close', 'إغلاق')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Users Modal */}
      {activeModal === 'users' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-400" />
                <span>{t('userManagementAndPermissions', 'إدارة المستخدمين والصلاحيات')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-2 bg-zinc-950/60 p-3 rounded-2xl border border-zinc-800 shrink-0">
              <div className="text-xs font-bold text-indigo-400">{t('addNewUser', 'إضافة مستخدم جديد')}</div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder={t('username', 'اسم المستخدم')}
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  required
                  className="bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-indigo-500"
                />
                <input
                  type="password"
                  placeholder={t('password', 'كلمة المرور')}
                  value={newUserPassword}
                  onChange={(e) => setNewUserPassword(e.target.value)}
                  required
                  className="bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div className="flex gap-2">
                <select
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value as 'admin' | 'sales')}
                  className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="sales">{t('salesRepOption', 'ممثل مبيعات (Sales)')}</option>
                  <option value="admin">{t('adminOption', 'مسؤول (Admin)')}</option>
                </select>
                <button type="submit" className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1 shadow-md shadow-indigo-600/20">
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('add', 'إضافة')}</span>
                </button>
              </div>
            </form>

            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
              {users.map((u) => (
                <div key={u.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{u.username}</div>
                    <div className="text-[10px] text-zinc-500 font-mono">{u.role === 'admin' ? t('roleAdmin', 'مسؤول (Admin)') : t('roleStaff', 'ممثل مبيعات')}</div>
                  </div>
                  {u.username !== 'admin' && (
                    <button onClick={() => handleDeleteUser(u.id)} className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Card Types Modal */}
      {activeModal === 'cardTypes' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  <span>{t('manageCardTypesPoints', 'إدارة أنواع بطاقات Visa والنقاط')}</span>
                </h3>
                <p className="text-[10px] text-zinc-400 mt-0.5">{t('manageCardTypesPointsDesc', 'تحديد ونقاط كل بطاقة قابلة للتعديل مباشرة')}</p>
              </div>
              <button onClick={() => { setActiveModal(null); setEditingCardId(null); }} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Add Card Form */}
            <form onSubmit={handleAddCardType} className="space-y-2 bg-zinc-950/60 p-3 rounded-2xl border border-zinc-800 shrink-0">
              <div className="text-xs font-bold text-emerald-400">{t('addCardType', 'إضافة نوع بطاقة جديد')}</div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={t('cardNamePlaceholder', 'اسم البطاقة (مثال: Signature)')}
                  value={newCardName}
                  onChange={(e) => setNewCardName(e.target.value)}
                  required
                  className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-emerald-500"
                />
                <div className="w-24">
                  <input
                    type="number"
                    placeholder={t('points', 'النقاط')}
                    value={newCardPoints}
                    onChange={(e) => setNewCardPoints(e.target.value ? Number(e.target.value) : '')}
                    min="0"
                    required
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-emerald-400 font-bold dir-ltr text-center focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <button type="submit" className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-extrabold px-3 py-2.5 rounded-xl text-xs flex items-center gap-1 shadow-md shadow-emerald-500/20">
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('add', 'إضافة')}</span>
                </button>
              </div>
            </form>

            {/* Card Types List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {cardTypes.map((ct) => (
                <div key={ct.id} className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-2xl space-y-2">
                  {editingCardId === ct.id ? (
                    <form onSubmit={handleUpdateCardType} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={editingCardName}
                        onChange={(e) => setEditingCardName(e.target.value)}
                        required
                        className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                      <input
                        type="number"
                        value={editingCardPoints}
                        onChange={(e) => setEditingCardPoints(e.target.value ? Number(e.target.value) : '')}
                        min="0"
                        required
                        className="w-20 bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-emerald-400 font-bold dir-ltr text-center focus:outline-none focus:border-emerald-500"
                      />
                      <button type="submit" className="p-2 bg-emerald-500 text-zinc-950 rounded-xl font-bold">
                        <Check className="w-4 h-4" />
                      </button>
                      <button type="button" onClick={() => setEditingCardId(null)} className="p-2 bg-zinc-800 text-zinc-400 rounded-xl">
                        <X className="w-4 h-4" />
                      </button>
                    </form>
                  ) : (
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{ct.name}</span>
                        <span className="px-2 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-extrabold text-[11px] font-mono">
                          {typeof ct.points === 'number' ? `${formatNumber(ct.points)} ${t('basePointsSuffix', 'نقطة أساسية')}` : `4,250 ${t('basePointsSuffix', 'نقطة أساسية')}`}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleStartEditCard(ct)}
                          className="p-1.5 text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                          title={t('editCardNamePoints', 'تعديل اسم ونقاط البطاقة')}
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDeleteCardType(ct.id)} className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors" title={t('deleteCardType', 'حذف نوع البطاقة')}>
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* WhatsApp Templates Modal */}
      {activeModal === 'templates' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-lg p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-amber-400" />
                <span>{t('manageWhatsappTemplates', 'إدارة قوالب رسائل الواتساب')}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                  {formatNumber(templates.length)}
                </span>
              </h3>
              <button
                onClick={() => {
                  handleCancelEditTemplate();
                  setActiveModal(null);
                }}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Template Add / Edit Form */}
            <form onSubmit={handleSaveTemplate} className="space-y-2.5 bg-zinc-950/80 p-3.5 rounded-2xl border border-zinc-800 shrink-0 shadow-inner">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  {editingTemplateId ? (
                    <>
                      <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t('templateEditTitle', 'تعديل القالب')}</span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-md border border-amber-500/30 font-mono">
                        #{editingTemplateId}
                      </span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t('templateAddTitle', 'إضافة قالب جديد')}</span>
                    </>
                  )}
                </span>
                {editingTemplateId && (
                  <button
                    type="button"
                    onClick={handleCancelEditTemplate}
                    className="text-[11px] font-semibold text-zinc-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
                  >
                    <X className="w-3 h-3" />
                    <span>{t('cancelEdit', 'إلغاء التعديل')}</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="sm:col-span-2">
                  <input
                    type="text"
                    placeholder={t('templateNamePlaceholder', 'عنوان القالب (مثال: تذكير بالموعد)')}
                    value={newTemplateName}
                    onChange={(e) => setNewTemplateName(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-amber-500/60"
                  />
                </div>
                <div>
                  <select
                    value={newTemplateType}
                    onChange={(e) => setNewTemplateType(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500/60"
                  >
                    <option value="general">{t('templateGeneral', 'عام')}</option>
                    <option value="welcome">{t('templateWelcome', 'ترحيب')}</option>
                    <option value="reminder">{t('templateReminder', 'تذكير')}</option>
                    <option value="activation">{t('templateActivation', 'تفعيل بطاقة')}</option>
                    <option value="followup">{t('templateFollowup', 'متابعة')}</option>
                  </select>
                </div>
              </div>

              <div>
                <textarea
                  placeholder={t('templateContentPlaceholder', 'محتوى الرسالة... استخدم {name} للاسم، {orderNumber} لرقم الطلب، {status} للحالة')}
                  value={newTemplateContent}
                  onChange={(e) => setNewTemplateContent(e.target.value)}
                  required
                  rows={3}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 resize-none focus:outline-none focus:border-amber-500/60"
                />
              </div>

              {/* Variable Quick Inserts */}
              <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                <span className="text-[10px] text-zinc-400 font-medium">{t('quickVariables', 'متغيرات سريعة:')}</span>
                {[
                  { tag: '{name}', label: t('customerNameCol', 'الاسم') },
                  { tag: '{phone}', label: t('phoneCol', 'الهاتف') },
                  { tag: '{orderNumber}', label: t('orderNumberCol', 'رقم الطلب') },
                  { tag: '{status}', label: t('statusCol', 'الحالة') }
                ].map((varItem) => (
                  <button
                    key={varItem.tag}
                    type="button"
                    onClick={() => setNewTemplateContent((prev) => prev + ` ${varItem.tag}`)}
                    className="px-2 py-0.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/60 text-indigo-300 rounded-lg text-[10px] font-mono transition-colors"
                  >
                    + {varItem.tag}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-black py-2.5 rounded-xl text-xs transition-all shadow-md shadow-amber-500/10 active:scale-98 flex items-center justify-center gap-1.5"
                >
                  {editingTemplateId ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{t('saveTemplateChanges', 'حفظ التعديلات')}</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>{t('addTemplateBtn', 'إضافة القالب')}</span>
                    </>
                  )}
                </button>
                {editingTemplateId && (
                  <button
                    type="button"
                    onClick={handleCancelEditTemplate}
                    className="px-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-2.5 rounded-xl text-xs transition-colors"
                  >
                    {t('cancel', 'إلغاء')}
                  </button>
                )}
              </div>
            </form>

            {/* Template Search Filter */}
            {templates.length > 3 && (
              <div className="relative shrink-0">
                <Search className={`w-3.5 h-3.5 text-zinc-400 absolute top-2.5 ${dir === 'rtl' ? 'right-3' : 'left-3'}`} />
                <input
                  type="text"
                  placeholder={t('searchTemplatesPlaceholder', 'البحث في القوالب...')}
                  value={templateSearch}
                  onChange={(e) => setTemplateSearch(e.target.value)}
                  className={`w-full bg-zinc-950/60 border border-zinc-700 rounded-xl py-1.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-amber-500/50 ${dir === 'rtl' ? 'pr-9 pl-3' : 'pl-9 pr-3'}`}
                />
              </div>
            )}

            {/* Template List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {templates
                .filter(
                  (t) =>
                    !templateSearch.trim() ||
                    t.name.toLowerCase().includes(templateSearch.toLowerCase()) ||
                    t.content.toLowerCase().includes(templateSearch.toLowerCase())
                )
                .map((tItem) => {
                  const isEditingThis = editingTemplateId === tItem.id;
                  return (
                    <div
                      key={tItem.id}
                      className={`p-3 bg-zinc-950/60 border rounded-2xl space-y-1.5 text-xs transition-all ${
                        isEditingThis
                          ? 'border-amber-500/80 bg-amber-500/5 ring-1 ring-amber-500/30'
                          : 'border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-amber-300">{tItem.name}</span>
                          {tItem.type && (
                            <span className="text-[10px] px-2 py-0.5 rounded-md bg-zinc-900 border border-zinc-800 text-zinc-400 font-mono">
                              {tItem.type === 'welcome'
                                ? t('templateWelcome', 'ترحيب')
                                : tItem.type === 'reminder'
                                ? t('templateReminder', 'تذكير')
                                : tItem.type === 'activation'
                                ? t('templateActivation', 'تفعيل')
                                : tItem.type === 'followup'
                                ? t('templateFollowup', 'متابعة')
                                : t('templateGeneral', 'عام')}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleStartEditTemplate(tItem)}
                            title={t('editTemplate', 'تعديل القالب')}
                            className="p-1.5 text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/10 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteTemplate(tItem.id, tItem.name)}
                            title={t('deleteTemplate', 'حذف القالب')}
                            className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <div className="text-zinc-300 font-sans text-[11px] leading-relaxed whitespace-pre-wrap bg-zinc-900/60 p-2 rounded-xl border border-zinc-800/60">
                        {tItem.content}
                      </div>
                    </div>
                  );
                })}
              {templates.length === 0 && (
                <div className="text-center py-6 text-xs text-zinc-500 italic">
                  {t('noTemplatesFound', 'لا توجد قوالب معرفة حالياً. أضف قالبك الأول أعلاه.')}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Target Modal */}
      {activeModal === 'target' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-bold text-sm text-white">{t('setMonthlyPointsTarget', '🎯 تحديد الهدف الشهري للنقاط')}</h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTarget} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('requiredTargetPoints', 'الهدف المطلوب (نقاط)')}</label>
                <input
                  type="number"
                  value={targetInput}
                  onChange={(e) => setTargetInput(Number(e.target.value))}
                  min={1}
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 text-sm text-white font-black text-center focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
              <button type="submit" className="w-full bg-rose-500 hover:bg-rose-400 text-white font-bold py-3 rounded-xl text-xs shadow-lg shadow-rose-500/20">
                {t('saveNewTarget', 'حفظ الهدف الجديد')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Points History Modal */}
      {activeModal === 'points' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <Award className="w-4 h-4 text-purple-400" />
                  <span>{t('pointsCalculationHistory', 'سجل حسابات النقاط')}</span>
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  {language === 'ar' ? 'سجل العمليات المكتسبة وتوثيق التارجت للمبيعات' : 'Log of earned points and sales quota transactions'}
                </p>
              </div>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            {pointsLog.length > 0 && (
              <div className="bg-purple-950/30 border border-purple-500/20 p-2.5 rounded-xl flex items-center justify-between">
                <span className="text-xs text-purple-200 font-bold">
                  {language === 'ar' ? 'إجمالي النقاط الموثقة:' : 'Total Logged Points:'}
                </span>
                <span className="text-sm font-black text-purple-300 font-mono">
                  {formatNumber(pointsLog.reduce((sum, p) => sum + (p.points || 0), 0))} {t('pointsUnit', 'نقطة')}
                </span>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-xs">
              {pointsLog.length === 0 ? (
                <div className="text-center py-8 px-4 bg-zinc-950/40 rounded-2xl border border-zinc-800/80 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mx-auto text-purple-400">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white mb-1">
                      {language === 'ar' ? 'لا توجد عمليات نقاط مسجلة حالياً' : 'No points logs recorded yet'}
                    </h4>
                    <p className="text-[11px] text-zinc-400 leading-relaxed max-w-xs mx-auto">
                      {language === 'ar' 
                        ? 'يتم توثيق النقاط هنا تلقائياً عند تحويل حالة أي عميل إلى «تم التفعيل» لحساب تحقيق التارجت الشهري للمبيعات بدقة.' 
                        : 'Points are automatically logged here when a customer is marked as "Activated" to calculate quota achievement.'}
                    </p>
                  </div>
                </div>
              ) : (
                pointsLog.map((p) => (
                  <div key={p.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white">{p.reason}</div>
                      <div className="text-[10px] text-zinc-500 font-mono">{new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
                    </div>
                    <span className="font-black text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg">+{formatNumber(p.points)}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Operations Log Modal */}
      {activeModal === 'operations' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <ScrollText className="w-4 h-4 text-zinc-400" />
                <span>{t('auditTrailTitleFull', 'سجل تدقيق العمليات (Audit Trail)')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-xs">
              {operationsLog.map((op) => (
                <div key={op.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl space-y-0.5">
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-indigo-400">{op.action} - {op.tableName}</span>
                    <span className="text-[10px] text-zinc-500 font-mono">{new Date(op.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</span>
                  </div>
                  {op.recordId && <div className="text-[10px] text-zinc-500 font-mono">{t('recordIdLabel', 'معرف السجل: #')}{op.recordId}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Salary Tiers & Points Percentage Multipliers Modal */}
      {activeModal === 'formula' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-lg p-5 shadow-2xl space-y-4 max-h-[88vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-teal-400" />
                  <span>{t('salaryTiersAndPercentages', 'إدارة شرائح الرواتب والنسب المئوية')}</span>
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  {t('salaryTiersSubtitle', 'تعديل نسب النقاط حسب راتب العميل - مفعلة حصرياً لعملاء البطاقات')}
                </p>
              </div>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Visa Only Banner */}
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-2.5 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-300 font-bold">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{t('activeVisaOnlyBadge', 'مُفعلة حصرياً على عملاء البطاقات فقط (Visa)')}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
                Active
              </span>
            </div>

            {/* Top Controls */}
            <div className="flex items-center justify-between gap-2 shrink-0">
              <button
                onClick={handleStartNewTier}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/20 transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>{t('addNewSalaryTier', 'إضافة شريحة راتب جديدة')}</span>
              </button>
              <button
                onClick={handleResetSalaryTiers}
                className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-2 px-3 rounded-xl text-xs border border-zinc-700 flex items-center gap-1 transition-all active:scale-95"
                title={t('restoreDefaultTiers', 'إعادة للقيم الافتراضية')}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t('resetToDefault', 'افتراضي')}</span>
              </button>
            </div>

            {/* Add / Edit Form */}
            {showTierForm && (
              <form onSubmit={handleSaveSalaryTier} className="p-3.5 bg-zinc-950 border border-indigo-500/30 rounded-2xl space-y-3 shrink-0 text-xs animate-in fade-in duration-200">
                <div className="flex items-center justify-between pb-1 border-b border-zinc-800">
                  <span className="font-bold text-indigo-400">
                    {editingTierId ? t('editSalaryTier', 'تعديل شريحة الراتب والنسبة المئوية') : t('addNewSalaryTier', 'إضافة شريحة جديدة')}
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowTierForm(false)}
                    className="text-zinc-500 hover:text-zinc-300 p-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">{t('minSalarySar', 'الحد الأدنى للراتب (ر.س)')}</label>
                    <input
                      type="number"
                      step="any"
                      value={minSalaryInput}
                      onChange={(e) => setMinSalaryInput(e.target.value === '' ? '' : Number(e.target.value))}
                      required
                      min={0}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white text-center font-mono focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">{t('maxSalarySar', 'الحد الأقصى للراتب (ر.س)')}</label>
                    <input
                      type="number"
                      step="any"
                      value={maxSalaryInput}
                      onChange={(e) => setMaxSalaryInput(e.target.value === '' ? '' : Number(e.target.value))}
                      required
                      min={0}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white text-center font-mono focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">{t('earnedPercentage', 'النسبة المئوية المكتسبة %')}</label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={percentageInput}
                        onChange={(e) => setPercentageInput(e.target.value === '' ? '' : Number(e.target.value))}
                        required
                        min={0}
                        max={100}
                        placeholder="1.25"
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-emerald-400 font-bold text-center font-mono focus:border-indigo-500 focus:outline-none"
                      />
                      <Percent className={`w-3.5 h-3.5 text-zinc-500 absolute top-2.5 ${dir === 'rtl' ? 'left-2.5' : 'right-2.5'}`} />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">{t('tierDescriptionOptional', 'الوصف (اختياري)')}</label>
                    <input
                      type="text"
                      value={tierDescInput}
                      onChange={(e) => setTierDescInput(e.target.value)}
                      placeholder={t('description', 'الوصف')}
                      className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-2 text-xs text-white placeholder-zinc-400 focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="appliesVisa"
                    checked={appliesToVisaOnlyInput}
                    onChange={(e) => setAppliesToVisaOnlyInput(e.target.checked)}
                    className="w-4 h-4 rounded bg-zinc-900 border-zinc-700 text-indigo-500 focus:ring-0"
                  />
                  <label htmlFor="appliesVisa" className="text-[11px] text-zinc-300 cursor-pointer">
                    {t('applyTierToVisaOnly', 'تفعيل هذه النسبة على عملاء البطاقات فقط (Visa)')}
                  </label>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="submit"
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all"
                  >
                    {t('saveTier', 'حفظ الشريحة')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowTierForm(false)}
                    className="px-3 bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs"
                  >
                    {t('cancel', 'إلغاء')}
                  </button>
                </div>
              </form>
            )}

            {/* Salary Tiers List */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {salaryTiers.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-xs space-y-2">
                  <Calculator className="w-8 h-8 mx-auto opacity-40" />
                  <div>{t('noSalaryTiersFound', 'لا توجد شرائح رواتب معرفة حالياً')}</div>
                  <button
                    onClick={handleResetSalaryTiers}
                    className="text-indigo-400 hover:underline font-bold"
                  >
                    {t('restoreDefaultTiers', 'استعادة الشرائح الافتراضية')}
                  </button>
                </div>
              ) : (
                salaryTiers.map((tItem) => {
                  const mult = (!tItem.percentage || tItem.percentage === 0) ? 1 : (tItem.percentage > 10 ? tItem.percentage / 100 : tItem.percentage);
                  const sampleInfinitePoints = formatNumber(Math.round(8500 * mult));
                  const samplePlatinumPoints = formatNumber(Math.round(4250 * mult));

                  return (
                    <div
                      key={tItem.id}
                      className="p-3 bg-zinc-950/70 border border-zinc-800 hover:border-zinc-700 rounded-2xl space-y-2 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-white">
                            {formatNumber(tItem.minSalary)} - {tItem.maxSalary >= 999000 ? t('orMore', 'فأكثر') : formatNumber(tItem.maxSalary)} {t('currencySar', 'ر.س')}
                          </span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {tItem.appliesToVisaOnly ? t('visaOnlyClients', 'بطاقات Visa فقط') : t('allClients', 'جميع العملاء')}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-lg font-mono">
                            {tItem.percentage}%
                          </span>

                          <button
                            onClick={() => handleStartEditTier(tItem)}
                            className="p-1.5 text-indigo-400 hover:bg-indigo-500/10 rounded-lg transition-colors"
                            title={t('edit', 'تعديل')}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleDeleteSalaryTier(tItem.id)}
                            className="p-1.5 text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                            title={t('delete', 'حذف')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {tItem.description && (
                        <p className="text-[11px] text-zinc-400">
                          {tItem.description}
                        </p>
                      )}

                      {/* Points Calculation Example Preview */}
                      <div className="p-2 bg-zinc-900/80 rounded-xl border border-zinc-800/80 text-[10px] text-zinc-400 flex flex-wrap justify-between gap-1 font-mono">
                        <div>
                          💡 {t('infiniteCardName', '💎 Infinite Card')} ⬅️ <span className="text-emerald-400 font-bold">{sampleInfinitePoints} {t('pointsUnit', 'نقطة')}</span>
                        </div>
                        <div>
                          💡 {t('platinumCardName', '💳 Platinum Card')} ⬅️ <span className="text-emerald-400 font-bold">{samplePlatinumPoints} {t('pointsUnit', 'نقطة')}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Personal Finance Rates & Margins Modal */}
      {activeModal === 'financeRates' && (
        <PersonalFinanceRatesModal
          isOpen={true}
          onClose={() => setActiveModal(null)}
          currentUser={currentUser}
        />
      )}

      {/* Backups Modal */}
      {activeModal === 'backups' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-indigo-400" />
                <span>{t('backupsHistory', 'سجل نقاط الاستعادة المخزنة')}</span>
              </h3>
              <button onClick={() => setActiveModal(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 text-xs">
              {backups.map((b) => (
                <div key={b.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white">{b.name}</div>
                    <div className="text-[10px] text-zinc-500 font-mono">{new Date(b.createdAt).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Delete Customers Modal */}
      {activeModal === 'deleteCustomers' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-3.5 max-h-[88vh] flex flex-col">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl">
                  <UserX className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    <span>{t('deleteAndManageCustomers', 'حذف وإدارة العملاء')}</span>
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    {t('deleteAndManageCustomersDesc', 'حذف عميل، تحديد مجموعة، أو تفريغ قائمة العملاء')}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Bar */}
            <div className="space-y-2 shrink-0">
              <div className="relative">
                <input
                  type="text"
                  placeholder={t('searchByNamePhoneOrder', '🔍 ابحث بالاسم، رقم الجوال، أو رقم الطلب...')}
                  value={custSearch}
                  onChange={(e) => setCustSearch(e.target.value)}
                  className={`w-full bg-zinc-950 border border-zinc-700 rounded-xl py-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-rose-500 ${dir === 'rtl' ? 'pr-3 pl-8' : 'pl-3 pr-8'}`}
                />
                {custSearch && (
                  <button onClick={() => setCustSearch('')} className={`absolute top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white ${dir === 'rtl' ? 'left-2.5' : 'right-2.5'}`}>
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Filter Selectors */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <select
                  value={filterProduct}
                  onChange={(e) => setFilterProduct(e.target.value)}
                  className="bg-zinc-950 border border-zinc-700 rounded-xl p-2 text-zinc-200 focus:outline-none focus:border-rose-500"
                >
                  <option value="all">{t('allProductsOption', 'جميع المنتجات')}</option>
                  <option value="visa">{t('visaOption', 'بطاقة فيزا')}</option>
                  <option value="finance">{t('financeOption', 'تمويل')}</option>
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="bg-zinc-950 border border-zinc-700 rounded-xl p-2 text-zinc-200 focus:outline-none focus:border-rose-500"
                >
                  <option value="all">{t('allStatusesOption', 'جميع الحالات')}</option>
                  <option value="عميل محتمل">{getStatusTranslation('عميل محتمل', language)}</option>
                  <option value="عميل معلق">{getStatusTranslation('عميل معلق', language)}</option>
                  <option value="تم التنفيذ">{getStatusTranslation('تم التنفيذ', language)}</option>
                  <option value="تم التفعيل">{getStatusTranslation('تم التفعيل', language)}</option>
                </select>
              </div>
            </div>

            {/* Selection & Action Bar */}
            <div className="flex items-center justify-between gap-2 p-2 bg-zinc-950/80 border border-zinc-800/80 rounded-2xl shrink-0 text-xs">
              <button
                onClick={toggleSelectAllFiltered}
                className="flex items-center gap-1.5 text-zinc-300 hover:text-white font-bold"
              >
                {isAllFilteredSelected ? (
                  <CheckSquare className="w-4 h-4 text-rose-400" />
                ) : (
                  <Square className="w-4 h-4 text-zinc-500" />
                )}
                <span>{t('selectAllCount', 'تحديد الكل ({count})').replace('{count}', formatNumber(filteredCustomersForDelete.length))}</span>
              </button>

              <div className="flex items-center gap-1.5">
                {selectedCustIds.length > 0 && (
                  <button
                    onClick={handleDeleteSelectedCustomers}
                    className="bg-rose-600 hover:bg-rose-500 text-white font-bold px-3 py-1.5 rounded-xl text-[11px] flex items-center gap-1 shadow-md shadow-rose-600/20 active:scale-95 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t('deleteSelectedCount', 'حذف المحددين ({count})').replace('{count}', formatNumber(selectedCustIds.length))}</span>
                  </button>
                )}

                {customers.length > 0 && (
                  <button
                    onClick={handleDeleteAllCustomers}
                    className="bg-zinc-800 hover:bg-rose-950/80 hover:text-rose-300 text-zinc-400 font-bold px-2.5 py-1.5 rounded-xl text-[11px] flex items-center gap-1 border border-zinc-700/60 active:scale-95 transition-all"
                    title={t('deleteAllCustomersBtn', 'حذف جميع العملاء من قاعدة البيانات')}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    <span>{t('deleteAllCustomersBtn', 'حذف الكل')}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Customers List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredCustomersForDelete.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-xs font-bold">
                  {t('noCustomersMatchFilter', 'لا يوجد عملاء مطابقين لخيارات البحث')}
                </div>
              ) : (
                filteredCustomersForDelete.map((c) => {
                  const isSelected = c.id && selectedCustIds.includes(c.id);
                  return (
                    <div
                      key={c.id}
                      className={`p-3 bg-zinc-950/60 border rounded-2xl flex items-center justify-between text-xs transition-all ${
                        isSelected ? 'border-rose-500/60 bg-rose-500/5' : 'border-zinc-800/80 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <button
                          type="button"
                          onClick={() => {
                            if (!c.id) return;
                            setSelectedCustIds(prev =>
                              prev.includes(c.id!) ? prev.filter(i => i !== c.id) : [...prev, c.id!]
                            );
                          }}
                          className="p-1 text-zinc-400 hover:text-white"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-rose-400" />
                          ) : (
                            <Square className="w-4 h-4 text-zinc-600" />
                          )}
                        </button>

                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <span>{c.name}</span>
                            {c.orderNumber && (
                              <span className="text-[10px] text-indigo-400 font-mono">
                                #{c.orderNumber}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-zinc-400 font-mono mt-0.5">
                            {c.phone} • <span className="text-zinc-500">{getProductTypeLabel(c.productType, language)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60">
                          {getStatusTranslation(c.status, language)}
                        </span>

                        <button
                          onClick={() => handleDeleteSingleCustomer(c.id, c.name)}
                          className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors border border-rose-500/20"
                          title={t('delete', 'حذف هذا العميل')}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {confirmConfig && (
        <ConfirmModal
          isOpen={confirmConfig.isOpen}
          title={confirmConfig.title}
          message={confirmConfig.message}
          confirmText={t('confirmExecution', 'تأكيد التنفيذ')}
          cancelText={t('cancel', 'إلغاء')}
          isDanger={true}
          onConfirm={confirmConfig.onConfirm}
          onCancel={() => setConfirmConfig(null)}
        />
      )}
    </div>
  );
};
