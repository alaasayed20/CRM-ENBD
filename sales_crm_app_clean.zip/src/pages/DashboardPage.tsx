import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, calculateCardPoints, calculatePoints } from '../db/db';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getStatusTranslation, getCardTypeName } from '../utils/translations';
import { Award, Users, CheckCircle, Clock, AlertTriangle, ArrowRight, Eye, EyeOff, DollarSign, Bell, UserPlus, Target, Calculator, CreditCard, Sparkles, ChevronDown, ChevronUp, Edit3, Check, Plus, Minus, X, Zap, Calendar, Hourglass, Phone, MessageCircle, BarChart3, TrendingUp, TrendingDown, Trophy, FileText, Loader2 } from 'lucide-react';
import type { Customer, CustomerStatus, PointLog, CardType, SalaryTier } from '../types';
import { triggerHaptic } from '../utils/haptics';
import { useToast } from '../components/Toast';
import { DailyTasksWidget } from '../components/DailyTasksWidget';
import { OperationsProgressWidget } from '../components/OperationsProgressWidget';
import { checkAndApplyMonthRollover, getCustomerMonthKey, formatMonthKey, ENGLISH_MONTHS, ARABIC_MONTHS } from '../utils/monthRollover';
import { exportReportToPDF, type PdfCell } from '../utils/pdfExport';

const EMPTY_CUSTOMERS: Customer[] = [];
const EMPTY_POINTS_LOG: PointLog[] = [];
const EMPTY_CARD_TYPES: CardType[] = [];
const EMPTY_SALARY_TIERS: SalaryTier[] = [];
let hasCheckedSessionRollover = false;

interface RecentCustomerRowProps {
  customer: Customer;
  formattedPhone: string;
  statusBadge: React.ReactNode;
  onSelect: (customerId: number) => void;
}

const RecentCustomerRow: React.FC<RecentCustomerRowProps> = React.memo(
  ({ customer, formattedPhone, statusBadge, onSelect }) => (
    <div
      onClick={() => {
        triggerHaptic('medium');
        if (customer.id) onSelect(customer.id);
      }}
      className="py-2.5 flex items-center justify-between gap-2 min-w-0 hover:bg-zinc-800/50 px-2 rounded-xl cursor-pointer transition-colors active:scale-98"
    >
      <div className="min-w-0 flex-1">
        <div className="font-bold text-xs text-zinc-100 truncate">{customer.name}</div>
        <div className="text-[11px] text-zinc-500 dir-ltr font-mono truncate">{formattedPhone}</div>
      </div>
      <div className="flex items-center gap-2 shrink-0">{statusBadge}</div>
    </div>
  )
);

interface DashboardPageProps {
  onSelectCustomer: (customerId: number) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = React.memo(({ onSelectCustomer }) => {
  const { setCurrentPage, pendingReminders, settings, updateSettingsState, selectedMonthKey, setSelectedMonthKey } = useAuth();
  const { t, language, formatNumber, formatCurrency, formatPhone, dir } = useLanguage();
  const { showToast } = useToast();

  const [showSimulator, setShowSimulator] = useState(false);
  const [showEditTargetModal, setShowEditTargetModal] = useState(false);
  const [isExportingSummaryPdf, setIsExportingSummaryPdf] = useState(false);
  const [targetInputValue, setTargetInputValue] = useState('');
  const [salesTargetInputValue, setSalesTargetInputValue] = useState('');
  const [targetMode, setTargetMode] = useState<'points' | 'sales'>('points');

  // Dynamic Card Types with Points
  const [simCardCounts, setSimCardCounts] = useState<Record<number, number>>({});

  // Collapsible view controls for simplified dashboard layout
  const [showCardBreakdown, setShowCardBreakdown] = useState<boolean>(false);
  const [showChartSection, setShowChartSection] = useState<boolean>(false);

  // Period state for monthly registrations chart (6 or 12 months)
  const [chartPeriodMonths, setChartPeriodMonths] = useState<number>(6);

  const customers = useLiveQuery(() => db.customers.toArray(), []) ?? EMPTY_CUSTOMERS;
  const pointsLog = useLiveQuery(() => db.pointsLog.toArray(), []) ?? EMPTY_POINTS_LOG;
  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) ?? EMPTY_CARD_TYPES;
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) ?? EMPTY_SALARY_TIERS;

  // Formatted Card Types list for suggestions and simulator
  const formattedCardTypes = useMemo(() => {
    if (cardTypes && cardTypes.length > 0) {
      return cardTypes.map((ct) => {
        const pts = ct.points && ct.points > 0 ? ct.points : (ct.name.toLowerCase().includes('infinite') ? 8500 : 4250);
        return {
          id: ct.id!,
          name: ct.name,
          points: pts,
          isInfinite: ct.name.toLowerCase().includes('infinite'),
        };
      });
    }
    return [
      { id: 101, name: 'إنفينيت Infinite', points: 8500, isInfinite: true },
      { id: 102, name: 'بلاتينيوم Platinum', points: 4250, isInfinite: false }
    ];
  }, [cardTypes]);

  // Automatic month rollover check once per app session (never re-runs on tab switches)
  useEffect(() => {
    if (hasCheckedSessionRollover) return;
    hasCheckedSessionRollover = true;
    checkAndApplyMonthRollover(false).then((res) => {
      if (res.rolledOver) {
        showToast(t('newMonthStartedSuccess', 'تم بدء الشهر الجديد وتصفير الإنجازات وترحيل العملاء بنجاح 🗓️'), 'success');
      }
    }).catch(console.error);
  }, []);

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  const daysLeftInMonth = Math.max(0, endOfMonth.getDate() - now.getDate());

  // Active month customers filter
  const activeMonthCustomers = useMemo(() => {
    if (selectedMonthKey === 'all') return customers;
    return customers.filter((c) => getCustomerMonthKey(c) === selectedMonthKey);
  }, [customers, selectedMonthKey]);

  // Month name helper
  const monthName = formatMonthKey(selectedMonthKey, language);

  // Calculate monthly points earned in active month
  const monthlyPoints = useMemo(() => {
    return pointsLog.filter((p) => {
      if (selectedMonthKey === 'all') return true;
      const pDate = new Date(p.timestamp);
      if (isNaN(pDate.getTime())) return false;
      const pKey = `${pDate.getFullYear()}-${String(pDate.getMonth() + 1).padStart(2, '0')}`;
      return pKey === selectedMonthKey;
    });
  }, [pointsLog, selectedMonthKey]);

  const pointsFromLogs = useMemo(() => {
    return monthlyPoints.reduce((sum, p) => sum + (p.points || 0), 0);
  }, [monthlyPoints]);

  // O(1) Card Type lookup map to avoid repeated linear scans
  const cardTypeMap = useMemo(() => {
    const map = new Map<number, CardType>();
    for (const ct of cardTypes) {
      if (ct.id !== undefined) map.set(ct.id, ct);
    }
    return map;
  }, [cardTypes]);

  const loggedCustomerIds = useMemo(() => {
    const set = new Set<number>();
    for (const p of monthlyPoints) {
      if (p.customerId !== undefined && p.customerId !== null) set.add(p.customerId);
    }
    return set;
  }, [monthlyPoints]);

  // Unlogged activated customers in active month (strictly تم التفعيل only)
  const unloggedActivatedPoints = useMemo(() => {
    let sum = 0;
    for (const c of activeMonthCustomers) {
      if ((c.status || '').trim() !== 'تم التفعيل') continue;
      if (c.id !== undefined && loggedCustomerIds.has(c.id)) continue;
      const cardType = c.cardTypeId ? cardTypeMap.get(c.cardTypeId) : undefined;
      const basePts = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
      const pts =
        c.points && c.points > 0
          ? c.points
          : basePts > 0
          ? calculateCardPoints(basePts, c.salary, c.productType || 'visa', salaryTiers)
          : calculatePoints(c.salary);
      sum += pts;
    }
    return sum;
  }, [activeMonthCustomers, loggedCustomerIds, cardTypeMap, salaryTiers]);

  const totalPoints = Math.round(pointsFromLogs + unloggedActivatedPoints);

  // Target points (default to 140,000 if not set or if small default)
  const rawTarget = settings.monthlyTarget;
  const target = (rawTarget && rawTarget > 1000) ? rawTarget : 140000;
  
  const remainingPoints = Math.max(0, target - totalPoints);
  const progressPercentRaw = target > 0 ? (totalPoints / target) * 100 : 0;
  const progressPercent = Math.min(progressPercentRaw, 100);

  // Sales Revenue Target (default to 500,000 SAR)
  const rawSalesTarget = settings.monthlySalesTarget;
  const salesTarget = (rawSalesTarget && rawSalesTarget > 0) ? rawSalesTarget : 500000;

  // Total completed sales revenue amount in active month
  const totalSalesAmount = useMemo(() => {
    return activeMonthCustomers
      .filter((c) => {
        const isCompleted = c.status === 'تم التنفيذ' || c.status === 'تم التفعيل' || c.status === 'مكتمل';
        return isCompleted;
      })
      .reduce((sum, c) => sum + (Number(c.amount) || Number(c.salary) || 0), 0);
  }, [activeMonthCustomers]);

  const remainingSalesAmount = Math.max(0, salesTarget - totalSalesAmount);
  const salesProgressPercentRaw = salesTarget > 0 ? (totalSalesAmount / salesTarget) * 100 : 0;
  const salesProgressPercent = Math.min(salesProgressPercentRaw, 100);

  // Active target calculations based on targetMode
  const activeRawPercent = targetMode === 'points' ? progressPercentRaw : salesProgressPercentRaw;
  const activeBarPercent = targetMode === 'points' ? progressPercent : salesProgressPercent;
  const isTargetAchieved = activeRawPercent >= 100;
  const surplusPercent = activeRawPercent > 100 ? activeRawPercent - 100 : 0;

  // Daily required run rates to reach monthly targets
  const requiredDailyPoints = daysLeftInMonth > 0 ? Math.ceil(remainingPoints / daysLeftInMonth) : 0;
  const requiredDailySales = daysLeftInMonth > 0 ? Math.ceil(remainingSalesAmount / daysLeftInMonth) : 0;

  // Top Card Type Representatives for Proposals
  const infiniteType = formattedCardTypes.find((c) => c.isInfinite) || formattedCardTypes[0] || { id: 999, name: 'إنفينيت Infinite', points: 8500 };
  const platinumType = formattedCardTypes.find((c) => !c.isInfinite) || formattedCardTypes[1] || { id: 998, name: 'بلاتينيوم Platinum', points: 4250 };

  const infinitePts = infiniteType.points || 8500;
  const platinumPts = platinumType.points || 4250;

  // Single card type standalone requirements
  const infiniteNeededAlone = remainingPoints > 0 ? Math.ceil(remainingPoints / infinitePts) : 0;
  const platinumNeededAlone = remainingPoints > 0 ? Math.ceil(remainingPoints / platinumPts) : 0;

  // Hybrid recommendation math (e.g. 50% Infinite, remainder Platinum)
  const halfPointsNeeded = remainingPoints / 2;
  const suggestedInfinite = remainingPoints > 0 ? Math.ceil(halfPointsNeeded / infinitePts) : 0;
  const remainingAfterInfinite = Math.max(0, remainingPoints - (suggestedInfinite * infinitePts));
  const suggestedPlatinum = remainingAfterInfinite > 0 ? Math.ceil(remainingAfterInfinite / platinumPts) : 0;

  // Simulator helper functions
  const updateSimCount = (id: number, delta: number) => {
    triggerHaptic('light');
    setSimCardCounts((prev) => {
      const current = prev[id] || 0;
      const next = Math.max(0, current + delta);
      return { ...prev, [id]: next };
    });
  };

  const applyHybridPlanToSimulator = () => {
    triggerHaptic('medium');
    const newCounts: Record<number, number> = {};
    if (infiniteType && infiniteType.id) newCounts[infiniteType.id] = suggestedInfinite;
    if (platinumType && platinumType.id) newCounts[platinumType.id] = suggestedPlatinum;
    setSimCardCounts(newCounts);
    setShowSimulator(true);
    showToast('تم تطبيق الخطة الهجينة المقترحة في حاسبة المحاكاة 🚀', 'success');
  };

  const applyInfiniteOnlyPlan = () => {
    triggerHaptic('medium');
    const newCounts: Record<number, number> = {};
    if (infiniteType && infiniteType.id) newCounts[infiniteType.id] = infiniteNeededAlone;
    setSimCardCounts(newCounts);
    setShowSimulator(true);
    showToast('تم تطبيق خطة البطاقات الكبرى (إنفينيت) في الحاسبة 💎', 'success');
  };

  // Simulator totals
  const simTotalPoints = useMemo(() => {
    return Object.entries(simCardCounts).reduce((sum, [idStr, count]) => {
      const id = Number(idStr);
      const ct = formattedCardTypes.find((c) => c.id === id);
      const pts = ct ? ct.points : 0;
      return sum + (Number(count) || 0) * pts;
    }, 0);
  }, [simCardCounts, formattedCardTypes]);

  const simRemaining = Math.max(0, remainingPoints - simTotalPoints);
  const simNewProgress = Math.min(((totalPoints + simTotalPoints) / target) * 100, 100);

  // Single-pass O(N) monthly customer registration counts
  const monthlyRegistrationData = useMemo(() => {
    const monthList = language === 'en' ? ENGLISH_MONTHS : ARABIC_MONTHS;
    const today = new Date();
    const bucketMap = new Map<string, { count: number; completedCount: number }>();

    for (const c of customers) {
      const created = new Date(c.createdAt);
      if (isNaN(created.getTime())) continue;
      const key = `${created.getFullYear()}-${created.getMonth()}`;
      const existing = bucketMap.get(key) || { count: 0, completedCount: 0 };
      existing.count += 1;
      if (c.status === 'تم التنفيذ' || c.status === 'تم التفعيل' || c.status === 'مكتمل') {
        existing.completedCount += 1;
      }
      bucketMap.set(key, existing);
    }

    const result = [];
    for (let i = chartPeriodMonths - 1; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const year = d.getFullYear();
      const monthIdx = d.getMonth();
      const monthLabel = `${monthList[monthIdx]} ${chartPeriodMonths > 6 ? year : ''}`.trim();
      const stats = bucketMap.get(`${year}-${monthIdx}`);

      result.push({
        month: monthLabel,
        rawMonth: monthIdx,
        year,
        count: stats ? stats.count : 0,
        completedCount: stats ? stats.completedCount : 0,
        isCurrentMonth: i === 0,
      });
    }

    return result;
  }, [customers, chartPeriodMonths, language]);

  // Statistics derived from monthly registration data
  const chartStats = useMemo(() => {
    if (monthlyRegistrationData.length === 0) {
      return { currentMonthCount: 0, growthPct: 0, avgMonthly: 0, peakMonth: '-', totalInPeriod: 0 };
    }

    const currentMonthData = monthlyRegistrationData[monthlyRegistrationData.length - 1];
    const prevMonthData = monthlyRegistrationData.length > 1 ? monthlyRegistrationData[monthlyRegistrationData.length - 2] : null;

    const currentMonthCount = currentMonthData ? currentMonthData.count : 0;
    const prevMonthCount = prevMonthData ? prevMonthData.count : 0;

    let growthPct = 0;
    if (prevMonthCount > 0) {
      growthPct = Math.round(((currentMonthCount - prevMonthCount) / prevMonthCount) * 100);
    } else if (currentMonthCount > 0) {
      growthPct = 100;
    }

    const totalInPeriod = monthlyRegistrationData.reduce((sum, item) => sum + item.count, 0);
    const avgMonthly = Math.round((totalInPeriod / monthlyRegistrationData.length) * 10) / 10;

    const peak = [...monthlyRegistrationData].sort((a, b) => b.count - a.count)[0];
    const peakMonth = peak && peak.count > 0 ? `${peak.month} (${peak.count})` : '-';

    return {
      currentMonthCount,
      prevMonthCount,
      growthPct,
      avgMonthly,
      peakMonth,
      totalInPeriod,
    };
  }, [monthlyRegistrationData]);

  // Single-pass Memoized Dashboard KPIs & Status Breakdowns (Strict per-status separation)
  const {
    pendingActivationCards,
    pendingActivationPoints,
    executedCustomers,
    executedCount,
    activatedCustomers,
    activatedCount,
    pendingCount,
    potentialCount,
    totalCount,
    financeTotal,
    recentCustomers,
  } = useMemo(() => {
    const pCards: Customer[] = [];
    const execCusts: Customer[] = [];
    const actCusts: Customer[] = [];
    const potCusts: Customer[] = [];
    let pendCount = 0;
    let pPointsSum = 0;
    let finTotal = 0;

    for (const c of activeMonthCustomers) {
      const st = (c.status || '').trim();
      if (c.productType === 'visa' && (st === 'تم التنفيذ' || st === 'بانتظار التفعيل')) {
        pCards.push(c);
        const cardType = c.cardTypeId ? cardTypeMap.get(c.cardTypeId) : undefined;
        const basePoints = cardType && typeof cardType.points === 'number' ? cardType.points : 4250;
        pPointsSum +=
          c.points && c.points > 0
            ? c.points
            : basePoints > 0
            ? calculateCardPoints(basePoints, c.salary, c.productType || 'visa', salaryTiers)
            : calculatePoints(c.salary);
      }
      if (st === 'تم التنفيذ') {
        execCusts.push(c);
        if (c.productType === 'finance') {
          finTotal += Number(c.amount) || Number(c.salary) || 0;
        }
      } else if (st === 'تم التفعيل') {
        actCusts.push(c);
      } else if (st === 'عميل معلق') {
        pendCount += 1;
      } else if (st === 'عميل محتمل') {
        potCusts.push(c);
      }
    }

    const recent = [...potCusts]
      .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
      .slice(0, 5);

    return {
      pendingActivationCards: pCards,
      pendingActivationPoints: Math.round(pPointsSum),
      executedCustomers: execCusts,
      executedCount: execCusts.length,
      activatedCustomers: actCusts,
      activatedCount: actCusts.length,
      pendingCount: pendCount,
      potentialCount: potCusts.length,
      totalCount: activeMonthCustomers.length,
      financeTotal: finTotal,
      recentCustomers: recent,
    };
  }, [activeMonthCustomers, cardTypeMap, salaryTiers]);

  const showPoints = settings.showPoints !== false;
  const dailyOperationsTarget = Number(settings.dailyOperationsTarget) > 0 ? Number(settings.dailyOperationsTarget) : 5;
  const weeklyOperationsTarget = Number(settings.weeklyOperationsTarget) > 0 ? Number(settings.weeklyOperationsTarget) : 25;

  const handleSaveOperationsTargets = useCallback(
    async (newDaily: number, newWeekly: number) => {
      await updateSettingsState('dailyOperationsTarget', newDaily);
      await updateSettingsState('weeklyOperationsTarget', newWeekly);
      showToast(
        language === 'ar'
          ? `تم تحديث أهداف العمليات: ${formatNumber(newDaily)} يومياً · ${formatNumber(newWeekly)} أسبوعياً`
          : `Operations targets saved: ${formatNumber(newDaily)}/day · ${formatNumber(newWeekly)}/week`,
        'success'
      );
    },
    [updateSettingsState, showToast, language, formatNumber]
  );

  const handleNavigateAddCustomer = useCallback(() => {
    setCurrentPage('addCustomer');
  }, [setCurrentPage]);

  const handleExportMonthlySummaryPDF = async () => {
    if (isExportingSummaryPdf) return;
    triggerHaptic('medium');
    setIsExportingSummaryPdf(true);
    try {
      const summaryRows: PdfCell[][] = [
        [{ text: language === 'ar' ? 'هدف النقاط الشهري' : 'Monthly Points Target', bold: true }, { text: `${formatNumber(target)} ${t('pointsUnit', 'نقطة')}`, mono: true }],
        [{ text: language === 'ar' ? 'النقاط المحققة (تم التفعيل)' : 'Achieved Points (Activated)', bold: true }, { text: `${formatNumber(totalPoints)} ${t('pointsUnit', 'نقطة')} (${formatNumber(progressPercentRaw.toFixed(1))}%)`, bold: true, mono: true, badgeAccent: 'emerald' }],
        [{ text: language === 'ar' ? 'المتبقي لهدف النقاط' : 'Remaining Points', bold: true }, { text: `${formatNumber(remainingPoints)} ${t('pointsUnit', 'نقطة')}`, mono: true, badgeAccent: remainingPoints > 0 ? 'amber' : 'emerald' }],
        [{ text: language === 'ar' ? 'هدف مبيعات المبالغ' : 'Monthly Sales Target', bold: true }, { text: formatCurrency(salesTarget), mono: true }],
        [{ text: language === 'ar' ? 'المبيعات المحققة' : 'Achieved Sales Volume', bold: true }, { text: `${formatCurrency(totalSalesAmount)} (${formatNumber(salesProgressPercentRaw.toFixed(1))}%)`, mono: true }],
        [{ text: `🟢 ${getStatusTranslation('تم التنفيذ', language)}`, bold: true }, { text: `${formatNumber(executedCount)} ${t('customersCount', 'عميل')}`, mono: true, badgeAccent: 'cyan' }],
        [{ text: `⚡ ${getStatusTranslation('تم التفعيل', language)}`, bold: true }, { text: `${formatNumber(activatedCount)} ${t('customersCount', 'عميل')}`, mono: true, badgeAccent: 'emerald' }],
        [{ text: `⏳ ${getStatusTranslation('بانتظار التفعيل', language)}`, bold: true }, { text: `${formatNumber(pendingActivationCards.length)} ${t('cardsWord', 'بطاقة')} (${formatNumber(pendingActivationPoints)} ${t('pointsUnit', 'نقطة')})`, mono: true, badgeAccent: 'amber' }],
        [{ text: `🟠 ${getStatusTranslation('عميل معلق', language)}`, bold: true }, { text: `${formatNumber(pendingCount)} ${t('customersCount', 'عميل')}`, mono: true }],
        [{ text: `🔵 ${getStatusTranslation('عميل محتمل', language)}`, bold: true }, { text: `${formatNumber(potentialCount)} ${t('customersCount', 'عميل')}`, mono: true }],
        [{ text: language === 'ar' ? 'إجمالي التمويل المنفذ (تم التنفيذ)' : 'Executed Finance Volume', bold: true }, { text: formatCurrency(financeTotal), mono: true, bold: true }],
      ];

      await exportReportToPDF({
        title: `${language === 'ar' ? 'ملخص لوحة المبيعات والأهداف —' : 'Monthly Sales Executive Summary —'} ${monthName}`,
        companyName: settings?.companyName?.trim() || 'SALES CRM SYSTEM',
        cycleLabel: monthName,
        statusLabel: language === 'ar' ? 'ملخص الأداء الشهري (حالات مفصولة)' : 'Monthly Performance Summary',
        statusAccent: 'indigo',
        totalCountLabel: language === 'ar' ? 'إجمالي العملاء' : 'Total Clients',
        totalCountValue: formatNumber(totalCount),
        dir,
        language,
        orientation: 'portrait',
        summaryCards: [
          { label: language === 'ar' ? 'نسبة النقاط' : 'Points %', value: `${formatNumber(progressPercentRaw.toFixed(1))}%`, subtext: `${formatNumber(totalPoints)} / ${formatNumber(target)}`, accent: 'emerald' },
          { label: getStatusTranslation('تم التنفيذ', language), value: formatNumber(executedCount), accent: 'cyan' },
          { label: getStatusTranslation('تم التفعيل', language), value: formatNumber(activatedCount), accent: 'emerald' },
          { label: language === 'ar' ? 'التمويل المنفذ' : 'Executed Finance', value: formatCurrency(financeTotal), accent: 'sky' },
        ],
        columns: [
          { label: language === 'ar' ? 'المؤشر / الحالة' : 'Metric / Status', align: dir === 'rtl' ? 'right' : 'left' },
          { label: language === 'ar' ? 'القيمة المحققة' : 'Value', align: 'center', width: '42%' },
        ],
        rows: summaryRows,
        footerText: language === 'ar' ? 'تم استخراج الملخص الشهري من نظام إدارة المبيعات Sales CRM' : 'Monthly Summary exported from Sales CRM',
        fileName: `sales-crm-dashboard-${selectedMonthKey}.pdf`,
      });
      showToast(language === 'ar' ? 'تم تصدير ملخص الشهر بصيغة PDF بنجاح 📄✨' : 'Monthly summary PDF exported 📄✨', 'success');
    } catch (err) {
      console.error('Dashboard PDF export error:', err);
      showToast(language === 'ar' ? 'تعذر تصدير ملخص الشهر PDF' : 'Failed to export summary PDF', 'error');
    } finally {
      setIsExportingSummaryPdf(false);
    }
  };

  const handleSaveTarget = async () => {
    const valPoints = parseInt(targetInputValue.replace(/,/g, ''), 10);
    const valSales = parseInt(salesTargetInputValue.replace(/,/g, ''), 10);

    if (isNaN(valPoints) || valPoints <= 0) {
      showToast(t('enterValidPointsTarget', 'يرجى إدخال قيمة نقطية صحيحة للهدف'), 'error');
      return;
    }

    try {
      triggerHaptic('success');
      await updateSettingsState('monthlyTarget', valPoints);
      if (!isNaN(valSales) && valSales >= 0) {
        await updateSettingsState('monthlySalesTarget', valSales);
      }
      showToast(t('monthlyTargetsUpdatedSuccess', 'تم تحديث أهداف المبيعات الشهرية بنجاح 🎯'), 'success');
      setShowEditTargetModal(false);
    } catch (err) {
      showToast(t('errorSavingTargets', 'حدث خطأ أثناء حفظ أهداف المبيعات'), 'error');
    }
  };

  const getStatusBadge = (status: CustomerStatus) => {
    const label = getStatusTranslation(status, language);
    switch ((status || '').trim()) {
      case 'تم التفعيل':
        return <span className="px-2.5 py-1 text-[10px] font-extrabold tracking-wider rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">⚡ {label}</span>;
      case 'تم التنفيذ':
        return <span className="px-2.5 py-1 text-[10px] font-bold tracking-wider rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">🟢 {label}</span>;
      case 'مكتمل':
        return <span className="px-2.5 py-1 text-[10px] font-bold tracking-wider rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">✓ {label}</span>;
      case 'بانتظار التفعيل':
        return <span className="px-2.5 py-1 text-[10px] font-extrabold tracking-wider rounded-full bg-gradient-to-r from-amber-500/30 to-yellow-500/30 text-amber-300 border border-amber-500/50 animate-pulse">⏳ {label}</span>;
      case 'عميل معلق':
      case 'مكتمَل الأوراق':
      case 'مكتمل الأوراق':
      case 'مؤجل':
        return <span className="px-2.5 py-1 text-[10px] font-bold tracking-wider rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">🟠 {label}</span>;
      case 'عميل محتمل':
      case 'متابعة':
      default:
        return <span className="px-2.5 py-1 text-[10px] font-bold tracking-wider rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20">🔵 {label}</span>;
    }
  };

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-20 pt-2 px-3 sm:px-4">
      {/* Quick Add Customer Banner for S24 Ultra ergonomic 1-tap thumb access */}
      <button
        onClick={() => {
          triggerHaptic('medium');
          setCurrentPage('addCustomer');
        }}
        className="w-full bg-gradient-to-r from-sky-500 via-blue-600 to-cyan-400 hover:from-sky-400 hover:to-cyan-300 text-white font-black p-3.5 rounded-2xl shadow-xl shadow-sky-500/25 active:scale-95 transition-all flex items-center justify-center gap-2 text-xs select-none"
      >
        <UserPlus className="w-4 h-4" />
        <span>{t('addNewCustomerBtn')} ⚡</span>
      </button>

      {/* High Priority Reminder Banner for Card Activations */}
      {pendingActivationCards.length > 0 && (
        <div className="bento-card bg-gradient-to-r from-amber-950/90 via-zinc-900 to-amber-950/60 border-amber-500/50 p-4 shadow-xl space-y-2.5">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/40 animate-pulse">
                <Zap className="w-5 h-5 fill-current" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="font-extrabold text-xs text-amber-200">
                    {language === 'ar' ? 'أولوية قصوى — بطاقات بانتظار التفعيل' : 'High Priority — Pending Card Activations'}
                  </h3>
                  <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {formatNumber(pendingActivationCards.length)} {language === 'ar' ? 'بطاقات' : 'cards'}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-300 mt-1 leading-relaxed">
                  {language === 'ar' ? (
                    <>لديك <strong className="text-amber-300 font-mono font-black">{formatNumber(pendingActivationPoints)} نقطة معلقة</strong>. تفعيل هذه البطاقات يخصم مباشرة من المتبقي للهدف الشهري!</>
                  ) : (
                    <>You have <strong className="text-amber-300 font-mono font-black">{formatNumber(pendingActivationPoints)} pending points</strong>. Activating these cards immediately counts towards your monthly target!</>
                  )}
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              triggerHaptic('medium');
              setCurrentPage('customers', 'تم التنفيذ');
            }}
            className="w-full bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-zinc-950 font-black py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition-all active:scale-98"
          >
            <CreditCard className="w-4 h-4" />
            <span>
              {language === 'ar' 
                ? `عرض وتفعيل بطاقات العملاء المنفذة (${formatNumber(pendingActivationCards.length)}) ⚡`
                : `View & Activate Executed Cards (${formatNumber(pendingActivationCards.length)}) ⚡`}
            </span>
          </button>
        </div>
      )}

      {/* Interactive Daily & Weekly Operations Achievement Progress Widget */}
      <OperationsProgressWidget
        customers={customers}
        dailyTarget={dailyOperationsTarget}
        weeklyTarget={weeklyOperationsTarget}
        onSaveTargets={handleSaveOperationsTargets}
        onAddCustomer={handleNavigateAddCustomer}
      />

      {/* Monthly Target & Sales Progress - Hero Bento Card */}
      <div className="bento-card bg-gradient-to-br from-[#0e2242] via-[#0a182e] to-[#061021] border-sky-500/35 p-4 sm:p-5 shadow-2xl relative space-y-3.5">
        <div className="glow-top" />
        
        {/* Header toolbar with mode toggle */}
        <div className="flex items-center justify-between gap-2 flex-wrap min-w-0">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="bg-sky-500/20 text-sky-200 px-2.5 sm:px-3 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider flex items-center gap-1.5 border border-sky-400/30 min-w-0 max-w-full">
              <Target className="w-3.5 h-3.5 text-sky-300 shrink-0" />
              <span className="truncate">{t('monthlyTarget')}: {monthName}</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleExportMonthlySummaryPDF}
              disabled={isExportingSummaryPdf}
              className="p-1.5 text-rose-200 hover:text-white rounded-lg bg-rose-500/20 border border-rose-400/35 active:scale-90 transition-all flex items-center gap-1 text-[11px] font-bold disabled:opacity-60"
              title={language === 'ar' ? 'تصدير وطباعة ملخص الشهر كملف PDF' : 'Export Monthly Summary PDF'}
            >
              {isExportingSummaryPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
              <span className="text-[10px]">PDF</span>
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                setTargetInputValue(target.toString());
                setSalesTargetInputValue(salesTarget.toString());
                setShowEditTargetModal(true);
              }}
              className="p-1.5 text-sky-200 hover:text-white rounded-lg bg-[#142c52] border border-sky-400/30 active:scale-90 transition-all flex items-center gap-1 text-[11px] font-bold"
              title={language === 'ar' ? 'تعديل قيمة الهدف الشهري للمبيعات' : 'Edit Monthly Target'}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t('editTarget')}</span>
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                updateSettingsState('showPoints', !showPoints);
              }}
              className="p-1.5 text-sky-300 hover:text-white rounded-lg bg-[#142c52] border border-sky-400/30 active:scale-90"
              title={showPoints ? (language === 'ar' ? 'إخفاء النقاط والمبالغ' : 'Hide Points & Amounts') : (language === 'ar' ? 'إظهار النقاط والمبالغ' : 'Show Points & Amounts')}
            >
              {showPoints ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Target View Switcher Tabs (Points vs Sales Amount) - Stacked Label & Number */}
        <div className="grid grid-cols-2 bg-[#071325]/90 p-1.5 rounded-2xl border border-sky-500/20 gap-1.5">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setTargetMode('points');
            }}
            className={`py-2 px-2.5 rounded-xl transition-all flex flex-col items-center justify-center text-center ${
              targetMode === 'points'
                ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-slate-950 shadow-md shadow-sky-500/25'
                : 'bg-[#0c1e38]/50 hover:bg-[#122748] text-sky-300 hover:text-white border border-sky-500/10'
            }`}
          >
            <div className="flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-extrabold">
              <Award className={`w-3.5 h-3.5 shrink-0 ${targetMode === 'points' ? 'text-slate-950' : 'text-sky-400'}`} />
              <span>{t('targetPointsLabel')}</span>
            </div>
            <div className={`text-xs sm:text-sm font-black font-mono mt-0.5 tracking-tight ${
              targetMode === 'points' ? 'text-slate-950' : 'text-sky-100'
            }`}>
              {formatNumber(target)} {t('pointsShort')}
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setTargetMode('sales');
            }}
            className={`py-2 px-2.5 rounded-xl transition-all flex flex-col items-center justify-center text-center ${
              targetMode === 'sales'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 shadow-md shadow-emerald-500/25'
                : 'bg-[#0c1e38]/50 hover:bg-[#122748] text-sky-300 hover:text-white border border-sky-500/10'
            }`}
          >
            <div className="flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-extrabold">
              <DollarSign className={`w-3.5 h-3.5 shrink-0 ${targetMode === 'sales' ? 'text-slate-950' : 'text-emerald-400'}`} />
              <span>{t('targetSalesLabel')}</span>
            </div>
            <div className={`text-xs sm:text-sm font-black font-mono mt-0.5 tracking-tight ${
              targetMode === 'sales' ? 'text-slate-950' : 'text-sky-100'
            }`}>
              {formatCurrency(salesTarget)}
            </div>
          </button>
        </div>

        {/* Calendar Range Note & Days Remaining */}
        <div className="flex items-center justify-between text-[11px] text-sky-100 font-medium bg-[#071325]/80 py-2 px-3 rounded-xl border border-sky-500/20 shadow-inner gap-2">
          <div className="flex items-center gap-1.5 truncate">
            <Calendar className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="truncate">
              {t('from')} <strong className="text-white font-bold">1</strong> {t('to')} <strong className="text-white font-bold">{formatNumber(endOfMonth.getDate())} {monthName}</strong>
            </span>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 font-black text-xs shrink-0 animate-pulse">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {language === 'ar' 
                ? `متبقي ${formatNumber(daysLeftInMonth)} ${daysLeftInMonth === 1 ? 'يوم' : daysLeftInMonth === 2 ? 'يومان' : 'أيام'}`
                : `${formatNumber(daysLeftInMonth)} ${daysLeftInMonth === 1 ? 'day' : 'days'} left`}
            </span>
          </div>
        </div>

        {/* 3 Metrics Grid based on Selected Target Mode */}
        <div className="grid grid-cols-3 gap-1.5 sm:gap-2 text-center bg-[#071325]/90 p-2.5 sm:p-3 rounded-2xl border border-sky-500/25 shadow-inner min-w-0">
          <div className="min-w-0 overflow-hidden">
            <div className="text-[10px] text-sky-300/80 font-bold mb-0.5 truncate">{t('requiredTarget')}</div>
            <div className="text-xs sm:text-base font-extrabold text-white font-mono truncate">
              {!showPoints ? '••••' : targetMode === 'points' ? formatNumber(target) : formatCurrency(salesTarget)}
            </div>
            <div className="text-[9px] text-sky-400/60 truncate">{targetMode === 'points' ? t('pointsShort') : t('sar')}</div>
          </div>

          <div className="border-x border-sky-500/20 px-1 min-w-0 overflow-hidden">
            <div className="text-[10px] text-emerald-400 font-bold mb-0.5 truncate">{t('achievedTarget')}</div>
            <div className="text-xs sm:text-base font-extrabold text-emerald-400 font-mono truncate">
              {!showPoints ? '••••' : targetMode === 'points' ? formatNumber(totalPoints) : formatCurrency(totalSalesAmount)}
            </div>
            <div className="text-[9px] text-emerald-400/80 font-bold flex items-center justify-center gap-1 flex-wrap">
              <span>{formatNumber(activeRawPercent.toFixed(1))}%</span>
              {surplusPercent > 0 && (
                <span className="text-[8px] bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded font-mono">
                  (+{formatNumber(surplusPercent.toFixed(1))}%)
                </span>
              )}
            </div>
          </div>

          <div className="min-w-0 overflow-hidden">
            <div className="text-[10px] text-amber-400 font-bold mb-0.5 truncate">{t('remainingTarget')}</div>
            <div className="text-xs sm:text-base font-extrabold text-amber-300 font-mono truncate">
              {!showPoints ? '••••' : targetMode === 'points' ? formatNumber(remainingPoints) : formatCurrency(remainingSalesAmount)}
            </div>
            <div className="text-[9px] text-amber-400/80 truncate">{targetMode === 'points' ? t('pointsShort') : t('sar')}</div>
          </div>
        </div>

        {/* Target Achieved Celebration Banner */}
        {isTargetAchieved && (
          <div className="p-3 bg-gradient-to-r from-emerald-950/90 via-teal-900/50 to-[#071325] border border-emerald-500/50 rounded-2xl text-emerald-200 shadow-xl space-y-1.5 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400 shrink-0 animate-bounce" />
                <span className="font-extrabold text-white text-xs sm:text-sm">
                  {language === 'ar' ? 'تهانينا! تم تحقيق الهدف بنجاح 🏆' : 'Congratulations! Target Achieved Successfully 🏆'}
                </span>
              </div>
              <span className="bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 text-[11px] font-black font-mono px-2 py-0.5 rounded-full">
                {formatNumber(activeRawPercent.toFixed(1))}% {t('achievement')}
              </span>
            </div>
            <div className="text-[11px] text-emerald-300/90 pr-7">
              {targetMode === 'points' ? (
                <span>
                  {language === 'ar' 
                    ? <>تم تنفيذ <strong className="text-white font-mono">{formatNumber(totalPoints)}</strong> نقطة من أصل <strong className="text-sky-200 font-mono">{formatNumber(target)}</strong> نقطة مطلوبة.</>
                    : <>Completed <strong className="text-white font-mono">{formatNumber(totalPoints)}</strong> points of <strong className="text-sky-200 font-mono">{formatNumber(target)}</strong> points required.</>}
                </span>
              ) : (
                <span>
                  {language === 'ar'
                    ? <>تم تنفيذ مبيعات بـ <strong className="text-white font-mono">{formatCurrency(totalSalesAmount)}</strong> من أصل <strong className="text-sky-200 font-mono">{formatCurrency(salesTarget)}</strong> مطلوبة.</>
                    : <>Completed sales of <strong className="text-white font-mono">{formatCurrency(totalSalesAmount)}</strong> of <strong className="text-sky-200 font-mono">{formatCurrency(salesTarget)}</strong> required.</>}
                </span>
              )}
              {surplusPercent > 0 && (
                <span className="block mt-0.5 text-amber-300 font-bold">
                  {language === 'ar' 
                    ? `🔥 نسبة الفائض والزيادة عن التارجت الأصلي: +${formatNumber(surplusPercent.toFixed(1))}%`
                    : `🔥 Surplus over original target: +${formatNumber(surplusPercent.toFixed(1))}%`}
                </span>
              )}
            </div>
          </div>
        )}

        {/* Enhanced Progress Bar with Percentage Floating Badge */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[11px] font-bold text-sky-200 flex items-center gap-1">
              <span>{t('achievementRate')}:</span>
            </span>
            <span className={`px-2.5 py-0.5 rounded-full border text-xs font-black font-mono shadow-sm flex items-center gap-1 ${
              isTargetAchieved
                ? 'bg-emerald-500/25 text-emerald-300 border-emerald-400/50'
                : 'bg-sky-500/20 text-sky-300 border border-sky-400/30'
            }`}>
              {isTargetAchieved && <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />}
              {formatNumber(activeRawPercent.toFixed(1))}%
            </span>
          </div>

          {/* Progress Track */}
          <div className="relative h-3.5 w-full bg-[#071325] rounded-full overflow-hidden border border-sky-500/30 p-0.5 shadow-inner">
            <div
              className={`h-full rounded-full transition-all duration-700 relative ${
                isTargetAchieved
                  ? 'bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 shadow-lg shadow-emerald-500/40'
                  : 'bg-gradient-to-r from-sky-500 via-blue-500 to-cyan-400 shadow-lg shadow-sky-500/30'
              }`}
              style={{ width: `${activeBarPercent}%` }}
            >
              {/* Animated Glowing Tip */}
              <div className="absolute top-0 right-0 bottom-0 w-2 bg-white/60 blur-[1px] animate-pulse rounded-full" />
            </div>
          </div>

          {/* Milestone Tick Labels */}
          <div className="flex justify-between items-center text-[9px] font-mono text-sky-300/60 px-0.5">
            <span>0%</span>
            <span>25%</span>
            <span>50%</span>
            <span>75%</span>
            <span>100% 🎯 {surplusPercent > 0 && <span className="text-amber-300 font-bold">(+{formatNumber(surplusPercent.toFixed(1))}%)</span>}</span>
          </div>
        </div>

        {/* Required Daily Run Rate Indicator Banner */}
        <div className="p-2.5 bg-[#071325]/80 rounded-xl border border-sky-500/20 flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5 text-sky-200">
            <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0 fill-current" />
            <span>{t('requiredDailyRate')}:</span>
          </div>
          <div className="font-mono font-black text-amber-300 text-xs">
            {targetMode === 'points' ? (
              <span>{formatNumber(requiredDailyPoints)} {t('pointsPerDay')}</span>
            ) : (
              <span>{formatCurrency(requiredDailySales)}/{t('day')}</span>
            )}
          </div>
        </div>

        {/* Card Requirements Breakdown Box */}
        {remainingPoints > 0 ? (
          <div className="mt-3 pt-3 border-t border-sky-500/20 space-y-3">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setShowCardBreakdown(!showCardBreakdown);
              }}
              className="w-full bg-[#122748] hover:bg-[#18325c] text-sky-200 hover:text-white py-2 px-3 rounded-xl text-xs font-bold border border-sky-400/30 flex items-center justify-between transition-all active:scale-98"
            >
              <span className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-amber-400" />
                <span>{language === 'ar' ? 'مُعادل البطاقات المطلوب وحاسبة الإنجاز 🧮' : 'Required Cards Breakdown & Calculator 🧮'}</span>
              </span>
              {showCardBreakdown ? <ChevronUp className="w-4 h-4 text-sky-300" /> : <ChevronDown className="w-4 h-4 text-sky-300" />}
            </button>

            {showCardBreakdown && (
              <div className="space-y-3 pt-1 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-extrabold text-sky-100 flex items-center gap-1.5">
                    <span>
                      {language === 'ar'
                        ? `مُعادل البطاقات المطلوب لاستكمال الهدف (${formatNumber(remainingPoints)} نقطة):`
                        : `Cards required to complete target (${formatNumber(remainingPoints)} pts):`}
                    </span>
                  </div>
                </div>

                {/* Top Standalone Card Options */}
                <div className="grid grid-cols-2 gap-2">
                  {/* Infinite Requirement Card */}
                  <div className={`p-3 bg-gradient-to-b from-[#1b2b4a] to-[#071325] border border-sky-400/30 rounded-2xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-extrabold text-sky-200">💎 {getCardTypeName(infiniteType.name, language)}</span>
                      <span className="text-[9px] font-mono text-sky-300 bg-sky-500/20 px-1.5 py-0.5 rounded-md">{formatNumber(infinitePts)} {t('pointsShort')}</span>
                    </div>
                    <div className="text-xl font-black text-white font-mono my-1 flex items-baseline gap-1">
                      <span>{formatNumber(infiniteNeededAlone)}</span>
                      <span className="text-xs font-normal text-sky-300">{language === 'ar' ? 'بطاقة' : 'cards'}</span>
                    </div>
                    <div className="text-[10px] text-sky-300/80 leading-tight">
                      {language === 'ar' ? 'تغطي المتبقي بالكامل بمفردها' : 'Covers remaining target alone'}
                    </div>
                  </div>

                  {/* Platinum Requirement Card */}
                  <div className={`p-3 bg-gradient-to-b from-[#142647] to-[#071325] border border-blue-400/30 rounded-2xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[11px] font-extrabold text-blue-200">💳 {getCardTypeName(platinumType.name, language)}</span>
                      <span className="text-[9px] font-mono text-blue-300 bg-blue-500/20 px-1.5 py-0.5 rounded-md">{formatNumber(platinumPts)} {t('pointsShort')}</span>
                    </div>
                    <div className="text-xl font-black text-white font-mono my-1 flex items-baseline gap-1">
                      <span>{formatNumber(platinumNeededAlone)}</span>
                      <span className="text-xs font-normal text-blue-300">{language === 'ar' ? 'بطاقة' : 'cards'}</span>
                    </div>
                    <div className="text-[10px] text-blue-300/80 leading-tight">
                      {language === 'ar' ? 'أو تغطي المتبقي بالكامل بمفردها' : 'Or covers remaining target alone'}
                    </div>
                  </div>
                </div>

                {/* Smart Suggested Hybrid Combination Banner with Action */}
                <div className="p-3.5 bg-gradient-to-br from-amber-950/50 via-[#122038] to-[#071325] border border-amber-500/40 rounded-2xl shadow-xl space-y-3">
                  {/* Header */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30 shrink-0">
                        <Sparkles className="w-4 h-4 fill-current animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-black text-xs sm:text-sm text-amber-200">
                          {language === 'ar' ? '💡 الخطة الهجينة الأسرع إنجازاً' : '💡 Fastest Hybrid Plan'}
                        </h4>
                        <p className="text-[10px] text-sky-200/80 mt-0.5">
                          {language === 'ar' ? 'خطة ذكية تجمع بين أعلى البطاقات نقاطاً لتحقيق الهدف بأقل مجهود' : 'Smart plan combining high-point cards to hit target effortlessly'}
                        </p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold font-mono shrink-0">
                      100% {t('achievement')}
                    </span>
                  </div>

                  {/* Card Allocation Grid */}
                  <div className="grid grid-cols-2 gap-2">
                    {/* Infinite Box */}
                    <div className={`p-2.5 bg-[#09172e] rounded-xl border border-sky-400/30 flex flex-col justify-between ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center justify-between text-[10px] text-sky-300 font-bold mb-1">
                        <span className="flex items-center gap-1 truncate">
                          <span>💎</span>
                          <span>{getCardTypeName(infiniteType.name, language)}</span>
                        </span>
                        <span className="font-mono text-[9px] text-sky-200/70 shrink-0">{formatNumber(infinitePts)} {t('pointsShort')}</span>
                      </div>
                      <div className="flex items-baseline justify-between mt-1">
                        <div className="text-base sm:text-lg font-black text-white font-mono">
                          {formatNumber(suggestedInfinite)} <span className="text-[10px] font-normal text-sky-300">{language === 'ar' ? 'بطاقة' : 'cards'}</span>
                        </div>
                        <div className="text-[10px] font-bold font-mono text-amber-300">
                          +{formatNumber(suggestedInfinite * infinitePts)}
                        </div>
                      </div>
                    </div>

                    {/* Platinum Box */}
                    <div className={`p-2.5 bg-[#09172e] rounded-xl border border-blue-400/30 flex flex-col justify-between ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center justify-between text-[10px] text-blue-300 font-bold mb-1">
                        <span className="flex items-center gap-1 truncate">
                          <span>💳</span>
                          <span>{getCardTypeName(platinumType.name, language)}</span>
                        </span>
                        <span className="font-mono text-[9px] text-blue-200/70 shrink-0">{formatNumber(platinumPts)} {t('pointsShort')}</span>
                      </div>
                      <div className="flex items-baseline justify-between mt-1">
                        <div className="text-base sm:text-lg font-black text-white font-mono">
                          {formatNumber(suggestedPlatinum)} <span className="text-[10px] font-normal text-blue-300">{language === 'ar' ? 'بطاقة' : 'cards'}</span>
                        </div>
                        <div className="text-[10px] font-bold font-mono text-amber-300">
                          +{formatNumber(suggestedPlatinum * platinumPts)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Summary Total & Action */}
                  <div className="flex items-center justify-between pt-2 border-t border-amber-500/20 gap-2 flex-wrap sm:flex-nowrap">
                    <div className="text-[11px] text-sky-100 font-medium">
                      <span>{language === 'ar' ? 'المجموع المتوقع:' : 'Total Yield:'} </span>
                      <strong className="text-amber-300 font-mono font-bold">{formatNumber((suggestedInfinite * infinitePts) + (suggestedPlatinum * platinumPts))}</strong> {t('pointsShort')}
                    </div>
                    <button
                      type="button"
                      onClick={applyHybridPlanToSimulator}
                      className="w-full sm:w-auto px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>{language === 'ar' ? 'تطبيق هذه الخطة في الحاسبة' : 'Apply Plan to Simulator'}</span>
                    </button>
                  </div>
                </div>

                {/* Interactive Simulator Toggle Button */}
                <button
                  onClick={() => {
                    triggerHaptic('light');
                    setShowSimulator(!showSimulator);
                  }}
                  className="w-full bg-[#122748] hover:bg-[#18325c] text-sky-200 hover:text-white py-2 rounded-xl text-xs font-bold border border-sky-400/30 flex items-center justify-center gap-2 transition-all active:scale-98"
                >
                  <Calculator className="w-4 h-4 text-sky-400" />
                  <span>
                    {showSimulator 
                      ? (language === 'ar' ? 'إخفاء حاسبة محاكاة البطاقات' : 'Hide Card Simulator')
                      : (language === 'ar' ? 'افتح حاسبة خطة الإنجاز التفاعلية لجميع البطاقات 🧮' : 'Open Interactive Card Simulator 🧮')}
                  </span>
                  {showSimulator ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {/* Interactive Cards Simulator Drawer for All Dynamic Card Types */}
                {showSimulator && (
                  <div className="p-3.5 bg-[#071325] border border-sky-500/30 rounded-2xl space-y-3">
                    <div className="text-xs font-bold text-white flex items-center justify-between border-b border-sky-500/20 pb-2">
                      <span>{language === 'ar' ? 'محاكاة خطة الإنجاز (اختر أعداد البطاقات):' : 'Achievement Simulator (Select card quantities):'}</span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setSimCardCounts({})}
                          className="text-[10px] text-sky-300/80 hover:text-white underline"
                        >
                          {t('reset', 'تصفير')}
                        </button>
                        <span className="text-[10px] text-sky-300 font-mono bg-sky-500/20 px-2 py-0.5 rounded-full border border-sky-400/30">
                          {language === 'ar' ? 'حاسبة فورية' : 'Live Calc'}
                        </span>
                      </div>
                    </div>

                    {/* List of Dynamic Card Types */}
                    <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                      {formattedCardTypes.map((ct) => {
                        const count = simCardCounts[ct.id] || 0;
                        const subtotal = count * ct.points;
                        return (
                          <div key={ct.id} className="flex items-center justify-between bg-[#0e2242] p-2.5 rounded-xl border border-sky-500/20 gap-2">
                            <div className="min-w-0">
                              <div className={`text-xs font-bold truncate ${ct.isInfinite ? 'text-sky-300' : 'text-blue-300'}`}>
                                {getCardTypeName(ct.name, language)}
                              </div>
                              <div className="text-[10px] text-sky-200/70 font-mono mt-0.5">
                                {formatNumber(ct.points)} {t('pointsPerCard', 'نقطة / بطاقة')} {count > 0 && <span className="text-amber-300 font-bold font-mono">({formatNumber(subtotal)} {t('pointsShort')})</span>}
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => updateSimCount(ct.id, -1)}
                                className="w-7 h-7 bg-[#162f59] hover:bg-[#1d3d73] text-sky-200 rounded-lg font-bold flex items-center justify-center border border-sky-400/30 active:scale-90"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-7 text-center text-sm font-bold text-white font-mono">
                                {formatNumber(count)}
                              </span>
                              <button
                                onClick={() => updateSimCount(ct.id, 1)}
                                className={`w-7 h-7 text-slate-950 font-black rounded-lg flex items-center justify-center border active:scale-90 bg-sky-400 hover:bg-sky-300 border-sky-300`}
                              >
                                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Simulation Output Result */}
                    <div className={`p-3 rounded-xl text-xs border ${
                      simTotalPoints >= remainingPoints
                        ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                        : 'bg-sky-500/15 border-sky-500/30 text-sky-200'
                    }`}>
                      <div className="flex justify-between font-bold mb-1">
                        <span>{language === 'ar' ? 'إجمالي نقاط الخطة المحاكاة:' : 'Simulated Total Points:'}</span>
                        <span className="font-mono text-white text-sm">{formatNumber(simTotalPoints)} {t('pointsShort')}</span>
                      </div>

                      {simTotalPoints >= remainingPoints ? (
                        <div className="text-[11px] font-extrabold text-emerald-400 flex items-center gap-1.5 mt-1">
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>{language === 'ar' ? 'ممتاز! هذه الخطة تغطي المتبقي بالكامل للوصول إلى الهدف 🎉' : 'Excellent! This plan fully covers the remaining target 🎉'}</span>
                        </div>
                      ) : (
                        <div className="text-[11px] text-amber-300 font-medium mt-1">
                          {language === 'ar' ? (
                            <>يتبقى فقط <b>{formatNumber(simRemaining)} نقطة</b> للوصول للهدف (نسبة الإنجاز المتوقعة: {formatNumber(simNewProgress.toFixed(1))}%)</>
                          ) : (
                            <>Only <b>{formatNumber(simRemaining)} pts</b> remaining to target (Projected: {formatNumber(simNewProgress.toFixed(1))}%)</>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center text-emerald-400 font-extrabold text-xs">
            {language === 'ar' ? '🎉 ألف مبروك! لقد قمت بتحقيق هدف الشهر كاملاً! واصل الإنجاز الرائع!' : '🎉 Congratulations! You achieved your monthly target in full!'}
          </div>
        )}
      </div>

      {/* Quick Target Edit Modal */}
      {showEditTargetModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3 overflow-x-hidden animate-fadeIn">
          <div className="bg-[#071325] border border-sky-500/30 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 text-right max-h-[92vh] overflow-y-auto overflow-x-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-sky-500/20">
              <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-sky-400" />
                <span>{language === 'ar' ? 'تحديد وتحديث الأهداف الشهرية للمبيعات' : 'Set & Update Monthly Sales Targets'}</span>
              </h3>
              <button
                onClick={() => setShowEditTargetModal(false)}
                className="p-1 text-sky-300 hover:text-white rounded-lg bg-[#0e2242] border border-sky-400/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Target 1: Points Target */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-sky-100 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-sky-400" />
                    <span>{language === 'ar' ? 'هدف النقاط الشهري المطلوب:' : 'Required Monthly Points Target:'}</span>
                  </span>
                  <span className="text-[10px] text-sky-400/70 font-mono">({t('pointsShort')})</span>
                </label>
                <input
                  type="number"
                  step="any"
                  value={targetInputValue}
                  onChange={(e) => setTargetInputValue(e.target.value)}
                  placeholder="140000"
                  className="w-full bg-[#030914] border border-sky-500/30 rounded-xl py-2.5 px-3 text-white font-mono font-bold text-sm focus:outline-none focus:border-sky-400 dir-ltr"
                />
                
                {/* Preset Points Buttons */}
                <div className="flex items-center gap-1 overflow-x-auto pt-1 pb-0.5 no-scrollbar">
                  <span className="text-[10px] text-sky-300/70 font-bold shrink-0">{t('suggestions', 'مقترحات')}:</span>
                  {['50000', '100000', '140000', '200000', '300000', '500000'].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setTargetInputValue(val)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold shrink-0 transition-colors ${
                        targetInputValue === val
                          ? 'bg-sky-500 text-slate-950 font-black'
                          : 'bg-[#0e2242] text-sky-200 hover:bg-[#15315e] border border-sky-500/20'
                      }`}
                    >
                      {formatNumber(Number(val))}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target 2: Sales Revenue Target in SAR */}
              <div className="space-y-1.5 pt-1 border-t border-sky-500/20">
                <label className="block text-xs font-bold text-emerald-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'ar' ? 'هدف المبيعات بالمبلغ (ريال سعودي):' : 'Sales Revenue Target (SAR):'}</span>
                  </span>
                  <span className="text-[10px] text-emerald-400/70 font-mono">({t('sar')})</span>
                </label>
                <input
                  type="number"
                  step="any"
                  value={salesTargetInputValue}
                  onChange={(e) => setSalesTargetInputValue(e.target.value)}
                  placeholder="500000"
                  className="w-full bg-[#030914] border border-emerald-500/30 rounded-xl py-2.5 px-3 text-emerald-300 font-mono font-bold text-sm focus:outline-none focus:border-emerald-400 dir-ltr"
                />

                {/* Preset Sales Amount Buttons */}
                <div className="flex items-center gap-1 overflow-x-auto pt-1 pb-0.5 no-scrollbar">
                  <span className="text-[10px] text-emerald-300/70 font-bold shrink-0">{language === 'ar' ? 'مبالغ:' : 'Presets:'}</span>
                  {[
                    { label: language === 'ar' ? '250 ألف' : '250K', val: '250000' },
                    { label: language === 'ar' ? '500 ألف' : '500K', val: '500000' },
                    { label: language === 'ar' ? '1 مليون' : '1M', val: '1000000' },
                    { label: language === 'ar' ? '2 مليون' : '2M', val: '2000000' },
                  ].map((item) => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setSalesTargetInputValue(item.val)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold shrink-0 transition-colors ${
                        salesTargetInputValue === item.val
                          ? 'bg-emerald-500 text-slate-950 font-black'
                          : 'bg-[#0e2242] text-emerald-300 hover:bg-[#15315e] border border-emerald-500/20'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-3 border-t border-sky-500/20">
                <button
                  type="button"
                  onClick={() => setShowEditTargetModal(false)}
                  className="flex-1 py-2.5 bg-[#0e2242] hover:bg-[#142c52] text-sky-200 rounded-xl text-xs font-bold border border-sky-400/20"
                >
                  {t('cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleSaveTarget}
                  className="flex-1 py-2.5 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-sky-500/20 active:scale-95 transition-all"
                >
                  {t('saveTargets', 'حفظ الأهداف')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Days Remaining Countdown Card */}
      <div className="bento-card bg-gradient-to-r from-zinc-900 via-indigo-950/40 to-amber-950/30 border-amber-500/30 p-3.5 flex items-center justify-between gap-2 min-w-0 shadow-xl">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
          <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/40 shrink-0">
            <Hourglass className="w-5 h-5 animate-pulse" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-bold text-zinc-300 truncate">
              {language === 'ar' ? `المهلة المتبقية لانتهاء شهر ${monthName}` : `Time remaining for ${monthName}`}
            </div>
            <div className="text-base font-black text-white font-mono flex items-center gap-1.5 mt-0.5 flex-wrap">
              <span className="text-amber-300 text-lg">{formatNumber(daysLeftInMonth)}</span>
              <span className="text-xs font-bold text-zinc-300">
                {language === 'ar' ? (daysLeftInMonth === 1 ? 'يوم واحد' : daysLeftInMonth === 2 ? 'يومان' : 'أيام متبقية') : (daysLeftInMonth === 1 ? 'day left' : 'days left')}
              </span>
            </div>
          </div>
        </div>
        <div className="text-left font-mono text-[10px] text-zinc-400 bg-zinc-950/80 px-2.5 sm:px-3 py-1.5 rounded-xl border border-zinc-800 shrink-0">
          <div className="text-zinc-500 text-[9px] font-bold">{t('monthEnd', 'نهاية الشهر')}</div>
          <div className="text-amber-300 font-extrabold">{formatNumber(endOfMonth.getDate())} {monthName}</div>
        </div>
      </div>

      {/* Daily Tasks & Appointments Widget */}
      <DailyTasksWidget onSelectCustomer={onSelectCustomer} externalCustomers={customers} />

      {/* Stats Bento Grid (Each Status Strictly Separated) */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3 select-none min-w-0">
        <div
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('customers', 'all');
          }}
          className="col-span-2 bento-card bg-zinc-900 border-zinc-800 p-3.5 flex items-center justify-between gap-2 min-w-0 cursor-pointer active:scale-98 transition-transform"
        >
          <div className="glow-top" />
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="p-2.5 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 shrink-0">
              <Users className="w-5 h-5 text-indigo-400" />
            </div>
            <div className={`min-w-0 flex-1 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              <div className="text-xs font-bold text-zinc-200 truncate">{t('totalCustomers')}</div>
              <div className="text-[10px] text-zinc-500 truncate">{monthName}</div>
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-light text-white tracking-tight font-mono shrink-0">{formatNumber(totalCount)}</div>
        </div>

        <div
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('customers', 'تم التنفيذ');
          }}
          className="bento-card bg-zinc-900 border-cyan-500/25 p-4 text-center cursor-pointer active:scale-95 transition-transform"
        >
          <div className="glow-top" />
          <CheckCircle className="w-5 h-5 text-cyan-400 mx-auto mb-1.5" />
          <div className="text-3xl font-light text-cyan-400 tracking-tight font-mono">{formatNumber(executedCount)}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-300 mt-1">🟢 {getStatusTranslation('تم التنفيذ', language)}</div>
        </div>

        <div
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('customers', 'تم التفعيل');
          }}
          className="bento-card bg-zinc-900 border-emerald-500/30 p-4 text-center cursor-pointer active:scale-95 transition-transform"
        >
          <div className="glow-top" />
          <Zap className="w-5 h-5 text-emerald-400 mx-auto mb-1.5" />
          <div className="text-3xl font-light text-emerald-400 tracking-tight font-mono">{formatNumber(activatedCount)}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 mt-1">⚡ {getStatusTranslation('تم التفعيل', language)}</div>
        </div>

        <div
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('customers', 'عميل معلق');
          }}
          className="bento-card bg-zinc-900 border-zinc-800 p-4 text-center cursor-pointer active:scale-95 transition-transform"
        >
          <div className="glow-top" />
          <Clock className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
          <div className="text-3xl font-light text-amber-400 tracking-tight font-mono">{formatNumber(pendingCount)}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mt-1">{getStatusTranslation('عميل معلق', language)}</div>
        </div>

        <div
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('customers', 'عميل محتمل');
          }}
          className="bento-card bg-zinc-900 border-zinc-800 p-4 text-center cursor-pointer active:scale-95 transition-transform"
        >
          <div className="glow-top" />
          <Users className="w-5 h-5 text-sky-400 mx-auto mb-1.5" />
          <div className="text-3xl font-light text-sky-400 tracking-tight font-mono">{formatNumber(potentialCount)}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mt-1">{getStatusTranslation('عميل محتمل', language)}</div>
        </div>
      </div>

      {/* Total Finance Bento Card */}
      <div className="bento-card bg-zinc-900 border-zinc-800 p-4 shadow-xl flex items-center justify-between gap-2 min-w-0">
        <div className="glow-top" />
        <div className="min-w-0 flex-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 mb-1 flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">{t('totalCompletedFinance')}</span>
          </span>
          <div className="text-xl sm:text-2xl font-light text-emerald-400 tracking-tight font-mono truncate">
            {formatCurrency(financeTotal)}
          </div>
        </div>
        <button
          onClick={() => {
            triggerHaptic('light');
            setCurrentPage('reports');
          }}
          className="text-xs text-indigo-400 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 px-3 py-2 rounded-xl font-bold flex items-center gap-1 transition-colors active:scale-95 shrink-0"
        >
          <span>{t('viewAll')}</span>
          <ArrowRight className={`w-3.5 h-3.5 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Pending Reminders Alert Banner */}
      {pendingReminders.length > 0 && (
        <div className="bento-card bg-amber-500/10 border-amber-500/20 p-3.5 flex items-center justify-between gap-2 min-w-0 shadow-lg">
          <div className="glow-top" />
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-bold text-amber-300 truncate">
                {t('pendingRemindersText')} ({formatNumber(pendingReminders.length)})
              </div>
              <div className="text-[11px] text-amber-400/80 truncate">{t('pendingActivation')}</div>
            </div>
          </div>
          <button
            onClick={() => {
              triggerHaptic('medium');
              setCurrentPage('reminders');
            }}
            className="text-xs bg-amber-500 text-zinc-950 px-3 py-1.5 rounded-xl font-bold hover:bg-amber-400 transition-colors shrink-0 active:scale-95"
          >
            {t('viewAll')}
          </button>
        </div>
      )}

      {/* Recent Customers Bento Card */}
      <div className="bento-card bg-zinc-900 border-zinc-800 p-4 shadow-xl min-w-0">
        <div className="glow-top" />
        <div className="flex items-center justify-between gap-2 mb-3 min-w-0">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 truncate">{t('recentCustomers')}</h3>
          <button
            onClick={() => {
              triggerHaptic('light');
              setCurrentPage('customers', 'عميل محتمل');
            }}
            className="text-xs text-indigo-400 font-semibold hover:underline shrink-0"
          >
            {t('viewAll')} ({formatNumber(potentialCount)})
          </button>
        </div>

        <div className="divide-y divide-zinc-800/70">
          {recentCustomers.length === 0 ? (
            <div className="text-center py-6 text-zinc-500 text-xs font-medium">{t('noCustomersYet')}</div>
          ) : (
            recentCustomers.map((c) => (
              <RecentCustomerRow
                key={c.id}
                customer={c}
                formattedPhone={formatPhone(c.phone)}
                statusBadge={getStatusBadge(c.status)}
                onSelect={onSelectCustomer}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
});


