import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { db, createBackup, enrichAndAddCustomers, wipeAllDataAndPrepareFreshCleanVersion } from '../db/db';
import { useToast } from '../components/Toast';
import { User, Lock, Award, Download, Upload, Save, ShieldCheck, LogOut, ChevronLeft, ChevronRight, X, Smartphone, Contact, Globe, Database, HardDrive, BellRing, Calendar, Check, CheckCircle2, ExternalLink, Copy, Key, Sparkles, Share2, Building2, Crown, Trash2, AlertTriangle, RefreshCw, Type, FileText, Fingerprint, KeyRound } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { EncryptedBackupModal } from '../components/EncryptedBackupModal';
import { exportCustomersToVCF, parseVCFToCustomers, parseCSVWithMetadata, readImportFileText, downloadSampleCSVTemplate, type ParsedImportCustomer } from '../utils/vcard';
import { triggerHaptic } from '../utils/haptics';
import { getCurrentMonthKey, getAvailableMonthOptions } from '../utils/monthRollover';
import { verifyLicenseKey, generateLicenseKey, type LicensePlan, type LicenseDetails } from '../utils/license';
import { getPublicBaseAppUrl, generateTrialLink, buildTrialWhatsAppMessage } from '../utils/shareUtils';
import { forceAppUpdateAndRefresh } from '../utils/appUpdate';
import {
  hashPin,
  verifyPin,
  hashPassword,
  verifyPassword,
  isBiometricSupported,
  registerBiometricCredential,
  normalizePhoneForMatch,
  safeOpenExternal,
  buildSafeWhatsAppHref,
} from '../utils/security';

export const SettingsPage: React.FC = () => {
  const { currentUser, isAdmin, permissions, logout, settings, updateSettingsState, checkReminders, setCurrentPage, selectedMonthKey, hasPinLock, lockApp } = useAuth();
  const { language, setLanguage, t, dir, formatNumber } = useLanguage();
  const { showToast } = useToast();

  // Live counts & existing phones for dedupe
  const tasksCount = useLiveQuery(() => db.tasks.count(), []) ?? 0;
  const allExistingCustomers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const customersCount = allExistingCustomers.length;

  const [confirmConfig, setConfirmConfig] = useState<{ isOpen: boolean; title: string; message: string; onConfirm: () => void } | null>(null);

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showEncryptedVaultModal, setShowEncryptedVaultModal] = useState(false);
  const [encryptedVaultInitialTab, setEncryptedVaultInitialTab] = useState<'export' | 'import'>('export');
  const [showVcfModal, setShowVcfModal] = useState(false);
  const [showMobileAppModal, setShowMobileAppModal] = useState(false);
  const [showLicenseModal, setShowLicenseModal] = useState(false);
  const [showLicenseGenModal, setShowLicenseGenModal] = useState(false);
  const [showBrandingModal, setShowBrandingModal] = useState(false);
  const [showTrialLinkModal, setShowTrialLinkModal] = useState(false);

  const [mobilePlatformTab, setMobilePlatformTab] = useState<'pwa' | 'android' | 'ios'>('pwa');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes('android-app://')
    );
  });

  const [licenseKeyInput, setLicenseKeyInput] = useState('');
  const [genPlan, setGenPlan] = useState<LicensePlan>('monthly');
  const [genClientName, setGenClientName] = useState('');
  const [genClientPhone, setGenClientPhone] = useState('');
  const [generatedKey, setGeneratedKey] = useState('');

  const [trialClientName, setTrialClientName] = useState('');
  const [trialClientPhone, setTrialClientPhone] = useState('');
  const [customTrialBaseUrl, setCustomTrialBaseUrl] = useState('');
  const [showCustomUrlInput, setShowCustomUrlInput] = useState(false);
  const [useCloudSharedPreview, setUseCloudSharedPreview] = useState(false);


  const [companyNameInput, setCompanyNameInput] = useState(settings.companyName || 'Sales CRM');
  const [companySubtitleInput, setCompanySubtitleInput] = useState(settings.companySubtitle || 'المنظومة الاحترافية لمبيعات التمويل والبطاقات');
  const [supportWhatsAppInput, setSupportWhatsAppInput] = useState(settings.supportWhatsAppNumber || '0544067585');

  const licenseInfo: LicenseDetails = React.useMemo(() => {
    return verifyLicenseKey(settings.commercialLicenseKey, settings.installDate);
  }, [settings.commercialLicenseKey, settings.installDate]);

  // Monitor PWA installation state
  React.useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    const checkStandalone = () => {
      if (
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone ||
        document.referrer.includes('android-app://')
      ) {
        setIsInstalled(true);
      }
    };
    checkStandalone();

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPWA = async () => {
    triggerHaptic('medium');
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast(language === 'ar' ? 'تم بدء تثبيت التطبيق على جهازك بنجاح 📲🎉' : 'App installation started successfully 📲🎉', 'success');
        setDeferredPrompt(null);
        setIsInstalled(true);
      }
    } else {
      setShowMobileAppModal(true);
    }
  };

  const handleOpenStandalone = () => {
    triggerHaptic('success');
    safeOpenExternal(window.location.origin);
  };

  const handleCopyLink = () => {
    triggerHaptic('light');
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.origin);
      showToast(t('linkCopiedSuccess', 'تم نسخ رابط التطبيق! الصقه في متصفح Chrome أو Safari لتثبيته فوراً 📋✨'), 'success');
    }
  };

  const handleActivateLicenseKey = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    const key = licenseKeyInput.trim().toUpperCase();
    const result = verifyLicenseKey(key);
    if (!result.isValid) {
      showToast(t('invalidLicenseKey', 'كود الترخيص غير صالح أو غير متطابق. يرجى التحقق وإعادة المحاولة.'), 'error');
      return;
    }
    await updateSettingsState('commercialLicenseKey', key);
    showToast(t('licenseActivatedSuccess', 'تم تفعيل كود الترخيص بنجاح! أهلاً بك في الباقة المميزة 🎉'), 'success');
    setShowLicenseModal(false);
    setLicenseKeyInput('');
  };

  const handleGenerateKey = () => {
    triggerHaptic('success');
    const name = genClientName.trim() || 'CLIENT';
    const key = generateLicenseKey(genPlan, name);
    setGeneratedKey(key);
    showToast(t('licenseGeneratedSuccess', 'تم توليد كود الترخيص بنجاح!'), 'success');
  };

  const handleShareKeyWhatsApp = () => {
    triggerHaptic('light');
    const planText = genPlan === 'lifetime' ? 'مدى الحياة VIP' : genPlan === 'annual' ? 'سنوي (365 يوم)' : genPlan === 'quarterly' ? 'ربع سنوي (90 يوم)' : 'شهري (30 يوم)';
    const text = `مرحباً ${genClientName || 'عزيزي المشترك'}،\nكود تفعيل اشتراكك في تطبيق Sales CRM الخاص بك:\n🔑 الكود: ${generatedKey}\n📦 الباقة: ${planText}\n\nخطوات التفعيل:\n1- افتح التطبيق ➔ صفحة الإعدادات ⚙️\n2- اضغط "تجديد / تفعيل كود الترخيص"\n3- الصق الكود واضغط تفعيل.\n\n📞 للدعم والتجديد: 0544067585\nنتمنى لك كل التوفيق والمبيعات القياسية! 🚀`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast(t('copyAndShareWhatsApp', 'تم نسخ الكود ورسالة التفعيل للواتساب 📲'), 'success');
    }
    const phone = (genClientPhone || '').replace(/[^0-9]/g, '');
    if (phone) {
      safeOpenExternal(buildSafeWhatsAppHref(phone, text));
    }
  };

  const handleWipeAllDataForClient = () => {
    if (!permissions.canWipeOrRestoreDb) {
      showToast(language === 'ar' ? 'هذه العملية متاحة للمدير فقط' : 'Admin privileges required', 'error');
      return;
    }
    triggerHaptic('warning');
    setConfirmConfig({
      isOpen: true,
      title: language === 'ar' ? '⚠️ تفريغ كافة البيانات لتسليم نسخة فارغة للعميل' : 'Wipe Data to Prepare Clean Version',
      message: language === 'ar'
        ? `هل أنت متأكد من رغبتك في تفريغ ومسح جميع بيانات العملاء (${customersCount}) والمهام (${tasksCount}) وسجلات النقاط؟ سيتم تحويل التطبيق إلى نسخة جديدة ونظيفة بالكامل 100% جاهزة للتسليم للعميل مع بقاء إعداداتك وقوالبك وبطاقاتك محفوظة.`
        : `Are you sure you want to completely wipe all customer data (${customersCount}), tasks (${tasksCount}), and logs? This will prepare a 100% fresh, clean database for client delivery.`,
      onConfirm: async () => {
        try {
          await wipeAllDataAndPrepareFreshCleanVersion(currentUser?.id);
          triggerHaptic('success');
          showToast(language === 'ar' ? 'تم تفريغ كافة البيانات بنجاح! النسخة الآن فارغة ونظيفة وجاهزة للتسليم 🧹✨' : 'All data wiped successfully! Clean version ready for client ✨', 'success');
        } catch (err) {
          console.error('Wipe data error:', err);
          showToast(language === 'ar' ? 'حدث خطأ أثناء تفريغ البيانات' : 'Error wiping data', 'error');
        } finally {
          setConfirmConfig(null);
        }
      }
    });
  };

  const currentGeneratedTrialLink = generateTrialLink(trialClientName, customTrialBaseUrl, useCloudSharedPreview);


  const handleSendTrialLinkWhatsApp = () => {
    triggerHaptic('success');
    const name = trialClientName.trim() || (language === 'ar' ? 'عزيزي المشترك' : 'Valued Client');
    const trialLink = currentGeneratedTrialLink;
    const message = buildTrialWhatsAppMessage(name, trialLink);

    if (navigator.clipboard) {
      navigator.clipboard.writeText(message);
      showToast(language === 'ar' ? 'تم نسخ رسالة الدعوة الثنائية ورابط التجربة بنجاح 📋' : 'Bilingual trial invitation copied successfully 📋', 'success');
    }

    const phone = (trialClientPhone || '').replace(/[^0-9]/g, '');
    if (phone) {
      safeOpenExternal(buildSafeWhatsAppHref(phone, message));
    } else {
      showToast(language === 'ar' ? 'تم نسخ الرسالة بالعربية والإنجليزية! يمكنك لصقها وإرسالها للعميل.' : 'Bilingual message copied! Paste to send to client.', 'info');
    }
  };

  const handleContactWhatsAppRenew = () => {
    triggerHaptic('medium');
    const phone = (settings.supportWhatsAppNumber || '0544067585').replace(/[^0-9]/g, '');
    const msg = t('whatsappRenewMessage', 'مرحباً، أود تجديد اشتراك تطبيق مبيعات CRM أو الاستفسار عن باقات التجديد والتفعيل.');
    safeOpenExternal(buildSafeWhatsAppHref(phone, msg));
  };

  const handleSaveBranding = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('success');
    await updateSettingsState('companyName', companyNameInput.trim());
    await updateSettingsState('companySubtitle', companySubtitleInput.trim());
    await updateSettingsState('supportWhatsAppNumber', supportWhatsAppInput.trim());
    showToast(language === 'ar' ? 'تم حفظ هوية الشركة وبيانات التواصل بنجاح ✅' : 'Company branding saved successfully ✅', 'success');
    setShowBrandingModal(false);
  };

  const [vcfParsedCustomers, setVcfParsedCustomers] = useState<any[]>([]);
  const [vcfFileName, setVcfFileName] = useState<string>('');
  const [importGeneralNotes, setImportGeneralNotes] = useState<string>('');
  const [skipDuplicatePhonesSettings, setSkipDuplicatePhonesSettings] = useState<boolean>(true);
  const [importTargetMonth, setImportTargetMonth] = useState<string>(() => {
    return selectedMonthKey !== 'all' ? selectedMonthKey : getCurrentMonthKey();
  });
  const [isImporting, setIsImporting] = useState(false);

  // Quick App Lock (PIN + Biometric) States
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinModalMode, setPinModalMode] = useState<'enable' | 'change' | 'disable'>('enable');
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [pinModalError, setPinModalError] = useState('');
  const [savingPin, setSavingPin] = useState(false);
  const [biometricSupported, setBiometricSupported] = useState(false);
  const [togglingBiometric, setTogglingBiometric] = useState(false);

  React.useEffect(() => {
    isBiometricSupported().then(setBiometricSupported).catch(() => setBiometricSupported(false));
  }, []);

  const openPinModal = (mode: 'enable' | 'change' | 'disable') => {
    triggerHaptic('light');
    setPinModalMode(mode);
    setCurrentPinInput('');
    setNewPinInput('');
    setConfirmPinInput('');
    setPinModalError('');
    setShowPinModal(true);
  };

  const handleSavePinModal = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinModalError('');

    if ((pinModalMode === 'change' || pinModalMode === 'disable') && settings.pinLockHash) {
      const ok = await verifyPin(currentPinInput.trim(), settings.pinLockHash);
      if (!ok) {
        setPinModalError(language === 'ar' ? 'رمز PIN الحالي غير صحيح' : 'Current PIN is incorrect');
        return;
      }
    }

    if (pinModalMode === 'disable') {
      setSavingPin(true);
      try {
        await updateSettingsState('pinLockEnabled', false);
        await updateSettingsState('pinLockHash', null);
        await updateSettingsState('biometricLockEnabled', false);
        await updateSettingsState('biometricCredentialId', null);
        showToast(language === 'ar' ? 'تم إلغاء قفل التطبيق برمز PIN بنجاح' : 'App PIN lock disabled', 'info');
        setShowPinModal(false);
      } finally {
        setSavingPin(false);
      }
      return;
    }

    const cleanPin = newPinInput.replace(/\D/g, '');
    if (cleanPin.length < 4 || cleanPin.length > 6) {
      setPinModalError(language === 'ar' ? 'يجب أن يتكون رمز PIN من 4 إلى 6 أرقام' : 'PIN must be 4 to 6 digits');
      return;
    }
    if (cleanPin !== confirmPinInput.replace(/\D/g, '')) {
      setPinModalError(language === 'ar' ? 'رمزا PIN غير متطابقين' : 'PINs do not match');
      return;
    }

    setSavingPin(true);
    try {
      const hashed = await hashPin(cleanPin);
      await updateSettingsState('pinLockHash', hashed);
      await updateSettingsState('pinLockLength', cleanPin.length);
      await updateSettingsState('pinLockEnabled', true);
      sessionStorage.setItem('sales_crm_pin_unlocked', 'true');
      triggerHaptic('success');
      showToast(
        language === 'ar'
          ? (pinModalMode === 'change' ? 'تم تحديث رمز PIN بنجاح 🔐' : 'تم تفعيل قفل التطبيق السريع بنجاح 🔐')
          : (pinModalMode === 'change' ? 'PIN updated successfully 🔐' : 'App PIN lock enabled 🔐'),
        'success'
      );
      setShowPinModal(false);
    } catch (err) {
      console.error('PIN save error:', err);
      setPinModalError(language === 'ar' ? 'تعذر حفظ رمز PIN' : 'Failed to save PIN');
    } finally {
      setSavingPin(false);
    }
  };

  const handleToggleBiometric = async () => {
    if (!hasPinLock || togglingBiometric) return;
    triggerHaptic('medium');
    if (settings.biometricLockEnabled) {
      await updateSettingsState('biometricLockEnabled', false);
      await updateSettingsState('biometricCredentialId', null);
      showToast(language === 'ar' ? 'تم تعطيل فتح التطبيق بالبصمة' : 'Biometric unlock disabled', 'info');
      return;
    }

    setTogglingBiometric(true);
    try {
      const credId = await registerBiometricCredential(currentUser?.username || 'SalesCRM');
      if (!credId) {
        showToast(language === 'ar' ? 'لم يتم تفعيل البصمة أو تم إلغاء الطلب' : 'Biometric enrollment was cancelled or unsupported', 'warning');
        return;
      }
      await updateSettingsState('biometricCredentialId', credId);
      await updateSettingsState('biometricLockEnabled', true);
      triggerHaptic('success');
      showToast(language === 'ar' ? 'تم تفعيل فتح التطبيق بالبصمة / الوجه بنجاح 👆✨' : 'Biometric unlock enabled 👆✨', 'success');
    } catch (err) {
      console.error('Biometric toggle error:', err);
      showToast(language === 'ar' ? 'تعذر تفعيل البصمة على هذا الجهاز' : 'Failed to enable biometrics', 'error');
    } finally {
      setTogglingBiometric(false);
    }
  };

  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changingPass, setChangingPass] = useState(false);

  const showPoints = settings.showPoints !== false;
  const browserNotificationsEnabled = settings.browserNotificationsEnabled === true;

  const currentFontSize = settings.fontSize || (typeof window !== 'undefined' ? localStorage.getItem('sales_crm_font_size') : null) || 'normal';

  const handleSetFontSize = async (size: 'normal' | 'medium' | 'large') => {
    triggerHaptic('medium');
    localStorage.setItem('sales_crm_font_size', size);
    document.documentElement.setAttribute('data-font-size', size);
    await updateSettingsState('fontSize', size);
    const sizeNames: Record<string, { ar: string; en: string }> = {
      normal: { ar: 'عادي (الافتراضي 100%)', en: 'Normal (Default 100%)' },
      medium: { ar: 'متوسط (112%) وضوح مريح', en: 'Medium (112%) Comfortable' },
      large: { ar: 'كبير (125%) وضوح فائق', en: 'Large (125%) High Visibility' },
    };
    showToast(
      language === 'ar'
        ? `تم ضبط حجم الخط إلى: ${sizeNames[size]?.ar || size} 🔍✨`
        : `Font size updated to: ${sizeNames[size]?.en || size} 🔍✨`,
      'success'
    );
  };

  const handleToggleBrowserNotifications = async () => {
    triggerHaptic('medium');
    if (!browserNotificationsEnabled) {
      if (!('Notification' in window)) {
        showToast(t('browserNotSupported', 'المتصفح الحالي لا يدعم إشعارات المتصفح'), 'error');
        return;
      }
      let perm = Notification.permission;
      if (perm === 'default') {
        perm = await Notification.requestPermission();
      }
      if (perm === 'granted') {
        await updateSettingsState('browserNotificationsEnabled', true);
        showToast(t('browserNotificationsEnabled', 'تم تفعيل إشعارات المتصفح عند اقتراب التذكيرات بنجاح 🔔'), 'success');
        try {
          new Notification(t('browserNotificationTitle', '🔔 إشعارات المتابعة والتذكيرات مفعلة'), {
            body: t('browserNotificationBody', 'سيتم تنبيهك تلقائياً عند اقتراب أي موعد تذكير أو متابعة للعملاء.'),
            icon: '/pwa-192x192.png'
          });
        } catch (e) {
          console.error(e);
        }
        await checkReminders();
      } else {
        await updateSettingsState('browserNotificationsEnabled', false);
        showToast(t('browserPermissionDenied', 'تم رفض إذن الإشعارات من إعدادات المتصفح'), 'error');
      }
    } else {
      await updateSettingsState('browserNotificationsEnabled', false);
      showToast(t('browserNotificationsDisabled', 'تم تعطيل إشعارات المتصفح'), 'info');
    }
  };

  const pointsLogCount = useLiveQuery(() => db.pointsLog.count(), []) || 0;
  const usersCount = useLiveQuery(() => db.users.count(), []) || 0;

  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      showToast(t('passwordsDoNotMatch', 'كلمتا المرور غير متطابقتين'), 'error');
      return;
    }
    if (newPassword.length < 6) {
      showToast(t('passwordLengthError', 'كلمة المرور يجب أن تكون 6 أرقام/رموز على الأقل'), 'error');
      return;
    }

    if (!currentUser || !currentUser.id) return;

    setChangingPass(true);
    try {
      const dbUser = await db.users.get(currentUser.id);
      if (!dbUser) {
        showToast(t('errorChangingPassword', 'تعذر العثور على الحساب'), 'error');
        return;
      }

      const { valid } = await verifyPassword(oldPassword, dbUser.password);
      if (!valid) {
        showToast(t('incorrectCurrentPassword', 'كلمة المرور الحالية غير صحيحة'), 'error');
        return;
      }

      const hashedNewPassword = await hashPassword(newPassword);
      await db.users.update(currentUser.id, { password: hashedNewPassword });
      showToast(t('passwordChangedSuccess', 'تم تغيير وتشفير كلمة المرور بنجاح 🔐'));
      setShowPasswordModal(false);
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      console.error('Password change error:', err);
      showToast(t('errorChangingPassword', 'حدث خطأ أثناء التغيير'), 'error');
    } finally {
      setChangingPass(false);
    }
  };

  const handleExportData = () => {
    triggerHaptic('light');
    setEncryptedVaultInitialTab('export');
    setShowEncryptedVaultModal(true);
  };

  const handleOpenEncryptedImport = () => {
    triggerHaptic('light');
    setEncryptedVaultInitialTab('import');
    setShowEncryptedVaultModal(true);
  };

  const handleManualBackup = async () => {
    try {
      triggerHaptic('medium');
      await createBackup(language === 'ar' ? 'نسخة احتياطية يدوية' : 'Manual Backup');
      showToast(t('internalBackupCreatedSuccess', 'تم إنشاء نقطة استعادة داخلية بنجاح 💾✨'), 'success');
    } catch (err) {
      console.error('Backup error:', err);
      showToast(t('errorCreatingBackup', 'حدث خطأ أثناء إنشاء النقطة الاحتياطية'), 'error');
    }
  };

  const handleExportVCF = async () => {
    try {
      triggerHaptic('medium');
      const customers = await db.customers.toArray();
      if (customers.length === 0) {
        showToast(t('noContactsToExport', 'لا يوجد عملاء لتصديرهم كجهات اتصال'), 'warning');
        return;
      }
      exportCustomersToVCF(customers, `Samsung_S24_Contacts_${new Date().toISOString().split('T')[0]}.vcf`);
      showToast(t('vcfExportSuccess', 'تم تصدير {count} جهة اتصال بتنسيق VCF لسامسونج S24 بنجاح 📱✨').replace('{count}', formatNumber(customers.length)), 'success');
    } catch (err: any) {
      showToast(err.message || t('errorExportingVcf', 'حدث خطأ أثناء تصدير ملف VCF'), 'error');
    }
  };

  const handleImportVCF = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      triggerHaptic('medium');
      const text = await readImportFileText(file);
      const isVCard = /BEGIN:VCARD/i.test(text);
      const parsedCustomers: ParsedImportCustomer[] = isVCard
        ? parseVCFToCustomers(text).map((c) => ({
            ...c,
            hasNotesFromFile: Boolean(c.notes && String(c.notes).trim()),
          }))
        : parseCSVWithMetadata(text).customers;

      if (parsedCustomers.length === 0) {
        showToast(language === 'ar' ? 'لم يتم العثور على عملاء صالحين في الملف' : 'No valid customers found in file', 'error');
        return;
      }

      const validCustomers = parsedCustomers.filter(c => c.name || c.phone);
      const notesCount = validCustomers.filter((c) => Boolean(c.notes && String(c.notes).trim())).length;
      setVcfParsedCustomers(validCustomers);
      setVcfFileName(file.name);
      showToast(
        language === 'ar'
          ? notesCount > 0
            ? `تم اكتشاف ${formatNumber(validCustomers.length)} عميل (${formatNumber(notesCount)} بملاحظات Notes) 📄✨`
            : `تم اكتشاف ${formatNumber(validCustomers.length)} عميل في الملف 📄`
          : notesCount > 0
            ? `Detected ${formatNumber(validCustomers.length)} customers (${formatNumber(notesCount)} with Notes) 📄✨`
            : `Detected ${formatNumber(validCustomers.length)} customers in file 📄`,
        'info'
      );
    } catch (err) {
      console.error('CSV/VCF import error:', err);
      showToast(language === 'ar' ? 'خطأ أثناء قراءة الملف' : 'Error reading file', 'error');
    } finally {
      e.target.value = '';
    }
  };

  const existingPhoneSetSettings = React.useMemo(() => {
    const map = new Map<string, string>();
    for (const c of allExistingCustomers) {
      const norm = normalizePhoneForMatch(c.phone || '');
      if (norm && !map.has(norm)) map.set(norm, c.name);
    }
    return map;
  }, [allExistingCustomers]);

  const settingsVcfDupes = React.useMemo(() => {
    const seen = new Set<string>();
    return vcfParsedCustomers.map((c) => {
      const norm = normalizePhoneForMatch(c.phone || '');
      if (!norm || norm.length < 7) return { isDuplicate: false, existingName: null as string | null };
      const existingName = existingPhoneSetSettings.get(norm) || null;
      const inFile = seen.has(norm);
      seen.add(norm);
      return { isDuplicate: Boolean(existingName || inFile), existingName };
    });
  }, [vcfParsedCustomers, existingPhoneSetSettings]);

  const settingsVcfDupeCount = React.useMemo(
    () => settingsVcfDupes.filter((d) => d.isDuplicate).length,
    [settingsVcfDupes]
  );

  const handleConfirmVcfImportSettings = async () => {
    if (vcfParsedCustomers.length === 0) return;
    setIsImporting(true);
    try {
      const generalNote = importGeneralNotes.trim();
      let skipped = 0;
      const prepared = vcfParsedCustomers
        .filter((_, idx) => {
          if (skipDuplicatePhonesSettings && settingsVcfDupes[idx]?.isDuplicate) {
            skipped += 1;
            return false;
          }
          return true;
        })
        .map((c) => {
          const custNote = c.notes ? String(c.notes).trim() : '';
          const mergedNotes = [custNote, generalNote].filter(Boolean).join(' | ');
          return {
            ...c,
            notes: mergedNotes || undefined,
          };
        });

      if (prepared.length === 0) {
        showToast(
          language === 'ar'
            ? `تم تخطي جميع الصفوف (${formatNumber(skipped)}) لأنها أرقام مكررة مسجلة مسبقاً`
            : `All ${formatNumber(skipped)} rows were skipped as duplicates`,
          'warning'
        );
        return;
      }

      const addedCount = await enrichAndAddCustomers(prepared, {
        sourceTag: `${language === 'ar' ? 'استيراد من' : 'Imported from'} ${vcfFileName || 'CSV/VCF'}`,
        userId: currentUser?.id,
        targetMonth: importTargetMonth
      });
      const notesSavedCount = prepared.filter((c) => Boolean(c.notes && String(c.notes).trim())).length;
      const skipNoteAr = skipped > 0 ? ` (وتم تخطي ${formatNumber(skipped)} مكرر)` : '';
      const skipNoteEn = skipped > 0 ? ` (${formatNumber(skipped)} duplicates skipped)` : '';
      showToast(
        language === 'ar'
          ? notesSavedCount > 0
            ? `تم استيراد ${formatNumber(addedCount)} عميل وحفظ الملاحظات (${formatNumber(notesSavedCount)})${skipNoteAr} 🎉`
            : `${t('vcfImportSuccess', 'تم استيراد {count} عميل جديد بنجاح إلى شهر {month} 🎉').replace('{count}', formatNumber(addedCount)).replace('{month}', importTargetMonth)}${skipNoteAr}`
          : `Imported ${formatNumber(addedCount)} customers (${formatNumber(notesSavedCount)} with Notes)${skipNoteEn} 🎉`,
        'success'
      );
      setShowVcfModal(false);
      setVcfParsedCustomers([]);
      setVcfFileName('');
      setImportGeneralNotes('');
    } catch (err) {
      console.error('VCF import error:', err);
      showToast(t('errorSavingImportedCustomers', 'حدث خطأ أثناء حفظ العملاء المستوردين'), 'error');
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-24 pt-2 px-3 sm:px-4" dir={dir}>
      {/* Current User Card */}
      <div className="bento-card bg-zinc-900 border-zinc-800 p-4 shadow-xl flex items-center justify-between gap-2 min-w-0">
        <div className="glow-top" />
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="w-11 h-11 bg-indigo-500/10 text-indigo-400 rounded-2xl flex items-center justify-center font-bold text-lg border border-indigo-500/20 shrink-0">
            <User className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-extrabold text-sm text-white truncate">{currentUser?.username}</div>
            <div className="text-[11px] text-zinc-400 font-mono truncate">
              {isAdmin ? t('adminRole', 'مسؤول (Admin)') : t('salesRole', 'ممثل مبيعات (Sales)')}
            </div>
          </div>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold shrink-0 ${isAdmin ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'}`}>
          {isAdmin ? t('adminBadge', 'مسؤول') : t('salesBadge', 'مبيعات')}
        </span>
      </div>

      {/* Language Switcher Section */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-zinc-400 px-1 flex items-center justify-between">
          <span>{t('language', 'اللغة')}</span>
          <span className="text-[10px] text-indigo-400 font-mono uppercase">{language}</span>
        </div>

        <div className="bento-card bg-zinc-900 border-zinc-800 p-3.5 shadow-xl space-y-3">
          <div className="glow-top" />
          <div className="flex items-center gap-2.5">
            <Globe className="w-5 h-5 text-indigo-400" />
            <div>
              <div className="text-xs font-bold text-zinc-200">{t('selectLanguage', 'اختر لغة الواجهة')}</div>
              <div className="text-[10px] text-zinc-400">{t('appLanguage', 'لغة التطبيق والقوائم')}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('medium');
                setLanguage('ar');
                showToast(language === 'ar' ? 'اللغة العربية مفعلة حالياً 🇸🇦' : 'تم تفعيل اللغة العربية 🇸🇦', 'info');
              }}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer ${
                language === 'ar'
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/30'
                  : 'bg-zinc-950/80 text-zinc-400 border-zinc-800 hover:text-zinc-200'
              }`}
            >
              <span>🇸🇦</span>
              <span>{t('arabic', 'العربية')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHaptic('medium');
                setLanguage('en');
                showToast(language === 'en' ? 'English is already active 🇺🇸' : 'English language enabled 🇺🇸', 'info');
              }}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer ${
                language === 'en'
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-600/30'
                  : 'bg-zinc-950/80 text-zinc-400 border-zinc-800 hover:text-zinc-200'
              }`}
            >
              <span>🇺🇸</span>
              <span>{t('english', 'English')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Font Size & Display Scaling Section */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-zinc-400 px-1 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Type className="w-4 h-4 text-sky-400" />
            <span>{language === 'ar' ? 'حجم الخط والقراءة' : 'Font Size & Display Scale'}</span>
          </div>
          <span className="text-[10px] text-sky-400 font-mono font-bold">
            {currentFontSize === 'large' 
              ? (language === 'ar' ? 'كبير (125%)' : 'Large (125%)')
              : currentFontSize === 'medium'
              ? (language === 'ar' ? 'متوسط (112%)' : 'Medium (112%)')
              : (language === 'ar' ? 'عادي (100%)' : 'Normal (100%)')}
          </span>
        </div>

        <div className="bento-card bg-zinc-900 border-zinc-800 p-3.5 shadow-xl space-y-3">
          <div className="glow-top" />
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20 shrink-0">
              <Type className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-zinc-200">
                {language === 'ar' ? 'تكبير وتنسيق خط النصوص' : 'Text Size & Scaling'}
              </div>
              <div className="text-[10px] text-zinc-400">
                {language === 'ar' 
                  ? 'اختر الحجم الأنسب لعينيك لتسهيل قراءة أسماء العملاء والأرقام' 
                  : 'Choose the optimal text size for easy reading on your device'}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-1">
            {/* 1. Normal */}
            <button
              type="button"
              onClick={() => handleSetFontSize('normal')}
              className={`py-3 px-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 active:scale-95 cursor-pointer ${
                currentFontSize === 'normal'
                  ? 'bg-sky-600 text-white border-sky-400 shadow-lg shadow-sky-600/30 ring-2 ring-sky-400/40'
                  : 'bg-zinc-950/80 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:border-zinc-700'
              }`}
            >
              <span className="text-base font-black leading-none">أ</span>
              <span className="text-xs font-bold mt-1">{language === 'ar' ? 'عادي' : 'Normal'}</span>
              <span className={`text-[9px] ${currentFontSize === 'normal' ? 'text-sky-100' : 'text-zinc-500'}`}>100%</span>
            </button>

            {/* 2. Medium */}
            <button
              type="button"
              onClick={() => handleSetFontSize('medium')}
              className={`py-3 px-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 active:scale-95 cursor-pointer relative ${
                currentFontSize === 'medium'
                  ? 'bg-sky-600 text-white border-sky-400 shadow-lg shadow-sky-600/30 ring-2 ring-sky-400/40'
                  : 'bg-zinc-950/80 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:border-zinc-700'
              }`}
            >
              <span className="text-xl font-black leading-none">أ</span>
              <span className="text-xs font-bold mt-1">{language === 'ar' ? 'متوسط' : 'Medium'}</span>
              <span className={`text-[9px] ${currentFontSize === 'medium' ? 'text-sky-100' : 'text-zinc-500'}`}>112%</span>
            </button>

            {/* 3. Large */}
            <button
              type="button"
              onClick={() => handleSetFontSize('large')}
              className={`py-3 px-2 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center gap-1 active:scale-95 cursor-pointer ${
                currentFontSize === 'large'
                  ? 'bg-sky-600 text-white border-sky-400 shadow-lg shadow-sky-600/30 ring-2 ring-sky-400/40'
                  : 'bg-zinc-950/80 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:border-zinc-700'
              }`}
            >
              <span className="text-2xl font-black leading-none">أ</span>
              <span className="text-xs font-bold mt-1">{language === 'ar' ? 'كبير' : 'Large'}</span>
              <span className={`text-[9px] ${currentFontSize === 'large' ? 'text-sky-100' : 'text-zinc-500'}`}>125%</span>
            </button>
          </div>

          {/* Live Interactive Preview Box */}
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-zinc-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shrink-0 shadow-sm shadow-emerald-400/50" />
              <div className="text-xs text-zinc-300 truncate">
                <span className="font-bold text-white">{language === 'ar' ? 'معاينة الخط:' : 'Preview:'}</span>{' '}
                {language === 'ar' ? 'محمد العتيبي (تم التنفيذ 🟢) 0501234567' : 'Customer Name (Executed 🟢) 0501234567'}
              </div>
            </div>
            <span className="text-[10px] text-sky-400 font-bold shrink-0 font-mono bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800/40">
              {currentFontSize === 'large' ? '20px' : currentFontSize === 'medium' ? '18px' : '16px'}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Mobile App Lock (PIN + Biometric) Section */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-zinc-400 px-1 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span>{language === 'ar' ? 'قفل التطبيق السريع (PIN / البصمة)' : 'Quick App Lock (PIN / Biometric)'}</span>
          </div>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
            hasPinLock
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              : 'bg-zinc-800 text-zinc-400 border-zinc-700'
          }`}>
            {hasPinLock
              ? (language === 'ar' ? 'مفعّل 🔐' : 'Active 🔐')
              : (language === 'ar' ? 'غير مفعّل' : 'Off')}
          </span>
        </div>

        <div className="bento-card bg-zinc-900 border-zinc-800 p-3.5 shadow-xl space-y-3">
          <div className="glow-top" />
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border shrink-0 ${
              hasPinLock
                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                : 'bg-zinc-800 text-zinc-400 border-zinc-700'
            }`}>
              <Lock className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-bold text-zinc-100">
                {language === 'ar' ? 'حماية بيانات العملاء على الجوال' : 'Protect Customer Data on Mobile'}
              </div>
              <div className="text-[10px] text-zinc-400 mt-0.5">
                {language === 'ar'
                  ? 'قفل فوري برمز PIN مشفّر (4-6 أرقام) مع إمكانية الفتح ببصمة الإصبع أو الوجه'
                  : 'Instant encrypted 4-6 digit PIN lock with optional Fingerprint / FaceID unlock'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {!hasPinLock ? (
              <button
                type="button"
                onClick={() => openPinModal('enable')}
                className="flex-1 min-h-[42px] py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
              >
                <KeyRound className="w-4 h-4" />
                <span>{language === 'ar' ? 'تفعيل قفل التطبيق برمز PIN' : 'Enable PIN Lock'}</span>
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('medium');
                    lockApp();
                  }}
                  className="flex-1 min-w-[115px] min-h-[42px] py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{language === 'ar' ? 'قفل الآن' : 'Lock Now'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => openPinModal('change')}
                  className="flex-1 min-w-[100px] min-h-[42px] py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 font-bold text-xs active:scale-95 transition-all"
                >
                  {language === 'ar' ? 'تغيير PIN' : 'Change PIN'}
                </button>
                <button
                  type="button"
                  onClick={() => openPinModal('disable')}
                  className="min-h-[42px] py-2 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold text-xs active:scale-95 transition-all"
                >
                  {language === 'ar' ? 'إلغاء' : 'Disable'}
                </button>
              </>
            )}
          </div>

          {hasPinLock && biometricSupported && (
            <div className="pt-2.5 border-t border-zinc-800 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <Fingerprint className="w-4 h-4 text-indigo-400 shrink-0" />
                <div className="min-w-0">
                  <div className="text-xs font-bold text-zinc-200 truncate">
                    {language === 'ar' ? 'الفتح بالبصمة أو الوجه (Biometric)' : 'Fingerprint / FaceID Unlock'}
                  </div>
                  <div className="text-[10px] text-zinc-400 truncate">
                    {language === 'ar' ? 'فتح سريع وآمن عبر مستشعر الجهاز' : 'Fast unlock using device biometrics'}
                  </div>
                </div>
              </div>
              <button
                type="button"
                disabled={togglingBiometric}
                onClick={handleToggleBiometric}
                className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 cursor-pointer active:scale-90 disabled:opacity-50 ${
                  settings.biometricLockEnabled ? 'bg-indigo-600 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
                }`}
              >
                <div className="w-4 h-4 bg-white rounded-full shadow" />
              </button>
            </div>
          )}

          {/* Auto-Lock on Inactivity & Tab Switch */}
          <div className="pt-2.5 border-t border-zinc-800 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-xs font-bold text-zinc-200 truncate">
                  {language === 'ar' ? 'القفل التلقائي عند الخمول' : 'Auto-Lock on Inactivity'}
                </div>
                <div className="text-[10px] text-zinc-400 truncate">
                  {language === 'ar'
                    ? 'قفل التطبيق تلقائياً عند تركه دون استخدام'
                    : 'Automatically lock the app when idle'}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {[0, 2, 5, 15].map((mins) => {
                  const active = (Number(settings.inactivityLockMinutes) || 0) === mins;
                  return (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        updateSettingsState('inactivityLockMinutes', mins);
                        showToast(
                          mins === 0
                            ? (language === 'ar' ? 'تم إيقاف القفل التلقائي للخمول' : 'Inactivity lock disabled')
                            : (language === 'ar' ? `سيتم قفل التطبيق تلقائياً بعد ${mins} دقائق من الخمول 🔒` : `Auto-lock set to ${mins} minutes 🔒`),
                          'info'
                        );
                      }}
                      className={`min-h-[34px] px-2.5 rounded-lg text-[11px] font-bold tabular-nums transition-colors ${
                        active
                          ? 'bg-sky-500 text-zinc-950'
                          : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {mins === 0
                        ? (language === 'ar' ? 'إيقاف' : 'Off')
                        : `${mins}${language === 'ar' ? 'د' : 'm'}`}
                    </button>
                  );
                })}
              </div>
            </div>

            {hasPinLock && (
              <div className="flex items-center justify-between gap-2">
                <div className="text-[11px] text-zinc-400 truncate">
                  {language === 'ar' ? 'قفل فوري عند تبديل التطبيق أو إخفاء الشاشة' : 'Lock immediately when switching apps'}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('light');
                    updateSettingsState('lockOnTabHide', !settings.lockOnTabHide);
                  }}
                  className={`w-11 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 cursor-pointer active:scale-90 ${
                    settings.lockOnTabHide ? 'bg-sky-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
                  }`}
                >
                  <div className="w-4 h-4 bg-white rounded-full shadow" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* General Settings */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-zinc-400 px-1">{t('generalSettingsAndSecurity', 'الإعدادات العامة والأمان')}</div>

        <div className="bento-card bg-zinc-900 border-zinc-800 divide-y divide-zinc-800 shadow-xl overflow-hidden">
          <div className="glow-top" />
          <button
            onClick={() => setShowPasswordModal(true)}
            className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold text-zinc-200">{t('changePassword', 'تغيير كلمة المرور')}</span>
            </div>
            <ChevronIcon className="w-4 h-4 text-zinc-500" />
          </button>

          {/* Android App & Icon Install */}
          <button
            type="button"
            onClick={() => {
              triggerHaptic('medium');
              if (isInstalled) {
                showToast(language === 'ar' ? 'التطبيق مثبت كـ أيقونة WebAPK ويعمل على جهازك بنجاح 🤖✅' : 'App is already installed as a standalone Android app 🤖✅', 'success');
              }
              setMobilePlatformTab('android');
              setShowMobileAppModal(true);
              window.dispatchEvent(new CustomEvent('open-android-install-dialog'));
            }}
            className={`w-full p-3.5 flex items-center justify-between gap-2 min-w-0 hover:bg-emerald-950/20 active:bg-emerald-950/40 transition-colors cursor-pointer ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <img 
                src="/pwa-192x192.png" 
                alt="Sales CRM App Icon" 
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-xl shadow border border-emerald-400/40 object-cover bg-slate-950 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-zinc-100 flex items-center gap-1.5 flex-wrap">
                  <span className="break-words">{language === 'ar' ? 'تثبيت التطبيق على نظام أندرويد (إضافة أيقونة)' : 'Install on Android (Add Icon)'}</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold shrink-0 ${isInstalled ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-500/20 text-emerald-400'}`}>
                    {isInstalled ? (language === 'ar' ? 'مثبت بالفعل ✅' : 'Installed ✅') : 'Android 🤖'}
                  </span>
                </div>
                <div className="text-[10px] text-emerald-400/80 break-words">
                  {isInstalled
                    ? (language === 'ar' ? 'الأيقونة مثبتة ونظام WebAPK نشط على هذا الجوال' : 'Icon is installed and WebAPK is active on this device')
                    : (language === 'ar' ? 'إضافة الأيقونة الرسمية لشاشة جوالك والعمل بدون متصفح' : 'Add official app icon to Android home screen')}
                </div>
              </div>
            </div>
            <div className={`flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-lg border shadow-sm shrink-0 whitespace-nowrap ${
              isInstalled
                ? 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40'
                : 'text-emerald-300 bg-emerald-500/15 border-emerald-500/30'
            }`}>
              {isInstalled ? <Check className="w-3.5 h-3.5 shrink-0" /> : <Download className="w-3.5 h-3.5 shrink-0" />}
              <span>{isInstalled ? (language === 'ar' ? 'التفاصيل' : 'Details') : (language === 'ar' ? 'تثبيت' : 'Install')}</span>
            </div>
          </button>

          {/* Android APK Package Generator */}
          <button
            type="button"
            onClick={() => {
              triggerHaptic('medium');
              setMobilePlatformTab('android');
              setShowMobileAppModal(true);
              window.dispatchEvent(new CustomEvent('open-apk-dialog'));
            }}
            className={`w-full p-3.5 flex items-center justify-between gap-2 min-w-0 hover:bg-indigo-950/20 active:bg-indigo-950/40 transition-colors cursor-pointer ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <div className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 shrink-0">
                <Download className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-zinc-200 flex items-center gap-1.5 flex-wrap">
                  <span className="break-words">{language === 'ar' ? 'توليد حزمة APK للأندرويد' : 'Generate Android APK Package'}</span>
                  <span className="text-[10px] bg-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-bold shrink-0">APK 📦</span>
                </div>
                <div className="text-[10px] text-indigo-300/80 break-words">{language === 'ar' ? 'تصدير ملف تثبيت APK مباشر لهواتف أندرويد أو Google Play' : 'Export direct APK file for Android or Google Play'}</div>
              </div>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-indigo-300 font-bold bg-indigo-500/10 px-2 py-1 rounded-lg border border-indigo-500/20 shrink-0 whitespace-nowrap">
              <span>{language === 'ar' ? 'عرض الدليل' : 'View'}</span>
              <ChevronIcon className="w-3.5 h-3.5 shrink-0" />
            </div>
          </button>

          {/* iOS Safari Install */}
          <button
            type="button"
            onClick={() => {
              triggerHaptic('medium');
              setMobilePlatformTab('ios');
              setShowMobileAppModal(true);
              window.dispatchEvent(new CustomEvent('open-pwa-install-dialog'));
            }}
            className={`w-full p-3.5 flex items-center justify-between gap-2 min-w-0 hover:bg-zinc-800/50 active:bg-zinc-800 transition-colors cursor-pointer ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <Smartphone className="w-4 h-4 text-sky-400 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-zinc-200 break-words">{language === 'ar' ? 'تثبيت على آيفون / آيباد (iOS)' : 'Install on iPhone / iPad (iOS)'}</div>
                <div className="text-[10px] text-sky-400/80 break-words">{language === 'ar' ? 'إضافة إلى الشاشة الرئيسية عبر Safari' : 'Add to Home Screen via Safari'}</div>
              </div>
            </div>
            <ChevronIcon className="w-4 h-4 text-zinc-500 shrink-0" />
          </button>

          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Award className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-zinc-200">{t('showPointsOnScreen', 'إظهار شارة النقاط على الشاشة')}</span>
            </div>
            <button
              type="button"
              onClick={async () => {
                triggerHaptic('medium');
                const nextVal = !showPoints;
                await updateSettingsState('showPoints', nextVal);
                showToast(nextVal ? 'تم تفعيل إظهار النقاط على الشاشة 🏆' : 'تم إخفاء النقاط من الشاشة', 'info');
              }}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center cursor-pointer active:scale-90 ${
                showPoints ? 'bg-indigo-600 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
              }`}
            >
              <div className="w-4 h-4 bg-white rounded-full shadow" />
            </button>
          </div>

          <div className="p-3.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <BellRing className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="min-w-0">
                <div className="text-xs font-bold text-zinc-200 truncate">{t('enableBrowserNotifications', 'تفعيل إشعارات وتنبيهات المتصفح')}</div>
                <div className="text-[10px] text-zinc-400 line-clamp-1">{t('enableBrowserNotificationsDesc', 'تنبيهك تلقائياً عند مواعيد متابعة وتذكير العملاء')}</div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleToggleBrowserNotifications}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 cursor-pointer active:scale-90 ${
                browserNotificationsEnabled ? 'bg-amber-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
              }`}
            >
              <div className="w-4 h-4 bg-white rounded-full shadow" />
            </button>
          </div>
        </div>
      </div>

      {/* Data Management */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-zinc-400 px-1 flex items-center justify-between">
          <span>{t('samsungVcfFiles', 'جهات اتصال سامسونج (VCF)')}</span>
          <span className="text-[10px] text-indigo-400 font-mono">vCard .vcf</span>
        </div>

        <div className="bento-card bg-zinc-900 border-zinc-800 divide-y divide-zinc-800 shadow-xl overflow-hidden">
          <div className="glow-top" />
          <button
            onClick={handleExportVCF}
            className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-3">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-xs font-bold text-zinc-200">{t('exportVcf', 'تصدير جهات الاتصال (VCF)')}</div>
                <div className="text-[10px] text-zinc-400">Samsung S24 Ultra vCard</div>
              </div>
            </div>
            <ChevronIcon className="w-4 h-4 text-zinc-500" />
          </button>

          <button
            onClick={() => {
              triggerHaptic('light');
              setShowVcfModal(true);
            }}
            className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
          >
            <div className="flex items-center gap-3">
              <Contact className="w-4 h-4 text-amber-400" />
              <div>
                <div className="text-xs font-bold text-zinc-200">{t('importVcf', 'استيراد جهات اتصال سامسونج (VCF)')}</div>
                <div className="text-[10px] text-zinc-400">vCard contacts parser</div>
              </div>
            </div>
            <ChevronIcon className="w-4 h-4 text-zinc-500" />
          </button>
        </div>

        {/* Admin Exclusive: Dexie Database Status and Full JSON Backups */}
        {isAdmin && (
          <>
            <div className="text-xs font-bold text-zinc-400 px-1 pt-2 flex items-center justify-between">
              <span>{t('databaseSecurityAndBackupDexie', 'أمان والنسخ الاحتياطي لقاعدة البيانات (Dexie.js)')}</span>
              <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                <Database className="w-3 h-3 inline" /> IndexedDB Active
              </span>
            </div>

            {/* Dexie Database Status Overview Card */}
            <div className="bento-card bg-gradient-to-br from-zinc-900 via-indigo-950/20 to-zinc-950 border-indigo-500/30 p-3.5 shadow-xl space-y-3 min-w-0">
              <div className="glow-top" />
              <div className="flex items-center justify-between gap-2 min-w-0">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 shrink-0">
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-white break-words">{t('dexieStatsTitle', 'إحصائيات قاعدة البيانات المحلية (Dexie)')}</div>
                    <div className="text-[10px] text-zinc-400 break-words">{t('dexieStatsDesc', 'حفظ تلقائي محلي بدون فقدان للبيانات')}</div>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full shrink-0 whitespace-nowrap">
                  {t('secure100', 'آمنة 100%')}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 bg-zinc-950/80 p-2.5 rounded-xl border border-zinc-800 text-center">
                <div>
                  <div className="text-[10px] text-zinc-400">{t('customersTab', 'العملاء')}</div>
                  <div className="text-sm font-black text-white font-mono">{formatNumber(customersCount)}</div>
                </div>
                <div className="border-x border-zinc-800">
                  <div className="text-[10px] text-amber-400">{t('pointsLogTitle', 'سجل النقاط')}</div>
                  <div className="text-sm font-black text-amber-300 font-mono">{formatNumber(pointsLogCount)}</div>
                </div>
                <div>
                  <div className="text-[10px] text-indigo-400">{t('userManagement', 'المستخدمين')}</div>
                  <div className="text-sm font-black text-indigo-300 font-mono">{formatNumber(usersCount)}</div>
                </div>
              </div>
            </div>

            {/* Database Actions — AES-256-GCM Encrypted Export & Import Vault */}
            <div className="bento-card bg-zinc-900 border-zinc-800 divide-y divide-zinc-800 shadow-xl overflow-hidden">
              <div className="glow-top" />
              <button
                onClick={handleExportData}
                className={`w-full p-3.5 flex items-center justify-between hover:bg-emerald-500/5 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0">
                    <Lock className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-zinc-100 flex items-center gap-1.5 flex-wrap">
                      <span>
                        {language === 'ar'
                          ? 'تصدير قاعدة البيانات مشفّرة (AES-256-GCM)'
                          : 'Export Encrypted Database (AES-256-GCM)'}
                      </span>
                      <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        .enc.json
                      </span>
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-0.5">
                      {language === 'ar'
                        ? 'تصدير كامل جداول IndexedDB إلى ملف JSON مشفّر بكلمة مرور وبصمة SHA-256'
                        : 'Encrypt full IndexedDB tables into a password-protected JSON vault'}
                    </div>
                  </div>
                </div>
                <ChevronIcon className="w-4 h-4 text-zinc-500 shrink-0" />
              </button>

              <button
                onClick={handleOpenEncryptedImport}
                className={`w-full p-3.5 flex items-center justify-between hover:bg-sky-500/5 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center shrink-0">
                    <Upload className="w-4 h-4 text-sky-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-extrabold text-zinc-100">
                      {language === 'ar'
                        ? 'استيراد وفك تشفير ملف نسخة احتياطية (JSON / AES-256)'
                        : 'Import & Decrypt Backup File (JSON / AES-256)'}
                    </div>
                    <div className="text-[10px] text-zinc-400 mt-0.5">
                      {language === 'ar'
                        ? 'فك التشفير ومعاينة السجلات قبل الاستبدال الكامل أو الدمج الآمن'
                        : 'Decrypt, inspect record counts, and choose full replace or safe merge'}
                    </div>
                  </div>
                </div>
                <ChevronIcon className="w-4 h-4 text-zinc-500 shrink-0" />
              </button>

              <button
                onClick={handleManualBackup}
                className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center shrink-0">
                    <Save className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-zinc-200">{t('createInternalRestorePoint', 'إنشاء نقطة استعادة داخلية')}</div>
                    <div className="text-[10px] text-zinc-400">{t('createInternalRestorePointDesc', 'حفظ لقطة شاشة داخل الذاكرة المحلية')}</div>
                  </div>
                </div>
                <ChevronIcon className="w-4 h-4 text-zinc-500 shrink-0" />
              </button>
            </div>
          </>
        )}

        {/* Commercial Subscription & License Status Card */}
        <div className="text-xs font-bold text-zinc-400 px-1 pt-2 flex items-center justify-between">
          <span>{t('subscriptionAndLicense', 'إدارة التراخيص والاشتراك التجاري')}</span>
          <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded-full border ${
            licenseInfo.plan === 'lifetime' 
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : licenseInfo.isExpired
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
          }`}>
            {licenseInfo.plan === 'lifetime' 
              ? 'VIP LIFETIME' 
              : licenseInfo.isExpired 
                ? 'EXPIRED' 
                : `${formatNumber(licenseInfo.daysRemaining)} DAYS LEFT`}
          </span>
        </div>

        <div className="bento-card bg-gradient-to-br from-indigo-950/40 via-purple-950/30 to-[#0c081e] border-indigo-500/40 p-4 shadow-xl space-y-3 min-w-0">
          <div className="glow-top" />
          <div className="flex items-center justify-between gap-2 min-w-0">
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <div className="p-2.5 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 shrink-0">
                <Crown className="w-6 h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-xs sm:text-sm font-black text-white break-words">
                  {language === 'ar' ? licenseInfo.planNameAr : licenseInfo.planNameEn}
                </h4>
                <p className="text-[10px] text-indigo-200/80 mt-0.5 break-words">
                  {licenseInfo.plan === 'lifetime'
                    ? t('lifetimeAccess', 'ترخيص دائم مدى الحياة (VIP) 🌟')
                    : licenseInfo.isExpired
                      ? t('licenseExpired', 'انتهت صلاحية الاشتراك ⚠️')
                      : `${t('daysRemainingLabel', 'متبقي {days} يوم').replace('{days}', formatNumber(licenseInfo.daysRemaining))} • ${licenseInfo.clientName}`}
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                triggerHaptic('light');
                setShowLicenseModal(true);
              }}
              className="px-2.5 sm:px-3 py-1.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-black rounded-xl text-xs active:scale-95 transition-all shadow-md shrink-0 whitespace-nowrap"
            >
              {t('renewOrActivateLicense', 'تجديد / تفعيل')}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-indigo-500/20 text-xs">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setShowLicenseModal(true);
              }}
              className="py-2.5 px-2.5 sm:px-3 bg-zinc-950/90 hover:bg-zinc-800 text-indigo-200 font-bold rounded-xl text-xs border border-indigo-500/30 flex items-center justify-center gap-1.5 active:scale-95 transition-all min-w-0"
            >
              <Key className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span className="truncate">{t('enterLicenseKey', 'إدخال كود الترخيص')}</span>
            </button>

            <button
              type="button"
              onClick={handleContactWhatsAppRenew}
              className="py-2.5 px-2.5 sm:px-3 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 font-bold rounded-xl text-xs border border-emerald-500/30 flex items-center justify-center gap-1.5 active:scale-95 transition-all min-w-0"
            >
              <span className="shrink-0">💬</span>
              <span className="truncate">{language === 'ar' ? 'طلب تجديد عبر واتساب' : 'Renew on WhatsApp'}</span>
            </button>
          </div>
        </div>

        <div className="text-xs font-bold text-zinc-400 px-1 pt-2 flex items-center justify-between gap-2 flex-wrap">
          <span>{t('mobileAppQualification', 'تأهيل وتثبيت كتطبيق جوال (iOS & Android)')}</span>
          <span className="text-[10px] text-sky-400 font-mono flex items-center gap-1 shrink-0">
            <Smartphone className="w-3 h-3 inline" /> PWA / Native Ready
          </span>
        </div>

        {/* Mobile App Qualification & Installation Card */}
        <div className="bento-card bg-gradient-to-br from-sky-950/40 via-blue-950/30 to-[#071325] border-sky-500/40 p-4 shadow-xl space-y-3 min-w-0">
          <div className="glow-top" />
          <div className="flex items-center justify-between gap-2 min-w-0">
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <div className="p-2.5 rounded-2xl bg-sky-500/20 border border-sky-400/40 text-sky-300 shrink-0">
                <Smartphone className="w-6 h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-xs sm:text-sm font-black text-white break-words">{t('mobileAppQualification', 'تأهيل وتثبيت كتطبيق جوال')}</h4>
                <p className="text-[10px] text-sky-200/80 mt-0.5 break-words">
                  {isInstalled 
                    ? t('appAlreadyInstalled', 'التطبيق مثبت حالياً ويعمل كـ Native App 📱✨')
                    : (language === 'ar' ? 'جاهز كلياً للعمل كتطبيق أصلي على آيفون وأندرويد' : 'Fully qualified for native iOS & Android experience')}
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0 whitespace-nowrap">
              v2.0 Native
            </span>
          </div>

          <div className={`grid ${isAdmin ? 'grid-cols-2' : 'grid-cols-1'} gap-2 pt-1`}>
            <button
              type="button"
              onClick={handleInstallPWA}
              className="py-2.5 px-3 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-sky-600/30 active:scale-95 transition-all"
            >
              <span>📲</span>
              <span>{t('installOnMobileNow', 'تثبيت على الجوال')}</span>
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setShowMobileAppModal(true);
                }}
                className="py-2.5 px-3 bg-zinc-900/90 hover:bg-zinc-800 text-sky-200 font-bold rounded-xl text-xs border border-sky-500/30 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <span>⚙️</span>
                <span>{language === 'ar' ? 'دليل النشر والـ APK' : 'Packaging Guide'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={async () => {
                triggerHaptic('medium');
                showToast(language === 'ar' ? 'جاري تحديث التطبيق وتثبيت أحدث نسخة... 🔄' : 'Updating app to latest version... 🔄', 'info');
                setTimeout(() => {
                  forceAppUpdateAndRefresh();
                }, 600);
              }}
              className="col-span-full py-2.5 px-3 bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 font-extrabold rounded-xl text-xs border border-emerald-500/40 flex items-center justify-center gap-2 active:scale-95 transition-all shadow-sm"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>{language === 'ar' ? 'تحديث التطبيق وفحص أحدث إصدار ⚡' : 'Check for Updates & Refresh App ⚡'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin Panel Entry */}
      {isAdmin && (
        <div className="space-y-2">
          <div className="text-xs font-bold text-zinc-400 px-1">{t('adminDashboardEntry', 'لوحة التحكم والمسؤول التجاري')}</div>
          
          <div className="bento-card bg-zinc-900 border-zinc-800 divide-y divide-zinc-800 shadow-xl overflow-hidden">
            <div className="glow-top" />
            
            <button
              onClick={() => setCurrentPage('admin')}
              className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 text-rose-400" />
                <div>
                  <div className="text-xs font-bold text-zinc-200">{t('adminDashboardEntry', 'لوحة التحكم وإدارة المستخدمين')}</div>
                  <div className="text-[10px] text-zinc-400">إدارة الصلاحيات والمندوبين والحالات</div>
                </div>
              </div>
              <ChevronIcon className="w-4 h-4 text-zinc-500" />
            </button>

            <button
              onClick={() => {
                triggerHaptic('light');
                setShowTrialLinkModal(true);
              }}
              className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
            >
              <div className="flex items-center gap-3">
                <Share2 className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="text-xs font-bold text-emerald-300">{t('sendTrialLinkTitle', 'إرسال رابط تجربة 14 يوم للعملاء (نسخة آمنة)')}</div>
                  <div className="text-[10px] text-zinc-400">{t('sendTrialLinkDesc', 'دعوة عميل لتجربة نسخة المبيعات بدون إظهار لوحة التحكم أو صلاحيات الأدمن')}</div>
                </div>
              </div>
              <ChevronIcon className="w-4 h-4 text-zinc-500" />
            </button>

            <button
              onClick={() => {
                triggerHaptic('light');
                setShowLicenseGenModal(true);
              }}
              className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
            >
              <div className="flex items-center gap-3">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <div>
                  <div className="text-xs font-bold text-amber-300">{t('licenseGeneratorTitle', 'مولد تراخيص واشتراكات العملاء')}</div>
                  <div className="text-[10px] text-zinc-400">{t('licenseGeneratorDesc', 'توليد أكواد بيع وتجديد وإرسالها عبر واتساب')}</div>
                </div>
              </div>
              <ChevronIcon className="w-4 h-4 text-zinc-500" />
            </button>

            <button
              onClick={() => {
                triggerHaptic('light');
                setShowBrandingModal(true);
              }}
              className={`w-full p-3.5 flex items-center justify-between hover:bg-zinc-800/50 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
            >
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="text-xs font-bold text-sky-300">{t('companyBrandingTitle', 'تخصيص هوية التطبيق للشركات (White-Label)')}</div>
                  <div className="text-[10px] text-zinc-400">{t('companyBrandingDesc', 'تعديل اسم الشركة، الشعار، ورقم التواصل')}</div>
                </div>
              </div>
              <ChevronIcon className="w-4 h-4 text-zinc-500" />
            </button>

            <button
              onClick={handleWipeAllDataForClient}
              className={`w-full p-3.5 flex items-center justify-between gap-2 min-w-0 hover:bg-rose-500/10 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <Trash2 className="w-4 h-4 text-rose-400 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-rose-300 break-words">تفريغ ومسح كافة البيانات (تجهيز نسخة فارغة للعميل)</div>
                  <div className="text-[10px] text-zinc-400 break-words">
                    {customersCount === 0 ? 'النسخة فارغة ونظيفة حالياً (0 عملاء)' : `حذف (${customersCount}) عميل وسجلاتهم لتسليم نسخة جديدة`}
                  </div>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30 shrink-0 whitespace-nowrap">
                🧹 تفريغ
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Logout Action */}
      <div className="pt-2">
        <button
          onClick={logout}
          className="w-full bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-400 font-extrabold py-3.5 px-4 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-98 shadow-lg"
        >
          <LogOut className="w-4 h-4" />
          <span>{t('logout', 'تسجيل الخروج')}</span>
        </button>
      </div>

      <div className="text-center pt-4 text-[11px] text-zinc-400 font-mono">
        {t('version', 'الإصدار 2.0.0 (Samsung S24 Optimized)')}
      </div>

      {/* PIN Setup / Change / Disable Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-sm min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400" />
                <span>
                  {pinModalMode === 'enable'
                    ? (language === 'ar' ? 'تفعيل رمز PIN السريع' : 'Enable Quick PIN')
                    : pinModalMode === 'change'
                      ? (language === 'ar' ? 'تغيير رمز PIN' : 'Change PIN')
                      : (language === 'ar' ? 'إلغاء قفل PIN' : 'Disable PIN Lock')}
                </span>
              </h3>
              <button onClick={() => setShowPinModal(false)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePinModal} className="space-y-3">
              {(pinModalMode === 'change' || pinModalMode === 'disable') && (
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    {language === 'ar' ? 'رمز PIN الحالي' : 'Current PIN'}
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={6}
                    value={currentPinInput}
                    onChange={(e) => setCurrentPinInput(e.target.value.replace(/\D/g, ''))}
                    required
                    placeholder="••••"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-sm text-center tracking-[0.5em] font-mono text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              )}

              {pinModalMode !== 'disable' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">
                      {language === 'ar' ? 'رمز PIN الجديد (4 إلى 6 أرقام)' : 'New PIN (4-6 digits)'}
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={6}
                      value={newPinInput}
                      onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                      required
                      placeholder="••••"
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-sm text-center tracking-[0.5em] font-mono text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-zinc-300 mb-1">
                      {language === 'ar' ? 'تأكيد رمز PIN الجديد' : 'Confirm New PIN'}
                    </label>
                    <input
                      type="password"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={6}
                      value={confirmPinInput}
                      onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                      required
                      placeholder="••••"
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-sm text-center tracking-[0.5em] font-mono text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </>
              )}

              {pinModalError && (
                <div className="p-2 rounded-xl bg-rose-500/15 border border-rose-500/35 text-rose-300 text-xs font-bold text-center">
                  {pinModalError}
                </div>
              )}

              <button
                type="submit"
                disabled={savingPin}
                className={`w-full font-black py-3 rounded-xl text-xs transition-all shadow-lg active:scale-95 disabled:opacity-50 ${
                  pinModalMode === 'disable'
                    ? 'bg-rose-600 hover:bg-rose-500 text-white'
                    : 'bg-amber-500 hover:bg-amber-400 text-zinc-950'
                }`}
              >
                {savingPin
                  ? '...'
                  : pinModalMode === 'disable'
                    ? (language === 'ar' ? 'تأكيد إلغاء القفل' : 'Confirm Disable')
                    : (language === 'ar' ? 'حفظ وتفعيل رمز PIN' : 'Save & Enable PIN')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-sm min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-bold text-sm text-white">🔐 {t('changePassword', 'تغيير كلمة المرور')}</h3>
              <button onClick={() => setShowPasswordModal(false)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('currentPassword', 'كلمة المرور الحالية')}</label>
                <input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('newPassword', 'كلمة المرور الجديدة')}</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('confirmNewPassword', 'تأكيد كلمة المرور الجديدة')}</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                disabled={changingPass}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl text-xs transition-all shadow-lg shadow-indigo-600/20"
              >
                {changingPass ? '...' : t('save', 'حفظ')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Dedicated AES-256-GCM Encrypted IndexedDB Export & Import/Decrypt Modal */}
      <EncryptedBackupModal
        isOpen={showEncryptedVaultModal}
        initialTab={encryptedVaultInitialTab}
        canRestoreDatabase={permissions.canWipeOrRestoreDb}
        onClose={() => setShowEncryptedVaultModal(false)}
      />

      {/* Samsung Contacts (.vcf) Import Modal */}
      {showVcfModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>{language === 'ar' ? 'استيراد العملاء (CSV / VCF)' : 'Import Customers (CSV / VCF)'}</span>
              </h3>
              <button 
                onClick={() => {
                  setShowVcfModal(false);
                  setVcfParsedCustomers([]);
                  setVcfFileName('');
                  setImportGeneralNotes('');
                }} 
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {vcfParsedCustomers.length === 0 ? (
              <div className="space-y-3">
                <div className="border-2 border-dashed border-amber-500/40 hover:border-amber-400 rounded-2xl p-6 text-center cursor-pointer transition-colors relative bg-zinc-950/50">
                  <Contact className="w-10 h-10 mx-auto text-amber-400 mb-2" />
                  <div className="font-bold text-xs text-white mb-1">{language === 'ar' ? 'اضغط لاختيار ملف CSV أو VCF' : 'Click to select CSV or VCF file'}</div>
                  <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'يدعم ملفات CSV (مع عمود الملاحظات Notes / ملاحظات) وملفات VCF' : 'Supports CSV (with Notes column) and VCF files'}</div>
                  <input
                    type="file"
                    accept=".vcf,.vcard,.csv,.txt,.tsv,text/vcard,text/csv"
                    onChange={handleImportVCF}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => {
                    downloadSampleCSVTemplate();
                    showToast(language === 'ar' ? 'تم تحميل نموذج CSV متضمناً عمود الملاحظات (Notes) 📄' : 'Sample CSV with Notes column downloaded 📄', 'success');
                  }}
                  className="w-full py-2.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>{language === 'ar' ? 'تحميل نموذج CSV (رقم ملف العميل + البيانات + الملاحظات)' : 'Download Sample CSV (File #, Data & Notes)'}</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3 overflow-hidden flex flex-col flex-1">
                <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl text-xs space-y-1 shrink-0">
                  <div className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>{t('vcfFileReadSuccess', 'تم قراءة الملف بنجاح')}</span>
                  </div>
                  <div className="text-zinc-300 text-[11px]">
                    {t('vcfContactsDetectedMsg', 'تم اكتشاف {count} عميل جاهز للإدراج من {file}.').replace('{count}', formatNumber(vcfParsedCustomers.length)).replace('{file}', vcfFileName)}
                  </div>
                </div>

                {/* Target Month Selector (Any Month / Any Year) */}
                <div className="bg-indigo-950/70 border border-indigo-500/40 p-3 rounded-2xl space-y-1.5 shrink-0">
                  <label className="text-[11px] font-bold text-indigo-200 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{t('targetMonthLabel', 'الشهر المستهدف لإدراج البيانات')}:</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    <select
                      value={importTargetMonth}
                      onChange={(e) => setImportTargetMonth(e.target.value)}
                      className="w-full bg-zinc-950 border border-indigo-500/40 rounded-xl py-1.5 px-2.5 text-xs font-bold text-indigo-100 focus:outline-none focus:border-indigo-400 cursor-pointer shadow-sm"
                    >
                      {getAvailableMonthOptions(allExistingCustomers, [importTargetMonth]).filter(m => m.key !== 'all').map((m) => (
                        <option key={m.key} value={m.key}>
                          {language === 'ar' ? m.labelAr : m.labelEn} {m.isCurrent ? (language === 'ar' ? '(الشهر الحالي)' : '(Current Month)') : ''}
                        </option>
                      ))}
                    </select>
                    <input
                      type="month"
                      value={importTargetMonth !== 'all' ? importTargetMonth : ''}
                      onChange={(e) => {
                        if (e.target.value) setImportTargetMonth(e.target.value);
                      }}
                      className="w-full bg-zinc-950 border border-indigo-500/40 rounded-xl py-1 px-2 text-xs font-mono font-bold text-white focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                </div>

                {/* Optional General Note */}
                <div className="bg-zinc-950/80 border border-zinc-800 p-2.5 rounded-2xl space-y-1 shrink-0">
                  <label className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-400" />
                    <span>{language === 'ar' ? 'ملاحظة عامة لجميع العملاء (اختياري):' : 'General note for all customers (optional):'}</span>
                  </label>
                  <input
                    type="text"
                    value={importGeneralNotes}
                    onChange={(e) => setImportGeneralNotes(e.target.value)}
                    placeholder={language === 'ar' ? 'أضف ملاحظة عامة تطبق على الكل...' : 'Add a general note...'}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-1.5 px-2.5 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                {/* Duplicate Phone Warning & Skip Toggle */}
                {settingsVcfDupeCount > 0 && (
                  <div className="bg-amber-500/15 border border-amber-500/40 p-2.5 rounded-2xl text-xs space-y-1.5 shrink-0">
                    <div className="font-bold text-amber-200 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>
                        {language === 'ar'
                          ? `تم رصد ${formatNumber(settingsVcfDupeCount)} رقم جوال مكرر`
                          : `Detected ${formatNumber(settingsVcfDupeCount)} duplicate numbers`}
                      </span>
                    </div>
                    <label className="flex items-center gap-2 text-[11px] text-amber-100 font-bold cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={skipDuplicatePhonesSettings}
                        onChange={(e) => setSkipDuplicatePhonesSettings(e.target.checked)}
                        className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                      />
                      <span>
                        {language === 'ar' ? 'تخطي الأرقام المكررة تلقائياً' : 'Skip duplicate numbers automatically'}
                      </span>
                    </label>
                  </div>
                )}

                {/* Preview & Edit Individual Notes */}
                <div className="overflow-y-auto max-h-48 space-y-1.5 pr-1 flex-1">
                  {vcfParsedCustomers.map((cust, idx) => {
                    const dupeInfo = settingsVcfDupes[idx];
                    return (
                    <div key={idx} className={`p-2.5 rounded-xl space-y-1.5 text-xs border ${
                      dupeInfo?.isDuplicate && skipDuplicatePhonesSettings
                        ? 'bg-amber-950/20 border-amber-500/35 opacity-75'
                        : 'bg-zinc-950/70 border-zinc-800'
                    }`}>
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5 flex-wrap min-w-0">
                          <span className="font-bold text-zinc-100 truncate">{cust.name}</span>
                          {cust.orderNumber && !String(cust.orderNumber).startsWith('VCF-') && (
                            <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/35 text-[9px] font-mono font-bold shrink-0">
                              📁 #{cust.orderNumber}
                            </span>
                          )}
                          {cust.idNumber && (
                            <span className="px-1.5 py-0.5 rounded bg-sky-500/15 text-sky-300 border border-sky-500/30 text-[9px] font-mono font-bold shrink-0">
                              🆔 {cust.idNumber}
                            </span>
                          )}
                          {cust.salary !== undefined && cust.salary !== null && (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono font-bold shrink-0">
                              💵 {formatNumber(cust.salary)}
                            </span>
                          )}
                          {dupeInfo?.isDuplicate && (
                            <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-black shrink-0">
                              {language === 'ar' ? 'جوال مكرر' : 'Duplicate'}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-zinc-400 font-mono dir-ltr shrink-0">{cust.phone}</span>
                      </div>
                      <div className={`rounded-lg px-2 py-1.5 border space-y-1 ${cust.notes && String(cust.notes).trim() ? 'bg-emerald-950/25 border-emerald-500/35' : 'bg-zinc-900 border-zinc-800'}`}>
                        <div className="flex items-center justify-between gap-1 text-[10px]">
                          <span className="font-bold text-amber-300 flex items-center gap-1">
                            <FileText className="w-3 h-3 text-amber-400 shrink-0" />
                            <span>{language === 'ar' ? 'الملاحظات (Notes):' : 'Notes:'}</span>
                          </span>
                          {cust.notes && String(cust.notes).trim() && (
                            <span className="text-[9px] text-emerald-300 font-bold">CSV ✓</span>
                          )}
                        </div>
                        <input
                          type="text"
                          value={cust.notes || ''}
                          onChange={(e) =>
                            setVcfParsedCustomers((prev) =>
                              prev.map((item, i) => (i === idx ? { ...item, notes: e.target.value } : item))
                            )
                          }
                          placeholder={language === 'ar' ? 'ملاحظات العميل...' : 'Customer notes...'}
                          className="w-full bg-transparent text-[11px] text-zinc-100 placeholder:text-zinc-500 focus:outline-none"
                        />
                      </div>
                    </div>
                    );
                  })}
                </div>

                <div className="flex gap-2 pt-1 shrink-0">
                  <button
                    onClick={() => {
                      setVcfParsedCustomers([]);
                      setVcfFileName('');
                      setImportGeneralNotes('');
                    }}
                    className="py-2.5 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold border border-zinc-700"
                  >
                    {t('changeFile', 'تغيير الملف')}
                  </button>
                  <button
                    onClick={handleConfirmVcfImportSettings}
                    disabled={isImporting}
                    className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-extrabold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-amber-500/20 active:scale-98 disabled:opacity-50"
                  >
                    {isImporting ? t('importing', 'جاري الاستيراد...') : `${t('confirmImportBtn', 'تأكيد استيراد')} (${formatNumber(vcfParsedCustomers.length)}) ${t('customerUnit', 'عميل')}`}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Mobile App Qualification & Packaging Guide Modal */}
      {showMobileAppModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-sky-500/20 text-sky-400">
                  <Smartphone className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-white">{t('mobileAppQualification', 'تأهيل وتثبيت كتطبيق جوال')}</h3>
              </div>
              <button
                onClick={() => setShowMobileAppModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Mobile Shortcut Icon Showcase Card */}
            <div className="p-3.5 bg-gradient-to-b from-slate-900 to-zinc-950 border border-sky-500/30 rounded-2xl flex items-center gap-3.5 shadow-lg relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />
              <div className="relative shrink-0 flex flex-col items-center">
                <img
                  src="/pwa-512x512.png"
                  alt="Sales CRM Mobile Shortcut Icon"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-2xl shadow-2xl border-2 border-sky-400/40 object-cover bg-slate-950 ring-2 ring-sky-500/20"
                />
                <span className="text-[10px] font-black text-sky-200 mt-1 tracking-tight">Sales CRM</span>
              </div>
              <div className="flex-1 min-w-0 space-y-1.5">
                <div>
                  <h4 className="font-extrabold text-xs text-white flex items-center gap-1.5">
                    <span>{language === 'ar' ? 'صورة اختصار سطح الجوال' : 'Mobile Shortcut Icon'}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">HD 512x512</span>
                  </h4>
                  <p className="text-[10px] text-zinc-400 leading-snug mt-0.5">
                    {language === 'ar' 
                      ? 'هذه الأيقونة الرسمية تظهر على شاشة هاتفك عند التثبيت وتعمل في وضع ملء الشاشة بدون إنترنت.' 
                      : 'This official icon appears on your home screen when the shortcut is added.'}
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-0.5">
                  <a
                    href="/pwa-512x512.png"
                    download="sales-crm-shortcut-icon.png"
                    className="px-2.5 py-1 bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all active:scale-95"
                  >
                    <Download className="w-3 h-3" />
                    <span>{language === 'ar' ? 'تحميل PNG' : 'Download PNG'}</span>
                  </a>
                  <a
                    href="/app-icon.svg"
                    download="sales-crm-icon.svg"
                    className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all active:scale-95"
                  >
                    <Download className="w-3 h-3" />
                    <span>SVG</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Platform Selector Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-zinc-950 p-1 rounded-2xl border border-zinc-800 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setMobilePlatformTab('pwa');
                }}
                className={`py-2 rounded-xl transition-all ${
                  mobilePlatformTab === 'pwa'
                    ? 'bg-sky-500 text-slate-950 shadow-md font-black'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t('pwaInstantTab', '🌐 تثبيت فوري (PWA)')}
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setMobilePlatformTab('ios');
                }}
                className={`py-2 rounded-xl transition-all ${
                  mobilePlatformTab === 'ios'
                    ? 'bg-sky-500 text-slate-950 shadow-md font-black'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t('iosTab', '🍏 آيفون (iOS)')}
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setMobilePlatformTab('android');
                }}
                className={`py-2 rounded-xl transition-all ${
                  mobilePlatformTab === 'android'
                    ? 'bg-sky-500 text-slate-950 shadow-md font-black'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t('androidTab', '🤖 أندرويد (APK)')}
              </button>
            </div>

            {/* Tab Content */}
            {mobilePlatformTab === 'pwa' && (
              <div className="space-y-3 text-xs text-zinc-300">
                <div className="p-3 bg-sky-500/10 border border-sky-500/30 rounded-2xl space-y-2">
                  <div className="font-extrabold text-sky-200 flex items-center gap-1.5">
                    <span>⚡ {t('pwaFeaturesTitle', 'مميزات التثبيت المباشر على الهاتف:')}</span>
                  </div>
                  <ul className="space-y-1 text-[11px] text-sky-100/90 list-disc list-inside">
                    <li>{t('pwaFeature1', 'أيقونة مخصصة مستقلة تظهر على شاشة هاتفك الرئيسية.')}</li>
                    <li>{t('pwaFeature2', 'تشغيل كامل بدون أشرطة المتصفح المزعجة (Full Screen).')}</li>
                    <li>{t('pwaFeature3', 'حفظ تلقائي للبيانات والعمل بدون اتصال بالإنترنت (Offline).')}</li>
                    <li>{t('pwaFeature4', 'سرعة فائقة ودعم كامل للتذكيرات ومزامنة جهات اتصال VCF.')}</li>
                  </ul>
                </div>

                {/* Direct Action Buttons for Mobile Install */}
                <div className="space-y-2 pt-1">
                  <button
                    type="button"
                    onClick={handleOpenStandalone}
                    className="w-full py-3 bg-gradient-to-r from-sky-500 via-blue-600 to-cyan-500 hover:from-sky-400 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-sky-600/35 active:scale-95 transition-all"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>{t('openInNewTabForInstall', 'فتح الرابط في نافذة متصفح مستقلة')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 text-sky-300 font-bold rounded-2xl text-xs border border-sky-500/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{t('copyDirectAppLink', 'نسخ رابط التطبيق المباشر')}</span>
                  </button>
                </div>

                {/* Step by step banner */}
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-1.5 text-[11px]">
                  <div className="font-bold text-white">{t('howToInstallChromeTitle', 'طريقة التثبيت المباشر من Google Chrome أو متصفح سامسونج:')}</div>
                  <ol className="space-y-1 text-zinc-300 list-decimal list-inside">
                    <li>{t('howToInstallChromeStep1', 'اضغط على زر (فتح الرابط في نافذة مستقلة) أو افتح الرابط في المتصفح.')}</li>
                    <li>{t('howToInstallChromeStep2', 'اضغط على قائمة الثلاث نقاط (⋮) في أعلى زاوية المتصفح.')}</li>
                    <li>{t('howToInstallChromeStep3', 'اضغط على خيار "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".')}</li>
                  </ol>
                </div>
              </div>
            )}

            {mobilePlatformTab === 'ios' && (
              <div className="space-y-3 text-xs text-zinc-300">
                <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <span>🍏 {t('howToInstallSafariTitle', 'طريقة التثبيت على أجهزة Apple iPhone و iPad (Safari):')}</span>
                  </div>
                  <div className="space-y-2 text-[11px] text-zinc-300">
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold font-mono text-[10px] shrink-0">1</span>
                      <span>{t('howToInstallSafariStep1', 'افتح الرابط في متصفح Safari على جهازك.')}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold font-mono text-[10px] shrink-0">2</span>
                      <span>{t('howToInstallSafariStep2', 'اضغط على زر المشاركة (Share ⎋) في أسفل الشاشة.')}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold font-mono text-[10px] shrink-0">3</span>
                      <span>{t('howToInstallSafariStep3', 'مرر للأسفل واختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen ➕).')}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="w-full py-2.5 bg-zinc-950 hover:bg-zinc-800 text-sky-300 font-bold rounded-2xl text-xs border border-sky-500/30 flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{t('copyDirectAppLink', 'نسخ رابط التطبيق لفتحه في Safari')}</span>
                  </button>
                </div>

                <div className="p-3 bg-indigo-500/10 border border-indigo-500/30 rounded-2xl space-y-1">
                  <div className="font-bold text-indigo-300 text-[11px]">{language === 'ar' ? '📦 للنشر على App Store (عبر Xcode):' : '📦 For App Store via Xcode:'}</div>
                  <code className="block bg-zinc-950 p-2 rounded-xl text-[10px] text-sky-300 font-mono select-all">
                    npm run build<br />
                    npx cap add ios<br />
                    npx cap open ios
                  </code>
                </div>
              </div>
            )}

            {mobilePlatformTab === 'android' && (
              <div className="space-y-3 text-xs text-zinc-300">
                <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <span>🤖 {t('androidInstallTitle', 'خطوات التثبيت على أجهزة Android & Samsung Galaxy:')}</span>
                  </div>
                  <div className="space-y-2 text-[11px] text-zinc-300">
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold font-mono text-[10px] shrink-0">1</span>
                      <span>{t('androidStep1', 'افتح الرابط في Google Chrome أو Samsung Internet.')}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold font-mono text-[10px] shrink-0">2</span>
                      <span>{t('androidStep2', 'اضغط على زر "تثبيت التطبيق" أو من القائمة (⋮) اختر "تثبيت التطبيق" / "إضافة للشاشة الرئيسية".')}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={handleOpenStandalone}
                    className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>{t('openInNewTabForInstall', 'فتح الرابط في متصفح أندرويد المستقل')}</span>
                  </button>

                  <a
                    href={`https://www.pwabuilder.com?site=${encodeURIComponent(typeof window !== 'undefined' ? window.location.origin : '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => triggerHaptic('medium')}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{language === 'ar' ? 'توليد ملف APK جاهز للتثبيت عبر PWABuilder ⚡' : 'Generate Ready APK via PWABuilder ⚡'}</span>
                  </a>
                </div>

                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl space-y-1.5">
                  <div className="font-bold text-emerald-300 text-[11px] flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{language === 'ar' ? 'حالة التثبيت على هذا الجهاز:' : 'Device Installation Status:'}</span>
                  </div>
                  <p className="text-[10px] text-emerald-200">
                    {isInstalled
                      ? (language === 'ar' ? '✅ التطبيق مثبت ويعمل بالفعل كـ تطبيق أندرويد مستقل (WebAPK) مع أيقونة على شاشتك.' : '✅ App is already installed and running as standalone WebAPK on this device.')
                      : (language === 'ar' ? '📲 يمكنك التثبيت مباشرة من قائمة خيارات المتصفح (⋮) ثم "تثبيت التطبيق".' : '📲 You can install directly via browser menu (⋮) -> Install App.')}
                  </p>
                </div>

                <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-1">
                  <div className="font-bold text-zinc-300 text-[11px]">{language === 'ar' ? '📦 لإنشاء ملف APK / AAB لـ Google Play محلياً:' : '📦 Build APK / AAB for Google Play locally:'}</div>
                  <code className="block bg-zinc-950 p-2 rounded-xl text-[10px] text-emerald-300 font-mono select-all">
                    npm run build<br />
                    npx cap add android<br />
                    npx cap open android
                  </code>
                </div>

                {/* Verified Clean Project ZIP Download */}
                <div className="p-3 bg-zinc-950 border border-emerald-500/30 rounded-2xl flex items-center justify-between gap-2 min-w-0 shadow-inner">
                  <div className="min-w-0 flex-1">
                    <p className="font-bold text-xs text-white flex items-center gap-1.5">
                      <Download className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="break-words">{language === 'ar' ? 'سورس كود التطبيق النظيف (ZIP)' : 'Clean Project Source (ZIP)'}</span>
                    </p>
                    <p className="text-[10px] text-zinc-400 break-words">{language === 'ar' ? 'نسخة تم التحقق من سلامة فك ضغطها 100% لجميع هواتف أندرويد' : '100% verified unzippable archive for all Android phones'}</p>
                  </div>
                  <a
                    href="/sales_crm_app_clean.zip"
                    download="sales_crm_app_clean.zip"
                    onClick={() => {
                      triggerHaptic('success');
                      showToast(language === 'ar' ? 'جاري تحميل ملف ZIP النظيف... 📦' : 'Downloading clean ZIP file...', 'success');
                    }}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl flex items-center gap-1.5 shadow-md active:scale-95 transition-all shrink-0 whitespace-nowrap"
                  >
                    <span>تحميل ZIP</span>
                  </a>
                </div>
              </div>
            )}

            <div className="pt-2 border-t border-zinc-800">
              <button
                type="button"
                onClick={() => setShowMobileAppModal(false)}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold rounded-xl text-xs"
              >
                {t('close', 'إغلاق')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* License Activation & Renewal Modal */}
      {showLicenseModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400">
                  <Key className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-white">{t('renewOrActivateLicense', 'تجديد / تفعيل كود الاشتراك')}</h3>
              </div>
              <button
                onClick={() => setShowLicenseModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current Status Overview */}
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400">{t('selectPlan', 'الباقة الحالية')}:</span>
                <span className="text-xs font-bold text-indigo-300">
                  {language === 'ar' ? licenseInfo.planNameAr : licenseInfo.planNameEn}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-zinc-400">{language === 'ar' ? 'حالة الترخيص' : 'Status'}:</span>
                <span className={`text-xs font-bold ${licenseInfo.isValid ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {licenseInfo.plan === 'lifetime'
                    ? t('lifetimeAccess', 'ترخيص دائم مدى الحياة (VIP)')
                    : licenseInfo.isExpired
                      ? t('licenseExpired', 'منتهي الصلاحية')
                      : t('daysRemainingLabel', 'متبقي {days} يوم').replace('{days}', formatNumber(licenseInfo.daysRemaining))}
                </span>
              </div>
            </div>

            {/* Enter License Key Form */}
            <form onSubmit={handleActivateLicenseKey} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1.5">
                  {t('enterLicenseKey', 'إدخال كود الترخيص')}
                </label>
                <input
                  type="text"
                  value={licenseKeyInput}
                  onChange={(e) => setLicenseKeyInput(e.target.value)}
                  placeholder="CRM-M30D-XXXX-XXXX-XXXX"
                  required
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-2xl p-3 text-xs text-indigo-300 font-mono placeholder-zinc-500 focus:outline-none focus:border-indigo-500 text-center tracking-wider uppercase"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-500 via-purple-600 to-indigo-600 hover:from-indigo-400 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-95 transition-all"
              >
                <Key className="w-4 h-4" />
                <span>{t('activateKeyBtn', 'تفعيل الكود الآن 🔑')}</span>
              </button>
            </form>

            {/* Request via WhatsApp */}
            <div className="pt-2 border-t border-zinc-800 space-y-2">
              <div className="text-[11px] text-zinc-400 text-center">
                {language === 'ar' ? 'ليس لديك كود ترخيص أو ترغب في التجديد؟' : "Don't have a license key or want to renew?"}
              </div>
              <button
                type="button"
                onClick={handleContactWhatsAppRenew}
                className="w-full py-2.5 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-bold rounded-2xl text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <span>💬</span>
                <span>{t('contactSupportToRenew', 'طلب التجديد أو كود الاشتراك عبر واتساب 📲')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Commercial License Key Generator Modal */}
      {showLicenseGenModal && isAdmin && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-white">{t('licenseGeneratorTitle', 'مولد تراخيص المشتركين التجاري')}</h3>
              </div>
              <button
                onClick={() => setShowLicenseGenModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Select Plan */}
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1.5">{t('selectPlan', 'اختر باقة الاشتراك')}</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'monthly', label: t('planMonthly', 'شهري (30 يوم)'), color: 'from-blue-500 to-indigo-600' },
                    { id: 'quarterly', label: t('planQuarterly', 'ربع سنوي (90 يوم)'), color: 'from-purple-500 to-indigo-600' },
                    { id: 'annual', label: t('planAnnual', 'سنوي (365 يوم)'), color: 'from-emerald-500 to-teal-600' },
                    { id: 'lifetime', label: t('planLifetime', 'مدى الحياة VIP'), color: 'from-amber-500 to-orange-600' }
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setGenPlan(p.id as LicensePlan)}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center ${
                        genPlan === p.id
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow-md font-black'
                          : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:bg-zinc-800'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Client Info */}
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('subscriberName', 'اسم المشترك / المندوب / الشركة')}</label>
                <input
                  type="text"
                  value={genClientName}
                  onChange={(e) => setGenClientName(e.target.value)}
                  placeholder="مثال: أحمد محمد / وكالة الوساطة"
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('subscriberPhone', 'رقم هاتف المشترك (واتساب)')}</label>
                <input
                  type="tel"
                  value={genClientPhone}
                  onChange={(e) => setGenClientPhone(e.target.value)}
                  placeholder="+966500000000"
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Generate Button */}
              <button
                type="button"
                onClick={handleGenerateKey}
                className="w-full py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>{t('generateKeyBtn', 'توليد كود الترخيص 🔑')}</span>
              </button>

              {/* Output & WhatsApp Share */}
              {generatedKey && (
                <div className="p-3.5 bg-zinc-950 border border-amber-500/40 rounded-2xl space-y-2.5 mt-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-amber-300">{language === 'ar' ? 'كود الترخيص المولد:' : 'Generated Key:'}</span>
                    <span className="text-[10px] font-mono text-zinc-400">Offline Verifiable</span>
                  </div>
                  
                  <div className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-center font-mono font-black text-amber-200 text-xs select-all tracking-wider">
                    {generatedKey}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText(generatedKey);
                          showToast(t('copyDirectAppLink', 'تم نسخ كود الترخيص بنجاح! 📋'), 'success');
                        }
                      }}
                      className="py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold rounded-xl text-xs border border-zinc-700 flex items-center justify-center gap-1.5"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>{t('copy', 'نسخ الكود')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleShareKeyWhatsApp}
                      className="py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'إرسال بالواتساب' : 'Send WhatsApp'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* White-Label Company Branding Modal */}
      {showBrandingModal && isAdmin && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-x-hidden" dir={dir}>
          <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="glow-top" />
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-xl bg-sky-500/20 text-sky-400">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-white">{t('companyBrandingTitle', 'تخصيص هوية التطبيق للشركات (White-Label)')}</h3>
              </div>
              <button
                onClick={() => setShowBrandingModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveBranding} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('companyName', 'اسم الشركة / الوكالة')}</label>
                <input
                  type="text"
                  value={companyNameInput}
                  onChange={(e) => setCompanyNameInput(e.target.value)}
                  placeholder="مثال: وكالة الأفق للوساطة التمويلية"
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('companySubtitle', 'الشعار أو الوصف الفرعي')}</label>
                <input
                  type="text"
                  value={companySubtitleInput}
                  onChange={(e) => setCompanySubtitleInput(e.target.value)}
                  placeholder="مثال: المنظومة الرسمية لمبيعات التمويل والبطاقات"
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">{t('supportWhatsAppNumber', 'رقم واتساب المبيعات والدعم الفني للتجديد')}</label>
                <input
                  type="tel"
                  value={supportWhatsAppInput}
                  onChange={(e) => setSupportWhatsAppInput(e.target.value)}
                  placeholder="+966500000000"
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="pt-2 border-t border-zinc-800 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowBrandingModal(false)}
                  className="w-1/2 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold rounded-xl text-xs"
                >
                  {t('cancel', 'إلغاء')}
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black rounded-xl text-xs shadow-md"
                >
                  {t('save', 'حفظ التغييرات')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safe Client 14-Day Trial Invitation Modal */}
      {showTrialLinkModal && isAdmin && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-3 sm:p-4 overflow-y-auto overflow-x-hidden animate-fadeIn touch-pan-y" 
          dir={dir}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowTrialLinkModal(false);
          }}
        >
          <div className="relative w-full max-w-lg min-w-0 bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col max-h-[88vh] sm:max-h-[86vh] overflow-hidden my-auto">
            {/* Modal Sticky Header */}
            <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/95 backdrop-blur-md sticky top-0 z-20 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">{t('sendTrialLinkTitle', 'إرسال رابط تجربة 14 يوم للعميل')}</h3>
                  <p className="text-[10px] text-zinc-400">{t('sendTrialLinkSubtitle', 'دعوة آمنة لمندوبي ومسؤولي المبيعات')}</p>
                </div>
              </div>
              <button
                onClick={() => setShowTrialLinkModal(false)}
                className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-800/80 hover:bg-zinc-700 transition-all"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Modal Body (Touch Smooth Scroll) */}
            <div className="flex-1 overflow-y-auto overscroll-contain p-4 sm:p-5 space-y-3.5 text-start">
              {/* Security Guarantee Notice */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-start gap-2.5 text-xs text-emerald-300">
                <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold">حماية تامة للوحة التحكم وصلاحيات الأدمن 🔒</p>
                  <p className="text-[11px] text-emerald-300/80">
                    عند فتح العميل للرابط، يتم دخوله مباشرة في **نسخة المبيعات** مع حجب كامل للوحة المسؤول، وإدارة المستخدمين، ومولد الأكواد، ولا يمكنه الوصول إليها بدون كلمة مرورك الخاصة.
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">{t('clientName', 'اسم العميل / المشترك')}</label>
                  <input
                    type="text"
                    value={trialClientName}
                    onChange={(e) => setTrialClientName(e.target.value)}
                    placeholder="مثال: أحمد محمد (مندوب مبيعات)"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">{t('clientPhone', 'رقم واتساب العميل')}</label>
                  <input
                    type="tel"
                    value={trialClientPhone}
                    onChange={(e) => setTrialClientPhone(e.target.value)}
                    placeholder="05xxxxxxxx أو +9665xxxxxxxx"
                    className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Data status and Clean wipe helper */}
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-400 font-medium">حالة البيانات الحالية بالجهاز:</span>
                    <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded-full ${customersCount === 0 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'}`}>
                      {customersCount === 0 ? 'نسخة فارغة ونظيفة (0 عملاء)' : `${customersCount} عميل مسجل`}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-zinc-900">
                    <p className="text-[11px] text-zinc-400 leading-tight">
                      {customersCount === 0 
                        ? 'النسخة فارغة تماماً ومجهزة لإرسالها للعميل للبدء فوراً.' 
                        : 'يمكنك تفريغ جميع العملاء والمهام الحالية لتسليم نسخة فارغة ونظيفة.'}
                    </p>
                    {customersCount > 0 && (
                      <button
                        type="button"
                        onClick={handleWipeAllDataForClient}
                        className="px-2.5 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold rounded-lg text-[10px] shrink-0 flex items-center gap-1 active:scale-95 transition-all"
                      >
                        <Trash2 className="w-3 h-3 text-rose-400" />
                        <span>تفريغ البيانات الآن 🧹</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Clarification about AI Studio Sandbox vs Public URLs */}
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-[11px] text-amber-300 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <span>⚠️ هام لنشر الرابط للعملاء دون طلب تسجيل دخول:</span>
                  </p>
                  <p className="text-amber-200/90 leading-relaxed">
                    روابط بيئة التطوير (ais-dev-) تكون محمية بحسابك. لفتح الرابط لدى أي شخص خارجياً:
                  </p>
                  <ul className="list-disc list-inside text-[10px] text-amber-300/80 space-y-0.5">
                    <li>اضغط على زر <b>Share</b> أعلى منصة AI Studio لمشاركة الرابط العام.</li>
                    <li>أو اضغط على <b>Deploy to Cloud Run</b> لنشر التطبيق كرابط دائم ومستقل.</li>
                    <li>أو ضع رابط موقعك/دومينك المنشور في خيار <b>استخدام دومين مخصص</b> بالأسفل.</li>
                  </ul>
                </div>

                {/* Live Link Preview & Direct Testing Box */}
                <div className="p-3.5 bg-zinc-950 border border-emerald-500/40 rounded-2xl space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-emerald-400" />
                      <span>رابط التجربة المباشر (جاهز للاختبار والإرسال):</span>
                    </span>
                  </div>

                  {/* Source Selection Tabs */}
                  <div className="grid grid-cols-2 gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-xl text-[11px]">
                    <button
                      type="button"
                      onClick={() => {
                        setUseCloudSharedPreview(false);
                        setShowCustomUrlInput(false);
                      }}
                      className={`py-1.5 px-2 rounded-lg font-bold transition-all text-center ${!useCloudSharedPreview && !showCustomUrlInput ? 'bg-emerald-500 text-slate-950 shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
                    >
                      ⚡ الرابط النشط المباشر
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setUseCloudSharedPreview(true);
                        setShowCustomUrlInput(false);
                      }}
                      className={`py-1.5 px-2 rounded-lg font-bold transition-all text-center ${useCloudSharedPreview && !showCustomUrlInput ? 'bg-indigo-600 text-white shadow' : 'text-zinc-400 hover:text-zinc-200'}`}
                    >
                      ☁️ رابط المشاركة السحابي
                    </button>
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => setShowCustomUrlInput(!showCustomUrlInput)}
                      className="text-[10px] text-zinc-400 hover:text-emerald-300 underline"
                    >
                      {showCustomUrlInput ? 'إخفاء تخصيص الدومين' : '⚙️ استخدام دومين خارجي مخصص'}
                    </button>
                  </div>

                  {showCustomUrlInput && (
                    <div className="pt-1">
                      <label className="block text-[10px] text-zinc-400 mb-0.5">رابط النشر أو الدومين المخصص الخاص بك (Custom Base URL):</label>
                      <input
                        type="url"
                        value={customTrialBaseUrl}
                        onChange={(e) => setCustomTrialBaseUrl(e.target.value)}
                        placeholder="https://your-crm-domain.com"
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 text-xs text-white font-mono placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  )}

                  {useCloudSharedPreview && (
                    <div className="p-2 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-[10px] text-indigo-300">
                      💡 تنبيه: رابط المشاركة السحابي (ais-pre-) يتطلب الضغط على زر <b>Share</b> في أعلى المنصة لتفعيله خارجياً، أو يمكنك استخدام <b>الرابط النشط المباشر ⚡</b> للاختبار الفوري دون 404.
                    </div>
                  )}

                  <div className="p-2.5 bg-zinc-900/90 border border-zinc-800 rounded-xl text-[11px] font-mono text-zinc-200 break-all select-all leading-relaxed">
                    {currentGeneratedTrialLink}
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        if (navigator.clipboard) {
                          navigator.clipboard.writeText(currentGeneratedTrialLink);
                          showToast(language === 'ar' ? 'تم نسخ الرابط المباشر 📋' : 'Direct trial link copied 📋', 'success');
                        }
                      }}
                      className="py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 font-bold rounded-xl text-xs border border-zinc-700 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      <Copy className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{language === 'ar' ? 'نسخ الرابط فقط' : 'Copy Link Only'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('medium');
                        safeOpenExternal(currentGeneratedTrialLink);
                      }}
                      className="py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs border border-emerald-400 shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'اختبار وفتح الرابط 🌐' : 'Test & Open Link'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Sticky Action Footer (Always visible & easily accessible) */}
            <div className="p-4 bg-zinc-900/95 backdrop-blur-md border-t border-zinc-800 sticky bottom-0 z-20 shrink-0 space-y-2">
              <button
                type="button"
                onClick={handleSendTrialLinkWhatsApp}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 transition-all"
              >
                <Share2 className="w-4 h-4" />
                <span>{language === 'ar' ? 'إرسال دعوة تجربة 14 يوم (نسخة نظيفة) عبر واتساب 📲' : 'Send 14-Day Clean Trial Invite on WhatsApp 📲'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmConfig && (
        <ConfirmModal
          isOpen={confirmConfig.isOpen}
          title={confirmConfig.title}
          message={confirmConfig.message}
          confirmText="نعم، تفريغ كافة البيانات الآن"
          cancelText="إلغاء وتراجع"
          isDanger={true}
          onConfirm={confirmConfig.onConfirm}
          onCancel={() => setConfirmConfig(null)}
        />
      )}
    </div>
  );
};
