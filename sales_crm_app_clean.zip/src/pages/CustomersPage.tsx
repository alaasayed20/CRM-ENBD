import React, { useState, useEffect, useMemo, useCallback, useDeferredValue, Suspense } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logOperation, deleteCustomerCascading, bulkDeleteCustomersCascading, bulkUpdateCustomerStatus, enrichAndAddCustomers, calculateCardPoints, calculatePoints } from '../db/db';
import { useLanguage } from '../context/LanguageContext';
import { getStatusTranslation } from '../utils/translations';
import { useAuth } from '../context/AuthContext';
import { Search, Phone, MessageCircle, CheckCircle, CreditCard, DollarSign, Filter, ChevronLeft, ChevronRight, X, Smartphone, Download, Camera, Contact, Upload, UserCheck, CheckSquare, Square, Check, LayoutList, Table, GripVertical, Eye, EyeOff, ArrowUp, ArrowDown, ArrowUpDown, RotateCcw, Settings2, SlidersHorizontal, Trash2, Edit3, Calendar, FileText, FileSpreadsheet, Loader2, Printer, AlertTriangle, ListChecks } from 'lucide-react';
import type { CustomerStatus, ProductType, Customer, CardType, SalaryTier, StatusConfig } from '../types';
import { triggerHaptic } from '../utils/haptics';
import { exportCustomersToVCF, parseVCFToCustomers, parseCSVWithMetadata, readImportFileText, downloadSampleCSVTemplate, type ParsedImportCustomer } from '../utils/vcard';
import { useToast } from '../components/Toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { PrintableReportSheet } from '../components/PrintableReportSheet';
import { getCustomerMonthKey, getAvailableMonthOptions, formatMonthKeyToArabic, formatMonthKeyToEnglish } from '../utils/monthRollover';
import { exportReportToPDF, type PdfAccent, type PdfCell } from '../utils/pdfExport';
import { lazyWithRetry } from '../utils/lazyWithRetry';
import {
  normalizePhoneForMatch,
  sanitizeSpreadsheetValue,
  buildSafeTelHref,
  buildSafeWhatsAppHref,
} from '../utils/security';
import { saveWorkbookNativeOrWeb } from '../utils/nativeMobile';

const CameraScanModal = lazyWithRetry(() =>
  import('../components/CameraScanModal').then((m) => ({ default: m.CameraScanModal }))
);

const EMPTY_CUSTOMERS: Customer[] = [];
const EMPTY_CARD_TYPES: CardType[] = [];
const EMPTY_SALARY_TIERS: SalaryTier[] = [];
const EMPTY_STATUSES: StatusConfig[] = [];
const PAGE_BATCH_SIZE = 40;

interface ColumnConfig {
  id: string;
  label: string;
  visible: boolean;
  minWidth?: string;
}

const DEFAULT_COLUMNS: ColumnConfig[] = [
  { id: 'name', label: 'اسم العميل', visible: true, minWidth: 'min-w-[130px]' },
  { id: 'phone', label: 'رقم الجوال', visible: true, minWidth: 'min-w-[110px]' },
  { id: 'idNumber', label: 'رقم الهوية', visible: true, minWidth: 'min-w-[110px]' },
  { id: 'orderNumber', label: 'رقم الطلب', visible: true, minWidth: 'min-w-[90px]' },
  { id: 'status', label: 'الحالة', visible: true, minWidth: 'min-w-[100px]' },
  { id: 'productType', label: 'نوع المنتج', visible: true, minWidth: 'min-w-[110px]' },
  { id: 'amount', label: 'المبلغ/التفاصيل', visible: true, minWidth: 'min-w-[120px]' },
  { id: 'points', label: 'النقاط', visible: true, minWidth: 'min-w-[80px]' },
  { id: 'notes', label: 'الملاحظات', visible: true, minWidth: 'min-w-[160px]' },
  { id: 'actions', label: 'الإجراءات', visible: true, minWidth: 'min-w-[120px]' },
];

interface CustomersPageProps {
  onSelectCustomer: (customerId: number, initialEdit?: boolean) => void;
  onActivateCustomer: (customerId: number) => void;
}

const renderCustomerStatusBadge = (status: CustomerStatus, language: 'ar' | 'en') => {
  const label = getStatusTranslation(status, language);
  switch ((status || '').trim()) {
    case 'تم التفعيل':
      return <span className="px-2.5 py-0.5 text-[11px] font-black rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">⚡ {label}</span>;
    case 'تم التنفيذ':
      return <span className="px-2.5 py-0.5 text-[11px] font-bold rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">🟢 {label}</span>;
    case 'مكتمل':
      return <span className="px-2.5 py-0.5 text-[11px] font-bold rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">✓ {label}</span>;
    case 'بانتظار التفعيل':
      return <span className="px-2.5 py-0.5 text-[11px] font-black rounded-full bg-gradient-to-r from-amber-500/30 to-yellow-500/30 text-amber-300 border border-amber-500/50 animate-pulse">⏳ {label}</span>;
    case 'عميل معلق':
    case 'مكتمَل الأوراق':
    case 'مكتمل الأوراق':
    case 'مؤجل':
      return <span className="px-2.5 py-0.5 text-[11px] font-bold rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">🟠 {label}</span>;
    case 'عميل محتمل':
    case 'متابعة':
    default:
      return <span className="px-2.5 py-0.5 text-[11px] font-bold rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30">🔵 {label}</span>;
  }
};

interface CustomerListItemSharedProps {
  customer: Customer;
  isSelected: boolean;
  isSelectionMode: boolean;
  points: number;
  cardTypeName: string;
  canDelete: boolean;
  dir: 'rtl' | 'ltr';
  language: 'ar' | 'en';
  t: (key: string, fallback?: string) => string;
  formatNumber: (n: number | string) => string;
  formatCurrency: (n: number | string) => string;
  formatPhone: (p: string) => string;
  onToggleSelect: (id: number) => void;
  onSelect: (id: number, initialEdit?: boolean) => void;
  onActivate: (id: number) => void;
  onDelete: (e: React.MouseEvent, c: Customer) => void;
}

interface CustomerTableRowProps extends CustomerListItemSharedProps {
  visibleColumns: ColumnConfig[];
}

const CustomerTableRow = React.memo<CustomerTableRowProps>(({
  customer: c,
  isSelected,
  isSelectionMode,
  visibleColumns,
  points,
  cardTypeName,
  canDelete,
  dir,
  language,
  t,
  formatNumber,
  formatCurrency,
  formatPhone,
  onToggleSelect,
  onSelect,
  onActivate,
  onDelete,
}) => {
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const renderCell = (colId: string) => {
    switch (colId) {
      case 'name':
        return <div className="font-bold text-white text-xs">{c.name}</div>;
      case 'phone':
        return <div className="font-mono text-zinc-300 text-xs dir-ltr">{formatPhone(c.phone)}</div>;
      case 'idNumber':
        return c.idNumber ? (
          <span className="font-mono text-indigo-300 font-bold text-[11px] dir-ltr inline-block">
            {c.idNumber}
          </span>
        ) : (
          <span className="text-zinc-600 text-[10px]">-</span>
        );
      case 'orderNumber':
        return c.orderNumber ? (
          <span className="font-mono text-indigo-400 font-bold text-[11px]">
            #{c.orderNumber}
          </span>
        ) : (
          <span className="text-zinc-600 text-[10px]">-</span>
        );
      case 'status':
        return renderCustomerStatusBadge(c.status, language);
      case 'productType':
        return c.productType === 'visa' ? (
          <span className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-[10px] font-medium inline-flex items-center gap-1">
            <CreditCard className="w-3 h-3" />
            <span>{cardTypeName}</span>
          </span>
        ) : (
          <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[10px] font-medium inline-flex items-center gap-1">
            <DollarSign className="w-3 h-3" />
            <span>{t('financeProduct')}</span>
          </span>
        );
      case 'amount':
        return c.productType === 'visa' ? (
          <span className="text-zinc-500 text-[10px]">-</span>
        ) : (
          <div className="text-[11px] font-mono text-emerald-400 font-bold">
            {formatCurrency(Number(c.amount || 0))}
          </div>
        );
      case 'points':
        return points > 0 ? (
          <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold font-mono">
            🏆 {formatNumber(points)}
          </span>
        ) : (
          <span className="text-zinc-600 text-[10px]">0</span>
        );
      case 'notes':
        return c.notes ? (
          <div className="max-w-[200px] text-[11px] text-amber-200/90 line-clamp-2 flex items-start gap-1" title={c.notes}>
            <FileText className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
            <span className="truncate">{c.notes}</span>
          </div>
        ) : (
          <span className="text-zinc-600 text-[10px]">-</span>
        );
      case 'actions':
        return (
          <div className="flex items-center gap-1.5 justify-end" onClick={(e) => e.stopPropagation()}>
            <a
              href={buildSafeTelHref(c.phone)}
              onClick={() => triggerHaptic('light')}
              className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-all"
              title={t('call', 'اتصال')}
            >
              <Phone className="w-3.5 h-3.5" />
            </a>
            <a
              href={buildSafeWhatsAppHref(c.phone)}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => triggerHaptic('light')}
              className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 hover:bg-indigo-500/20 transition-all"
              title={t('whatsapp', 'واتساب')}
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </a>
            {c.productType === 'visa' && (c.status === 'تم التنفيذ' || c.status === 'بانتظار التفعيل') && (
              <button
                onClick={() => {
                  triggerHaptic('medium');
                  if (c.id) onActivate(c.id);
                }}
                className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 font-bold text-[10px] animate-pulse"
                title={t('activateCard', 'تفعيل البطاقة')}
              >
                <CheckCircle className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              onClick={() => {
                triggerHaptic('medium');
                if (c.id) onSelect(c.id, false);
              }}
              className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-700/60"
              title={t('details', 'تفاصيل')}
            >
              <ChevronIcon className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                triggerHaptic('medium');
                if (c.id) onSelect(c.id, true);
              }}
              className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 hover:bg-indigo-500/20 transition-all"
              title={t('edit', 'تعديل العميل')}
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
            {canDelete && (
              <button
                onClick={(e) => onDelete(e, c)}
                className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 transition-all"
                title={t('delete', 'حذف العميل')}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <tr
      onClick={() => {
        if (isSelectionMode && c.id !== undefined) {
          onToggleSelect(c.id);
          return;
        }
        triggerHaptic('medium');
        if (c.id) onSelect(c.id);
      }}
      className={`transition-colors cursor-pointer ${
        isSelected ? 'bg-indigo-500/15 hover:bg-indigo-500/20' : 'hover:bg-zinc-800/60'
      }`}
    >
      {isSelectionMode && (
        <td className="p-2.5 text-center border-l border-zinc-800/40 align-middle" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            onClick={() => c.id !== undefined && onToggleSelect(c.id)}
            className={`w-7 h-7 rounded-lg border flex items-center justify-center mx-auto transition-colors ${
              isSelected
                ? 'bg-indigo-600 border-indigo-400 text-white'
                : 'bg-zinc-900 border-zinc-700 text-transparent'
            }`}
          >
            <Check className="w-4 h-4 stroke-[3]" />
          </button>
        </td>
      )}
      {visibleColumns.map((col) => (
        <td key={col.id} className="p-3 border-l border-zinc-800/40 last:border-l-0 align-middle">
          {renderCell(col.id)}
        </td>
      ))}
    </tr>
  );
});

const CustomerCardItem = React.memo<CustomerListItemSharedProps>(({
  customer: c,
  isSelected,
  isSelectionMode,
  points,
  cardTypeName,
  canDelete,
  dir,
  language,
  t,
  formatNumber,
  formatCurrency,
  formatPhone,
  onToggleSelect,
  onSelect,
  onActivate,
  onDelete,
}) => {
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  return (
    <div
      onClick={() => {
        if (isSelectionMode && c.id !== undefined) {
          onToggleSelect(c.id);
          return;
        }
        triggerHaptic('medium');
        if (c.id) onSelect(c.id);
      }}
      className={`bento-card cv-auto w-full max-w-full min-w-0 p-3.5 shadow-lg cursor-pointer transition-colors active:scale-[0.98] space-y-2 ${dir === 'rtl' ? 'text-right' : 'text-left'} ${
        isSelected
          ? 'bg-indigo-950/40 border-indigo-400/70 ring-2 ring-indigo-500/30'
          : 'bg-zinc-900 hover:bg-zinc-800/80 border-zinc-800'
      }`}
    >
      <div className="glow-top" />
      <div className="flex items-start justify-between gap-2 min-w-0">
        <div className="flex items-start gap-2.5 min-w-0 flex-1">
          {isSelectionMode && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                if (c.id !== undefined) onToggleSelect(c.id);
              }}
              className={`mt-0.5 w-8 h-8 rounded-xl border-2 flex items-center justify-center shrink-0 transition-all ${
                isSelected
                  ? 'bg-indigo-600 border-indigo-400 text-white shadow-md shadow-indigo-600/30'
                  : 'bg-zinc-950 border-zinc-700 text-transparent'
              }`}
              aria-label={language === 'ar' ? 'تحديد العميل' : 'Select customer'}
            >
              <Check className="w-4 h-4 stroke-[3]" />
            </button>
          )}
          <div className="min-w-0 flex-1">
            <h4 className="font-bold text-sm text-white mb-0.5 break-words">{c.name}</h4>
            <div className="text-xs text-zinc-400 font-mono dir-ltr truncate">📱 {formatPhone(c.phone)}</div>
            {c.idNumber && (
              <div className="text-[11px] text-zinc-400 font-mono mt-0.5 flex items-center gap-1 min-w-0">
                <span className="shrink-0">🪪</span>
                <span className="text-indigo-300 font-bold truncate">{c.idNumber}</span>
              </div>
            )}
            {c.orderNumber && (
              <div className="text-[11px] text-indigo-400 font-mono font-bold mt-0.5 truncate">
                #{c.orderNumber}
              </div>
            )}
          </div>
        </div>
        <div className="shrink-0">{renderCustomerStatusBadge(c.status, language)}</div>
      </div>

      {/* Product Info & Salary/Points Badges */}
      <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-zinc-800">
        {c.productType === 'visa' ? (
          <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-[11px] font-medium flex items-center gap-1">
            <CreditCard className="w-3 h-3" />
            <span>{cardTypeName}</span>
          </span>
        ) : (
          <>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[11px] font-medium flex items-center gap-1 font-mono">
              <DollarSign className="w-3 h-3" />
              <span>{t('amount', 'المبلغ')}: {formatCurrency(Number(c.amount || 0))}</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20 text-[11px] font-medium">
              {c.financeType === 'no_salary_transfer' ? t('noSalaryTransfer', 'بدون تحويل راتب') : t('salaryTransfer', 'تحويل راتب')}
            </span>
            {c.financeRate !== undefined && c.financeRate !== null && (
              <span className="px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-300 border border-sky-500/20 text-[11px] font-medium font-mono dir-ltr">
                %{formatNumber(c.financeRate)}
              </span>
            )}
          </>
        )}

        {c.salary && (
          <span className="px-2.5 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700/60 text-[11px] font-medium font-mono">
            {t('salary', 'الراتب')}: {formatCurrency(c.salary)}
          </span>
        )}

        {points > 0 && (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[11px] font-bold font-mono">
            🏆 {formatNumber(points)} {t('pointsUnit')}
          </span>
        )}
      </div>

      {/* Customer Notes Preview (directly visible on card) */}
      {c.notes && c.notes.trim() && (
        <div className="flex items-start gap-1.5 bg-zinc-950/70 border border-amber-500/20 rounded-xl px-2.5 py-1.5 text-[11px] text-amber-100/90">
          <FileText className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
          <p className="line-clamp-2 leading-relaxed break-words">{c.notes}</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex items-center flex-wrap gap-1.5 pt-1" onClick={(e) => e.stopPropagation()}>
        <a
          href={buildSafeTelHref(c.phone)}
          onClick={() => triggerHaptic('light')}
          className="flex-1 min-w-[76px] bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 transition-colors active:scale-95"
        >
          <Phone className="w-3.5 h-3.5 shrink-0" />
          <span>{t('call', 'اتصال')}</span>
        </a>

        <a
          href={buildSafeWhatsAppHref(c.phone)}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => triggerHaptic('light')}
          className="flex-1 min-w-[76px] bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 font-bold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 transition-colors active:scale-95"
        >
          <MessageCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{t('whatsapp', 'واتساب')}</span>
        </a>

        {c.productType === 'visa' && (c.status === 'تم التنفيذ' || c.status === 'بانتظار التفعيل') && (
          <button
            onClick={() => {
              triggerHaptic('success');
              if (c.id) onActivate(c.id);
            }}
            className="flex-1 min-w-[100px] bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-zinc-950 font-extrabold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 transition-colors shadow-md shadow-emerald-500/20 active:scale-95"
          >
            <CheckCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{t('activateCard', 'تفعيل البطاقة')}</span>
          </button>
        )}

        <button
          onClick={() => {
            triggerHaptic('medium');
            if (c.id) onSelect(c.id, false);
          }}
          className="p-2 text-zinc-400 hover:text-white bg-zinc-800 rounded-xl border border-zinc-700/60 active:scale-95"
          title={t('details', 'عرض التفاصيل')}
        >
          <ChevronIcon className="w-4 h-4" />
        </button>

        <button
          onClick={() => {
            triggerHaptic('medium');
            if (c.id) onSelect(c.id, true);
          }}
          className="p-2 text-indigo-400 hover:bg-indigo-500/10 rounded-xl border border-indigo-500/20 active:scale-95 transition-all"
          title={t('edit', 'تعديل العميل')}
        >
          <Edit3 className="w-4 h-4" />
        </button>

        {canDelete && (
          <button
            onClick={(e) => onDelete(e, c)}
            className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-xl border border-rose-500/20 active:scale-95 transition-all"
            title={t('delete', 'حذف العميل')}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
});

export const CustomersPage: React.FC<CustomersPageProps> = React.memo(({
  onSelectCustomer,
  onActivateCustomer
}) => {
  const { isAdmin, permissions, currentUser, customerStatusFilter, setCustomerStatusFilter, selectedMonthKey, setSelectedMonthKey, settings } = useAuth();
  const { showToast } = useToast();
  const { t, language, formatNumber, formatCurrency, formatPhone, dir } = useLanguage();
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isPrintingSheet, setIsPrintingSheet] = useState(false);
  const [visibleLimit, setVisibleLimit] = useState<number>(PAGE_BATCH_SIZE);
  const [searchTerm, setSearchTerm] = useState('');
  const deferredSearchTerm = useDeferredValue(searchTerm);
  const [selectedStatus, setSelectedStatus] = useState<string>(customerStatusFilter || 'all');

  // Mount hidden print sheet only when browser print dialog is triggered
  useEffect(() => {
    const onBeforePrint = () => setIsPrintingSheet(true);
    const onAfterPrint = () => setIsPrintingSheet(false);
    window.addEventListener('beforeprint', onBeforePrint);
    window.addEventListener('afterprint', onAfterPrint);
    return () => {
      window.removeEventListener('beforeprint', onBeforePrint);
      window.removeEventListener('afterprint', onAfterPrint);
    };
  }, []);

  useEffect(() => {
    if (customerStatusFilter) {
      setSelectedStatus(customerStatusFilter);
    }
  }, [customerStatusFilter]);

  const changeSelectedStatus = (status: string) => {
    setSelectedStatus(status);
    setCustomerStatusFilter(status);
  };
  const [selectedProduct, setSelectedProduct] = useState<string>('all');
  const [showScanModal, setShowScanModal] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState<Customer | null>(null);

  // Bulk Multi-Select State
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedCustomerIds, setSelectedCustomerIds] = useState<number[]>([]);
  const [bulkStatusValue, setBulkStatusValue] = useState<CustomerStatus>('تم التنفيذ');
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  const handleDeleteCustomer = useCallback((e: React.MouseEvent, c: Customer) => {
    e.stopPropagation();
    if (!permissions.canDeleteCustomer) {
      showToast(language === 'ar' ? 'صلاحية حذف العملاء متاحة للمدير فقط' : 'Only administrators can delete customers', 'error');
      return;
    }
    if (!c.id) return;
    setCustomerToDelete(c);
  }, [permissions.canDeleteCustomer, showToast, language]);

  const confirmDeleteCustomer = async () => {
    if (!permissions.canDeleteCustomer) {
      setCustomerToDelete(null);
      return;
    }
    if (!customerToDelete || !customerToDelete.id) return;
    try {
      await deleteCustomerCascading(customerToDelete.id, currentUser?.id);
      showToast(`تم حذف العميل "${customerToDelete.name}" بنجاح 🗑️`, 'success');
    } catch (err) {
      console.error('Delete error:', err);
      showToast('حدث خطأ أثناء حذف العميل', 'error');
    } finally {
      setCustomerToDelete(null);
    }
  };

  // VCF / CSV Contacts Import Modal States
  const [showVcfImportModal, setShowVcfImportModal] = useState(false);
  const [vcfFile, setVcfFile] = useState<File | null>(null);
  const [parsedVcfCustomers, setParsedVcfCustomers] = useState<ParsedImportCustomer[]>([]);
  const [csvDetectedNotesInfo, setCsvDetectedNotesInfo] = useState<{
    detectedColumn: boolean;
    columnNames: string[];
    withNotesCount: number;
    detectedFileNumberColumn?: boolean;
    fileNumberColumnName?: string | null;
    withFileNumberCount?: number;
  } | null>(null);
  const [selectedVcfIndices, setSelectedVcfIndices] = useState<number[]>([]);
  const [skipDuplicatePhones, setSkipDuplicatePhones] = useState<boolean>(true);
  const [importProductType, setImportProductType] = useState<ProductType>('visa');
  const [importStatus, setImportStatus] = useState<CustomerStatus>('عميل محتمل');
  const [importTargetMonth, setImportTargetMonth] = useState<string>('all');
  const [importGeneralNotes, setImportGeneralNotes] = useState<string>('');
  const [isImporting, setIsImporting] = useState(false);

  // Synchronize import target month with selected month or current month
  useEffect(() => {
    if (selectedMonthKey && selectedMonthKey !== 'all') {
      setImportTargetMonth(selectedMonthKey);
    } else {
      const now = new Date();
      setImportTargetMonth(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`);
    }
  }, [selectedMonthKey, showVcfImportModal]);

  // View mode, Sort mode & Custom columns state
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'name-asc' | 'name-desc'>(() => {
    return (localStorage.getItem('sales_crm_sort_by') as any) || 'date-desc';
  });

  useEffect(() => {
    localStorage.setItem('sales_crm_sort_by', sortBy);
  }, [sortBy]);

  const [showColumnSettingsModal, setShowColumnSettingsModal] = useState(false);
  const [columns, setColumns] = useState<ColumnConfig[]>(() => {
    try {
      const saved = localStorage.getItem('sales_crm_columns_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const hasNotesCol = parsed.some((col: ColumnConfig) => col.id === 'notes');
          if (!hasNotesCol) {
            const notesCol = DEFAULT_COLUMNS.find((col) => col.id === 'notes');
            const actionsIdx = parsed.findIndex((col: ColumnConfig) => col.id === 'actions');
            if (notesCol) {
              if (actionsIdx >= 0) {
                parsed.splice(actionsIdx, 0, notesCol);
              } else {
                parsed.push(notesCol);
              }
            }
          }
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load columns config:', e);
    }
    return DEFAULT_COLUMNS;
  });
  const [draggedColIndex, setDraggedColIndex] = useState<number | null>(null);

  const moveColumn = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= columns.length) return;
    triggerHaptic('light');
    const updated = [...columns];
    const [moved] = updated.splice(fromIndex, 1);
    updated.splice(toIndex, 0, moved);
    setColumns(updated);
    localStorage.setItem('sales_crm_columns_config', JSON.stringify(updated));
  };

  const toggleColumnVisibility = (colId: string) => {
    triggerHaptic('light');
    const updated = columns.map((col) => (col.id === colId ? { ...col, visible: !col.visible } : col));
    setColumns(updated);
    localStorage.setItem('sales_crm_columns_config', JSON.stringify(updated));
  };

  const resetColumnsToDefault = () => {
    triggerHaptic('medium');
    setColumns(DEFAULT_COLUMNS);
    localStorage.removeItem('sales_crm_columns_config');
    showToast('تم إعادة تعيين ترتيب الأعمدة للوضع الافتراضي ↺', 'info');
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedColIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    if (draggedColIndex !== null && draggedColIndex !== dropIndex) {
      moveColumn(draggedColIndex, dropIndex);
    }
    setDraggedColIndex(null);
  };

  const visibleColumns = useMemo(() => columns.filter((c) => c.visible), [columns]);

  const customers = useLiveQuery(() => db.customers.toArray(), []) ?? EMPTY_CUSTOMERS;
  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) ?? EMPTY_CARD_TYPES;
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) ?? EMPTY_SALARY_TIERS;
  const rawStatuses = useLiveQuery(() => db.statuses.orderBy('order').toArray(), []) ?? EMPTY_STATUSES;

  const cardTypeMap = useMemo(() => {
    const map = new Map<number, CardType>();
    for (const ct of cardTypes) {
      if (ct.id !== undefined) map.set(ct.id, ct);
    }
    return map;
  }, [cardTypes]);

  const customerPointsMap = useMemo(() => {
    const map = new Map<number, number>();
    for (const c of customers) {
      if (c.id === undefined) continue;
      if (c.points && c.points > 0) {
        map.set(c.id, c.points);
        continue;
      }
      const cardType = c.cardTypeId ? cardTypeMap.get(c.cardTypeId) : undefined;
      const basePoints = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
      const sal = c.salary || 0;
      if (basePoints > 0) {
        map.set(c.id, calculateCardPoints(basePoints, sal, c.productType || 'visa', salaryTiers));
      } else if (sal >= 6000) {
        map.set(c.id, calculatePoints(sal));
      } else {
        map.set(c.id, 0);
      }
    }
    return map;
  }, [customers, cardTypeMap, salaryTiers]);

  const getCustomerPoints = useCallback((c: Customer) => {
    if (c.id !== undefined) {
      const cached = customerPointsMap.get(c.id);
      if (cached !== undefined) return cached;
    }
    if (c.points && c.points > 0) return c.points;
    const cardType = c.cardTypeId ? cardTypeMap.get(c.cardTypeId) : undefined;
    const basePoints = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
    const sal = c.salary || 0;
    if (basePoints > 0) {
      return calculateCardPoints(basePoints, sal, c.productType || 'visa', salaryTiers);
    }
    if (sal >= 6000) {
      return calculatePoints(sal);
    }
    return 0;
  }, [customerPointsMap, cardTypeMap, salaryTiers]);

  const dbStatuses = useMemo(() => {
    const map = new Map<string, (typeof rawStatuses)[0]>();
    const coreDefaults: Array<(typeof rawStatuses)[0]> = [
      { name: 'عميل محتمل', nameEn: 'Potential', color: '#3b82f6', description: 'عميل محتمل', order: 1 },
      { name: 'عميل معلق', nameEn: 'Pending', color: '#f59e0b', description: 'عميل معلق', order: 2 },
      { name: 'تم التنفيذ', nameEn: 'Executed', color: '#06b6d4', description: 'تم التنفيذ', order: 3 },
      { name: 'تم التفعيل', nameEn: 'Activated', color: '#22c55e', description: 'تم التفعيل', order: 4 },
    ];
    for (const s of rawStatuses) {
      if (s && s.name && !map.has(s.name.trim())) {
        map.set(s.name.trim(), { ...s, name: s.name.trim() });
      }
    }
    for (const def of coreDefaults) {
      if (!map.has(def.name)) {
        map.set(def.name, def);
      }
    }
    // Include any custom status present in customer records without merging
    for (const c of customers) {
      const sName = (c.status || '').trim();
      if (sName && !map.has(sName)) {
        map.set(sName, {
          name: sName,
          nameEn: sName,
          color: sName === 'تم التفعيل' ? '#22c55e' : sName === 'تم التنفيذ' ? '#06b6d4' : '#6366f1',
          description: sName,
          order: 99
        });
      }
    }
    return Array.from(map.values()).sort((a, b) => (a.order ?? 99) - (b.order ?? 99));
  }, [rawStatuses, customers]);

  const availableMonthOptions = useMemo(() => {
    return getAvailableMonthOptions(customers, [selectedMonthKey, importTargetMonth]);
  }, [customers, selectedMonthKey, importTargetMonth]);

  const getColumnLabel = (colId: string) => {
    switch (colId) {
      case 'name': return t('customerName', 'اسم العميل');
      case 'phone': return t('phone', 'رقم الجوال');
      case 'idNumber': return t('idNumber', 'رقم الهوية');
      case 'orderNumber': return t('orderNumber', 'رقم الطلب');
      case 'status': return t('status', 'الحالة');
      case 'productType': return t('productType', 'نوع المنتج');
      case 'amount': return t('amount', 'المبلغ/التفاصيل');
      case 'points': return t('points', 'النقاط');
      case 'notes': return t('notes', 'الملاحظات');
      case 'actions': return t('actions', 'الإجراءات');
      default: return colId;
    }
  };

  const handleQuickVCFExport = () => {
    try {
      triggerHaptic('medium');
      if (sortedCustomers.length === 0) {
        showToast(language === 'ar' ? 'لا يوجد عملاء مطبقين للتصدير' : 'No customers to export', 'warning');
        return;
      }
      exportCustomersToVCF(sortedCustomers, `Samsung_Contacts_${new Date().toISOString().split('T')[0]}.vcf`);
      showToast(language === 'ar' ? `تم تصدير ${sortedCustomers.length} جهة اتصال لسامسونج S24 بنجاح 📱✨` : `Exported ${sortedCustomers.length} contacts successfully 📱✨`, 'success');
    } catch (err: any) {
      showToast(err.message || (language === 'ar' ? 'حدث خطأ أثناء التصدير' : 'Export error'), 'error');
    }
  };

  const handleExportCustomersExcel = async (customList?: Customer[]) => {
    try {
      triggerHaptic('medium');
      const targetList = customList || sortedCustomers;
      if (targetList.length === 0) {
        showToast(language === 'ar' ? 'لا يوجد عملاء للتصدير' : 'No customers to export', 'warning');
        return;
      }
      const XLSX = await import('xlsx');
      const rows = targetList.map((c, idx) => ({
        '#': idx + 1,
        [language === 'ar' ? 'اسم العميل' : 'Customer Name']: sanitizeSpreadsheetValue(c.name || ''),
        [language === 'ar' ? 'رقم الجوال' : 'Phone']: sanitizeSpreadsheetValue(c.phone || ''),
        [language === 'ar' ? 'رقم الهوية' : 'ID Number']: sanitizeSpreadsheetValue(c.idNumber || ''),
        [language === 'ar' ? 'رقم الطلب' : 'Order #']: sanitizeSpreadsheetValue(c.orderNumber || ''),
        [language === 'ar' ? 'الحالة' : 'Status']: sanitizeSpreadsheetValue(getStatusTranslation(c.status, language)),
        [language === 'ar' ? 'نوع المنتج' : 'Product']: sanitizeSpreadsheetValue(c.productType === 'visa' ? getCardTypeName(c.cardTypeId) : (language === 'ar' ? 'تمويل شخصي' : 'Personal Finance')),
        [language === 'ar' ? 'المبلغ / الراتب' : 'Amount / Salary']: Number(c.amount || c.salary || 0),
        [language === 'ar' ? 'النقاط' : 'Points']: getCustomerPoints(c),
        [language === 'ar' ? 'الملاحظات' : 'Notes']: sanitizeSpreadsheetValue(c.notes || ''),
      }));
      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      if (dir === 'rtl') {
        wb.Workbook = { Views: [{ RTL: true }] };
      }
      XLSX.utils.book_append_sheet(wb, ws, 'Customers');
      await saveWorkbookNativeOrWeb(
        XLSX,
        wb,
        `sales-crm-customers-${new Date().toISOString().split('T')[0]}.xlsx`,
        language === 'ar' ? 'سجل العملاء' : 'Customers Directory'
      );
      showToast(language === 'ar' ? `تم تصدير ${formatNumber(targetList.length)} عميل إلى ملف Excel بنجاح 📊` : `Exported ${targetList.length} customers to Excel 📊`, 'success');
    } catch (err) {
      console.error('Customers Excel export error:', err);
      showToast(language === 'ar' ? 'تعذر تصدير ملف Excel' : 'Failed to export Excel', 'error');
    }
  };

  const handleExportCustomersPDF = async (customList?: Customer[]) => {
    if (isExportingPdf) return;
    const targetList = customList || sortedCustomers;
    if (targetList.length === 0) {
      showToast(language === 'ar' ? 'لا يوجد عملاء للتصدير' : 'No customers to export', 'warning');
      return;
    }
    triggerHaptic('medium');
    setIsExportingPdf(true);
    try {
      const getAccent = (s: string): PdfAccent => {
        const clean = (s || '').trim();
        if (clean === 'تم التفعيل') return 'emerald';
        if (clean === 'تم التنفيذ') return 'cyan';
        if (clean === 'عميل معلق' || clean === 'بانتظار التفعيل') return 'amber';
        if (clean === 'عميل محتمل') return 'sky';
        return 'slate';
      };

      const cycleLabel = selectedMonthKey === 'all'
        ? (language === 'ar' ? 'جميع الشهور' : 'All Months')
        : (language === 'ar' ? formatMonthKeyToArabic(selectedMonthKey) : formatMonthKeyToEnglish(selectedMonthKey));

      const statusLabel = customList
        ? (language === 'ar' ? `تصدير محدد (${formatNumber(targetList.length)})` : `Selected Export (${formatNumber(targetList.length)})`)
        : selectedStatus === 'all'
        ? (language === 'ar' ? 'جميع الحالات (مفصولة)' : 'All Statuses')
        : getStatusTranslation(selectedStatus, language);

      const totalVol = targetList.reduce((sum, c) => sum + (Number(c.amount) || Number(c.salary) || 0), 0);
      const totalPts = targetList.reduce((sum, c) => sum + getCustomerPoints(c), 0);

      await exportReportToPDF({
        title: customList
          ? (language === 'ar' ? 'كشف العملاء المحددين' : 'Selected Customers Directory')
          : (language === 'ar' ? 'كشف وسجل العملاء المفلتر' : 'Filtered Customers Directory'),
        companyName: settings?.companyName?.trim() || 'SALES CRM SYSTEM',
        cycleLabel,
        statusLabel,
        statusAccent: customList || selectedStatus === 'all' ? 'indigo' : getAccent(selectedStatus),
        totalCountLabel: language === 'ar' ? 'إجمالي العملاء' : 'Total Clients',
        totalCountValue: formatNumber(targetList.length),
        dir,
        language,
        orientation: 'landscape',
        summaryCards: [
          { label: language === 'ar' ? 'عدد العملاء' : 'Clients', value: formatNumber(targetList.length), accent: 'indigo' },
          { label: language === 'ar' ? 'بطاقات Visa' : 'Visa Cards', value: formatNumber(targetList.filter(c => c.productType === 'visa').length), accent: 'sky' },
          { label: language === 'ar' ? 'تمويل شخصي' : 'Finance', value: formatNumber(targetList.filter(c => c.productType === 'finance').length), accent: 'emerald' },
          { label: language === 'ar' ? 'المبالغ / النقاط' : 'Volume / Pts', value: formatCurrency(totalVol), subtext: `${formatNumber(totalPts)} ${t('pointsUnit', 'نقطة')}`, accent: 'amber' },
        ],
        columns: [
          { label: '#', align: 'center', width: '36px' },
          { label: language === 'ar' ? 'اسم العميل' : 'Customer', align: dir === 'rtl' ? 'right' : 'left' },
          { label: language === 'ar' ? 'الجوال' : 'Phone', align: 'center', width: '105px' },
          { label: language === 'ar' ? 'الحالة' : 'Status', align: 'center', width: '100px' },
          { label: language === 'ar' ? 'المنتج' : 'Product', align: 'center', width: '115px' },
          { label: language === 'ar' ? 'المبلغ / الراتب' : 'Amount / Salary', align: 'center', width: '105px' },
          { label: language === 'ar' ? 'النقاط' : 'Points', align: 'center', width: '75px' },
          { label: language === 'ar' ? 'الملاحظات' : 'Notes', align: dir === 'rtl' ? 'right' : 'left' },
        ],
        rows: targetList.map((c, idx): PdfCell[] => [
          { text: formatNumber(idx + 1), mono: true },
          { text: c.name || '-', bold: true },
          { text: formatPhone(c.phone || '-'), mono: true, dir: 'ltr' },
          { text: getStatusTranslation(c.status, language), badgeAccent: getAccent(c.status) },
          { text: c.productType === 'visa' ? getCardTypeName(c.cardTypeId) : (language === 'ar' ? 'تمويل شخصي' : 'Finance') },
          { text: formatCurrency(Number(c.amount || c.salary || 0)), mono: true },
          { text: formatNumber(getCustomerPoints(c)), mono: true, bold: true },
          { text: c.notes?.trim() || '-' },
        ]),
        footerText: language === 'ar' ? 'تم استخراج هذا السجل من نظام إدارة المبيعات Sales CRM' : 'Generated by Sales CRM System',
        fileName: `sales-crm-customers-${new Date().toISOString().split('T')[0]}.pdf`,
      });
      showToast(language === 'ar' ? 'تم تصدير ملف PDF لقائمة العملاء بنجاح 📄✨' : 'Customers PDF exported successfully 📄✨', 'success');
    } catch (err) {
      console.error('Customers PDF export error:', err);
      showToast(language === 'ar' ? 'تعذر تصدير ملف PDF' : 'Failed to export PDF', 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleVcfFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      triggerHaptic('medium');
      const text = await readImportFileText(file);
      const isVCard = /BEGIN:VCARD/i.test(text);
      let parsed: ParsedImportCustomer[] = [];

      if (isVCard) {
        parsed = parseVCFToCustomers(text).map((c) => ({
          ...c,
          hasNotesFromFile: Boolean(c.notes && String(c.notes).trim()),
        }));
        const withNotesCount = parsed.filter((c) => c.hasNotesFromFile).length;
        const withFileNoCount = parsed.filter((c) => Boolean(c.orderNumber && !String(c.orderNumber).startsWith('VCF-'))).length;
        setCsvDetectedNotesInfo({
          detectedColumn: withNotesCount > 0,
          columnNames: ['NOTE'],
          withNotesCount,
          detectedFileNumberColumn: withFileNoCount > 0,
          fileNumberColumnName: 'NOTE',
          withFileNumberCount: withFileNoCount,
        });
      } else {
        const csvResult = parseCSVWithMetadata(text);
        parsed = csvResult.customers;
        setCsvDetectedNotesInfo({
          detectedColumn: csvResult.detectedNotesColumn,
          columnNames: csvResult.notesColumnNames,
          withNotesCount: csvResult.customersWithNotesCount,
          detectedFileNumberColumn: csvResult.detectedFileNumberColumn,
          fileNumberColumnName: csvResult.fileNumberColumnName,
          withFileNumberCount: csvResult.customersWithFileNumberCount,
        });
      }

      if (parsed.length === 0) {
        showToast(language === 'ar' ? 'لم يتم العثور على عملاء صالحين في الملف' : 'No valid customers found in file', 'error');
        return;
      }

      setVcfFile(file);
      setParsedVcfCustomers(parsed);
      setSelectedVcfIndices(parsed.map((_, i) => i)); // select all by default
      const notesCount = parsed.filter((c) => Boolean(c.notes && String(c.notes).trim())).length;
      const fileNoCount = parsed.filter((c) => Boolean(c.orderNumber && !String(c.orderNumber).startsWith('VCF-'))).length;
      showToast(
        language === 'ar'
          ? `تم اكتشاف ${parsed.length} عميل${fileNoCount > 0 ? ` (${fileNoCount} برقم ملف)` : ''}${notesCount > 0 ? ` (${notesCount} بملاحظات)` : ''} 📄✨`
          : `Found ${parsed.length} customers${fileNoCount > 0 ? ` (${fileNoCount} with File #)` : ''}${notesCount > 0 ? ` (${notesCount} with Notes)` : ''} 📄✨`,
        'info'
      );
    } catch (err: any) {
      console.error('CSV/VCF Read error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء قراءة الملف' : 'Error reading file', 'error');
    } finally {
      e.target.value = '';
    }
  };

  const toggleVcfSelection = (index: number) => {
    triggerHaptic('light');
    if (selectedVcfIndices.includes(index)) {
      setSelectedVcfIndices(selectedVcfIndices.filter((i) => i !== index));
    } else {
      setSelectedVcfIndices([...selectedVcfIndices, index]);
    }
  };

  const toggleSelectAllVcf = () => {
    triggerHaptic('light');
    if (selectedVcfIndices.length === parsedVcfCustomers.length) {
      setSelectedVcfIndices([]);
    } else {
      setSelectedVcfIndices(parsedVcfCustomers.map((_, i) => i));
    }
  };

  const updateParsedVcfCustomerNotes = (index: number, notesValue: string) => {
    setParsedVcfCustomers((prev) =>
      prev.map((cust, i) => (i === index ? { ...cust, notes: notesValue } : cust))
    );
  };

  const updateParsedVcfCustomerFileNo = (index: number, fileNoValue: string) => {
    setParsedVcfCustomers((prev) =>
      prev.map((cust, i) => (i === index ? { ...cust, orderNumber: fileNoValue } : cust))
    );
  };

  // Precompute normalized existing phone numbers for instant CSV/VCF duplicate detection
  const existingPhoneMap = useMemo(() => {
    const map = new Map<string, Customer>();
    for (const c of customers) {
      const norm = normalizePhoneForMatch(c.phone || '');
      if (norm && !map.has(norm)) {
        map.set(norm, c);
      }
    }
    return map;
  }, [customers]);

  const vcfDuplicateStatusByIndex = useMemo(() => {
    const seenInFile = new Set<string>();
    return parsedVcfCustomers.map((item) => {
      const norm = normalizePhoneForMatch(item.phone || '');
      if (!norm || norm.length < 7) return { isDuplicate: false, existingName: null as string | null, inFileDuplicate: false };
      const existing = existingPhoneMap.get(norm);
      const inFile = seenInFile.has(norm);
      seenInFile.add(norm);
      return {
        isDuplicate: Boolean(existing || inFile),
        existingName: existing ? existing.name : null,
        inFileDuplicate: !existing && inFile,
      };
    });
  }, [parsedVcfCustomers, existingPhoneMap]);

  const vcfDuplicateCount = useMemo(
    () => vcfDuplicateStatusByIndex.filter((d) => d.isDuplicate).length,
    [vcfDuplicateStatusByIndex]
  );

  const handleConfirmVcfImport = async () => {
    if (selectedVcfIndices.length === 0) {
      showToast(language === 'ar' ? 'يرجى تحديد جهة اتصال واحدة على الأقل للاستيراد' : 'Please select at least one contact to import', 'warning');
      return;
    }

    setIsImporting(true);
    try {
      triggerHaptic('success');
      const generalNote = importGeneralNotes.trim();
      let skippedDupes = 0;
      const selectedList = selectedVcfIndices
        .filter((idx) => {
          if (skipDuplicatePhones && vcfDuplicateStatusByIndex[idx]?.isDuplicate) {
            skippedDupes += 1;
            return false;
          }
          return true;
        })
        .map((idx) => parsedVcfCustomers[idx])
        .filter((item) => item && (item.name || item.phone))
        .map((item) => {
          const customerNote = item.notes ? String(item.notes).trim() : '';
          const mergedNotes = [customerNote, generalNote].filter(Boolean).join(' | ');
          return {
            ...item,
            notes: mergedNotes || undefined,
          };
        });

      if (selectedList.length === 0) {
        showToast(
          language === 'ar'
            ? `تم تخطي جميع الصفوف المحددة (${formatNumber(skippedDupes)}) لأنها أرقام مكررة مسجلة مسبقاً`
            : `All selected rows (${formatNumber(skippedDupes)}) were skipped as duplicates`,
          'warning'
        );
        return;
      }

      const addedCount = await enrichAndAddCustomers(selectedList, {
        defaultStatus: importStatus,
        defaultProductType: importProductType,
        sourceTag: language === 'ar' ? `استيراد من ${vcfFile?.name || 'ملف'}` : `Import from ${vcfFile?.name || 'file'}`,
        userId: currentUser?.id,
        targetMonth: importTargetMonth
      });

      const importedWithNotesCount = selectedList.filter((item) => Boolean(item.notes && String(item.notes).trim())).length;
      const skippedTextAr = skippedDupes > 0 ? ` (وتم تخطي ${formatNumber(skippedDupes)} مكرر)` : '';
      const skippedTextEn = skippedDupes > 0 ? ` (${formatNumber(skippedDupes)} duplicates skipped)` : '';
      showToast(
        language === 'ar'
          ? importedWithNotesCount > 0
            ? `تم استيراد ${addedCount} عميل وحفظ الملاحظات (${importedWithNotesCount})${skippedTextAr} 🎉`
            : `تم استيراد ${addedCount} عميل جديد بنجاح${skippedTextAr} 🎉`
          : importedWithNotesCount > 0
            ? `Imported ${addedCount} customers & saved Notes (${importedWithNotesCount})${skippedTextEn} 🎉`
            : `Imported ${addedCount} customers successfully${skippedTextEn} 🎉`,
        'success'
      );
      if (importTargetMonth && importTargetMonth !== 'all' && importTargetMonth.includes('-')) {
        setSelectedMonthKey(importTargetMonth);
      }
      setShowVcfImportModal(false);
      setVcfFile(null);
      setParsedVcfCustomers([]);
      setCsvDetectedNotesInfo(null);
      setSelectedVcfIndices([]);
      setImportGeneralNotes('');
    } catch (err: any) {
      console.error('Import confirmation error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء حفظ العملاء المستوردين' : 'Error saving imported customers', 'error');
    } finally {
      setIsImporting(false);
    }
  };

  // Customers filtered by search, product, and month (before status filter) for exact per-status counts
  const baseFilteredCustomers = useMemo(() => {
    const search = deferredSearchTerm.trim().toLowerCase();

    return customers.filter((c) => {
      const cardTypeName = (c.cardTypeId ? cardTypeMap.get(c.cardTypeId)?.name?.toLowerCase() : '') || '';

      const matchesSearch =
        !search ||
        c.name.toLowerCase().includes(search) ||
        c.phone.includes(search) ||
        (c.idNumber && c.idNumber.toLowerCase().includes(search)) ||
        (c.orderNumber && c.orderNumber.toLowerCase().includes(search)) ||
        (c.email && c.email.toLowerCase().includes(search)) ||
        (c.notes && c.notes.toLowerCase().includes(search)) ||
        c.productType.toLowerCase().includes(search) ||
        cardTypeName.includes(search);

      const matchesProduct =
        selectedProduct === 'all' || c.productType === (selectedProduct as ProductType);

      const matchesMonth = selectedMonthKey === 'all' || getCustomerMonthKey(c) === selectedMonthKey;

      return matchesSearch && matchesProduct && matchesMonth;
    });
  }, [customers, deferredSearchTerm, selectedProduct, selectedMonthKey, cardTypeMap]);

  // Exact per-status counts without merging any statuses
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const c of baseFilteredCustomers) {
      const s = (c.status || '').trim();
      if (s) {
        counts[s] = (counts[s] || 0) + 1;
      }
    }
    return counts;
  }, [baseFilteredCustomers]);

  // Strict exact status filtering: each customer appears ONLY in their exact current status
  const filteredCustomers = useMemo(() => {
    if (selectedStatus === 'all') return baseFilteredCustomers;
    const normFilterStatus = selectedStatus.trim();
    return baseFilteredCustomers.filter((c) => {
      if (!c.status) return false;
      return c.status.trim() === normFilterStatus;
    });
  }, [baseFilteredCustomers, selectedStatus]);

  // Memoized Sorting logic based on user selection (Date or Name)
  const sortedCustomers = useMemo(() => {
    return [...filteredCustomers].sort((a, b) => {
      if (sortBy === 'name-asc') {
        return a.name.localeCompare(b.name, 'ar');
      }
      if (sortBy === 'name-desc') {
        return b.name.localeCompare(a.name, 'ar');
      }
      if (sortBy === 'date-asc') {
        const dateA = new Date(a.createdAt || 0).getTime();
        const dateB = new Date(b.createdAt || 0).getTime();
        return dateA - dateB;
      }
      // Default: date-desc (newest first)
      const dateA = new Date(a.createdAt || 0).getTime();
      const dateB = new Date(b.createdAt || 0).getTime();
      return dateB - dateA;
    });
  }, [filteredCustomers, sortBy]);

  // Reset rendered window back to 40 items whenever filters/search/month/sort change
  useEffect(() => {
    setVisibleLimit(PAGE_BATCH_SIZE);
  }, [deferredSearchTerm, selectedStatus, selectedProduct, selectedMonthKey, sortBy]);

  const visibleCustomers = useMemo(
    () => sortedCustomers.slice(0, visibleLimit),
    [sortedCustomers, visibleLimit]
  );
  const hasMoreCustomers = sortedCustomers.length > visibleLimit;

  // Bulk Multi-Select Helpers
  const selectedCustomerSet = useMemo(() => new Set(selectedCustomerIds), [selectedCustomerIds]);

  const selectedCustomersList = useMemo(
    () => sortedCustomers.filter((c) => c.id !== undefined && selectedCustomerSet.has(c.id)),
    [sortedCustomers, selectedCustomerSet]
  );

  const toggleCustomerSelection = useCallback((id: number) => {
    triggerHaptic('light');
    setSelectedCustomerIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }, []);

  const toggleSelectAllFiltered = () => {
    triggerHaptic('light');
    const visibleIds = sortedCustomers.map((c) => c.id).filter((id): id is number => id !== undefined);
    if (visibleIds.length > 0 && visibleIds.every((id) => selectedCustomerSet.has(id))) {
      setSelectedCustomerIds([]);
    } else {
      setSelectedCustomerIds(visibleIds);
    }
  };

  const exitSelectionMode = () => {
    triggerHaptic('light');
    setIsSelectionMode(false);
    setSelectedCustomerIds([]);
  };

  const handleBulkStatusApply = async () => {
    if (selectedCustomerIds.length === 0 || isBulkProcessing) return;
    setIsBulkProcessing(true);
    try {
      triggerHaptic('medium');
      const updatedCount = await bulkUpdateCustomerStatus(
        selectedCustomerIds,
        bulkStatusValue,
        currentUser?.id
      );
      const statusLabel = getStatusTranslation(bulkStatusValue, language);
      if (updatedCount > 0) {
        showToast(
          language === 'ar'
            ? `تم تحديث حالة ${formatNumber(updatedCount)} عميل إلى "${statusLabel}" بنجاح ✨`
            : `Updated ${formatNumber(updatedCount)} customers to "${statusLabel}" ✨`,
          'success'
        );
      } else {
        showToast(
          language === 'ar'
            ? 'لم يتم تحديث أي عميل'
            : 'No customers updated',
          'warning'
        );
      }
      setSelectedCustomerIds([]);
    } catch (err) {
      console.error('Bulk status update error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء التحديث الجماعي' : 'Bulk update failed', 'error');
    } finally {
      setIsBulkProcessing(false);
    }
  };

  const handleBulkDeleteConfirm = async () => {
    if (!permissions.canDeleteCustomer) {
      setShowBulkDeleteConfirm(false);
      showToast(language === 'ar' ? 'صلاحية الحذف الجماعي متاحة للمدير فقط' : 'Bulk delete is restricted to administrators', 'error');
      return;
    }
    if (selectedCustomerIds.length === 0 || isBulkProcessing) return;
    setIsBulkProcessing(true);
    try {
      triggerHaptic('warning');
      const count = selectedCustomerIds.length;
      await bulkDeleteCustomersCascading(selectedCustomerIds, currentUser?.id);
      showToast(
        language === 'ar'
          ? `تم حذف ${formatNumber(count)} عميل وجميع سجلاتهم المرتبطة بنجاح 🗑️`
          : `Deleted ${formatNumber(count)} customers successfully 🗑️`,
        'success'
      );
      setSelectedCustomerIds([]);
      setIsSelectionMode(false);
    } catch (err) {
      console.error('Bulk delete error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء الحذف الجماعي' : 'Bulk delete error', 'error');
    } finally {
      setIsBulkProcessing(false);
      setShowBulkDeleteConfirm(false);
    }
  };

  const getCardTypeName = useCallback((id?: number | null) => {
    if (!id) return 'Visa';
    return cardTypeMap.get(id)?.name || 'Visa';
  }, [cardTypeMap]);

  return (
    <div className={`w-full max-w-full min-w-0 overflow-x-clip space-y-3 pb-24 pt-2 px-3 sm:px-4 print:p-0 print:space-y-0 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
      <div className="screen-only no-print space-y-3">
      {/* Search Input */}
      <div className="space-y-1.5">
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={language === 'ar' ? '🔍 ابحث بالاسم، الجوال، رقم الطلب، النوع أو الملاحظات...' : '🔍 Search by name, phone, order #, product or notes...'}
            className={`w-full bg-zinc-900 border border-zinc-800 rounded-2xl py-3 text-zinc-100 text-xs focus:outline-none focus:border-indigo-500 transition-all shadow-inner font-sans ${dir === 'rtl' ? 'pr-10 pl-10 text-right' : 'pl-10 pr-10 text-left'}`}
          />
          <Search className={`w-4 h-4 text-zinc-500 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
          {searchTerm && (
            <button
              onClick={() => {
                triggerHaptic('light');
                setSearchTerm('');
              }}
              className={`absolute top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-200 p-1 ${dir === 'rtl' ? 'left-3' : 'right-3'}`}
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Result Counter & Reset Bar */}
        {(searchTerm || selectedStatus !== 'all' || selectedProduct !== 'all' || selectedMonthKey !== 'all') && (
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] px-1 text-zinc-400 font-medium min-w-0">
            <span>
              {language === 'ar' ? (
                <>تم العثور على <b className="text-white font-mono">{formatNumber(filteredCustomers.length)}</b> عميل من أصل <span className="font-mono">{formatNumber(customers.length)}</span></>
              ) : (
                <>Found <b className="text-white font-mono">{formatNumber(filteredCustomers.length)}</b> of <span className="font-mono">{formatNumber(customers.length)}</span> customers</>
              )}
            </span>
            <button
              onClick={() => {
                triggerHaptic('light');
                setSearchTerm('');
                changeSelectedStatus('all');
                setSelectedProduct('all');
                setSelectedMonthKey('all');
              }}
              className="text-amber-400 hover:text-amber-300 font-bold underline underline-offset-2 flex items-center gap-1"
            >
              {language === 'ar' ? 'إعادة تعيين التصفية ↺' : 'Reset Filter ↺'}
            </button>
          </div>
        )}
      </div>

      {/* Status Filter Chips (Wrapped & Strict per-status counts) */}
      <div className="flex items-center flex-wrap gap-1.5 pb-1 text-xs select-none">
        <button
          onClick={() => {
            triggerHaptic('light');
            changeSelectedStatus('all');
          }}
          className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all active:scale-95 flex items-center gap-1.5 ${
            selectedStatus === 'all'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
              : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
          }`}
        >
          <span>{t('allStatuses')}</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${selectedStatus === 'all' ? 'bg-white/20 text-white' : 'bg-zinc-800 text-zinc-400'}`}>
            {formatNumber(baseFilteredCustomers.length)}
          </span>
        </button>
        {dbStatuses
          .filter((s) => selectedProduct === 'visa' || selectedProduct === 'all' || (s.name !== 'تم التفعيل' && s.nameEn !== 'Activated') || (statusCounts[s.name] || 0) > 0)
          .map((s) => {
            const count = statusCounts[s.name] || 0;
            const isSelected = selectedStatus === s.name;
            const isActivated = s.name === 'تم التفعيل';
            const isExecuted = s.name === 'تم التنفيذ';
            return (
              <button
                key={s.id || s.name}
                onClick={() => {
                  triggerHaptic('light');
                  changeSelectedStatus(s.name);
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all active:scale-95 flex items-center gap-1.5 ${
                  isSelected
                    ? isActivated
                      ? 'bg-emerald-500 text-zinc-950 shadow-md shadow-emerald-500/20'
                      : isExecuted
                      ? 'bg-cyan-500 text-zinc-950 shadow-md shadow-cyan-500/20'
                      : 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : isActivated
                    ? 'bg-zinc-900 text-emerald-300 hover:text-emerald-200 border border-emerald-500/30'
                    : isExecuted
                    ? 'bg-zinc-900 text-cyan-300 hover:text-cyan-200 border border-cyan-500/30'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
                }`}
              >
                <span>{isActivated ? `⚡ ${getStatusTranslation(s.name, language)}` : isExecuted ? `🟢 ${getStatusTranslation(s.name, language)}` : getStatusTranslation(s.name, language)}</span>
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isSelected
                    ? (isActivated || isExecuted) ? 'bg-black/20 text-zinc-950' : 'bg-white/20 text-white'
                    : 'bg-zinc-800 text-zinc-400'
                }`}>
                  {formatNumber(count)}
                </span>
              </button>
            );
          })}
      </div>

      {/* Product Type Filter Chips */}
      <div className="flex items-center flex-wrap gap-1.5 text-xs select-none">
        <button
          onClick={() => {
            triggerHaptic('light');
            setSelectedProduct('all');
          }}
          className={`px-3 py-1 rounded-xl font-medium text-[11px] transition-all active:scale-95 ${
            selectedProduct === 'all'
              ? 'bg-zinc-800 text-white border border-zinc-700'
              : 'bg-zinc-900/60 text-zinc-400 border border-zinc-800/80'
          }`}
        >
          {t('allProducts')}
        </button>
        <button
          onClick={() => {
            triggerHaptic('light');
            setSelectedProduct('visa');
          }}
          className={`px-3 py-1 rounded-xl font-medium text-[11px] transition-all active:scale-95 ${
            selectedProduct === 'visa'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
              : 'bg-zinc-900/60 text-zinc-400 border border-zinc-800/80'
          }`}
        >
          💳 {t('cardsProduct')}
        </button>
        <button
          onClick={() => {
            triggerHaptic('light');
            setSelectedProduct('finance');
          }}
          className={`px-3 py-1 rounded-xl font-medium text-[11px] transition-all active:scale-95 ${
            selectedProduct === 'finance'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'bg-zinc-900/60 text-zinc-400 border border-zinc-800/80'
          }`}
        >
          💰 {t('financeProduct')}
        </button>
      </div>

      {/* Month Filter Selector Bar */}
      <div className="bg-zinc-900/90 border border-indigo-500/30 p-2 rounded-2xl flex items-center flex-wrap sm:flex-nowrap gap-2 shadow-inner w-full max-w-full min-w-0">
        <div className="flex items-center gap-1.5 shrink-0 text-indigo-200 font-bold text-xs pr-1">
          <Calendar className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{language === 'ar' ? 'شهر العمل:' : 'Work Month:'}</span>
        </div>
        <select
          value={selectedMonthKey}
          onChange={(e) => {
            triggerHaptic('light');
            setSelectedMonthKey(e.target.value);
            showToast(
              e.target.value === 'all'
                ? (language === 'ar' ? 'تم عرض جميع الشهور' : 'Showing all months')
                : (language === 'ar' ? 'تم تغيير شهر العمل وتحديث القائمة والتصنيفات' : 'Work month changed and list updated'),
              'info'
            );
          }}
          className="bg-zinc-950 border border-indigo-500/40 rounded-xl py-1.5 px-2.5 text-xs font-bold text-indigo-200 focus:outline-none focus:border-indigo-400 min-w-0 flex-1 cursor-pointer shadow-sm"
        >
          {availableMonthOptions.map((m) => (
            <option key={m.key} value={m.key}>
              {language === 'en' ? m.labelEn : m.labelAr} {m.count !== undefined ? `(${formatNumber(m.count)})` : ''}
            </option>
          ))}
        </select>
        <input
          type="month"
          value={selectedMonthKey !== 'all' ? selectedMonthKey : ''}
          onChange={(e) => {
            if (!e.target.value) return;
            triggerHaptic('light');
            setSelectedMonthKey(e.target.value);
            showToast(
              language === 'ar'
                ? `تم الانتقال إلى شهر ${formatMonthKeyToArabic(e.target.value)}`
                : `Switched to ${formatMonthKeyToEnglish(e.target.value)}`,
              'info'
            );
          }}
          title={language === 'ar' ? 'اختر أي شهر وسنة مخصصة' : 'Jump to any custom month & year'}
          className="bg-zinc-950 border border-indigo-500/40 rounded-xl py-1.5 px-2 text-[11px] font-mono font-bold text-indigo-200 focus:outline-none focus:border-indigo-400 cursor-pointer shrink-0 w-[132px]"
        />
      </div>

      {/* Customers List Header with VCF Import & Export & AI Camera Scan */}
      <div className="flex items-center justify-between pt-1 text-xs select-none gap-2 flex-wrap w-full min-w-0">
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 w-full min-w-0">
          <span className="font-bold text-zinc-400 shrink-0">
            {t('totalCustomers')}: ({formatNumber(filteredCustomers.length)})
          </span>

          {/* View Switcher: Cards vs Table */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-xl p-0.5 shadow-inner shrink-0">
            <button
              onClick={() => {
                triggerHaptic('light');
                setViewMode('cards');
              }}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'cards'
                  ? 'bg-indigo-600 text-white shadow-sm font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title={language === 'ar' ? 'عرض كبطاقات' : 'Cards View'}
            >
              <LayoutList className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                setViewMode('table');
              }}
              className={`p-1.5 rounded-lg transition-all ${
                viewMode === 'table'
                  ? 'bg-indigo-600 text-white shadow-sm font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title={language === 'ar' ? 'عرض كجدول تفاعلي' : 'Interactive Table View'}
            >
              <Table className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Sort Control Dropdown */}
          <div className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded-xl px-2 py-1 shadow-inner text-[11px] font-bold min-w-0 max-w-full">
            <ArrowUpDown className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <select
              value={sortBy}
              onChange={(e) => {
                triggerHaptic('light');
                setSortBy(e.target.value as any);
              }}
              className="bg-transparent text-zinc-200 font-bold focus:outline-none cursor-pointer text-[11px] min-w-0 max-w-full truncate"
              title={language === 'ar' ? 'ترتيب عرض القائمة' : 'Sort List'}
            >
              <option value="date-desc" className="bg-zinc-900 text-white">{language === 'ar' ? '📅 التاريخ (الأحدث)' : '📅 Date (Newest)'}</option>
              <option value="date-asc" className="bg-zinc-900 text-white">{language === 'ar' ? '📅 التاريخ (الأقدم)' : '📅 Date (Oldest)'}</option>
              <option value="name-asc" className="bg-zinc-900 text-white">{language === 'ar' ? '🔤 الاسم (أ - ي)' : '🔤 Name (A - Z)'}</option>
              <option value="name-desc" className="bg-zinc-900 text-white">{language === 'ar' ? '🔤 الاسم (ي - أ)' : '🔤 Name (Z - A)'}</option>
            </select>
          </div>

          {/* Customize Columns Button */}
          <button
            onClick={() => {
              triggerHaptic('light');
              setShowColumnSettingsModal(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 hover:border-zinc-700 rounded-xl text-[11px] font-bold transition-all active:scale-95 shadow-sm shrink-0"
            title={language === 'ar' ? 'تخصيص وترتيب أعمدة الجدول' : 'Customize Table Columns'}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{language === 'ar' ? 'تخصيص الأعمدة' : 'Columns'}</span>
          </button>

          {/* Bulk Multi-Select Mode Toggle */}
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              if (isSelectionMode) {
                exitSelectionMode();
              } else {
                setIsSelectionMode(true);
              }
            }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-all active:scale-95 shadow-sm shrink-0 ${
              isSelectionMode
                ? 'bg-indigo-600 text-white border-indigo-400 shadow-indigo-600/30'
                : 'bg-zinc-900 hover:bg-zinc-800 text-indigo-300 border-indigo-500/30'
            }`}
          >
            <ListChecks className="w-3.5 h-3.5 shrink-0" />
            <span>
              {isSelectionMode
                ? (language === 'ar' ? `إلغاء التحديد (${formatNumber(selectedCustomerIds.length)})` : `Done (${formatNumber(selectedCustomerIds.length)})`)
                : (language === 'ar' ? 'تحديد متعدد' : 'Multi-Select')}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap w-full">
          <button
            onClick={() => handleExportCustomersPDF()}
            disabled={isExportingPdf}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-500/15 hover:bg-rose-500/25 disabled:opacity-60 text-rose-300 border border-rose-500/40 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px] cursor-pointer"
            title={language === 'ar' ? 'تصدير وطباعة قائمة العملاء الحالية كملف PDF منظم' : 'Export filtered customers to PDF'}
          >
            {isExportingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
            <span>{language === 'ar' ? 'تصدير PDF' : 'Export PDF'}</span>
          </button>
          <button
            onClick={() => {
              triggerHaptic('light');
              setIsPrintingSheet(true);
              requestAnimationFrame(() => {
                setTimeout(() => window.print(), 60);
              });
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 border border-sky-500/40 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px] cursor-pointer"
            title={language === 'ar' ? 'طباعة تقرير العملاء الحالي بتنسيق A4 احترافي' : 'Print filtered customers as A4 report'}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'طباعة A4' : 'Print A4'}</span>
          </button>
          <button
            onClick={() => handleExportCustomersExcel()}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/40 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px] cursor-pointer"
            title={language === 'ar' ? 'تصدير قائمة العملاء إلى Excel (XLSX)' : 'Export customers to Excel'}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'Excel' : 'Excel'}</span>
          </button>
          <button
            onClick={() => {
              triggerHaptic('light');
              setShowVcfImportModal(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px]"
            title={language === 'ar' ? 'استيراد عملاء من ملف CSV (مع عمود الملاحظات Notes) أو VCF' : 'Import customers from CSV (with Notes) or VCF'}
          >
            <Contact className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'استيراد CSV / VCF' : 'Import CSV / VCF'}</span>
          </button>
          <button
            onClick={handleQuickVCFExport}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px]"
            title={t('exportVcf')}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{t('exportVcfBtn', 'تصدير VCF')}</span>
          </button>
          <button
            onClick={() => setShowScanModal(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl font-bold transition-all active:scale-95 shadow-sm text-[11px]"
            title={t('ocrScannerTab', 'مسح مستندات بكاميرا S24 Ultra')}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{t('scanDoc', 'مسح مستند')}</span>
          </button>
        </div>
      </div>

      {/* Customers List Render (Cards or Table) */}
      <div className="space-y-2.5 pt-0.5">
        {sortedCustomers.length === 0 ? (
          <div className="bento-card bg-zinc-900 border-zinc-800 p-8 text-center text-zinc-400 space-y-2">
            <div className="glow-top" />
            <Filter className="w-10 h-10 mx-auto text-zinc-600 stroke-1" />
            <div className="font-bold text-sm text-zinc-300">{t('noCustomersFound')}</div>
          </div>
        ) : viewMode === 'table' ? (
          /* Table View with Drag & Drop Draggable Header Columns */
          <div className="bento-card w-full max-w-full min-w-0 bg-zinc-900 border-zinc-800 overflow-hidden shadow-2xl rounded-2xl">
            <div className="glow-top" />
            <div className="w-full max-w-full overflow-x-auto scrollbar-thin">
              <table className={`w-full ${dir === 'rtl' ? 'text-right' : 'text-left'} text-xs border-collapse`}>
                <thead>
                  <tr className="bg-zinc-950/80 text-zinc-400 border-b border-zinc-800 text-[11px] font-bold select-none">
                    {isSelectionMode && (
                      <th className="p-2.5 w-11 text-center border-l border-zinc-800/60">
                        <button
                          type="button"
                          onClick={toggleSelectAllFiltered}
                          className="w-7 h-7 rounded-lg border border-indigo-400/50 bg-zinc-900 flex items-center justify-center mx-auto text-indigo-300"
                          title={language === 'ar' ? 'تحديد الكل' : 'Select All'}
                        >
                          {sortedCustomers.length > 0 && sortedCustomers.every((c) => c.id !== undefined && selectedCustomerSet.has(c.id))
                            ? <Check className="w-4 h-4 text-indigo-400 stroke-[3]" />
                            : <Square className="w-3.5 h-3.5 text-zinc-500" />}
                        </button>
                      </th>
                    )}
                    {visibleColumns.map((col) => (
                      <th
                        key={col.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, columns.findIndex(c => c.id === col.id))}
                        onDragOver={handleDragOver}
                        onDrop={(e) => handleDrop(e, columns.findIndex(c => c.id === col.id))}
                        className={`p-3 font-bold text-zinc-300 border-l border-zinc-800/60 last:border-l-0 ${col.minWidth || ''} cursor-grab active:cursor-grabbing hover:bg-zinc-800/50 transition-colors`}
                        title={language === 'ar' ? 'انقر واسحب لإعادة ترتيب العمود' : 'Click & drag to reorder column'}
                      >
                        <div className="flex items-center gap-1.5 justify-between">
                          <span className="truncate">{getColumnLabel(col.id)}</span>
                          <GripVertical className="w-3 h-3 text-zinc-600 shrink-0" />
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/80">
                  {visibleCustomers.map((c) => (
                    <CustomerTableRow
                      key={c.id}
                      customer={c}
                      isSelected={c.id !== undefined && selectedCustomerSet.has(c.id)}
                      isSelectionMode={isSelectionMode}
                      visibleColumns={visibleColumns}
                      points={c.id !== undefined ? (customerPointsMap.get(c.id) ?? 0) : getCustomerPoints(c)}
                      cardTypeName={c.cardTypeId ? (cardTypeMap.get(c.cardTypeId)?.name || 'Visa') : 'Visa'}
                      canDelete={permissions.canDeleteCustomer}
                      dir={dir}
                      language={language}
                      t={t}
                      formatNumber={formatNumber}
                      formatCurrency={formatCurrency}
                      formatPhone={formatPhone}
                      onToggleSelect={toggleCustomerSelection}
                      onSelect={onSelectCustomer}
                      onActivate={onActivateCustomer}
                      onDelete={handleDeleteCustomer}
                    />
                  ))}
                </tbody>
              </table>
            </div>
            <div className="p-2.5 bg-zinc-950/50 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-2 text-[10px] text-zinc-500">
              <span className="min-w-0 break-words">{language === 'ar' ? '💡 يمكنك سحب وإفلات رؤوس الجدول (Drag & Drop) لإعادة ترتيب العمود' : '💡 Drag & drop column headers to reorder table'}</span>
              <button
                onClick={() => setShowColumnSettingsModal(true)}
                className="text-amber-400 hover:underline font-bold flex items-center gap-1 shrink-0"
              >
                {language === 'ar' ? 'تخصيص وإخفاء/إظهار الأعمدة ⚙️' : 'Customize Columns ⚙️'}
              </button>
            </div>
          </div>
        ) : (
          /* Card View */
          visibleCustomers.map((c) => (
            <CustomerCardItem
              key={c.id}
              customer={c}
              isSelected={c.id !== undefined && selectedCustomerSet.has(c.id)}
              isSelectionMode={isSelectionMode}
              points={c.id !== undefined ? (customerPointsMap.get(c.id) ?? 0) : getCustomerPoints(c)}
              cardTypeName={c.cardTypeId ? (cardTypeMap.get(c.cardTypeId)?.name || 'Visa') : 'Visa'}
              canDelete={permissions.canDeleteCustomer}
              dir={dir}
              language={language}
              t={t}
              formatNumber={formatNumber}
              formatCurrency={formatCurrency}
              formatPhone={formatPhone}
              onToggleSelect={toggleCustomerSelection}
              onSelect={onSelectCustomer}
              onActivate={onActivateCustomer}
              onDelete={handleDeleteCustomer}
            />
          ))
        )}

        {/* Fast incremental pagination bar for large customer lists */}
        {hasMoreCustomers && (
          <div className="pt-2 pb-1 flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setVisibleLimit((prev) => prev + PAGE_BATCH_SIZE);
              }}
              className="px-4 py-2.5 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 rounded-2xl text-xs font-extrabold transition-colors active:scale-95"
            >
              {language === 'ar'
                ? `عرض المزيد (${formatNumber(Math.min(PAGE_BATCH_SIZE, sortedCustomers.length - visibleLimit))} من أصل ${formatNumber(sortedCustomers.length - visibleLimit)} متبقي)`
                : `Load More (${Math.min(PAGE_BATCH_SIZE, sortedCustomers.length - visibleLimit)} of ${sortedCustomers.length - visibleLimit} left)`}
            </button>
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setVisibleLimit(sortedCustomers.length);
              }}
              className="px-3 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 rounded-2xl text-xs font-bold transition-colors active:scale-95"
            >
              {language === 'ar'
                ? `عرض الكل (${formatNumber(sortedCustomers.length)})`
                : `Show All (${sortedCustomers.length})`}
            </button>
          </div>
        )}
      </div>

      {/* Sticky Thumb-Zone Bulk Action Bar */}
      {isSelectionMode && selectedCustomerIds.length > 0 && (
        <div
          className="fixed bottom-[76px] left-1/2 -translate-x-1/2 z-40 w-[calc(100%-24px)] max-w-[440px] bg-zinc-950/95 backdrop-blur-xl border border-indigo-500/50 rounded-2xl p-3 shadow-2xl shadow-black/70 space-y-2.5 animate-fadeIn no-print"
          dir={dir}
        >
          <div className="flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <span className="px-2 py-0.5 rounded-lg bg-indigo-600 text-white font-black tabular-nums">
                {formatNumber(selectedCustomerIds.length)}
              </span>
              <span className="font-extrabold text-zinc-100 truncate">
                {language === 'ar' ? 'عميل محدد' : 'selected'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={toggleSelectAllFiltered}
                className="px-2 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-indigo-300 border border-zinc-700 text-[11px] font-bold"
              >
                {sortedCustomers.length > 0 && sortedCustomers.every((c) => c.id !== undefined && selectedCustomerSet.has(c.id))
                  ? (language === 'ar' ? 'إلغاء الكل' : 'Clear')
                  : (language === 'ar' ? 'تحديد الكل' : 'Select All')}
              </button>
              <button
                type="button"
                onClick={exitSelectionMode}
                className="p-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-400 border border-zinc-800"
                title={language === 'ar' ? 'إغلاق' : 'Close'}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1.5 min-w-0">
            <select
              value={bulkStatusValue}
              onChange={(e) => setBulkStatusValue(e.target.value as CustomerStatus)}
              className="flex-1 min-w-0 bg-zinc-900 border border-zinc-700 rounded-xl py-2 px-2.5 text-xs font-bold text-white focus:outline-none focus:border-indigo-400"
            >
              {dbStatuses.map((s) => (
                <option key={s.id || s.name} value={s.name} className="bg-zinc-900 text-white">
                  {getStatusTranslation(s.name, language)}
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={isBulkProcessing}
              onClick={handleBulkStatusApply}
              className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white font-black text-xs shrink-0 active:scale-95 transition-all"
            >
              {language === 'ar' ? 'تغيير الحالة' : 'Apply'}
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={isExportingPdf}
              onClick={() => handleExportCustomersPDF(selectedCustomersList)}
              className="flex-1 py-2 px-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/35 text-[11px] font-bold flex items-center justify-center gap-1 active:scale-95"
            >
              <FileText className="w-3.5 h-3.5 shrink-0" />
              <span>PDF</span>
            </button>
            <button
              type="button"
              onClick={() => handleExportCustomersExcel(selectedCustomersList)}
              className="flex-1 py-2 px-2.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/35 text-[11px] font-bold flex items-center justify-center gap-1 active:scale-95"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" />
              <span>Excel</span>
            </button>
            {permissions.canDeleteCustomer && (
              <button
                type="button"
                disabled={isBulkProcessing}
                onClick={() => setShowBulkDeleteConfirm(true)}
                className="flex-1 py-2 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-black flex items-center justify-center gap-1 active:scale-95 shadow-md shadow-rose-600/25"
              >
                <Trash2 className="w-3.5 h-3.5 shrink-0" />
                <span>{language === 'ar' ? 'حذف المحدد' : 'Delete'}</span>
              </button>
            )}
          </div>
        </div>
      )}

      {showScanModal && (
        <Suspense fallback={null}>
          <CameraScanModal onClose={() => setShowScanModal(false)} />
        </Suspense>
      )}

      {/* VCF Contact List Import Modal */}
      {showVcfImportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-2.5 sm:p-4 overflow-x-hidden">
          <div className={`bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-lg min-w-0 overflow-x-hidden p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <div className="glow-top" />
            
            {/* Modal Header */}
            <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800 shrink-0 min-w-0">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20 shrink-0">
                  <Contact className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-extrabold text-sm text-white break-words">
                    {language === 'ar' ? 'استيراد العملاء من ملف CSV / VCF' : 'Import Customers from CSV / VCF'}
                  </h3>
                  <p className="text-[11px] text-zinc-400 break-words">
                    {language === 'ar'
                      ? 'يدعم استيراد عمود الملاحظات (Notes / ملاحظات) وحفظها مباشرة في سجل العميل'
                      : 'Supports dedicated Notes column and saves directly into customer records'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  triggerHaptic('light');
                  setShowVcfImportModal(false);
                  setVcfFile(null);
                  setParsedVcfCustomers([]);
                  setCsvDetectedNotesInfo(null);
                  setSelectedVcfIndices([]);
                  setImportGeneralNotes('');
                }}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* File Upload Zone (If no file picked or parsed) */}
            {parsedVcfCustomers.length === 0 ? (
              <div className="py-4 px-2 sm:px-4 space-y-4 overflow-y-auto">
                <div className="border-2 border-dashed border-amber-500/30 hover:border-amber-400 rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all bg-zinc-950/60 relative group">
                  <Upload className="w-12 h-12 mx-auto text-amber-400 mb-3 group-hover:scale-110 transition-transform" />
                  <div className="font-bold text-xs text-white mb-1">
                    {t('chooseVcfFile', 'اضغط لاختيار ملف جهات الاتصال (.vcf / .csv)')}
                  </div>
                  <div className="text-[11px] text-zinc-400">
                    {language === 'ar'
                      ? 'يدعم ملفات CSV (مع عمود الملاحظات Notes / ملاحظات)، VCF، Excel، TXT'
                      : 'Supports CSV (with Notes column), VCF, Excel, TXT (.csv, .vcf, .txt)'}
                  </div>
                  <input
                    type="file"
                    accept=".vcf,.vcard,.csv,.txt,.tsv,text/vcard,text/csv"
                    onChange={handleVcfFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2.5 bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl">
                  <div className="text-xs text-amber-200 min-w-0 flex-1">
                    <div className="font-bold">{language === 'ar' ? 'هل ترغب بتجربة الاستيراد بملف جاهز؟' : 'Want to try importing with a sample file?'}</div>
                    <div className="text-[11px] text-amber-300/80 break-words">{language === 'ar' ? 'حمل نموذج CSV متضمناً: رقم ملف العميل، الاسم، الهوية، الجوال، البطاقة، الراتب، والملاحظات' : 'Download sample CSV with File #, Name, ID, Phone, Card, Salary, and Notes'}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      downloadSampleCSVTemplate();
                      showToast(language === 'ar' ? 'تم تحميل نموذج الملف التجريبي بنجاح 📄✨' : 'Sample CSV downloaded successfully 📄✨', 'success');
                    }}
                    className="shrink-0 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                  >
                    <Download className="w-4 h-4 shrink-0" />
                    <span>{language === 'ar' ? 'تحميل نموذج CSV' : 'Download Sample CSV'}</span>
                  </button>
                </div>

                <div className="bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 text-xs text-zinc-400 space-y-1.5">
                  <div className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 shrink-0" />
                    <span>{language === 'ar' ? 'خطوات تصدير الملف من جوال سامسونج S24:' : 'Export steps on Samsung Galaxy / Android:'}</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-zinc-400 pr-1">
                    {language === 'ar' ? (
                      <>
                        <li>افتح تطبيق <b>جهات الاتصال (Contacts)</b> في سامسونج.</li>
                        <li>اضغط على القائمة (☰) ثم اختَر <b>إدارة جهات الاتصال (Manage contacts)</b>.</li>
                        <li>اختر <b>استيراد أو تصدير جهات الاتصال (Import/Export)</b>.</li>
                        <li>اضغط <b>تصدير إلى ملف VCF</b> واعتمد حفظ الملف.</li>
                        <li>قم برفع هذا الملف هنا مباشرة لربط عملائك بالتطبيق!</li>
                      </>
                    ) : (
                      <>
                        <li>Open the <b>Contacts</b> app on your phone.</li>
                        <li>Tap the menu (☰) and select <b>Manage contacts</b>.</li>
                        <li>Select <b>Import or export contacts</b>.</li>
                        <li>Tap <b>Export contacts to VCF</b> and save the file.</li>
                        <li>Upload that file here to import all your contacts!</li>
                      </>
                    )}
                  </ol>
                </div>
              </div>
            ) : (
              /* Parsed Contacts Preview & Configuration List */
              <div className="space-y-3 overflow-hidden flex flex-col flex-1 min-w-0">
                {/* Configuration Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 text-xs shrink-0">
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">
                      {language === 'ar' ? 'نوع المنتج الافتراضي:' : 'Default Product:'}
                    </label>
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => setImportProductType('visa')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition-all flex items-center justify-center gap-1 ${
                          importProductType === 'visa'
                            ? 'bg-indigo-600 text-white border-indigo-500'
                            : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        <CreditCard className="w-3 h-3" />
                        <span>Visa</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setImportProductType('finance')}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition-all flex items-center justify-center gap-1 ${
                          importProductType === 'finance'
                            ? 'bg-emerald-600 text-white border-emerald-500'
                            : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        <DollarSign className="w-3 h-3" />
                        <span>{t('financeProduct')}</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">
                      {language === 'ar' ? 'الحالة الأولية:' : 'Initial Status:'}
                    </label>
                    <select
                      value={importStatus}
                      onChange={(e) => setImportStatus(e.target.value as CustomerStatus)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-1.5 px-2 text-[11px] font-bold text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="عميل محتمل">{getStatusTranslation('عميل محتمل', language)}</option>
                      <option value="عميل معلق">{getStatusTranslation('عميل معلق', language)}</option>
                      <option value="تم التنفيذ">{getStatusTranslation('تم التنفيذ', language)}</option>
                      <option value="تم التفعيل">{getStatusTranslation('تم التفعيل', language)}</option>
                    </select>
                  </div>
                </div>

                {/* Target Work Month Selection Block (Any Month / Any Year) */}
                <div className="bg-indigo-950/70 border border-indigo-500/40 p-3 rounded-2xl space-y-2">
                  <label className="text-[11px] font-bold text-indigo-200 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{t('targetMonthLabel', 'الشهر المستهدف لإدراج هذه الداتا بالكامل')}:</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <select
                      value={importTargetMonth}
                      onChange={(e) => setImportTargetMonth(e.target.value)}
                      className="w-full bg-zinc-950 border border-indigo-500/40 rounded-xl py-2 px-2.5 text-xs font-bold text-indigo-100 focus:outline-none focus:border-indigo-400 cursor-pointer shadow-sm"
                    >
                      {getAvailableMonthOptions(customers, [importTargetMonth]).filter(m => m.key !== 'all').map((m) => (
                        <option key={m.key} value={m.key}>
                          {language === 'ar' ? m.labelAr : m.labelEn} {m.isCurrent ? (language === 'ar' ? '(الشهر الحالي)' : '(Current Month)') : ''}
                        </option>
                      ))}
                    </select>
                    <input
                      type="month"
                      value={importTargetMonth !== 'all' ? importTargetMonth : ''}
                      onChange={(e) => {
                        if (e.target.value) setImportTargetMonth(e.target.value);
                      }}
                      title={language === 'ar' ? 'أو اختر أي شهر وسنة مخصصة' : 'Or pick any custom year & month'}
                      className="w-full bg-zinc-950 border border-indigo-500/40 rounded-xl py-1.5 px-2.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                  <p className="text-[10px] text-indigo-300/80">
                    {language === 'ar'
                      ? 'يمكنك اختيار أي شهر وسنة (سابق أو حالي أو مستقبلي) لإدراج كامل ملف البيانات فيه مباشرة.'
                      : 'Choose any past, current, or future month & year to import this entire dataset into.'}
                  </p>
                </div>

                {/* CSV Columns Detection Status Banner (File Number + Notes) */}
                {csvDetectedNotesInfo && (
                  <div className="space-y-1.5 shrink-0">
                    <div className={`p-2.5 rounded-2xl border text-[11px] flex items-center justify-between gap-2 flex-wrap ${
                      csvDetectedNotesInfo.detectedFileNumberColumn || (csvDetectedNotesInfo.withFileNumberCount ?? 0) > 0
                        ? 'bg-indigo-500/10 border-indigo-500/35 text-indigo-200'
                        : 'bg-zinc-950/70 border-zinc-800 text-zinc-400'
                    }`}>
                      <div className="flex items-center gap-1.5 min-w-0 flex-1">
                        <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span className="font-bold break-words">
                          {csvDetectedNotesInfo.detectedFileNumberColumn
                            ? (language === 'ar'
                                ? `تم ربط عمود رقم ملف العميل (${csvDetectedNotesInfo.fileNumberColumnName}) — ${formatNumber(csvDetectedNotesInfo.withFileNumberCount ?? 0)} من ${formatNumber(parsedVcfCustomers.length)} عميل ✓`
                                : `Customer File # column linked (${csvDetectedNotesInfo.fileNumberColumnName}) — ${formatNumber(csvDetectedNotesInfo.withFileNumberCount ?? 0)} of ${formatNumber(parsedVcfCustomers.length)} ✓`)
                            : (language === 'ar'
                                ? 'يمكنك كتابة أو تعديل «رقم ملف العميل» لكل صف أدناه (أو إضافة عمود: رقم ملف العميل / FileNo / CIF في CSV)'
                                : 'You can edit Customer File # per row below (or include FileNo / CIF column in CSV)')}
                        </span>
                      </div>
                    </div>

                    <div className={`p-2.5 rounded-2xl border text-[11px] flex items-center justify-between gap-2 flex-wrap ${
                      csvDetectedNotesInfo.detectedColumn || csvDetectedNotesInfo.withNotesCount > 0
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                        : 'bg-zinc-950/70 border-zinc-800 text-zinc-300'
                    }`}>
                      <div className="flex items-center gap-1.5 min-w-0 flex-1">
                        <FileText className={`w-3.5 h-3.5 shrink-0 ${csvDetectedNotesInfo.detectedColumn || csvDetectedNotesInfo.withNotesCount > 0 ? 'text-emerald-400' : 'text-amber-400'}`} />
                        <span className="font-bold break-words">
                          {csvDetectedNotesInfo.detectedColumn
                            ? (language === 'ar'
                                ? `تم ربط عمود الملاحظات (${csvDetectedNotesInfo.columnNames.join(' / ')}) — ${formatNumber(csvDetectedNotesInfo.withNotesCount)} من ${formatNumber(parsedVcfCustomers.length)} عميل يحتوي على ملاحظات`
                                : `Notes column linked (${csvDetectedNotesInfo.columnNames.join(' / ')}) — ${formatNumber(csvDetectedNotesInfo.withNotesCount)} of ${formatNumber(parsedVcfCustomers.length)} have notes`)
                            : (language === 'ar'
                                ? 'يمكنك إضافة أو تعديل حقل الملاحظات (Notes) لكل عميل أدناه قبل الحفظ'
                                : 'You can add or edit the Notes field for each customer below before saving')}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* General Batch Notes Input */}
                <div className="bg-zinc-950/80 border border-zinc-800 p-3 rounded-2xl space-y-1.5 shrink-0">
                  <label className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-amber-400" />
                    <span>
                      {language === 'ar'
                        ? 'ملاحظة عامة تضاف لجميع العملاء المستوردين (اختياري):'
                        : 'General note added to all imported customers (optional):'}
                    </span>
                  </label>
                  <input
                    type="text"
                    value={importGeneralNotes}
                    onChange={(e) => setImportGeneralNotes(e.target.value)}
                    placeholder={
                      language === 'ar'
                        ? 'مثال: حملة نوفمبر، عملاء فرع الرياض...'
                        : 'e.g., November campaign, Riyadh branch...'
                    }
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-1.5 px-2.5 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                {/* Duplicate Phone Warning & Auto-Skip Toggle */}
                {vcfDuplicateCount > 0 && (
                  <div className="p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/40 text-xs space-y-2 shrink-0">
                    <div className="flex items-center gap-2 text-amber-200 font-bold">
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>
                        {language === 'ar'
                          ? `تم اكتشاف ${formatNumber(vcfDuplicateCount)} رقم جوال مكرر في الملف`
                          : `Detected ${formatNumber(vcfDuplicateCount)} duplicate phone numbers`}
                      </span>
                    </div>
                    <label className="flex items-center gap-2 text-[11px] text-amber-100 font-bold cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={skipDuplicatePhones}
                        onChange={(e) => setSkipDuplicatePhones(e.target.checked)}
                        className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                      />
                      <span>
                        {language === 'ar'
                          ? 'تخطي الأرقام المكررة تلقائياً عند الحفظ'
                          : 'Automatically skip duplicate numbers on import'}
                      </span>
                    </label>
                  </div>
                )}

                {/* Contacts Selection Toolbar */}
                <div className="flex items-center justify-between text-xs font-bold text-zinc-300 px-1 shrink-0">
                  <span>
                    {language === 'ar'
                      ? `تم تحديد (${formatNumber(selectedVcfIndices.length)} من أصل ${formatNumber(parsedVcfCustomers.length)})`
                      : `Selected (${formatNumber(selectedVcfIndices.length)} of ${formatNumber(parsedVcfCustomers.length)})`}
                  </span>
                  <button
                    type="button"
                    onClick={toggleSelectAllVcf}
                    className="text-amber-400 hover:text-amber-300 text-[11px] flex items-center gap-1"
                  >
                    {selectedVcfIndices.length === parsedVcfCustomers.length ? (
                      <>
                        <CheckSquare className="w-3.5 h-3.5" />
                        <span>{language === 'ar' ? 'إلغاء تحديد الكل' : 'Deselect All'}</span>
                      </>
                    ) : (
                      <>
                        <Square className="w-3.5 h-3.5" />
                        <span>{language === 'ar' ? 'تحديد الكل' : 'Select All'}</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Scrollable list of parsed contacts */}
                <div className="overflow-y-auto max-h-[38vh] space-y-2 pr-1 scrollbar-thin scrollbar-thumb-zinc-800 flex-1">
                  {parsedVcfCustomers.map((cust, idx) => {
                    const isSelected = selectedVcfIndices.includes(idx);
                    const dupeMeta = vcfDuplicateStatusByIndex[idx];
                    return (
                      <div
                        key={idx}
                        onClick={() => toggleVcfSelection(idx)}
                        className={`p-2.5 rounded-2xl border transition-all cursor-pointer space-y-2 text-xs ${
                          dupeMeta?.isDuplicate && skipDuplicatePhones
                            ? 'bg-amber-950/20 border-amber-500/35 opacity-75'
                            : isSelected
                            ? 'bg-amber-500/10 border-amber-500/30 text-white'
                            : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className={`w-5 h-5 rounded-lg flex items-center justify-center border transition-colors shrink-0 ${
                              isSelected ? 'bg-amber-500 border-amber-400 text-zinc-950' : 'border-zinc-700 bg-zinc-900'
                            }`}>
                              {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-zinc-100 flex flex-wrap items-center gap-1.5">
                                <span className="truncate">{cust.name}</span>
                                {dupeMeta?.isDuplicate && (
                                  <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-[10px] font-black border border-amber-500/40 flex items-center gap-1">
                                    <AlertTriangle className="w-3 h-3 shrink-0" />
                                    <span>
                                      {dupeMeta.existingName
                                        ? (language === 'ar' ? `جوال مكرر (${dupeMeta.existingName})` : `Duplicate (${dupeMeta.existingName})`)
                                        : (language === 'ar' ? 'مكرر بالملف' : 'Duplicate in file')}
                                    </span>
                                  </span>
                                )}
                                {cust.orderNumber && !String(cust.orderNumber).startsWith('VCF-') && (
                                  <span className="bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border border-indigo-500/35">
                                    📁 #{cust.orderNumber}
                                  </span>
                                )}
                                {cust.idNumber && (
                                  <span className="bg-sky-500/15 text-sky-300 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border border-sky-500/30">
                                    🆔 {cust.idNumber}
                                  </span>
                                )}
                                {cust.cardTypeName && (
                                  <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-[10px] font-bold border border-amber-500/30">
                                    💳 {cust.cardTypeName}
                                  </span>
                                )}
                                {cust.salary !== undefined && cust.salary !== null && (
                                  <span className="bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold border border-emerald-500/30">
                                    💵 {formatCurrency(cust.salary)}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-wrap items-center gap-2 mt-0.5">
                                <span className="text-[10px] text-zinc-400 font-mono dir-ltr">{formatPhone(cust.phone)}</span>
                                <div onClick={(e) => e.stopPropagation()} className="flex items-center gap-1">
                                  <span className="text-[9px] text-indigo-300 font-bold">{language === 'ar' ? 'رقم الملف:' : 'File #:'}</span>
                                  <input
                                    type="text"
                                    value={cust.orderNumber && !String(cust.orderNumber).startsWith('VCF-') ? cust.orderNumber : ''}
                                    onChange={(e) => updateParsedVcfCustomerFileNo(idx, e.target.value)}
                                    placeholder={language === 'ar' ? 'تلقائي' : 'Auto'}
                                    className="w-24 bg-zinc-900/90 border border-indigo-500/30 rounded px-1.5 py-0.5 text-[10px] font-mono text-indigo-200 placeholder:text-zinc-600 focus:outline-none focus:border-indigo-400"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>

                          {cust.email && (
                            <span className="text-[10px] text-zinc-500 max-w-[100px] truncate hidden sm:inline shrink-0">
                              {cust.email}
                            </span>
                          )}
                        </div>

                        {/* Dedicated Per-Customer Notes (CSV) Field */}
                        <div
                          onClick={(e) => e.stopPropagation()}
                          className={`rounded-xl p-2 border transition-colors space-y-1 ${
                            cust.notes && cust.notes.trim()
                              ? 'bg-emerald-950/25 border-emerald-500/35 focus-within:border-emerald-400'
                              : 'bg-zinc-950/80 border-zinc-800/90 focus-within:border-amber-500/50'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 text-[10px]">
                            <span className="font-bold text-amber-300 flex items-center gap-1">
                              <FileText className="w-3 h-3 text-amber-400 shrink-0" />
                              <span>{language === 'ar' ? 'الملاحظات (Notes):' : 'Notes:'}</span>
                            </span>
                            {cust.hasNotesFromFile && cust.notes && cust.notes.trim() && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[9px] shrink-0">
                                {language === 'ar' ? 'من ملف CSV ✓' : 'From CSV ✓'}
                              </span>
                            )}
                          </div>
                          <textarea
                            rows={cust.notes && cust.notes.length > 55 ? 2 : 1}
                            value={cust.notes || ''}
                            onChange={(e) => updateParsedVcfCustomerNotes(idx, e.target.value)}
                            placeholder={
                              language === 'ar'
                                ? 'أضف أو عدّل ملاحظات هذا العميل...'
                                : 'Add or edit notes for this customer...'
                            }
                            className="w-full bg-transparent text-[11px] text-zinc-100 placeholder:text-zinc-500 focus:outline-none resize-none leading-relaxed"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Modal Actions */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-800 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setParsedVcfCustomers([]);
                      setVcfFile(null);
                      setCsvDetectedNotesInfo(null);
                      setSelectedVcfIndices([]);
                      setImportGeneralNotes('');
                    }}
                    className="py-2.5 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold border border-zinc-700 transition-all"
                  >
                    {language === 'ar' ? 'تغيير الملف' : 'Change File'}
                  </button>

                  <button
                    type="button"
                    disabled={isImporting || selectedVcfIndices.length === 0}
                    onClick={handleConfirmVcfImport}
                    className="flex-1 min-w-[140px] bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-extrabold py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-amber-500/20 active:scale-98 disabled:opacity-50"
                  >
                    <UserCheck className="w-4 h-4 shrink-0" />
                    <span>
                      {isImporting
                        ? (language === 'ar' ? 'جاري الاستيراد...' : 'Importing...')
                        : (language === 'ar' ? `تأكيد استيراد (${formatNumber(selectedVcfIndices.length)}) عميل` : `Confirm Import (${formatNumber(selectedVcfIndices.length)})`)}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {/* Column Customization Modal */}
      {showColumnSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-x-hidden animate-fadeIn">
          <div className={`bg-zinc-900 border border-zinc-800 rounded-3xl max-w-md w-full min-w-0 overflow-x-hidden p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <div className="flex items-center justify-between gap-2 border-b border-zinc-800 pb-3 min-w-0">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20 shrink-0">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-extrabold text-sm text-white break-words">
                    {language === 'ar' ? 'تخصيص وترتيب أعمدة الجدول' : 'Customize Table Columns'}
                  </h3>
                  <p className="text-[11px] text-zinc-400 break-words">
                    {language === 'ar' ? 'اسحب وأسقط (Drag & Drop) أو استخدم الأسهم للترتيب، وفّعّل الأعمدة المراد عرضها' : 'Drag & drop or use arrows to order, toggle visibility'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowColumnSettingsModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 overflow-y-auto overflow-x-hidden flex-1 pr-1 scrollbar-thin">
              {columns.map((col, idx) => (
                <div
                  key={col.id}
                  draggable
                  onDragStart={(e) => handleDragStart(e, idx)}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, idx)}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-2 min-w-0 text-xs ${
                    col.visible
                      ? 'bg-zinc-950/80 border-zinc-800 text-white hover:border-indigo-500/40'
                      : 'bg-zinc-950/40 border-zinc-800/40 text-zinc-500'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div className="cursor-grab active:cursor-grabbing text-zinc-500 hover:text-zinc-300 p-1 shrink-0">
                      <GripVertical className="w-4 h-4" />
                    </div>
                    <button
                      onClick={() => toggleColumnVisibility(col.id)}
                      className={`p-1.5 rounded-xl border transition-all shrink-0 ${
                        col.visible
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-zinc-800 text-zinc-500 border-zinc-700'
                      }`}
                      title={col.visible ? (language === 'ar' ? 'إخفاء العمود' : 'Hide Column') : (language === 'ar' ? 'إظهار العمود' : 'Show Column')}
                    >
                      {col.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    </button>
                    <span className="font-bold text-xs truncate">{getColumnLabel(col.id)}</span>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      disabled={idx === 0}
                      onClick={() => moveColumn(idx, idx - 1)}
                      className="p-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-zinc-300 rounded-lg border border-zinc-700/60"
                      title={language === 'ar' ? 'تحريك لأعلى' : 'Move Up'}
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      disabled={idx === columns.length - 1}
                      onClick={() => moveColumn(idx, idx + 1)}
                      className="p-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-30 text-zinc-300 rounded-lg border border-zinc-700/60"
                      title={language === 'ar' ? 'تحريك لأسفل' : 'Move Down'}
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-zinc-800">
              <button
                type="button"
                onClick={resetColumnsToDefault}
                className="py-2 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold border border-zinc-700 transition-all flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                <span>{language === 'ar' ? 'إعادة الافتراضي' : 'Reset Defaults'}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowColumnSettingsModal(false)}
                className="py-2 px-5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl text-xs transition-all shadow-md active:scale-95"
              >
                {t('saveAndClose', 'حفظ وإغلاق')}
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!customerToDelete}
        title={language === 'ar' ? 'تأكيد حذف العميل' : 'Confirm Customer Deletion'}
        message={language === 'ar' ? `هل أنت متأكد من حذف العميل "${customerToDelete?.name}" وجميع البيانات والمهام والمرتبطة به نهائياً؟` : `Are you sure you want to permanently delete customer "${customerToDelete?.name}" and all associated data?`}
        confirmText={language === 'ar' ? 'نعم، حذف العميل 🗑️' : 'Yes, Delete Customer 🗑️'}
        cancelText={t('cancel', 'إلغاء')}
        isDanger={true}
        onConfirm={confirmDeleteCustomer}
        onCancel={() => setCustomerToDelete(null)}
      />

      <ConfirmModal
        isOpen={showBulkDeleteConfirm}
        title={language === 'ar' ? 'تأكيد الحذف الجماعي للعملاء' : 'Confirm Bulk Customer Deletion'}
        message={
          language === 'ar'
            ? `هل أنت متأكد من حذف (${formatNumber(selectedCustomerIds.length)}) عميل وجميع المهام وسجلات النقاط المرتبطة بهم نهائياً؟`
            : `Are you sure you want to permanently delete (${formatNumber(selectedCustomerIds.length)}) selected customers and all their associated records?`
        }
        confirmText={language === 'ar' ? `نعم، حذف (${formatNumber(selectedCustomerIds.length)}) عميل 🗑️` : `Yes, Delete (${formatNumber(selectedCustomerIds.length)}) 🗑️`}
        cancelText={t('cancel', 'إلغاء')}
        isDanger={true}
        onConfirm={handleBulkDeleteConfirm}
        onCancel={() => setShowBulkDeleteConfirm(false)}
      />
      </div>

      {/* Print-Only Professional A4 Customer List Report (mounted on demand for printing) */}
      {isPrintingSheet && (
        <PrintableReportSheet
          mode="print-only"
          reportTitle={
            selectedStatus === 'all'
              ? (language === 'ar' ? 'تقرير قائمة العملاء' : 'Customers List Report')
              : (language === 'ar'
                  ? `تقرير قائمة العملاء — ${getStatusTranslation(selectedStatus, language)}`
                  : `Customers Report — ${getStatusTranslation(selectedStatus, language)}`)
          }
          companyName={settings?.companyName}
          repName={currentUser?.username}
          cycleLabel={
            selectedMonthKey === 'all'
              ? (language === 'ar' ? 'جميع الشهور' : 'All Months')
              : (language === 'ar' ? formatMonthKeyToArabic(selectedMonthKey) : formatMonthKeyToEnglish(selectedMonthKey))
          }
          statusLabel={
            selectedStatus === 'all'
              ? (language === 'ar' ? 'جميع الحالات' : 'All Statuses')
              : getStatusTranslation(selectedStatus, language)
          }
          extraFilterNote={
            [
              selectedProduct !== 'all'
                ? (selectedProduct === 'visa' ? (language === 'ar' ? 'بطاقات Visa' : 'Visa Cards') : (language === 'ar' ? 'تمويل شخصي' : 'Personal Finance'))
                : null,
              searchTerm.trim() ? `"${searchTerm.trim()}"` : null,
            ]
              .filter(Boolean)
              .join(' • ') || undefined
          }
          reportType="customers"
          customers={sortedCustomers}
          getCardTypeName={getCardTypeName}
          footerText={t('systemGeneratedReportFooter', 'تم استخراج هذا التقرير تلقائياً من نظام إدارة المبيعات Sales CRM')}
        />
      )}
    </div>
  );
});
