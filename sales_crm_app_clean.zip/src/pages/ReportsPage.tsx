import React, { useState, useMemo, useEffect, useCallback, Suspense } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, calculateCardPoints, calculatePoints } from '../db/db';
import { useToast } from '../components/Toast';
import { useLanguage } from '../context/LanguageContext';
import { getStatusTranslation, getFinanceTypeTranslation } from '../utils/translations';
import { CheckCircle2, Clock, AlertTriangle, CreditCard, DollarSign, BarChart3, Award, FileSpreadsheet, Printer, X, ChevronRight, Ban, Eye, Sliders, Sparkles, Target, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, PieChart as PieChartIcon, Calendar, Archive, Download, FileText, Check, Filter, RotateCcw, Table as TableIcon, Loader2 } from 'lucide-react';
import type { Customer, PointLog, CardType, SalaryTier, StatusConfig } from '../types';
import { PrintableReportSheet } from '../components/PrintableReportSheet';
import { useAuth } from '../context/AuthContext';
import { getCurrentMonthKey, getCustomerMonthKey, formatMonthKeyToArabic, formatMonthKeyToEnglish, MonthlySnapshot } from '../utils/monthRollover';
import { exportReportToPDF, type PdfAccent, type PdfCell, type PdfSummaryCard } from '../utils/pdfExport';
import { lazyWithRetry } from '../utils/lazyWithRetry';
import { sanitizeCsvCell, sanitizeSpreadsheetValue, sanitizeDownloadFilename } from '../utils/security';
import { saveOrShareBlob, saveWorkbookNativeOrWeb, isNativeCapacitor } from '../utils/nativeMobile';

const CustomReportBuilderModal = lazyWithRetry(() =>
  import('../components/CustomReportBuilderModal').then((m) => ({ default: m.CustomReportBuilderModal }))
);

const EMPTY_CUSTOMERS: Customer[] = [];
const EMPTY_POINTS_LOG: PointLog[] = [];
const EMPTY_CARD_TYPES: CardType[] = [];
const EMPTY_SALARY_TIERS: SalaryTier[] = [];
const EMPTY_STATUSES: StatusConfig[] = [];
const REPORT_TABLE_BATCH_SIZE = 50;

interface ReportSummaryCardProps {
  id: string;
  icon: React.ReactNode;
  title: string;
  color: string;
  formattedCount: string;
  dir: 'rtl' | 'ltr';
  onSelect: (id: string) => void;
}

const ReportSummaryCard: React.FC<ReportSummaryCardProps> = React.memo(
  ({ id, icon, title, color, formattedCount, dir, onSelect }) => (
    <button
      onClick={() => onSelect(id)}
      className={`bento-card min-w-0 w-full p-3.5 sm:p-4 transition-transform active:scale-98 flex flex-col justify-between shadow-lg ${color} ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
    >
      <div className="glow-top" />
      <div className="flex items-center justify-between gap-2 w-full mb-3 min-w-0">
        <div className="p-2 rounded-xl bg-zinc-950/70 border border-zinc-800 shrink-0">{icon}</div>
        <span className="text-xl font-light text-white tracking-tight truncate">{formattedCount}</span>
      </div>
      <div className="font-bold text-xs text-zinc-200 break-words leading-snug">{title}</div>
    </button>
  )
);

interface ReportTableRowProps {
  customer: Customer;
  rowIndexLabel: string;
  formattedPhone: string;
  productLabel: string;
  valueLabel: string;
  statusBadgeClass: string;
  statusLabel: string;
}

const ReportTableRow: React.FC<ReportTableRowProps> = React.memo(
  ({ customer, rowIndexLabel, formattedPhone, productLabel, valueLabel, statusBadgeClass, statusLabel }) => (
    <tr className="hover:bg-zinc-800/40 transition-colors">
      <td className="p-2.5 text-center font-mono text-zinc-500">{rowIndexLabel}</td>
      <td className="p-2.5 whitespace-nowrap">
        <div className="font-bold text-zinc-100">{customer.name}</div>
        <div className="text-[10px] text-zinc-500 font-mono dir-ltr">{formattedPhone}</div>
      </td>
      <td className="p-2.5 whitespace-nowrap text-zinc-300">{productLabel}</td>
      <td className="p-2.5 whitespace-nowrap font-mono font-bold text-emerald-400">{valueLabel}</td>
      <td className="p-2.5 whitespace-nowrap text-center">
        <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border inline-block ${statusBadgeClass}`}>
          {statusLabel}
        </span>
      </td>
      <td className="p-2.5 max-w-[160px] truncate text-zinc-400" title={customer.notes || ''}>
        {customer.notes || '-'}
      </td>
    </tr>
  )
);

interface ReportDetailCustomerItemProps {
  customer: Customer;
  formattedPhone: string;
  cardTypeName: string | null;
  financeTypeLabel: string;
  financeRateLabel: string | null;
  statusBadgeClass: string;
  statusLabel: string;
  amountLabel: string;
  pointsLabel: string | null;
  dir: 'rtl' | 'ltr';
}

const ReportDetailCustomerItem: React.FC<ReportDetailCustomerItemProps> = React.memo(
  ({
    customer,
    formattedPhone,
    cardTypeName,
    financeTypeLabel,
    financeRateLabel,
    statusBadgeClass,
    statusLabel,
    amountLabel,
    pointsLabel,
    dir,
  }) => (
    <div className="cv-auto p-3 bg-zinc-950/60 border border-zinc-800 rounded-2xl flex items-center justify-between gap-2 min-w-0 text-xs">
      <div className="space-y-0.5 min-w-0 flex-1">
        <div className="font-bold text-zinc-100 flex flex-wrap items-center gap-1.5">
          <span className="break-words">{customer.name}</span>
          {customer.orderNumber && <span className="text-[10px] text-indigo-400 font-mono font-normal">#{customer.orderNumber}</span>}
        </div>
        <div className="text-[10px] text-zinc-500 font-mono dir-ltr truncate">{formattedPhone}</div>
        {customer.productType === 'visa' && cardTypeName && (
          <div className="text-[11px] font-bold text-indigo-300 flex items-center gap-1 mt-1 min-w-0">
            <CreditCard className="w-3 h-3 text-indigo-400 shrink-0" />
            <span className="truncate">{cardTypeName}</span>
          </div>
        )}
        {customer.productType === 'finance' && (
          <div className="text-[11px] font-bold text-emerald-300 flex flex-wrap items-center gap-1 mt-1">
            <DollarSign className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>{financeTypeLabel}</span>
            {financeRateLabel && <span className="text-[10px] text-zinc-400 font-mono">({financeRateLabel})</span>}
          </div>
        )}
      </div>
      <div className={`flex flex-col ${dir === 'rtl' ? 'items-end' : 'items-start'} gap-1 shrink-0`}>
        <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${statusBadgeClass}`}>
          {statusLabel}
        </span>
        <span className="text-[11px] font-mono text-zinc-400">{amountLabel}</span>
        {pointsLabel && <span className="text-[10px] font-bold text-amber-400 font-mono">{pointsLabel}</span>}
      </div>
    </div>
  )
);

export const ReportsPage: React.FC = React.memo(() => {
  const currentMonthKey = getCurrentMonthKey();
  const [selectedMonthKey, setSelectedMonthKey] = useState<string>(currentMonthKey);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [activeReport, setActiveReport] = useState<string | null>(null);
  const [isCustomBuilderOpen, setIsCustomBuilderOpen] = useState<boolean>(false);
  const [isPrintPreviewModalOpen, setIsPrintPreviewModalOpen] = useState<boolean>(false);
  const [isBrowserPrinting, setIsBrowserPrinting] = useState<boolean>(false);
  const [printPreviewReportId, setPrintPreviewReportId] = useState<string>('executedOrders');
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [tableVisibleLimit, setTableVisibleLimit] = useState<number>(REPORT_TABLE_BATCH_SIZE);
  const [modalVisibleLimit, setModalVisibleLimit] = useState<number>(REPORT_TABLE_BATCH_SIZE);
  const { showToast } = useToast();
  const { t, formatNumber, formatCurrency, formatPhone, dir, language } = useLanguage();
  const { settings, currentUser } = useAuth();

  useEffect(() => {
    setTableVisibleLimit(REPORT_TABLE_BATCH_SIZE);
  }, [selectedMonthKey, selectedStatusFilter]);

  useEffect(() => {
    setModalVisibleLimit(REPORT_TABLE_BATCH_SIZE);
  }, [activeReport, selectedMonthKey, selectedStatusFilter]);

  const handleOpenReport = useCallback((reportId: string) => {
    setActiveReport(reportId);
  }, []);

  useEffect(() => {
    const onBeforePrint = () => setIsBrowserPrinting(true);
    const onAfterPrint = () => setIsBrowserPrinting(false);
    window.addEventListener('beforeprint', onBeforePrint);
    window.addEventListener('afterprint', onAfterPrint);
    return () => {
      window.removeEventListener('beforeprint', onBeforePrint);
      window.removeEventListener('afterprint', onAfterPrint);
    };
  }, []);

  const customers = useLiveQuery(() => db.customers.toArray(), []) ?? EMPTY_CUSTOMERS;
  const pointsLog = useLiveQuery(() => db.pointsLog.toArray(), []) ?? EMPTY_POINTS_LOG;
  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) ?? EMPTY_CARD_TYPES;
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) ?? EMPTY_SALARY_TIERS;
  const rawStatuses = useLiveQuery(() => db.statuses.orderBy('order').toArray(), []) ?? EMPTY_STATUSES;
  const snapshotsSetting = useLiveQuery(() => db.settings.get('monthlySnapshots'), []);

  const cardTypeMap = useMemo(() => {
    const map = new Map<number, CardType>();
    for (const ct of cardTypes) {
      if (ct.id !== undefined) map.set(ct.id, ct);
    }
    return map;
  }, [cardTypes]);

  const savedSnapshots: MonthlySnapshot[] = useMemo(() => {
    try {
      return snapshotsSetting?.value ? JSON.parse(snapshotsSetting.value) : [];
    } catch {
      return [];
    }
  }, [snapshotsSetting]);

  // Build available month keys list
  const availableMonthKeys = useMemo(() => {
    const keysSet = new Set<string>();
    keysSet.add(currentMonthKey);

    // Compute previous month key so it is always selectable
    const [cYrStr, cMoStr] = currentMonthKey.split('-');
    let cYr = parseInt(cYrStr, 10);
    let cMo = parseInt(cMoStr, 10) - 1;
    if (cMo < 1) {
      cMo = 12;
      cYr -= 1;
    }
    const prevMonthKey = `${cYr}-${String(cMo).padStart(2, '0')}`;
    keysSet.add(prevMonthKey);

    // From saved snapshots
    savedSnapshots.forEach((s) => {
      if (s.monthKey) keysSet.add(s.monthKey);
    });

    // From points log
    pointsLog.forEach((p) => {
      if (p.timestamp) {
        const d = new Date(p.timestamp);
        const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        keysSet.add(k);
      }
    });

    // From customers activation or creation
    customers.forEach((c) => {
      const dt = c.activatedAt ? new Date(c.activatedAt) : (c.createdAt ? new Date(c.createdAt) : null);
      if (dt) {
        const k = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}`;
        keysSet.add(k);
      }
    });

    return Array.from(keysSet).sort((a, b) => {
      const [yrA, moA] = a.split('-').map(Number);
      const [yrB, moB] = b.split('-').map(Number);
      if (yrA !== yrB) return yrB - yrA;
      return moA - moB;
    });
  }, [currentMonthKey, savedSnapshots, pointsLog, customers]);

  const getCardTypeName = (cardTypeId?: number | null) => {
    if (!cardTypeId) return null;
    return cardTypeMap.get(cardTypeId)?.name || null;
  };

  // Bounds for selected month
  const { startOfSelectedMonth, endOfSelectedMonth, selectedMonthName } = useMemo(() => {
    const [yrStr, moStr] = selectedMonthKey.split('-');
    const yr = parseInt(yrStr, 10) || new Date().getFullYear();
    const mo = (parseInt(moStr, 10) || (new Date().getMonth() + 1)) - 1;

    const start = new Date(yr, mo, 1, 0, 0, 0, 0);
    const end = new Date(yr, mo + 1, 0, 23, 59, 59, 999);
    const mName = language === 'ar' ? formatMonthKeyToArabic(selectedMonthKey) : formatMonthKeyToEnglish(selectedMonthKey);

    return { startOfSelectedMonth: start, endOfSelectedMonth: end, selectedMonthName: mName };
  }, [selectedMonthKey, language]);

  // Build strict list of distinct statuses (never merging تم التنفيذ and تم التفعيل)
  const availableStatuses = useMemo(() => {
    const coreOrder = ['تم التنفيذ', 'تم التفعيل', 'عميل معلق', 'عميل محتمل'];
    const set = new Set<string>(coreOrder);
    rawStatuses.forEach((s) => {
      const name = (s?.name || '').trim();
      if (name) set.add(name);
    });
    customers.forEach((c) => {
      const name = (c.status || '').trim();
      if (name) set.add(name);
    });
    return Array.from(set);
  }, [rawStatuses, customers]);

  const getStatusBadgeStyle = (status?: string) => {
    const s = (status || '').trim();
    if (s === 'تم التفعيل') return 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300';
    if (s === 'تم التنفيذ') return 'border-cyan-500/40 bg-cyan-500/15 text-cyan-300';
    if (s === 'عميل معلق') return 'border-amber-500/40 bg-amber-500/15 text-amber-300';
    if (s === 'عميل محتمل') return 'border-sky-500/40 bg-sky-500/15 text-sky-300';
    return 'border-indigo-500/40 bg-indigo-500/15 text-indigo-300';
  };

  const getStatusIconEmoji = (status?: string) => {
    const s = (status || '').trim();
    if (s === 'تم التفعيل') return '⚡';
    if (s === 'تم التنفيذ') return '🟢';
    if (s === 'عميل معلق') return '⏳';
    if (s === 'عميل محتمل') return '🔵';
    return '🏷️';
  };

  const getStatusPdfAccent = (status?: string): PdfAccent => {
    const s = (status || '').trim();
    if (s === 'تم التفعيل') return 'emerald';
    if (s === 'تم التنفيذ') return 'cyan';
    if (s === 'عميل معلق') return 'amber';
    if (s === 'عميل محتمل') return 'sky';
    return 'indigo';
  };

  // Single-pass partitioning of selected month customers into strictly separated status lists
  const {
    selectedMonthAllCustomers,
    selectedMonthActivatedCustomers,
    selectedMonthExecutedCustomers,
    selectedMonthPendingCustomers,
    selectedMonthPotentialCustomers,
    executedMonthRevenue,
    activatedMonthRevenue,
  } = useMemo(() => {
    const allMonth: Customer[] = [];
    const activated: Customer[] = [];
    const executed: Customer[] = [];
    const pending: Customer[] = [];
    const potential: Customer[] = [];
    let execRev = 0;
    let actRev = 0;

    for (const c of customers) {
      if (getCustomerMonthKey(c) !== selectedMonthKey) continue;
      allMonth.push(c);
      const st = (c.status || '').trim();
      if (st === 'تم التفعيل') {
        activated.push(c);
        actRev += Number(c.amount) || Number(c.salary) || 0;
      } else if (st === 'تم التنفيذ') {
        executed.push(c);
        execRev += Number(c.amount) || Number(c.salary) || 0;
      } else if (st === 'عميل معلق') {
        pending.push(c);
      } else if (st === 'عميل محتمل') {
        potential.push(c);
      }
    }

    return {
      selectedMonthAllCustomers: allMonth,
      selectedMonthActivatedCustomers: activated,
      selectedMonthExecutedCustomers: executed,
      selectedMonthPendingCustomers: pending,
      selectedMonthPotentialCustomers: potential,
      executedMonthRevenue: execRev,
      activatedMonthRevenue: actRev,
    };
  }, [customers, selectedMonthKey]);

  // Customers strictly matching the active top status filter
  const statusScopedMonthCustomers = useMemo(() => {
    if (selectedStatusFilter === 'all') return selectedMonthAllCustomers;
    return selectedMonthAllCustomers.filter((c) => (c.status || '').trim() === selectedStatusFilter);
  }, [selectedMonthAllCustomers, selectedStatusFilter]);

  const statusScopedAllCustomers = useMemo(() => {
    if (selectedStatusFilter === 'all') return customers;
    return customers.filter((c) => (c.status || '').trim() === selectedStatusFilter);
  }, [customers, selectedStatusFilter]);

  // Selected month points total (O(1) Set + Map lookup, never O(N*M))
  const selectedMonthPoints = useMemo(() => {
    let logPts = 0;
    const loggedIds = new Set<number>();
    for (const p of pointsLog) {
      const dt = new Date(p.timestamp);
      if (dt >= startOfSelectedMonth && dt <= endOfSelectedMonth) {
        logPts += p.points || 0;
        if (p.customerId !== undefined && p.customerId !== null) {
          loggedIds.add(p.customerId);
        }
      }
    }

    let unloggedPts = 0;
    for (const c of selectedMonthActivatedCustomers) {
      if (c.id !== undefined && loggedIds.has(c.id)) continue;
      const cardType = c.cardTypeId ? cardTypeMap.get(c.cardTypeId) : undefined;
      const basePts = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
      unloggedPts +=
        c.points && c.points > 0
          ? c.points
          : basePts > 0
          ? calculateCardPoints(basePts, c.salary, c.productType || 'visa', salaryTiers)
          : calculatePoints(c.salary);
    }

    return Math.round(logPts + unloggedPts);
  }, [pointsLog, startOfSelectedMonth, endOfSelectedMonth, selectedMonthActivatedCustomers, cardTypeMap, salaryTiers]);

  const statusScopedRevenue = useMemo(() => {
    let sum = 0;
    for (const c of statusScopedMonthCustomers) {
      sum += Number(c.amount) || Number(c.salary) || 0;
    }
    return sum;
  }, [statusScopedMonthCustomers]);

  const visibleStatusTableCustomers = useMemo(
    () => statusScopedMonthCustomers.slice(0, tableVisibleLimit),
    [statusScopedMonthCustomers, tableVisibleLimit]
  );

  const selectedStatusLabel = selectedStatusFilter === 'all'
    ? (language === 'ar' ? 'جميع الحالات' : 'All Statuses')
    : getStatusTranslation(selectedStatusFilter, language);

  const reportTypes = useMemo(() => {
    if (selectedStatusFilter !== 'all') {
      const stLabel = getStatusTranslation(selectedStatusFilter, language);
      const isActivated = selectedStatusFilter === 'تم التفعيل';
      const isExecuted = selectedStatusFilter === 'تم التنفيذ';
      const accentBorder = isActivated
        ? 'border-emerald-500/35 bg-emerald-500/10'
        : isExecuted
        ? 'border-cyan-500/35 bg-cyan-500/10'
        : selectedStatusFilter === 'عميل معلق'
        ? 'border-amber-500/35 bg-amber-500/10'
        : 'border-sky-500/35 bg-sky-500/10';

      const cards = [
        {
          id: 'statusReport',
          icon: <CheckCircle2 className={`w-6 h-6 ${isActivated ? 'text-emerald-400' : isExecuted ? 'text-cyan-400' : selectedStatusFilter === 'عميل معلق' ? 'text-amber-400' : 'text-sky-400'}`} />,
          title: language === 'ar' ? `تقرير حالة: ${stLabel} (${selectedMonthName})` : `${stLabel} Report (${selectedMonthName})`,
          color: accentBorder,
          count: statusScopedMonthCustomers.length,
        },
        {
          id: 'visa',
          icon: <CreditCard className="w-6 h-6 text-indigo-400" />,
          title: language === 'ar' ? `بطاقات Visa (${stLabel})` : `Visa Cards (${stLabel})`,
          color: 'border-indigo-500/25 bg-indigo-500/10',
          count: statusScopedMonthCustomers.filter((c) => c.productType === 'visa').length,
        },
        {
          id: 'cardTypeReport',
          icon: <CreditCard className="w-6 h-6 text-purple-400" />,
          title: language === 'ar' ? `أنواع البطاقات (${stLabel})` : `Card Types (${stLabel})`,
          color: 'border-purple-500/25 bg-purple-500/10',
          count: statusScopedMonthCustomers.filter((c) => c.productType === 'visa').length,
        },
        {
          id: 'totalFinance',
          icon: <DollarSign className="w-6 h-6 text-emerald-400" />,
          title: language === 'ar' ? `إجمالي التمويل (${stLabel})` : `Total Finance (${stLabel})`,
          color: 'border-emerald-500/25 bg-emerald-500/10',
          count: statusScopedMonthCustomers.filter((c) => c.productType === 'finance').length,
        },
        {
          id: 'financeWithSalary',
          icon: <DollarSign className="w-6 h-6 text-teal-400" />,
          title: language === 'ar' ? `تمويل بتحويل راتب (${stLabel})` : `Salary Transfer Finance (${stLabel})`,
          color: 'border-teal-500/25 bg-teal-500/10',
          count: statusScopedMonthCustomers.filter((c) => c.productType === 'finance' && c.financeType !== 'no_salary_transfer' && c.financeType !== 'بدون تحويل راتب').length,
        },
        {
          id: 'financeNoSalary',
          icon: <DollarSign className="w-6 h-6 text-cyan-400" />,
          title: language === 'ar' ? `تمويل بدون تحويل راتب (${stLabel})` : `Non-Salary Finance (${stLabel})`,
          color: 'border-cyan-500/25 bg-cyan-500/10',
          count: statusScopedMonthCustomers.filter((c) => c.productType === 'finance' && (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب')).length,
        },
        {
          id: 'salaryReport',
          icon: <DollarSign className="w-6 h-6 text-emerald-400" />,
          title: language === 'ar' ? `تقرير الرواتب والدخل (${stLabel})` : `Salaries & Income (${stLabel})`,
          color: 'border-emerald-500/20 bg-emerald-500/10',
          count: statusScopedMonthCustomers.filter((c) => (c.salary && c.salary > 0) || (c.amount && c.amount > 0)).length,
        },
        {
          id: 'comprehensive',
          icon: <BarChart3 className="w-6 h-6 text-purple-400" />,
          title: language === 'ar' ? `جميع الأشهر (${stLabel})` : `All Months (${stLabel})`,
          color: 'border-purple-500/20 bg-purple-500/10',
          count: statusScopedAllCustomers.length,
        },
      ];

      if (isActivated) {
        cards.splice(1, 0,
          {
            id: 'targetBreakdown',
            icon: <Target className="w-6 h-6 text-amber-400" />,
            title: t('targetTrackingAndCards', 'متابعة الهدف ومُعادل البطاقات'),
            color: 'border-amber-500/30 bg-gradient-to-r from-amber-950/40 via-indigo-950/40 to-zinc-900',
            count: selectedMonthPoints,
          },
          {
            id: 'points',
            icon: <Award className="w-6 h-6 text-amber-400" />,
            title: `${t('pointsReportMonth', 'تقرير نقاط شهر ({month})').replace('{month}', selectedMonthName)}`,
            color: 'border-amber-500/20 bg-amber-500/10',
            count: selectedMonthPoints,
          }
        );
      }

      return cards;
    }

    return [
      { id: 'executedOrders', icon: <CheckCircle2 className="w-6 h-6 text-cyan-400" />, title: t('executedOrdersTitle', 'طلبات تم تنفيذها فقط (تم التنفيذ 🟢)'), color: 'border-cyan-500/35 bg-cyan-500/10', count: selectedMonthExecutedCustomers.length },
      { id: 'activatedOrders', icon: <CheckCircle2 className="w-6 h-6 text-emerald-400" />, title: t('activatedOrdersTitle', 'طلبات تم تفعيلها فقط (تم التفعيل ⚡)'), color: 'border-emerald-500/35 bg-emerald-500/10', count: selectedMonthActivatedCustomers.length },
      { id: 'pending', icon: <Clock className="w-6 h-6 text-amber-400" />, title: t('pendingClientsTitle', 'عملاء معلقون فقط (عميل معلق)'), color: 'border-amber-500/25 bg-amber-500/10', count: selectedMonthPendingCustomers.length },
      { id: 'potential', icon: <ChevronRight className="w-6 h-6 text-sky-400" />, title: t('potentialClientsTitle', 'عملاء محتملون فقط (عميل محتمل)'), color: 'border-sky-500/25 bg-sky-500/10', count: selectedMonthPotentialCustomers.length },
      { id: 'visaExecuted', icon: <CreditCard className="w-6 h-6 text-cyan-400" />, title: language === 'ar' ? 'بطاقات Visa (تم التنفيذ 🟢)' : 'Visa Cards (Executed)', color: 'border-cyan-500/25 bg-cyan-500/10', count: selectedMonthExecutedCustomers.filter((c) => c.productType === 'visa').length },
      { id: 'visa', icon: <CreditCard className="w-6 h-6 text-emerald-400" />, title: language === 'ar' ? 'بطاقات Visa (تم التفعيل ⚡)' : 'Visa Cards (Activated)', color: 'border-emerald-500/25 bg-emerald-500/10', count: selectedMonthActivatedCustomers.filter((c) => c.productType === 'visa').length },
      { id: 'totalFinance', icon: <DollarSign className="w-6 h-6 text-cyan-400" />, title: t('totalCompletedFinanceTitle', 'إجمالي التمويل (تم التنفيذ 🟢)'), color: 'border-cyan-500/25 bg-cyan-500/10', count: selectedMonthExecutedCustomers.filter((c) => c.productType === 'finance').length },
      { id: 'totalFinanceActivated', icon: <DollarSign className="w-6 h-6 text-emerald-400" />, title: language === 'ar' ? 'إجمالي التمويل (تم التفعيل ⚡)' : 'Total Finance (Activated)', color: 'border-emerald-500/25 bg-emerald-500/10', count: selectedMonthActivatedCustomers.filter((c) => c.productType === 'finance').length },
      { id: 'targetBreakdown', icon: <Target className="w-6 h-6 text-amber-400" />, title: t('targetTrackingAndCards', 'متابعة الهدف ومُعادل البطاقات'), color: 'border-amber-500/30 bg-gradient-to-r from-amber-950/40 via-indigo-950/40 to-zinc-900', count: selectedMonthPoints },
      { id: 'points', icon: <Award className="w-6 h-6 text-amber-400" />, title: `${t('pointsReportMonth', 'تقرير نقاط شهر ({month})').replace('{month}', selectedMonthName)}`, color: 'border-amber-500/20 bg-amber-500/10', count: selectedMonthPoints },
      { id: 'cardTypeReport', icon: <CreditCard className="w-6 h-6 text-indigo-400" />, title: t('cardTypesReport', 'أنواع البطاقات المفعلة (تم التفعيل)'), color: 'border-indigo-500/20 bg-indigo-500/10', count: selectedMonthActivatedCustomers.filter((c) => c.productType === 'visa').length },
      { id: 'salaryReport', icon: <DollarSign className="w-6 h-6 text-emerald-400" />, title: t('salaryAndIncomeReport', 'تقرير الرواتب ودخل العملاء'), color: 'border-emerald-500/20 bg-emerald-500/10', count: selectedMonthAllCustomers.filter((c) => (c.salary && c.salary > 0) || (c.amount && c.amount > 0)).length },
      { id: 'financeWithSalary', icon: <DollarSign className="w-6 h-6 text-teal-400" />, title: t('reportFinanceWithSalary', 'تمويل بتحويل راتب'), color: 'border-teal-500/20 bg-teal-500/10', count: selectedMonthAllCustomers.filter((c) => c.productType === 'finance' && c.financeType !== 'no_salary_transfer' && c.financeType !== 'بدون تحويل راتب').length },
      { id: 'financeNoSalary', icon: <DollarSign className="w-6 h-6 text-cyan-400" />, title: t('reportFinanceNoSalary', 'تمويل بدون تحويل راتب'), color: 'border-cyan-500/20 bg-cyan-500/10', count: selectedMonthAllCustomers.filter((c) => c.productType === 'finance' && (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب')).length },
      { id: 'archiveReport', icon: <Archive className="w-6 h-6 text-amber-400" />, title: `${t('monthlyArchiveReport', 'تقرير الأرشيف الشهري ({month})').replace('{month}', selectedMonthName)}`, color: 'border-amber-500/30 bg-gradient-to-r from-amber-950/50 via-indigo-950/40 to-zinc-900', count: selectedMonthAllCustomers.length },
      { id: 'comprehensive', icon: <BarChart3 className="w-6 h-6 text-purple-400" />, title: t('reportComprehensive', 'التقرير الشامل (جميع الأشهر)'), color: 'border-purple-500/20 bg-purple-500/10', count: customers.length },
    ];
  }, [
    selectedStatusFilter,
    selectedMonthName,
    selectedMonthAllCustomers,
    selectedMonthActivatedCustomers,
    selectedMonthExecutedCustomers,
    selectedMonthPendingCustomers,
    selectedMonthPotentialCustomers,
    statusScopedMonthCustomers,
    statusScopedAllCustomers,
    selectedMonthPoints,
    customers,
    language,
    t
  ]);

  const getFilteredData = (reportId: string): Customer[] => {
    const isStatusScoped = selectedStatusFilter !== 'all';
    const monthPool = isStatusScoped ? statusScopedMonthCustomers : selectedMonthAllCustomers;

    switch (reportId) {
      case 'statusReport': return statusScopedMonthCustomers;
      case 'activatedOrders': return selectedMonthActivatedCustomers;
      case 'executedOrders': return selectedMonthExecutedCustomers;
      case 'archiveReport': return monthPool;
      case 'salaryReport': return monthPool.filter((c) => (c.salary && c.salary > 0) || (c.amount && c.amount > 0));
      case 'cardTypeReport':
        return isStatusScoped
          ? statusScopedMonthCustomers.filter((c) => c.productType === 'visa')
          : selectedMonthActivatedCustomers.filter((c) => c.productType === 'visa');
      case 'pending': return selectedMonthPendingCustomers;
      case 'potential':
      case 'following': return selectedMonthPotentialCustomers;
      case 'visaExecuted': return selectedMonthExecutedCustomers.filter((c) => c.productType === 'visa');
      case 'visa':
        return isStatusScoped
          ? statusScopedMonthCustomers.filter((c) => c.productType === 'visa')
          : selectedMonthActivatedCustomers.filter((c) => c.productType === 'visa');
      case 'finance': return monthPool.filter((c) => c.productType === 'finance');
      case 'financeWithSalary': return monthPool.filter((c) => c.productType === 'finance' && c.financeType !== 'no_salary_transfer' && c.financeType !== 'بدون تحويل راتب');
      case 'financeNoSalary': return monthPool.filter((c) => c.productType === 'finance' && (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب'));
      case 'comprehensive': return statusScopedAllCustomers;
      case 'totalFinance':
        return isStatusScoped
          ? statusScopedMonthCustomers.filter((c) => c.productType === 'finance')
          : selectedMonthExecutedCustomers.filter((c) => c.productType === 'finance');
      case 'totalFinanceActivated':
        return selectedMonthActivatedCustomers.filter((c) => c.productType === 'finance');
      default: return [];
    }
  };

  const handleExportCSV = (reportId: string) => {
    let rows: string[][] = [];
    let headers: string[] = [];

    if (reportId === 'targetBreakdown') {
      const targetVal = (settings.monthlyTarget && settings.monthlyTarget > 1000) ? settings.monthlyTarget : 140000;
      const monthlyLogs = pointsLog.filter(p => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth);
      const pointsFromLogs = monthlyLogs.reduce((sum, p) => sum + (p.points || 0), 0);
      const unloggedActivatedPoints = selectedMonthActivatedCustomers
        .filter((c) => !monthlyLogs.some((p) => p.customerId === c.id))
        .reduce((sum, c) => {
          const cardType = cardTypes.find((ct) => ct.id === c.cardTypeId);
          const basePts = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
          const pts = (c.points && c.points > 0)
            ? c.points
            : (basePts > 0
                ? calculateCardPoints(basePts, c.salary, c.productType || 'visa', salaryTiers)
                : calculatePoints(c.salary));
          return sum + pts;
        }, 0);
      const achieved = Math.round(pointsFromLogs + unloggedActivatedPoints);
      const remaining = Math.max(0, targetVal - achieved);
      const infiniteNeeded = remaining > 0 ? Math.ceil(remaining / 8500) : 0;
      const platinumNeeded = remaining > 0 ? Math.ceil(remaining / 4250) : 0;

      headers = [t('statementMetric', 'البيان / المعيار'), t('valueAndDetails', 'القيمة والتفاصيل')];
      rows = [
        [t('monthlyCycle', 'الدورة الشهرية'), `${selectedMonthName}`],
        [t('requiredMonthlyTarget', 'الهدف الشهري المطلوب'), `${formatNumber(targetVal)} ${t('pointsUnit')}`],
        [t('achievedPointsSoFar', 'النقاط المحققة حتى الآن'), `${formatNumber(achieved)} ${t('pointsUnit')}`],
        [t('remainingTargetPoints', 'النقاط المتبقية للهدف'), `${formatNumber(remaining)} ${t('pointsUnit')}`],
        [t('progressRate', 'نسبة الإنجاز'), `${((achieved / (targetVal || 1)) * 100).toFixed(1)}%`],
        [t('infiniteCardsNeeded', 'بطاقات إنفينيت Infinite المطلوبة (8500 نقطة/بطاقة)'), `${formatNumber(infiniteNeeded)} ${t('cardUnit', 'بطاقة')}`],
        [t('platinumCardsNeeded', 'بطاقات بلاتينيوم Platinum المطلوبة (4250 نقطة/بطاقة)'), `${formatNumber(platinumNeeded)} ${t('cardUnit', 'بطاقة')}`]
      ];
    } else if (reportId === 'points') {
      const filteredPoints = pointsLog.filter(p => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth);
      headers = [t('reasonOrCustomer', 'العميل / السبب'), t('pointsTotal', 'عدد النقاط'), t('dateTime', 'التاريخ والوقت')];
      rows = filteredPoints.map(p => [
        p.reason || t('ptsEarnReason', 'كسب نقاط'),
        String(p.points || 0),
        new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')
      ]);
    } else {
      const data = getFilteredData(reportId);
      headers = [
        t('customerName', 'الاسم'),
        t('phone', 'الجوال'),
        t('email', 'البريد'),
        t('orderNumber', 'رقم الطلب'),
        t('productOrCardType', 'المنتج / نوع البطاقة'),
        t('salaryOrAmountRequired', 'الراتب / المبلغ المطلوب'),
        t('financeType', 'نوع التمويل'),
        t('financeRate', 'نسبة التمويل %'),
        t('points', 'النقاط'),
        t('status', 'الحالة'),
        t('createdDate', 'تاريخ الإضافة')
      ];
      rows = data.map(c => [
        c.name,
        c.phone,
        c.email || '',
        c.orderNumber || '',
        c.productType === 'visa' ? `Visa ${getCardTypeName(c.cardTypeId) ? `(${getCardTypeName(c.cardTypeId)})` : ''}`.trim() : t('personalFinance', 'تمويل شخصي'),
        c.productType === 'visa' ? String(c.salary || 0) : String(c.amount || 0),
        c.productType === 'finance' ? getFinanceTypeTranslation(c.financeType, language) : '-',
        c.productType === 'finance' && c.financeRate !== undefined && c.financeRate !== null ? `${c.financeRate}%` : '-',
        String(c.points || 0),
        getStatusTranslation(c.status, language),
        new Date(c.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')
      ]);
    }

    if (rows.length === 0) {
      showToast(t('noDataToExport', 'لا توجد بيانات للتصدير'), 'warning');
      return;
    }

    const csvContent = [
      headers.map((h) => sanitizeCsvCell(h)).join(','),
      ...rows.map((r) => r.map((cell) => sanitizeCsvCell(cell)).join(',')),
    ].join('\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const safeFileName = sanitizeDownloadFilename(`sales-crm-report-${reportId}-${selectedMonthKey}.csv`, 'report.csv');
    void saveOrShareBlob(blob, safeFileName, {
      title: safeFileName,
      fallbackName: 'report.csv',
    });
    showToast(t('csvExportSuccess', 'تم تصدير ملف CSV بنجاح 📊'));
  };

  const handleExportExcel = async (reportId: string) => {
    let rows: (string | number)[][] = [];
    let headers: string[] = [];
    const reportTitle = reportTypes.find(r => r.id === reportId)?.title || t('salesReport', 'تقرير المبيعات');

    if (reportId === 'targetBreakdown') {
      const targetVal = (settings.monthlyTarget && settings.monthlyTarget > 1000) ? settings.monthlyTarget : 140000;
      const achieved = selectedMonthPoints;
      const remaining = Math.max(0, targetVal - achieved);
      const infiniteNeeded = remaining > 0 ? Math.ceil(remaining / 8500) : 0;
      const platinumNeeded = remaining > 0 ? Math.ceil(remaining / 4250) : 0;

      headers = [t('statementMetric', 'البيان / المعيار'), t('valueAndDetails', 'القيمة والتفاصيل')];
      rows = [
        [t('monthlyCycle', 'الدورة الشهرية'), `${selectedMonthName}`],
        [t('requiredMonthlyTarget', 'الهدف الشهري المطلوب'), `${formatNumber(targetVal)} ${t('pointsUnit')}`],
        [t('achievedPointsSoFar', 'النقاط المحققة حتى الآن'), `${formatNumber(achieved)} ${t('pointsUnit')}`],
        [t('remainingTargetPoints', 'النقاط المتبقية للهدف'), `${formatNumber(remaining)} ${t('pointsUnit')}`],
        [t('progressRate', 'نسبة الإنجاز'), `${((achieved / (targetVal || 1)) * 100).toFixed(1)}%`],
        [t('infiniteCardsNeeded', 'بطاقات إنفينيت Infinite المطلوبة (8500 نقطة/بطاقة)'), `${formatNumber(infiniteNeeded)} ${t('cardUnit', 'بطاقة')}`],
        [t('platinumCardsNeeded', 'بطاقات بلاتينيوم Platinum المطلوبة (4250 نقطة/بطاقة)'), `${formatNumber(platinumNeeded)} ${t('cardUnit', 'بطاقة')}`]
      ];
    } else if (reportId === 'points') {
      const filteredPoints = pointsLog.filter(p => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth);
      headers = [t('reasonOrCustomer', 'العميل / السبب'), t('pointsTotal', 'عدد النقاط'), t('dateTime', 'التاريخ والوقت')];
      rows = filteredPoints.map(p => [
        p.reason || t('ptsEarnReason', 'كسب نقاط'),
        p.points || 0,
        new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')
      ]);
    } else {
      const data = getFilteredData(reportId);
      headers = [
        t('seqNumber', 'م'),
        t('customerName', 'الاسم'),
        t('phone', 'الجوال'),
        t('email', 'البريد الإلكتروني'),
        t('orderNumber', 'رقم الطلب'),
        t('productOrCardType', 'المنتج / نوع البطاقة'),
        t('salaryOrAmountRequired', 'الراتب / المبلغ المطلوب'),
        t('financeType', 'نوع التمويل'),
        t('financeRate', 'نسبة التمويل %'),
        t('points', 'النقاط'),
        t('status', 'الحالة'),
        t('createdDate', 'تاريخ الإضافة')
      ];
      rows = data.map((c, index) => [
        index + 1,
        c.name,
        c.phone,
        c.email || '-',
        c.orderNumber || '-',
        c.productType === 'visa' ? `Visa ${getCardTypeName(c.cardTypeId) ? `(${getCardTypeName(c.cardTypeId)})` : ''}`.trim() : t('personalFinance', 'تمويل شخصي'),
        c.productType === 'visa' ? (c.salary || 0) : (c.amount || 0),
        c.productType === 'finance' ? getFinanceTypeTranslation(c.financeType, language) : '-',
        c.productType === 'finance' && c.financeRate !== undefined && c.financeRate !== null ? `${c.financeRate}%` : '-',
        c.points || 0,
        getStatusTranslation(c.status, language),
        new Date(c.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')
      ]);
    }

    if (rows.length === 0) {
      showToast(t('noDataToExport', 'لا توجد بيانات للتصدير'), 'warning');
      return;
    }

    // Build sanitized XLSX worksheet (loads SheetJS on demand)
    const XLSX = await import('xlsx');
    const safeHeaders = headers.map((h) => sanitizeSpreadsheetValue(h));
    const safeRows = rows.map((r) => r.map((cell) => sanitizeSpreadsheetValue(cell)));
    const worksheetData = [safeHeaders, ...safeRows];
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    // Set RTL direction if Arabic
    if (!worksheet['!views']) worksheet['!views'] = [];
    worksheet['!views'].push({ RTL: dir === 'rtl' });

    // Auto calculate column widths
    const colWidths = safeHeaders.map((h, i) => {
      let maxLen = String(h).length;
      safeRows.forEach(r => {
        const val = String(r[i] ?? '');
        if (val.length > maxLen) maxLen = val.length;
      });
      return { wch: Math.max(maxLen + 4, 12) };
    });
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, reportTitle.slice(0, 31));

    const fileName = sanitizeDownloadFilename(`sales-crm-${reportId}-${selectedMonthKey}.xlsx`, 'report.xlsx');

    if (isNativeCapacitor()) {
      await saveWorkbookNativeOrWeb(XLSX, workbook, fileName, reportTitle);
      showToast(language === 'ar' ? 'تم تصدير ومشاركة ملف الإكسل (XLSX) بنجاح 📊' : 'Excel exported successfully 📊');
      return;
    }

    // Modern mobile share support (Web browsers)
    if (typeof navigator !== 'undefined' && typeof File !== 'undefined' && navigator.canShare) {
      try {
        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const file = new File([blob], fileName, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        if (navigator.canShare({ files: [file] })) {
          navigator.share({
            files: [file],
            title: reportTitle,
            text: `تقرير ${reportTitle}`
          }).then(() => {
            showToast(language === 'ar' ? 'تمت مشاركة تقرير الإكسل بنجاح 🟢' : 'Excel report shared successfully 🟢');
          }).catch((err) => {
            if (err.name !== 'AbortError') {
              XLSX.writeFile(workbook, fileName);
              showToast(language === 'ar' ? 'تم تصدير ملف الإكسل (XLSX) بنجاح! تجده في مجلد "التنزيلات" (Downloads) في تطبيق "ملفاتي" 📂📊' : 'Excel exported to Downloads folder');
            }
          });
          return;
        }
      } catch (e) {
        console.warn('Share error fallback to download:', e);
      }
    }

    // Export true .xlsx binary workbook
    await saveWorkbookNativeOrWeb(XLSX, workbook, fileName, reportTitle);
    showToast(language === 'ar' ? 'تم تصدير ملف الإكسل (XLSX) بنجاح! تجده في مجلد "التنزيلات" (Downloads) في تطبيق "ملفاتي" 📂📊' : 'Excel exported! Saved in Downloads folder');
  };

  const handlePrint = (reportIdParam?: string) => {
    const rId = reportIdParam || activeReport || (selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport');
    setPrintPreviewReportId(rId);
    setIsPrintPreviewModalOpen(true);
  };

  const handleExportPDF = async (reportIdParam?: string) => {
    if (isExportingPdf) return;
    const rId = reportIdParam || activeReport || (selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport');
    const reportTitle = reportTypes.find((r) => r.id === rId)?.title || t('salesReport', 'تقرير المبيعات');
    const companyName = settings?.companyName?.trim() || 'SALES CRM SYSTEM';
    const footerText = t('systemGeneratedReportFooter', 'تم استخراج هذا التقرير تلقائياً من نظام إدارة المبيعات Sales CRM');

    // Determine accurate status badge & accent for the specific report being exported
    let effectiveStatusName: string | null = null;
    if (rId === 'executedOrders' || rId === 'visaExecuted' || (rId === 'totalFinance' && selectedStatusFilter === 'all')) {
      effectiveStatusName = 'تم التنفيذ';
    } else if (
      rId === 'activatedOrders' ||
      rId === 'totalFinanceActivated' ||
      rId === 'points' ||
      rId === 'targetBreakdown' ||
      ((rId === 'visa' || rId === 'cardTypeReport') && selectedStatusFilter === 'all')
    ) {
      effectiveStatusName = 'تم التفعيل';
    } else if (rId === 'pending') {
      effectiveStatusName = 'عميل معلق';
    } else if (rId === 'potential' || rId === 'following') {
      effectiveStatusName = 'عميل محتمل';
    } else if (selectedStatusFilter !== 'all') {
      effectiveStatusName = selectedStatusFilter;
    }

    const pdfStatusLabel = effectiveStatusName
      ? getStatusTranslation(effectiveStatusName, language)
      : (language === 'ar' ? 'جميع الحالات (مفصولة)' : 'All Statuses (Separated)');
    const pdfStatusAccent: PdfAccent = effectiveStatusName ? getStatusPdfAccent(effectiveStatusName) : 'indigo';
    const statusFileSlug = effectiveStatusName
      ? effectiveStatusName === 'تم التفعيل'
        ? 'activated'
        : effectiveStatusName === 'تم التنفيذ'
        ? 'executed'
        : effectiveStatusName === 'عميل معلق'
        ? 'pending'
        : effectiveStatusName === 'عميل محتمل'
        ? 'potential'
        : 'filtered'
      : 'all';

    setIsExportingPdf(true);
    try {
      if (rId === 'targetBreakdown') {
        const targetVal = (settings.monthlyTarget && settings.monthlyTarget > 1000) ? settings.monthlyTarget : 140000;
        const achieved = selectedMonthPoints;
        const remaining = Math.max(0, targetVal - achieved);
        const progressPct = ((achieved / (targetVal || 1)) * 100).toFixed(1);
        const infiniteNeeded = remaining > 0 ? Math.ceil(remaining / 8500) : 0;
        const platinumNeeded = remaining > 0 ? Math.ceil(remaining / 4250) : 0;

        await exportReportToPDF({
          title: reportTitle,
          companyName,
          cycleLabel: selectedMonthName,
          statusLabel: pdfStatusLabel,
          statusAccent: 'emerald',
          totalCountLabel: t('progressRate', 'نسبة الإنجاز'),
          totalCountValue: `${formatNumber(progressPct)}%`,
          dir,
          language,
          orientation: 'portrait',
          summaryCards: [
            { label: t('requiredMonthlyTarget', 'الهدف الشهري'), value: `${formatNumber(targetVal)}`, subtext: t('pointsUnit', 'نقطة'), accent: 'slate' },
            { label: t('achieved', 'النقاط المحققة'), value: `${formatNumber(achieved)}`, subtext: t('pointsUnit', 'نقطة'), accent: 'emerald' },
            { label: t('remaining', 'المتبقي للهدف'), value: `${formatNumber(remaining)}`, subtext: t('pointsUnit', 'نقطة'), accent: 'amber' },
            { label: t('progressRate', 'نسبة الإنجاز'), value: `${formatNumber(progressPct)}%`, accent: 'indigo' },
          ],
          columns: [
            { label: t('statementMetric', 'البيان / المعيار'), align: dir === 'rtl' ? 'right' : 'left' },
            { label: t('valueAndDetails', 'القيمة والتفاصيل'), align: 'center', width: '38%' },
          ],
          rows: [
            [{ text: t('monthlyCycle', 'الدورة الشهرية'), bold: true }, { text: selectedMonthName }],
            [{ text: t('requiredMonthlyTarget', 'الهدف الشهري المطلوب'), bold: true }, { text: `${formatNumber(targetVal)} ${t('pointsUnit', 'نقطة')}`, mono: true }],
            [{ text: t('achievedPointsSoFar', 'النقاط المحققة حتى الآن'), bold: true }, { text: `${formatNumber(achieved)} ${t('pointsUnit', 'نقطة')}`, bold: true, mono: true, badgeAccent: 'emerald' }],
            [{ text: t('remainingTargetPoints', 'النقاط المتبقية للهدف'), bold: true }, { text: `${formatNumber(remaining)} ${t('pointsUnit', 'نقطة')}`, mono: true, badgeAccent: remaining > 0 ? 'amber' : 'emerald' }],
            [{ text: t('progressRate', 'نسبة الإنجاز'), bold: true }, { text: `${formatNumber(progressPct)}%`, bold: true, mono: true }],
            [{ text: t('infiniteCardsNeeded', 'بطاقات إنفينيت Infinite المطلوبة (8500 نقطة/بطاقة)') }, { text: `${formatNumber(infiniteNeeded)} ${t('cardUnit', 'بطاقة')}`, mono: true }],
            [{ text: t('platinumCardsNeeded', 'بطاقات بلاتينيوم Platinum المطلوبة (4250 نقطة/بطاقة)') }, { text: `${formatNumber(platinumNeeded)} ${t('cardUnit', 'بطاقة')}`, mono: true }],
          ],
          footerText,
          fileName: `sales-crm-target-${selectedMonthKey}.pdf`,
        });
      } else if (rId === 'points') {
        const filteredPoints = pointsLog.filter((p) => {
          const dt = new Date(p.timestamp);
          return dt >= startOfSelectedMonth && dt <= endOfSelectedMonth;
        });

        if (filteredPoints.length === 0 && selectedMonthPoints === 0) {
          showToast(t('noDataToExport', 'لا توجد بيانات للتصدير'), 'warning');
          return;
        }

        await exportReportToPDF({
          title: reportTitle,
          companyName,
          cycleLabel: selectedMonthName,
          statusLabel: pdfStatusLabel,
          statusAccent: 'emerald',
          totalCountLabel: t('pointsTotal', 'إجمالي النقاط'),
          totalCountValue: formatNumber(selectedMonthPoints),
          dir,
          language,
          orientation: 'portrait',
          summaryCards: [
            { label: t('monthPointsTotal', 'إجمالي النقاط'), value: formatNumber(selectedMonthPoints), subtext: t('pointsUnit', 'نقطة'), accent: 'amber' },
            { label: getStatusTranslation('تم التفعيل', language), value: formatNumber(selectedMonthActivatedCustomers.length), subtext: language === 'ar' ? 'عميل مفعل' : 'Activated Clients', accent: 'emerald' },
            { label: language === 'ar' ? 'عدد العمليات المسجلة' : 'Recorded Entries', value: formatNumber(filteredPoints.length), accent: 'indigo' },
          ],
          columns: [
            { label: t('seqNumber', 'م'), align: 'center', width: '44px' },
            { label: t('reasonOrCustomer', 'العميل / السبب'), align: dir === 'rtl' ? 'right' : 'left' },
            { label: t('pointsTotal', 'النقاط'), align: 'center', width: '90px' },
            { label: t('dateTime', 'التاريخ والوقت'), align: 'center', width: '150px' },
          ],
          rows: filteredPoints.map((p, idx): PdfCell[] => [
            { text: formatNumber(idx + 1), mono: true },
            { text: p.reason || t('ptsEarnReason', 'كسب نقاط'), bold: true },
            { text: `+${formatNumber(p.points || 0)}`, bold: true, mono: true, badgeAccent: 'emerald' },
            { text: new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US'), mono: true },
          ]),
          footerText,
          fileName: `sales-crm-points-${selectedMonthKey}.pdf`,
        });
      } else {
        const data = getFilteredData(rId);
        if (data.length === 0) {
          showToast(t('noDataToExport', 'لا توجد بيانات للتصدير'), 'warning');
          return;
        }

        const totalVolume = data.reduce((sum, c) => sum + (Number(c.amount) || Number(c.salary) || 0), 0);
        const visaCount = data.filter((c) => c.productType === 'visa').length;
        const financeCount = data.filter((c) => c.productType === 'finance').length;

        let summaryCards: PdfSummaryCard[] = [];
        if (rId === 'salaryReport') {
          const validSalaries = data.map((c) => c.salary || (c.productType === 'finance' ? c.amount : 0) || 0).filter((s) => s > 0);
          const totalSum = validSalaries.reduce((acc, s) => acc + s, 0);
          const avgSalary = validSalaries.length > 0 ? Math.round(totalSum / validSalaries.length) : 0;
          const maxSalary = validSalaries.length > 0 ? Math.max(...validSalaries) : 0;
          summaryCards = [
            { label: t('totalRecordsCount', 'عدد العملاء'), value: formatNumber(data.length), accent: pdfStatusAccent },
            { label: t('totalSalaries', 'إجمالي الرواتب والدخل'), value: formatCurrency(totalSum), accent: 'emerald' },
            { label: t('averageSalary', 'متوسط الراتب'), value: formatCurrency(avgSalary), accent: 'indigo' },
            { label: t('highestSalary', 'أعلى راتب'), value: formatCurrency(maxSalary), accent: 'amber' },
          ];
        } else if (effectiveStatusName) {
          summaryCards = [
            {
              label: `${getStatusIconEmoji(effectiveStatusName)} ${pdfStatusLabel}`,
              value: formatNumber(data.length),
              subtext: language === 'ar' ? 'عميل مطابق للفلتر' : 'Matching Clients',
              accent: pdfStatusAccent,
            },
            {
              label: language === 'ar' ? 'حجم المبيعات / الرواتب' : 'Sales / Salary Volume',
              value: formatCurrency(totalVolume),
              accent: 'sky',
            },
            {
              label: language === 'ar' ? 'بطاقات Visa' : 'Visa Cards',
              value: formatNumber(visaCount),
              accent: 'indigo',
            },
            effectiveStatusName === 'تم التفعيل'
              ? {
                  label: t('monthPointsTotal', 'إجمالي النقاط'),
                  value: formatNumber(data.reduce((sum, c) => sum + (Number(c.points) || 0), 0) || selectedMonthPoints),
                  subtext: t('pointsUnit', 'نقطة'),
                  accent: 'amber',
                }
              : {
                  label: language === 'ar' ? 'التمويل الشخصي' : 'Personal Finance',
                  value: formatNumber(financeCount),
                  accent: 'emerald',
                },
          ];
        } else {
          // Strictly separated breakdown across statuses — never merging executed & activated
          const execRows = data.filter((c) => (c.status || '').trim() === 'تم التنفيذ');
          const actRows = data.filter((c) => (c.status || '').trim() === 'تم التفعيل');
          const pendRows = data.filter((c) => (c.status || '').trim() === 'عميل معلق');
          const potRows = data.filter((c) => (c.status || '').trim() === 'عميل محتمل');
          summaryCards = [
            {
              label: `🟢 ${getStatusTranslation('تم التنفيذ', language)}`,
              value: formatNumber(execRows.length),
              subtext: formatCurrency(execRows.reduce((s, c) => s + (Number(c.amount) || Number(c.salary) || 0), 0)),
              accent: 'cyan',
            },
            {
              label: `⚡ ${getStatusTranslation('تم التفعيل', language)}`,
              value: formatNumber(actRows.length),
              subtext: `${formatNumber(actRows.reduce((s, c) => s + (Number(c.points) || 0), 0))} ${t('pointsUnit', 'نقطة')}`,
              accent: 'emerald',
            },
            {
              label: `⏳ ${getStatusTranslation('عميل معلق', language)}`,
              value: formatNumber(pendRows.length),
              accent: 'amber',
            },
            {
              label: `🔵 ${getStatusTranslation('عميل محتمل', language)}`,
              value: formatNumber(potRows.length),
              accent: 'sky',
            },
          ];
        }

        await exportReportToPDF({
          title: reportTitle,
          subtitle: effectiveStatusName
            ? (language === 'ar'
                ? `تقرير معزول لحالة "${pdfStatusLabel}" فقط — دون دمج أي حالات أخرى`
                : `Isolated report strictly for "${pdfStatusLabel}" status only`)
            : (language === 'ar'
                ? 'كل عميل معروض في حالته الفعلية بشكل منفصل دون دمج بين الحالات'
                : 'Each customer is listed strictly under their actual status'),
          companyName,
          cycleLabel: rId === 'comprehensive' ? (language === 'ar' ? 'جميع الأشهر' : 'All Months') : selectedMonthName,
          statusLabel: pdfStatusLabel,
          statusAccent: pdfStatusAccent,
          totalCountLabel: t('totalRecordsCount', 'إجمالي السجلات'),
          totalCountValue: formatNumber(data.length),
          dir,
          language,
          orientation: 'landscape',
          summaryCards,
          columns: [
            { label: t('seqNumber', 'م'), align: 'center', width: '34px' },
            { label: t('customerName', 'اسم العميل'), align: dir === 'rtl' ? 'right' : 'left' },
            { label: t('phone', 'الجوال'), align: 'center', width: '98px' },
            { label: t('orderNumber', 'رقم الطلب'), align: 'center', width: '92px' },
            { label: t('productOrCardType', 'المنتج / البطاقة'), align: dir === 'rtl' ? 'right' : 'left' },
            { label: t('salaryOrAmountRequired', 'الراتب / التمويل'), align: 'center', width: '95px' },
            { label: t('points', 'النقاط'), align: 'center', width: '58px' },
            { label: t('status', 'الحالة'), align: 'center', width: '95px' },
            { label: t('notes', 'الملاحظات'), align: dir === 'rtl' ? 'right' : 'left', width: '165px' },
            { label: t('createdDate', 'تاريخ الإضافة'), align: 'center', width: '82px' },
          ],
          rows: data.map((c, idx): PdfCell[] => [
            { text: formatNumber(idx + 1), mono: true },
            { text: c.name || '-', bold: true },
            { text: formatPhone(c.phone), mono: true, dir: 'ltr' },
            { text: c.orderNumber || '-', mono: true, dir: 'ltr' },
            {
              text:
                c.productType === 'visa'
                  ? `Visa ${getCardTypeName(c.cardTypeId) ? `(${getCardTypeName(c.cardTypeId)})` : ''}`.trim()
                  : `${t('personalFinance', 'تمويل شخصي')} (${getFinanceTypeTranslation(c.financeType, language)})`,
            },
            {
              text:
                c.productType === 'visa'
                  ? c.salary
                    ? formatCurrency(c.salary)
                    : '-'
                  : formatCurrency(Number(c.amount || 0)),
              bold: true,
              mono: true,
            },
            { text: c.points ? formatNumber(c.points) : '0', bold: Boolean(c.points), mono: true },
            { text: getStatusTranslation(c.status, language), badgeAccent: getStatusPdfAccent(c.status) },
            { text: c.notes?.trim() || '-' },
            { text: new Date(c.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'), mono: true },
          ]),
          footerText,
          fileName: `sales-crm-${rId}-${statusFileSlug}-${selectedMonthKey}.pdf`,
        });
      }

      showToast(
        language === 'ar'
          ? 'تم تصدير التقرير بصيغة PDF بنجاح! تجده في مجلد التنزيلات 📄✅'
          : 'PDF report exported successfully! Check your Downloads folder 📄✅'
      );
    } catch (err) {
      console.error('PDF export error:', err);
      showToast(
        language === 'ar'
          ? 'حدث خطأ أثناء إنشاء ملف PDF، يرجى المحاولة مرة أخرى'
          : 'Failed to generate PDF report, please try again',
        'error'
      );
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Recharts Analytics Aggregations (Memoized for instant responsiveness)
  // 1. Month-Over-Month Performance Comparison & Growth
  const momData = useMemo(() => {
    const today = new Date();
    const isCompletedStatus = (s?: string) => {
      const clean = (s || '').trim();
      return clean === 'تم التفعيل' || clean === 'تم التنفيذ' || clean === 'مكتمل';
    };

    // Current Month bounds
    const currentMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const currentMonthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59);

    // Previous Month bounds
    const prevMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const prevMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59);

    const currentMonthLabel = currentMonthStart.toLocaleDateString('ar-SA', { month: 'long' });
    const prevMonthLabel = prevMonthStart.toLocaleDateString('ar-SA', { month: 'long' });

    // Completed Sales (Executed & Activated)
    const currCompleted = customers.filter(c => {
      const d = new Date(c.createdAt);
      return d >= currentMonthStart && d <= currentMonthEnd && isCompletedStatus(c.status);
    }).length;

    const prevCompleted = customers.filter(c => {
      const d = new Date(c.createdAt);
      return d >= prevMonthStart && d <= prevMonthEnd && isCompletedStatus(c.status);
    }).length;

    // Points
    const currPoints = pointsLog
      .filter(p => {
        const d = new Date(p.timestamp);
        return d >= currentMonthStart && d <= currentMonthEnd;
      })
      .reduce((sum, p) => sum + (p.points || 0), 0);

    const prevPoints = pointsLog
      .filter(p => {
        const d = new Date(p.timestamp);
        return d >= prevMonthStart && d <= prevMonthEnd;
      })
      .reduce((sum, p) => sum + (p.points || 0), 0);

    // New Customers
    const currNewCust = customers.filter(c => {
      const d = new Date(c.createdAt);
      return d >= currentMonthStart && d <= currentMonthEnd;
    }).length;

    const prevNewCust = customers.filter(c => {
      const d = new Date(c.createdAt);
      return d >= prevMonthStart && d <= prevMonthEnd;
    }).length;

    // Sales Volume (Executed & Activated)
    const currVolume = customers
      .filter(c => {
        const d = new Date(c.createdAt);
        return d >= currentMonthStart && d <= currentMonthEnd && isCompletedStatus(c.status);
      })
      .reduce((sum, c) => sum + (Number(c.amount) || Number(c.salary) || 0), 0);

    const prevVolume = customers
      .filter(c => {
        const d = new Date(c.createdAt);
        return d >= prevMonthStart && d <= prevMonthEnd && isCompletedStatus(c.status);
      })
      .reduce((sum, c) => sum + (Number(c.amount) || Number(c.salary) || 0), 0);

    const calcGrowth = (curr: number, prev: number) => {
      if (prev === 0) return curr > 0 ? 100 : 0;
      return Math.round(((curr - prev) / prev) * 100 * 10) / 10;
    };

    const pointsGrowth = calcGrowth(currPoints, prevPoints);
    const completedGrowth = calcGrowth(currCompleted, prevCompleted);
    const volumeGrowth = calcGrowth(currVolume, prevVolume);
    const custGrowth = calcGrowth(currNewCust, prevNewCust);

    // Grouped data for bar chart comparison
    const comparisonChartData = [
      {
        metric: 'العمليات المنجزة',
        [prevMonthLabel]: prevCompleted,
        [currentMonthLabel]: currCompleted,
        unit: 'عملية',
        growth: completedGrowth,
      },
      {
        metric: 'النقاط المحققة',
        [prevMonthLabel]: prevPoints,
        [currentMonthLabel]: currPoints,
        unit: 'نقطة',
        growth: pointsGrowth,
      },
      {
        metric: 'عملاء جدد',
        [prevMonthLabel]: prevNewCust,
        [currentMonthLabel]: currNewCust,
        unit: 'عميل',
        growth: custGrowth,
      },
    ];

    return {
      currentMonthLabel,
      prevMonthLabel,
      currCompleted,
      prevCompleted,
      completedGrowth,
      currPoints,
      prevPoints,
      pointsGrowth,
      currVolume,
      prevVolume,
      volumeGrowth,
      currNewCust,
      prevNewCust,
      custGrowth,
      comparisonChartData,
    };
  }, [customers, pointsLog]);

  // 2. Monthly Performance (Last 6 Months)
  const monthlySalesData = useMemo(() => {
    const result = [];
    const curr = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(curr.getFullYear(), curr.getMonth() - i, 1);
      const endD = new Date(curr.getFullYear(), curr.getMonth() - i + 1, 0, 23, 59, 59);
      const monthLabel = d.toLocaleDateString('ar-SA', { month: 'short' });

      const pointsCount = pointsLog
        .filter((p) => {
          const pt = new Date(p.timestamp);
          return pt >= d && pt <= endD;
        })
        .reduce((sum, p) => sum + (p.points || 0), 0);

      const completedCount = customers.filter((c) => {
        const ct = new Date(c.createdAt);
        const s = (c.status || '').trim();
        return ct >= d && ct <= endD && (s === 'تم التفعيل' || s === 'تم التنفيذ' || s === 'مكتمل');
      }).length;

      result.push({
        month: monthLabel,
        points: pointsCount,
        completed: completedCount,
      });
    }
    return result;
  }, [customers, pointsLog]);

  // 3. Product Distribution
  const productDistributionData = useMemo(() => {
    const visaCount = customers.filter((c) => c.productType === 'visa' && (c.status || '').trim() === 'تم التفعيل').length;
    const financeSalaryCount = customers.filter(
      (c) => c.productType === 'finance' && c.financeType !== 'no_salary_transfer' && c.financeType !== 'بدون تحويل راتب'
    ).length;
    const financeNoSalaryCount = customers.filter(
      (c) => c.productType === 'finance' && (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب')
    ).length;

    const data = [
      { name: 'بطاقات Visa', value: visaCount, color: '#8b5cf6' },
      { name: 'تمويل راتب', value: financeSalaryCount, color: '#10b981' },
      { name: 'تمويل بدون', value: financeNoSalaryCount, color: '#06b6d4' },
    ].filter((item) => item.value > 0);

    return data.length > 0
      ? data
      : [
          { name: 'بطاقات Visa', value: 1, color: '#8b5cf6' },
          { name: 'تمويل', value: 1, color: '#10b981' },
        ];
  }, [customers]);

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-24 pt-2 px-3 sm:px-4 print:p-0 print:space-y-0">
      <div className="screen-only no-print space-y-4">
      {/* Month Selection Bar */}
      <div className="bento-card w-full max-w-full min-w-0 p-3.5 bg-zinc-900/90 border-zinc-800 shadow-xl space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2 min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs font-bold text-zinc-200 truncate">{t('selectReportArchiveMonth', 'اختر شهر التقرير والأرشيف:')}</span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono border border-amber-500/30 shrink-0">
            {selectedMonthName}
          </span>
        </div>

        <div className="flex items-center gap-1.5 w-full max-w-full min-w-0 overflow-x-auto pb-1 no-scrollbar">
          {availableMonthKeys.map((mKey) => {
            const isCurrent = mKey === currentMonthKey;
            const isSelected = mKey === selectedMonthKey;
            const mLabel = language === 'ar' ? formatMonthKeyToArabic(mKey) : formatMonthKeyToEnglish(mKey);

            return (
              <button
                key={mKey}
                onClick={() => setSelectedMonthKey(mKey)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 shadow-md shadow-amber-500/20 ring-1 ring-amber-300'
                    : isCurrent
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 hover:bg-indigo-500/30'
                    : 'bg-zinc-800/80 text-zinc-400 border-zinc-700 hover:text-zinc-200 hover:bg-zinc-800'
                }`}
              >
                {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                <span>{mLabel}</span>
                {isCurrent && <span className="text-[9px] opacity-80">({t('current', 'الحالي')})</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Status Filter Bar with Dropdown Select (Strict separation — never merging executed & activated) */}
      <div className="bento-card w-full max-w-full min-w-0 p-3.5 bg-zinc-900/90 border-zinc-800 shadow-xl space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2 min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <Filter className="w-4 h-4 text-cyan-400 shrink-0" />
            <label htmlFor="report-status-filter" className="text-xs font-bold text-zinc-200 truncate">
              {language === 'ar' ? 'فلتر حالة العميل:' : 'Customer Status Filter:'}
            </label>
          </div>
          {selectedStatusFilter !== 'all' ? (
            <button
              type="button"
              onClick={() => setSelectedStatusFilter('all')}
              className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-bold border border-amber-500/30 flex items-center gap-1 transition-all shrink-0"
            >
              <RotateCcw className="w-3 h-3 shrink-0" />
              <span>{language === 'ar' ? 'عرض الكل' : 'Show All'}</span>
            </button>
          ) : (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-400 font-bold border border-zinc-700 shrink-0">
              {language === 'ar' ? 'الحالات مفصولة بالكامل' : 'Strict Status Separation'}
            </span>
          )}
        </div>

        {/* Status Filter Dropdown Menu */}
        <select
          id="report-status-filter"
          value={selectedStatusFilter}
          onChange={(e) => setSelectedStatusFilter(e.target.value)}
          className="w-full min-w-0 bg-zinc-950 border border-cyan-500/40 rounded-xl py-2.5 px-3 text-xs font-bold text-zinc-100 focus:outline-none focus:border-cyan-400 cursor-pointer shadow-sm"
        >
          <option value="all">
            {language === 'ar'
              ? `📋 جميع الحالات (${formatNumber(selectedMonthAllCustomers.length)})`
              : `📋 All Statuses (${formatNumber(selectedMonthAllCustomers.length)})`}
          </option>
          {availableStatuses.map((statusName) => {
            const countInMonth = selectedMonthAllCustomers.filter((c) => (c.status || '').trim() === statusName).length;
            return (
              <option key={statusName} value={statusName}>
                {`${getStatusIconEmoji(statusName)} ${getStatusTranslation(statusName, language)} (${formatNumber(countInMonth)})`}
              </option>
            );
          })}
        </select>

        <div className="flex items-center gap-1.5 w-full max-w-full min-w-0 overflow-x-auto pb-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setSelectedStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 border ${
              selectedStatusFilter === 'all'
                ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25'
                : 'bg-zinc-800/80 text-zinc-400 border-zinc-700 hover:text-zinc-200 hover:bg-zinc-800'
            }`}
          >
            <span>{language === 'ar' ? 'جميع الحالات' : 'All Statuses'}</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${selectedStatusFilter === 'all' ? 'bg-white/20 text-white' : 'bg-zinc-900 text-zinc-400'}`}>
              {formatNumber(selectedMonthAllCustomers.length)}
            </span>
          </button>

          {availableStatuses.map((statusName) => {
            const countInMonth = selectedMonthAllCustomers.filter((c) => (c.status || '').trim() === statusName).length;
            const isSelected = selectedStatusFilter === statusName;
            const activeClasses =
              statusName === 'تم التنفيذ'
                ? 'bg-cyan-500 text-zinc-950 border-cyan-300 shadow-md shadow-cyan-500/25'
                : statusName === 'تم التفعيل'
                ? 'bg-emerald-500 text-zinc-950 border-emerald-300 shadow-md shadow-emerald-500/25'
                : statusName === 'عميل معلق'
                ? 'bg-amber-500 text-zinc-950 border-amber-300 shadow-md shadow-amber-500/25'
                : statusName === 'عميل محتمل'
                ? 'bg-sky-500 text-zinc-950 border-sky-300 shadow-md shadow-sky-500/25'
                : 'bg-purple-500 text-white border-purple-300 shadow-md shadow-purple-500/25';

            const inactiveClasses =
              statusName === 'تم التنفيذ'
                ? 'bg-cyan-950/30 text-cyan-300 border-cyan-500/30 hover:bg-cyan-950/50'
                : statusName === 'تم التفعيل'
                ? 'bg-emerald-950/30 text-emerald-300 border-emerald-500/30 hover:bg-emerald-950/50'
                : statusName === 'عميل معلق'
                ? 'bg-amber-950/30 text-amber-300 border-amber-500/30 hover:bg-amber-950/50'
                : statusName === 'عميل محتمل'
                ? 'bg-sky-950/30 text-sky-300 border-sky-500/30 hover:bg-sky-950/50'
                : 'bg-zinc-800/80 text-zinc-300 border-zinc-700 hover:bg-zinc-800';

            return (
              <button
                key={statusName}
                type="button"
                onClick={() => setSelectedStatusFilter(statusName)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 border ${
                  isSelected ? activeClasses : inactiveClasses
                }`}
              >
                <span>{getStatusIconEmoji(statusName)}</span>
                <span>{getStatusTranslation(statusName, language)}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono font-black ${
                  isSelected ? 'bg-black/20 text-current' : 'bg-zinc-950/70 text-current'
                }`}>
                  {formatNumber(countInMonth)}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Month & Status Summary Card Banner */}
      <div className="bento-card w-full max-w-full min-w-0 p-3.5 sm:p-4 bg-gradient-to-br from-zinc-900 via-indigo-950/30 to-amber-950/20 border-amber-500/30 shadow-xl relative overflow-hidden">
        <div className="glow-top" />
        <div className="flex items-center justify-between gap-2 mb-3 border-b border-zinc-800/80 pb-2.5 min-w-0">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 shrink-0">
              <Archive className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm text-white flex flex-wrap items-center gap-1.5">
                <span className="break-words">{t('reportMonth', 'تقرير شهر')} {selectedMonthName}</span>
                {selectedStatusFilter !== 'all' ? (
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${getStatusBadgeStyle(selectedStatusFilter)}`}>
                    {getStatusIconEmoji(selectedStatusFilter)} {selectedStatusLabel} {language === 'ar' ? 'فقط' : 'Only'}
                  </span>
                ) : selectedMonthKey === currentMonthKey ? (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                    {t('inProgressStatus', 'جاري الإنجاز')}
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-mono border border-amber-500/30">
                    {t('completedArchiveStatus', 'أرشيف مكتمل')}
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-zinc-400 break-words leading-snug mt-0.5">
                {selectedStatusFilter !== 'all'
                  ? (language === 'ar'
                      ? `عرض النتائج الخاصة بحالة "${selectedStatusLabel}" فقط دون دمج أي حالات أخرى`
                      : `Showing results strictly for "${selectedStatusLabel}" only`)
                  : (language === 'ar'
                      ? 'اضغط على أي حالة لعزل التقرير وعرض تفاصيلها بشكل مستقل'
                      : 'Tap any status card to isolate its report independently')}
              </p>
            </div>
          </div>
        </div>

        {selectedStatusFilter === 'all' ? (
          <div className="grid grid-cols-2 gap-2 text-center my-3">
            <button
              type="button"
              onClick={() => setSelectedStatusFilter('تم التنفيذ')}
              className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-cyan-500/30 hover:border-cyan-400 transition-all text-center group"
            >
              <div className="text-[10px] text-cyan-300 font-bold truncate">🟢 {getStatusTranslation('تم التنفيذ', language)}</div>
              <div className="text-lg font-black text-cyan-400 mt-0.5 truncate">{formatNumber(selectedMonthExecutedCustomers.length)}</div>
              <div className="text-[10px] text-cyan-200/70 font-mono mt-0.5 truncate">{formatCurrency(executedMonthRevenue)}</div>
            </button>

            <button
              type="button"
              onClick={() => setSelectedStatusFilter('تم التفعيل')}
              className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-emerald-500/35 hover:border-emerald-400 transition-all text-center group"
            >
              <div className="text-[10px] text-emerald-300 font-bold truncate">⚡ {getStatusTranslation('تم التفعيل', language)}</div>
              <div className="text-lg font-black text-emerald-400 mt-0.5 truncate">{formatNumber(selectedMonthActivatedCustomers.length)}</div>
              <div className="text-[10px] text-amber-300/90 font-mono mt-0.5 truncate">{formatNumber(selectedMonthPoints)} {t('pointsUnit', 'نقطة')}</div>
            </button>

            <button
              type="button"
              onClick={() => setSelectedStatusFilter('عميل معلق')}
              className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-amber-500/25 hover:border-amber-400 transition-all text-center"
            >
              <div className="text-[10px] text-amber-300 font-bold truncate">⏳ {getStatusTranslation('عميل معلق', language)}</div>
              <div className="text-lg font-black text-amber-400 mt-0.5 truncate">{formatNumber(selectedMonthPendingCustomers.length)}</div>
            </button>

            <button
              type="button"
              onClick={() => setSelectedStatusFilter('عميل محتمل')}
              className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-sky-500/25 hover:border-sky-400 transition-all text-center"
            >
              <div className="text-[10px] text-sky-300 font-bold truncate">🔵 {getStatusTranslation('عميل محتمل', language)}</div>
              <div className="text-lg font-black text-sky-400 mt-0.5 truncate">{formatNumber(selectedMonthPotentialCustomers.length)}</div>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 text-center my-3">
            <div className={`min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border ${getStatusBadgeStyle(selectedStatusFilter)}`}>
              <div className="text-[10px] font-bold opacity-90 truncate">{getStatusIconEmoji(selectedStatusFilter)} {language === 'ar' ? `عملاء ${selectedStatusLabel}` : `${selectedStatusLabel} Clients`}</div>
              <div className="text-lg font-black mt-0.5 truncate">{formatNumber(statusScopedMonthCustomers.length)}</div>
            </div>

            <div className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-zinc-800">
              <div className="text-[10px] text-zinc-400 font-medium truncate">{language === 'ar' ? 'حجم المبيعات / الرواتب' : 'Sales / Salary Volume'}</div>
              <div className="text-sm font-black text-sky-400 mt-1 font-mono break-words">{formatCurrency(statusScopedRevenue)}</div>
            </div>

            <div className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-indigo-500/25">
              <div className="text-[10px] text-indigo-300 font-bold truncate">💳 {language === 'ar' ? 'بطاقات Visa' : 'Visa Cards'}</div>
              <div className="text-lg font-black text-indigo-400 mt-0.5 truncate">
                {formatNumber(statusScopedMonthCustomers.filter((c) => c.productType === 'visa').length)}
              </div>
            </div>

            {selectedStatusFilter === 'تم التفعيل' ? (
              <div className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-amber-500/30">
                <div className="text-[10px] text-amber-300 font-bold truncate">⭐ {t('monthPointsTotal', 'إجمالي النقاط')}</div>
                <div className="text-lg font-black text-amber-400 mt-0.5 truncate">{formatNumber(selectedMonthPoints)}</div>
              </div>
            ) : (
              <div className="min-w-0 overflow-hidden p-2.5 rounded-2xl bg-zinc-950/70 border border-emerald-500/25">
                <div className="text-[10px] text-emerald-300 font-bold truncate">💰 {language === 'ar' ? 'التمويل الشخصي' : 'Personal Finance'}</div>
                <div className="text-lg font-black text-emerald-400 mt-0.5 truncate">
                  {formatNumber(statusScopedMonthCustomers.filter((c) => c.productType === 'finance').length)}
                </div>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-end gap-2 pt-1 flex-wrap">
          {selectedStatusFilter !== 'all' && (
            <button
              onClick={() => setActiveReport('statusReport')}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'ar' ? 'عرض القائمة' : 'View List'}</span>
            </button>
          )}
          <button
            onClick={() => handleExportPDF(selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport')}
            disabled={isExportingPdf}
            className="px-3 py-1.5 rounded-xl bg-rose-500/20 text-rose-200 hover:bg-rose-500/30 disabled:opacity-50 border border-rose-500/35 text-xs font-bold transition-all flex items-center gap-1.5"
          >
            {isExportingPdf ? <Loader2 className="w-3.5 h-3.5 text-rose-300 animate-spin" /> : <FileText className="w-3.5 h-3.5 text-rose-400" />}
            <span>{isExportingPdf ? (language === 'ar' ? 'جاري التصدير...' : 'Exporting...') : (language === 'ar' ? 'تصدير PDF' : 'Export PDF')}</span>
          </button>
          <button
            onClick={() => handleExportExcel(selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport')}
            className="px-3 py-1.5 rounded-xl bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 border border-indigo-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-400" />
            <span>{t('exportExcelBtn', 'تصدير Excel')}</span>
          </button>
          <button
            onClick={() => handlePrint(selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport')}
            className="px-3 py-1.5 rounded-xl bg-sky-500/20 text-sky-200 hover:bg-sky-500/30 border border-sky-500/35 text-xs font-bold transition-all flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-sky-400" />
            <span>{language === 'ar' ? 'طباعة / معاينة A4' : 'Print / Preview A4'}</span>
          </button>
        </div>
      </div>

      {/* Live Status-Filtered Customers Table */}
      <div className="bento-card w-full max-w-full min-w-0 bg-zinc-900/95 border-zinc-800 shadow-xl overflow-hidden">
        <div className="glow-top" />
        <div className="p-3.5 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-2 min-w-0">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="p-1.5 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 shrink-0">
              <TableIcon className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="font-bold text-xs text-white flex flex-wrap items-center gap-1.5">
                <span>{language === 'ar' ? 'جدول العملاء في التقرير' : 'Report Customers Table'}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                  selectedStatusFilter === 'all'
                    ? 'border-indigo-500/30 bg-indigo-500/15 text-indigo-300'
                    : getStatusBadgeStyle(selectedStatusFilter)
                }`}>
                  {selectedStatusFilter === 'all'
                    ? (language === 'ar' ? 'الكل' : 'All')
                    : `${getStatusIconEmoji(selectedStatusFilter)} ${selectedStatusLabel}`}
                </span>
              </h4>
              <p className="text-[10px] text-zinc-400 mt-0.5 break-words leading-snug">
                {selectedStatusFilter === 'all'
                  ? (language === 'ar'
                      ? `إجمالي السجلات: ${formatNumber(statusScopedMonthCustomers.length)} — اختر حالة من القائمة أعلاه لعزل الجدول`
                      : `Total records: ${formatNumber(statusScopedMonthCustomers.length)} — pick a status above to isolate`)
                  : (language === 'ar'
                      ? `يعرض فقط عملاء "${selectedStatusLabel}" (${formatNumber(statusScopedMonthCustomers.length)} عميل)`
                      : `Showing strictly "${selectedStatusLabel}" (${formatNumber(statusScopedMonthCustomers.length)})`)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => handleExportPDF(selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport')}
              disabled={isExportingPdf || statusScopedMonthCustomers.length === 0}
              className="px-2.5 py-1 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 disabled:opacity-40 text-rose-200 border border-rose-500/35 text-[11px] font-bold flex items-center gap-1 transition-all"
              title={language === 'ar' ? 'تصدير الجدول المفلتر إلى PDF' : 'Export filtered table to PDF'}
            >
              {isExportingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5 text-rose-300" />}
              <span>PDF</span>
            </button>
            <span className="text-xs font-black font-mono px-2.5 py-1 rounded-xl bg-zinc-950 border border-zinc-800 text-amber-400">
              {formatNumber(statusScopedMonthCustomers.length)}
            </span>
          </div>
        </div>

        <div className="w-full max-w-full overflow-x-auto max-h-72 overflow-y-auto scrollbar-thin">
          <table className={`w-full border-collapse text-[11px] ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <thead className="bg-zinc-950/90 text-zinc-400 sticky top-0 z-10 border-b border-zinc-800">
              <tr>
                <th className="p-2.5 text-center w-8">#</th>
                <th className="p-2.5 whitespace-nowrap">{t('customerName', 'العميل')}</th>
                <th className="p-2.5 whitespace-nowrap">{t('productOrCardType', 'المنتج / البطاقة')}</th>
                <th className="p-2.5 whitespace-nowrap">{t('salaryOrAmountRequired', 'الراتب / التمويل')}</th>
                <th className="p-2.5 whitespace-nowrap text-center">{t('status', 'الحالة')}</th>
                <th className="p-2.5 whitespace-nowrap">{t('notes', 'الملاحظات')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70">
              {statusScopedMonthCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 px-4 text-center text-zinc-500 text-xs font-medium">
                    {language === 'ar'
                      ? `لا يوجد عملاء بحالة "${selectedStatusLabel}" في شهر ${selectedMonthName}`
                      : `No customers with status "${selectedStatusLabel}" in ${selectedMonthName}`}
                  </td>
                </tr>
              ) : (
                visibleStatusTableCustomers.map((c, idx) => {
                  const cardName = c.productType === 'visa' ? getCardTypeName(c.cardTypeId) : null;
                  const productLabel =
                    c.productType === 'visa'
                      ? `Visa ${cardName ? `(${cardName})` : ''}`.trim()
                      : t('personalFinance', 'تمويل شخصي');
                  const valueLabel =
                    c.productType === 'visa'
                      ? (c.salary ? formatCurrency(c.salary) : '-')
                      : formatCurrency(Number(c.amount || 0));
                  return (
                    <ReportTableRow
                      key={c.id ?? idx}
                      customer={c}
                      rowIndexLabel={formatNumber(idx + 1)}
                      formattedPhone={formatPhone(c.phone)}
                      productLabel={productLabel}
                      valueLabel={valueLabel}
                      statusBadgeClass={getStatusBadgeStyle(c.status)}
                      statusLabel={`${getStatusIconEmoji(c.status)} ${getStatusTranslation(c.status, language)}`}
                    />
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        {statusScopedMonthCustomers.length > tableVisibleLimit && (
          <div className="p-2.5 border-t border-zinc-800/80 flex items-center justify-center gap-2 bg-zinc-950/60">
            <button
              type="button"
              onClick={() => setTableVisibleLimit((prev) => prev + REPORT_TABLE_BATCH_SIZE)}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 border border-cyan-500/35 text-[11px] font-bold transition-colors active:scale-95"
            >
              {language === 'ar'
                ? `عرض المزيد (${formatNumber(Math.min(REPORT_TABLE_BATCH_SIZE, statusScopedMonthCustomers.length - tableVisibleLimit))} متبقي ${formatNumber(statusScopedMonthCustomers.length - tableVisibleLimit)})`
                : `Load More (${Math.min(REPORT_TABLE_BATCH_SIZE, statusScopedMonthCustomers.length - tableVisibleLimit)} of ${statusScopedMonthCustomers.length - tableVisibleLimit} left)`}
            </button>
            <button
              type="button"
              onClick={() => setTableVisibleLimit(statusScopedMonthCustomers.length)}
              className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 text-[11px] font-bold transition-colors active:scale-95"
            >
              {language === 'ar'
                ? `عرض الكل (${formatNumber(statusScopedMonthCustomers.length)})`
                : `Show All (${statusScopedMonthCustomers.length})`}
            </button>
          </div>
        )}
      </div>

      {/* Custom Report Builder Banner Card for Admin */}
      <button
        onClick={() => setIsCustomBuilderOpen(true)}
        className={`w-full max-w-full min-w-0 bento-card p-3.5 sm:p-4 transition-all hover:scale-[1.01] active:scale-98 flex items-center justify-between gap-2.5 shadow-xl bg-gradient-to-r from-indigo-950/80 via-zinc-900 to-indigo-900/40 border border-indigo-500/30 group ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
      >
        <div className="glow-top" />
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
          <div className="p-2.5 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 group-hover:scale-110 transition-transform shrink-0">
            <Sliders className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5 font-bold text-sm text-white">
              <span className="break-words">{t('customReportBuilderTitle', 'صانع التقارير المخصصة')}</span>
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-mono border border-indigo-500/30 shrink-0">{t('adminOnly', 'خاص بالأدمن')}</span>
            </div>
            <p className="text-[11px] text-zinc-400 mt-0.5 break-words leading-snug">
              {t('customReportBuilderDesc', 'فلترة حسب المنتجات والرواتب والبطاقات، تحديد الأعمدة، وتصدير Excel/PDF')}
            </p>
          </div>
        </div>
        <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400 shrink-0">
          <Sparkles className="w-5 h-5" />
        </div>
      </button>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 sm:gap-3">
        {reportTypes.map((r) => (
          <ReportSummaryCard
            key={r.id}
            id={r.id}
            icon={r.icon}
            title={r.title}
            color={r.color}
            formattedCount={formatNumber(r.count)}
            dir={dir}
            onSelect={handleOpenReport}
          />
        ))}
      </div>

      {/* Report Detailed View Modal */}
      {activeReport && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-2.5 sm:p-4 overflow-x-hidden">
          <div className={`bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-md sm:max-w-lg min-w-0 overflow-x-hidden p-4 sm:p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <div className="glow-top" />
            <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800 shrink-0 min-w-0">
              <h3 className="font-bold text-base text-white truncate min-w-0 flex-1">
                {reportTypes.find(r => r.id === activeReport)?.title}
              </h3>
              <button onClick={() => setActiveReport(null)} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 shrink-0">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden min-w-0 space-y-2 pr-1">
              {activeReport === 'targetBreakdown' ? (
                (() => {
                  const targetVal = (settings.monthlyTarget && settings.monthlyTarget > 1000) ? settings.monthlyTarget : 140000;
                  const monthlyLogs = pointsLog.filter(p => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth);
                  const achieved = selectedMonthPoints;
                  const remaining = Math.max(0, targetVal - achieved);
                  const progressPctRaw = targetVal > 0 ? (achieved / targetVal) * 100 : 0;
                  const progressPct = Math.min(100, progressPctRaw);

                  const infiniteNeeded = remaining > 0 ? Math.ceil(remaining / 8500) : 0;
                  const platinumNeeded = remaining > 0 ? Math.ceil(remaining / 4250) : 0;

                  return (
                    <div className="space-y-3">
                      {/* Overview Card */}
                      <div className="bg-gradient-to-br from-indigo-950/60 to-zinc-950 border border-indigo-500/30 p-3.5 sm:p-4 rounded-2xl text-center space-y-3">
                        <div className="text-[11px] text-zinc-400">
                          {t('monthlyCycle', 'الدورة الشهرية')}: <b className="text-white">{selectedMonthName}</b>
                        </div>

                        <div className="grid grid-cols-3 gap-1.5 sm:gap-2 bg-zinc-900/80 p-2 rounded-xl border border-zinc-800">
                          <div className="min-w-0 overflow-hidden">
                            <div className="text-[10px] text-zinc-400 truncate">{t('target', 'الهدف')}</div>
                            <div className="text-xs sm:text-sm font-black text-white font-mono truncate">{formatNumber(targetVal)}</div>
                          </div>
                          <div className="min-w-0 overflow-hidden border-x border-zinc-800 px-1">
                            <div className="text-[10px] text-emerald-400 truncate">{t('achieved', 'المحقق')}</div>
                            <div className="text-xs sm:text-sm font-black text-emerald-400 font-mono truncate">{formatNumber(achieved)}</div>
                          </div>
                          <div className="min-w-0 overflow-hidden">
                            <div className="text-[10px] text-amber-400 truncate">{t('remaining', 'المتبقي')}</div>
                            <div className="text-xs sm:text-sm font-black text-amber-300 font-mono truncate">{formatNumber(remaining)}</div>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-1">
                          <div className="h-2 w-full bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                            <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400" style={{ width: `${progressPct}%` }} />
                          </div>
                          <div className={`text-[10px] text-emerald-400 font-bold font-mono ${dir === 'rtl' ? 'text-left' : 'text-right'}`}>
                            {progressPctRaw > 100
                              ? t('completedPercentageWithPlus', '{pct}% تم إنجازه (+{plus}%)').replace('{pct}', formatNumber(progressPctRaw.toFixed(1))).replace('{plus}', formatNumber((progressPctRaw - 100).toFixed(1)))
                              : t('completedPercentage', '{pct}% تم إنجازه').replace('{pct}', formatNumber(progressPctRaw.toFixed(1)))}
                          </div>
                        </div>
                      </div>

                      {/* Card Requirements Cards */}
                      {remaining > 0 ? (
                        <div className="space-y-2">
                          <div className="text-xs font-bold text-zinc-300">
                            {t('neededForTargetCount', 'العدد المطلوب لاستكمال الهدف ({count} نقطة):').replace('{count}', formatNumber(remaining))}
                          </div>
                          <div className={`grid grid-cols-2 gap-2 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                            <div className="p-3 bg-purple-950/30 border border-purple-500/30 rounded-2xl">
                              <div className="text-[10px] text-purple-300 font-bold">{t('infiniteCardName', '💎 بطاقة إنفينيت')}</div>
                              <div className="text-lg font-black text-white font-mono my-0.5">
                                {formatNumber(infiniteNeeded)} <span className="text-xs font-normal">{t('cardUnit', 'بطاقة')}</span>
                              </div>
                              <div className="text-[9px] text-purple-400">
                                {t('pointsPerCard', '{pts} نقطة / بطاقة').replace('{pts}', formatNumber(8500))}
                              </div>
                            </div>
                            <div className="p-3 bg-indigo-950/30 border border-indigo-500/30 rounded-2xl">
                              <div className="text-[10px] text-indigo-300 font-bold">{t('platinumCardName', '💳 بطاقة بلاتينيوم')}</div>
                              <div className="text-lg font-black text-white font-mono my-0.5">
                                {formatNumber(platinumNeeded)} <span className="text-xs font-normal">{t('cardUnit', 'بطاقة')}</span>
                              </div>
                              <div className="text-[9px] text-indigo-400">
                                {t('pointsPerCard', '{pts} نقطة / بطاقة').replace('{pts}', formatNumber(4250))}
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs text-center font-bold rounded-2xl">
                          {t('monthlyGoalReachedCongrats', '🎉 تم الوصول للهدف الشهري بنجاح!')}
                        </div>
                      )}

                      {/* Monthly Point Log Items */}
                      <div className="pt-2">
                        <div className="text-xs font-bold text-zinc-400 mb-2">
                          {t('pointsEarnedLog', 'سجل النقاط المكتسبة خلال هذا الشهر ({count}):').replace('{count}', formatNumber(monthlyLogs.length))}
                        </div>
                        <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                          {monthlyLogs.length === 0 ? (
                            <div className="text-center py-4 text-zinc-500 text-xs">
                              {t('noPointsLogsThisMonth', 'لا يوجد عمليات كسب نقاط حتى الآن لهذا الشهر')}
                            </div>
                          ) : (
                            monthlyLogs.map((p) => (
                              <div key={p.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between gap-2 min-w-0 text-xs">
                                <div className="min-w-0 flex-1">
                                  <div className="font-bold text-zinc-200 break-words">{p.reason || t('ptsEarnReason', 'كسب نقاط')}</div>
                                  <div className="text-[10px] text-zinc-500 font-mono truncate">{new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
                                </div>
                                <span className="font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg font-mono shrink-0">+{formatNumber(p.points || 0)}</span>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : activeReport === 'points' ? (
                (() => {
                  const monthlyLogs = pointsLog.filter(p => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth);
                  const total = selectedMonthPoints;
                  return (
                    <div className="space-y-3">
                      <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl text-center">
                        <div className="text-xs text-amber-400 font-bold mb-1">{t('totalMonthlyPointsEarned', 'إجمالي النقاط المكتسبة هذا الشهر (تم التفعيل ⚡)')}</div>
                        <div className="text-3xl font-light text-amber-300 break-words">{formatNumber(total)} {t('pointsUnit')}</div>
                      </div>
                      <div className="space-y-1.5">
                        {monthlyLogs.map((p) => (
                          <div key={p.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between gap-2 min-w-0 text-xs">
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-zinc-200 break-words">{p.reason || t('ptsEarnReason', 'كسب نقاط')}</div>
                              <div className="text-[10px] text-zinc-500 font-mono truncate">{new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}</div>
                            </div>
                            <span className="font-black text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg shrink-0">+{formatNumber(p.points || 0)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()
              ) : activeReport === 'salaryReport' ? (
                (() => {
                  const data = getFilteredData('salaryReport');
                  const validSalaries = data.map(c => c.salary || (c.productType === 'finance' ? c.amount : 0) || 0).filter(s => s > 0);
                  const totalSum = validSalaries.reduce((acc, s) => acc + s, 0);
                  const avgSalary = validSalaries.length > 0 ? Math.round(totalSum / validSalaries.length) : 0;
                  const maxSalary = validSalaries.length > 0 ? Math.max(...validSalaries) : 0;

                  return (
                    <div className="space-y-3">
                      {/* Summary Cards */}
                      <div className="grid grid-cols-3 gap-1.5 sm:gap-2 text-center">
                        <div className="min-w-0 overflow-hidden bg-emerald-500/10 border border-emerald-500/20 p-2 rounded-2xl">
                          <div className="text-[10px] text-emerald-400 font-bold truncate">{t('totalSalaries', 'إجمالي الرواتب')}</div>
                          <div className="text-[11px] sm:text-xs font-black text-emerald-300 font-mono mt-0.5 break-words">{formatCurrency(totalSum)}</div>
                        </div>
                        <div className="min-w-0 overflow-hidden bg-indigo-500/10 border border-indigo-500/20 p-2 rounded-2xl">
                          <div className="text-[10px] text-indigo-400 font-bold truncate">{t('averageSalary', 'متوسط الراتب')}</div>
                          <div className="text-[11px] sm:text-xs font-black text-indigo-300 font-mono mt-0.5 break-words">{formatCurrency(avgSalary)}</div>
                        </div>
                        <div className="min-w-0 overflow-hidden bg-amber-500/10 border border-amber-500/20 p-2 rounded-2xl">
                          <div className="text-[10px] text-amber-400 font-bold truncate">{t('highestSalary', 'أعلى راتب')}</div>
                          <div className="text-[11px] sm:text-xs font-black text-amber-300 font-mono mt-0.5 break-words">{formatCurrency(maxSalary)}</div>
                        </div>
                      </div>

                      {/* Customer List with Salaries */}
                      <div className="space-y-1.5 pt-1">
                        <div className="text-xs font-bold text-zinc-400">
                          {t('clientsAndSalariesList', 'قائمة العملاء والرواتب المسجلة ({count}):').replace('{count}', formatNumber(data.length))}
                        </div>
                        {data.map((c) => (
                          <div key={c.id} className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-2xl flex items-center justify-between gap-2 min-w-0 text-xs">
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-zinc-100 break-words">{c.name}</div>
                              <div className="text-[10px] text-zinc-500 font-mono dir-ltr truncate">{formatPhone(c.phone)}</div>
                              <div className="text-[10px] text-indigo-400 font-bold mt-0.5 truncate">
                                {c.productType === 'visa' ? `Visa ${getCardTypeName(c.cardTypeId) ? `(${getCardTypeName(c.cardTypeId)})` : ''}` : t('personalFinance', 'تمويل شخصي')}
                              </div>
                            </div>
                            <div className={`${dir === 'rtl' ? 'text-left' : 'text-right'} font-mono shrink-0`}>
                              <div className="text-xs font-black text-emerald-400">{c.salary ? formatCurrency(c.salary) : formatCurrency(c.amount || 0)}</div>
                              <div className="text-[10px] text-zinc-500">{getStatusTranslation(c.status, language)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()
              ) : activeReport === 'cardTypeReport' ? (
                (() => {
                  const visaCustomers = getFilteredData('cardTypeReport');
                  const cardCountsMap: Record<string, number> = {};
                  visaCustomers.forEach(c => {
                    const ctName = getCardTypeName(c.cardTypeId) || t('undefinedCard', 'غير محدد');
                    cardCountsMap[ctName] = (cardCountsMap[ctName] || 0) + 1;
                  });

                  return (
                    <div className="space-y-3">
                      {/* Card Type Statistics Breakdown */}
                      <div className="grid grid-cols-2 gap-2">
                        {Object.entries(cardCountsMap).map(([ctName, count]) => (
                          <div key={ctName} className="min-w-0 overflow-hidden p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl flex items-center justify-between gap-2">
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-bold text-indigo-200 truncate">{ctName}</div>
                              <div className="text-[10px] text-indigo-400 font-mono truncate">
                                {formatNumber(((count / (visaCustomers.length || 1)) * 100).toFixed(1))}% {t('ofActiveCards', 'من البطاقات المفعلة')}
                              </div>
                            </div>
                            <div className="text-lg font-black text-white font-mono bg-indigo-500/20 px-2.5 py-0.5 rounded-xl border border-indigo-500/30 shrink-0">
                              {formatNumber(count)}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Customer List by Card Type */}
                      <div className="space-y-1.5 pt-1">
                        <div className="text-xs font-bold text-zinc-400">
                          {t('activeCreditCardClients', 'عملاء بطاقات الائتمان المفعلة ({count}):').replace('{count}', formatNumber(visaCustomers.length))}
                        </div>
                        {visaCustomers.map((c) => (
                          <div key={c.id} className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-2xl flex items-center justify-between gap-2 min-w-0 text-xs">
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-zinc-100 break-words">{c.name}</div>
                              <div className="text-[10px] text-zinc-500 font-mono dir-ltr truncate">{formatPhone(c.phone)}</div>
                              <div className="text-[10px] text-indigo-300 font-bold mt-0.5 flex items-center gap-1 min-w-0">
                                <CreditCard className="w-3 h-3 text-indigo-400 shrink-0" />
                                <span className="truncate">{getCardTypeName(c.cardTypeId) || t('undefinedCard', 'غير محدد')}</span>
                              </div>
                            </div>
                            <div className={`${dir === 'rtl' ? 'text-left' : 'text-right'} font-mono shrink-0`}>
                              <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${getStatusBadgeStyle(c.status)}`}>
                                {getStatusTranslation(c.status, language)}
                              </span>
                              {c.salary && <div className="text-[10px] text-zinc-400 mt-1">{t('salary', 'الراتب')}: {formatCurrency(c.salary)}</div>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()
              ) : activeReport === 'totalFinance' || activeReport === 'totalFinanceActivated' ? (
                (() => {
                  const finData = getFilteredData(activeReport);
                  const sumTotal = finData.reduce((acc, c) => acc + (Number(c.amount) || 0), 0);
                  const activeTitle = reportTypes.find((r) => r.id === activeReport)?.title || t('totalCompletedFinanceTitle', 'إجمالي التمويل');
                  const isActivatedFinance = activeReport === 'totalFinanceActivated' || selectedStatusFilter === 'تم التفعيل';
                  return (
                    <div className="space-y-3">
                      <div className={`${isActivatedFinance ? 'bg-emerald-500/10 border-emerald-500/25' : 'bg-cyan-500/10 border-cyan-500/25'} border p-4 rounded-2xl text-center`}>
                        <div className={`text-xs ${isActivatedFinance ? 'text-emerald-400' : 'text-cyan-300'} font-bold mb-1`}>{activeTitle}</div>
                        <div className={`text-2xl sm:text-3xl font-light break-words ${isActivatedFinance ? 'text-emerald-300' : 'text-cyan-200'}`}>{formatCurrency(sumTotal)}</div>
                      </div>
                      <div className="space-y-1.5">
                        {finData.length === 0 ? (
                          <div className="text-center py-8 text-zinc-500 text-xs">{t('noReportData', 'لا توجد بيانات لهذا التقرير')}</div>
                        ) : (
                          finData.map((c) => (
                            <div key={c.id} className="p-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl flex items-center justify-between gap-2 min-w-0 text-xs">
                              <div className="min-w-0 flex-1">
                                <div className="font-bold text-zinc-200 break-words">{c.name}</div>
                                <div className="text-[10px] text-zinc-500 font-mono dir-ltr truncate">{formatPhone(c.phone)}</div>
                              </div>
                              <div className="flex flex-col items-end gap-1 shrink-0">
                                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${getStatusBadgeStyle(c.status)}`}>
                                  {getStatusTranslation(c.status, language)}
                                </span>
                                <span className="font-black text-emerald-400">{formatCurrency(Number(c.amount || 0))}</span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  );
                })()
              ) : (
                (() => {
                  const data = getFilteredData(activeReport);
                  const visibleData = data.slice(0, modalVisibleLimit);
                  return data.length === 0 ? (
                    <div className="text-center py-10 text-zinc-500 text-xs font-medium">{t('noReportData', 'لا توجد بيانات لهذا التقرير')}</div>
                  ) : (
                    <>
                      {visibleData.map((c) => (
                        <ReportDetailCustomerItem
                          key={c.id}
                          customer={c}
                          formattedPhone={formatPhone(c.phone)}
                          cardTypeName={c.productType === 'visa' ? getCardTypeName(c.cardTypeId) : null}
                          financeTypeLabel={getFinanceTypeTranslation(c.financeType, language)}
                          financeRateLabel={
                            c.financeRate !== undefined && c.financeRate !== null ? `%${formatNumber(c.financeRate)}` : null
                          }
                          statusBadgeClass={getStatusBadgeStyle(c.status)}
                          statusLabel={getStatusTranslation(c.status, language)}
                          amountLabel={
                            c.productType === 'visa'
                              ? (c.salary ? formatCurrency(c.salary) : 'Visa')
                              : formatCurrency(Number(c.amount || 0))
                          }
                          pointsLabel={c.points ? `${formatNumber(c.points)} ${t('pointsUnit')}` : null}
                          dir={dir}
                        />
                      ))}
                      {data.length > modalVisibleLimit && (
                        <div className="pt-2 flex items-center justify-center gap-2">
                          <button
                            type="button"
                            onClick={() => setModalVisibleLimit((prev) => prev + REPORT_TABLE_BATCH_SIZE)}
                            className="px-3.5 py-2 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 border border-indigo-500/35 text-[11px] font-bold"
                          >
                            {language === 'ar'
                              ? `عرض المزيد (${formatNumber(data.length - modalVisibleLimit)} متبقي)`
                              : `Load More (${data.length - modalVisibleLimit} left)`}
                          </button>
                          <button
                            type="button"
                            onClick={() => setModalVisibleLimit(data.length)}
                            className="px-3 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-700 text-[11px] font-bold"
                          >
                            {language === 'ar' ? `عرض الكل (${formatNumber(data.length)})` : `Show All (${data.length})`}
                          </button>
                        </div>
                      )}
                    </>
                  );
                })()
              )}
            </div>

            {/* Actions Footer */}
            <div className="flex flex-wrap gap-2 pt-2 border-t border-zinc-800 shrink-0">
              <button
                onClick={() => handleExportPDF(activeReport)}
                disabled={isExportingPdf}
                className="flex-1 min-w-[96px] bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white py-2.5 px-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/25 transition-all"
                title={language === 'ar' ? 'تصدير PDF' : 'Export PDF'}
              >
                {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin shrink-0" /> : <FileText className="w-4 h-4 text-rose-100 shrink-0" />}
                <span>{isExportingPdf ? (language === 'ar' ? 'جاري التجهيز...' : 'Generating...') : (language === 'ar' ? 'تصدير PDF' : 'Export PDF')}</span>
              </button>

              <button
                onClick={() => handleExportExcel(activeReport)}
                className="flex-1 min-w-[96px] bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 px-2 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20"
                title={t('exportExcel', 'تصدير Excel')}
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-200 shrink-0" />
                <span>{t('exportExcel', 'Excel')}</span>
              </button>

              <button
                onClick={() => handlePrint(activeReport)}
                className="px-3 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-bold border border-zinc-700 flex items-center justify-center gap-1.5"
                title={language === 'ar' ? 'معاينة للطباعة' : 'Print Preview'}
              >
                <Printer className="w-4 h-4 text-sky-400 shrink-0" />
                <span>{language === 'ar' ? 'معاينة' : 'Preview'}</span>
              </button>

              <button
                onClick={() => handleExportCSV(activeReport)}
                className="px-2.5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-200 rounded-xl text-xs font-bold border border-zinc-700 flex items-center justify-center"
                title="CSV"
              >
                <span>CSV</span>
              </button>
            </div>
          </div>
        </div>
      )}

      </div>

      {/* Direct Print-Only A4 Report (mounted only when browser Print / Ctrl+P is active) */}
      {isBrowserPrinting && !isPrintPreviewModalOpen && (() => {
        const directReportId = activeReport || (selectedStatusFilter !== 'all' ? 'statusReport' : 'archiveReport');
        const directTitle =
          reportTypes.find((r) => r.id === directReportId)?.title ||
          (selectedStatusFilter !== 'all'
            ? (language === 'ar' ? `تقرير عملاء — ${selectedStatusLabel}` : `Customers Report — ${selectedStatusLabel}`)
            : t('salesReport', 'تقرير المبيعات والعملاء'));
        const directPointsRows = pointsLog.filter(
          (p) => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth
        );
        return (
          <PrintableReportSheet
            mode="print-only"
            reportTitle={directTitle}
            companyName={settings?.companyName}
            repName={currentUser?.username}
            cycleLabel={selectedMonthName}
            statusLabel={selectedStatusLabel}
            reportType={directReportId === 'points' ? 'points' : 'customers'}
            customers={directReportId === 'points' ? [] : getFilteredData(directReportId)}
            pointsLog={directReportId === 'points' ? directPointsRows : []}
            getCardTypeName={getCardTypeName}
            footerText={t('systemGeneratedReportFooter', 'تم استخراج هذا التقرير تلقائياً من نظام إدارة المبيعات Sales CRM')}
          />
        );
      })()}

      {/* In-App Print Preview & Document Control Modal */}
      {isPrintPreviewModalOpen && (
        <div className="print-modal-backdrop fixed inset-0 z-[100] bg-black/85 backdrop-blur-md flex flex-col items-center justify-start p-2 sm:p-5 overflow-y-auto overflow-x-hidden">
          {/* Sticky Action Toolbar (Hidden during print) */}
          <div className="no-print sticky top-2 z-[110] w-full max-w-4xl min-w-0 bg-zinc-900/95 border border-zinc-700 shadow-2xl rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2 mb-4 backdrop-blur-md">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPrintPreviewModalOpen(false)}
                className="px-3.5 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 hover:text-white border border-red-500/40 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
              >
                <X className="w-4 h-4" />
                <span>{t('closeAndReturn', '❌ إغلاق والعودة')}</span>
              </button>
              <span className="text-xs font-bold text-zinc-200 hidden sm:inline">
                {reportTypes.find((r) => r.id === printPreviewReportId)?.title}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {printPreviewReportId !== 'points' && (
                <select
                  value={selectedStatusFilter}
                  onChange={(e) => {
                    const nextStatus = e.target.value;
                    setSelectedStatusFilter(nextStatus);
                    if (nextStatus !== 'all') {
                      setPrintPreviewReportId('statusReport');
                    } else {
                      setPrintPreviewReportId('archiveReport');
                    }
                  }}
                  className="bg-zinc-950 border border-cyan-500/40 rounded-xl py-2 px-3 text-xs font-bold text-zinc-100 focus:outline-none focus:border-cyan-400 cursor-pointer"
                  aria-label={language === 'ar' ? 'فلتر حالة العميل للطباعة' : 'Print Status Filter'}
                >
                  <option value="all">
                    {language === 'ar' ? 'جميع الحالات' : 'All Statuses'}
                  </option>
                  {availableStatuses.map((statusName) => (
                    <option key={statusName} value={statusName}>
                      {`${getStatusIconEmoji(statusName)} ${getStatusTranslation(statusName, language)}`}
                    </option>
                  ))}
                </select>
              )}

              <button
                onClick={() => handleExportPDF(printPreviewReportId)}
                disabled={isExportingPdf}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-lg shadow-rose-600/30 transition-all active:scale-95"
              >
                {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                <span>{isExportingPdf ? (language === 'ar' ? 'جاري إنشاء PDF...' : 'Generating PDF...') : (language === 'ar' ? 'تحميل PDF' : 'Download PDF')}</span>
              </button>

              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-lg shadow-sky-600/30 transition-all active:scale-95"
              >
                <Printer className="w-4 h-4" />
                <span>{language === 'ar' ? 'طباعة A4' : 'Print A4'}</span>
              </button>

              <button
                onClick={() => handleExportExcel(printPreviewReportId)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>{t('exportExcel', 'تصدير Excel')}</span>
              </button>
            </div>
          </div>

          {/* Printable White A4 Sheet Document */}
          <PrintableReportSheet
            mode="preview"
            reportTitle={reportTypes.find((r) => r.id === printPreviewReportId)?.title || t('salesReport', 'تقرير المبيعات')}
            companyName={settings?.companyName}
            repName={currentUser?.username}
            cycleLabel={selectedMonthName}
            statusLabel={selectedStatusLabel}
            reportType={printPreviewReportId === 'points' ? 'points' : 'customers'}
            customers={printPreviewReportId === 'points' ? [] : getFilteredData(printPreviewReportId)}
            pointsLog={
              printPreviewReportId === 'points'
                ? pointsLog.filter((p) => new Date(p.timestamp) >= startOfSelectedMonth && new Date(p.timestamp) <= endOfSelectedMonth)
                : []
            }
            getCardTypeName={getCardTypeName}
            footerText={t('systemGeneratedReportFooter', 'تم استخراج هذا التقرير تلقائياً من نظام إدارة المبيعات Sales CRM')}
          />
        </div>
      )}

      {/* Custom Report Builder Modal (mounted & loaded strictly on demand) */}
      {isCustomBuilderOpen && (
        <div className="no-print">
          <Suspense fallback={null}>
            <CustomReportBuilderModal
              isOpen={isCustomBuilderOpen}
              onClose={() => setIsCustomBuilderOpen(false)}
              initialStatusFilter={selectedStatusFilter}
            />
          </Suspense>
        </div>
      )}
    </div>
  );
});
