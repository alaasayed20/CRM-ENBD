import React, { useState, useMemo } from 'react';
import { db, generateOrderNumber, calculatePoints, calculateCardPoints, logOperation } from '../db/db';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { useLanguage } from '../context/LanguageContext';
import { useLiveQuery } from 'dexie-react-hooks';
import { RefreshCw, Save, User, Phone, Mail, FileText, CreditCard, DollarSign, Calendar, Camera, Sparkles, Calculator, AlertTriangle, ExternalLink } from 'lucide-react';
import type { CustomerStatus, ProductType } from '../types';
import { CameraScanModal, type ScannedCustomerData } from '../components/CameraScanModal';
import { FinanceCalculatorModal } from '../components/FinanceCalculatorModal';
import { getStoredPersonalFinanceRates, calculateFinanceRateFromSalary, type PersonalFinanceRatesConfig } from '../utils/finance';
import { getAvailableMonthOptions, getCurrentMonthKey, getExactDateForMonth, formatMonthKeyToArabic } from '../utils/monthRollover';
import { getCardTypeName, getStatusTranslation } from '../utils/translations';
import { triggerHaptic } from '../utils/haptics';
import { normalizePhoneForMatch } from '../utils/security';
import {
  parseScheduledCardIssuanceFromNote,
  schedulePotentialCustomerForIssuanceMonth,
  upsertScheduledIssuanceSnippetInNote,
} from '../utils/scheduledIssuance';

interface AddCustomerPageProps {
  onOpenExistingCustomer?: (customerId: number) => void;
}

export const AddCustomerPage: React.FC<AddCustomerPageProps> = ({ onOpenExistingCustomer }) => {
  const { setCurrentPage, currentUser, selectedMonthKey, setSelectedMonthKey } = useAuth();
  const { showToast } = useToast();
  const { t, formatNumber, formatCurrency, dir, language } = useLanguage();

  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) || [];
  const statuses = useLiveQuery(() => db.statuses.orderBy('order').toArray(), []) || [];
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) || [];
  const allCustomers = useLiveQuery(() => db.customers.toArray(), []) || [];

  const [showScanModal, setShowScanModal] = useState(false);
  const [showFinanceCalcModal, setShowFinanceCalcModal] = useState(false);
  const [confirmDuplicateOverride, setConfirmDuplicateOverride] = useState(false);

  // Restore draft if user refreshes page while typing
  const [name, setName] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d) return JSON.parse(d).name || '';
    } catch {}
    return '';
  });

  const [phone, setPhone] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d) return JSON.parse(d).phone || '';
    } catch {}
    return '';
  });

  const [idNumber, setIdNumber] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d) return JSON.parse(d).idNumber || '';
    } catch {}
    return '';
  });

  const [email, setEmail] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d) return JSON.parse(d).email || '';
    } catch {}
    return '';
  });

  const [orderNumber, setOrderNumber] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).orderNumber) return JSON.parse(d).orderNumber;
    } catch {}
    return generateOrderNumber();
  });

  const [productType, setProductType] = useState<ProductType>(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).productType) return JSON.parse(d).productType;
    } catch {}
    return 'visa';
  });

  const [cardTypeId, setCardTypeId] = useState<number | ''>(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).cardTypeId !== undefined) return JSON.parse(d).cardTypeId;
    } catch {}
    return '';
  });

  const [salary, setSalary] = useState<string>(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).salary) return JSON.parse(d).salary;
    } catch {}
    return '';
  });

  const [amount, setAmount] = useState<string>(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).amount) return JSON.parse(d).amount;
    } catch {}
    return '';
  });

  const [financeType, setFinanceType] = useState<'salary_transfer' | 'no_salary_transfer'>('salary_transfer');
  const [financeRate, setFinanceRate] = useState<string>('');

  // Live Query personal finance rates
  const liveRatesSetting = useLiveQuery(() => db.settings.get('personalFinanceRates'));
  const activeFinanceRates = React.useMemo<PersonalFinanceRatesConfig>(() => {
    if (liveRatesSetting?.value) return liveRatesSetting.value as PersonalFinanceRatesConfig;
    return getStoredPersonalFinanceRates();
  }, [liveRatesSetting]);

  // Suggested default rate based on salary and transfer type
  const suggestedRate = React.useMemo(() => {
    const sal = parseFloat(salary) || 0;
    const loan = parseFloat(amount) || 100000;
    if (sal > 0) {
      return calculateFinanceRateFromSalary(sal, loan, financeType, activeFinanceRates);
    }
    return financeType === 'salary_transfer' 
      ? activeFinanceRates.quickDefaultStl 
      : activeFinanceRates.quickDefaultNstl;
  }, [salary, amount, financeType, activeFinanceRates]);

  const [status, setStatus] = useState<CustomerStatus>('عميل محتمل');
  
  const [targetMonth, setTargetMonth] = useState<string>(() => {
    return selectedMonthKey !== 'all' ? selectedMonthKey : getCurrentMonthKey();
  });

  const [registrationDate, setRegistrationDate] = useState<string>(() => {
    const initMonth = selectedMonthKey !== 'all' ? selectedMonthKey : getCurrentMonthKey();
    const d = getExactDateForMonth(initMonth, new Date().getDate());
    return d.toISOString().split('T')[0];
  });

  const handleMonthChange = (newMonthKey: string) => {
    if (!newMonthKey || !newMonthKey.includes('-')) return;
    setTargetMonth(newMonthKey);
    const d = getExactDateForMonth(newMonthKey, 15);
    setRegistrationDate(d.toISOString().split('T')[0]);
  };

  const availableMonths = useMemo(
    () => getAvailableMonthOptions(allCustomers, [targetMonth]).filter((m) => m.key !== 'all'),
    [allCustomers, targetMonth]
  );
  const [followUpDate, setFollowUpDate] = useState('');
  const [notes, setNotes] = useState(() => {
    try {
      const d = localStorage.getItem('sales_crm_add_customer_draft');
      if (d && JSON.parse(d).notes) return JSON.parse(d).notes;
    } catch {}
    return '';
  });
  const [autoScheduleIssuance, setAutoScheduleIssuance] = useState(true);
  const [scheduleMode, setScheduleMode] = useState<'add_in_month' | 'move_to_month'>('add_in_month');
  const [showQuickIssuancePicker, setShowQuickIssuancePicker] = useState(false);
  const [quickIssuanceDate, setQuickIssuanceDate] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const detectedIssuance = useMemo(
    () => parseScheduledCardIssuanceFromNote(notes, targetMonth),
    [notes, targetMonth]
  );

  // Auto-save form draft so reloading the page never loses user work
  React.useEffect(() => {
    if (name.trim() || phone.trim() || idNumber.trim() || notes.trim()) {
      try {
        localStorage.setItem(
          'sales_crm_add_customer_draft',
          JSON.stringify({
            name,
            phone,
            idNumber,
            email,
            orderNumber,
            productType,
            cardTypeId,
            salary,
            amount,
            notes,
            targetMonth,
            registrationDate,
            status
          })
        );
      } catch {}
    }
  }, [name, phone, idNumber, email, orderNumber, productType, cardTypeId, salary, amount, notes, targetMonth, registrationDate, status]);

  // Prompt before unload if user is actively filling out the customer form
  React.useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (name.trim() || phone.trim()) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [name, phone]);

  const handleScanExtracted = (data: ScannedCustomerData) => {
    if (data.name) setName(data.name);
    if (data.phone) setPhone(data.phone);
    if (data.idNumber) setIdNumber(data.idNumber);
    if (data.email) setEmail(data.email);
    if (data.productType) setProductType(data.productType);
    if (data.salary) setSalary(String(data.salary));
    if (data.amount) setAmount(String(data.amount));
    if (data.financeType) {
      setFinanceType(data.financeType === 'no_salary_transfer' || data.financeType === 'بدون تحويل راتب' ? 'no_salary_transfer' : 'salary_transfer');
    }
    if (data.financeRate) setFinanceRate(String(data.financeRate));
    if (data.notes) setNotes(prev => prev ? `${prev}\n${data.notes}` : (data.notes || ''));
    showToast(t('scanExtractedSuccess', 'تمت تعبئة نموذج العميل بالمسح الذكي ✨'));
  };

  // Real-time duplicate phone detection
  const duplicateCustomer = useMemo(() => {
    const normalizedInput = normalizePhoneForMatch(phone);
    if (!normalizedInput || normalizedInput.length < 7) return null;
    return allCustomers.find((c) => normalizePhoneForMatch(c.phone || '') === normalizedInput) || null;
  }, [phone, allCustomers]);

  React.useEffect(() => {
    setConfirmDuplicateOverride(false);
  }, [phone]);

  const parsedSalary = parseFloat(salary) || 0;
  const selectedCardType = cardTypes.find((ct) => ct.id === cardTypeId);
  const baseCardPoints = selectedCardType && typeof selectedCardType.points === 'number' ? selectedCardType.points : 0;
  const expectedPoints = baseCardPoints > 0
    ? calculateCardPoints(baseCardPoints, parsedSalary, productType, salaryTiers)
    : calculatePoints(parsedSalary);

  const handleGenerateOrder = () => {
    setOrderNumber(generateOrderNumber());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      showToast(t('namePhoneRequired', 'الاسم ورقم الجوال مطلوبان'), 'error');
      return;
    }

    if (duplicateCustomer && !confirmDuplicateOverride) {
      triggerHaptic('warning');
      showToast(
        language === 'ar'
          ? `رقم الجوال مسجل مسبقاً للعميل "${duplicateCustomer.name}". فعّل خيار تأكيد الإضافة أو افتح الملف الموجود.`
          : `Phone already exists for "${duplicateCustomer.name}". Confirm override or open existing record.`,
        'warning'
      );
      return;
    }

    if (productType === 'finance' && (!amount || parseFloat(amount) <= 0)) {
      showToast(t('amountRequiredFinance', 'المبلغ المطلوب مطلوب للتمويل الشخصي'), 'error');
      return;
    }

    setSubmitting(true);
    try {
      const todayStr = new Date().toISOString().split('T')[0];
      const shouldAutoSchedule = Boolean(
        detectedIssuance && autoScheduleIssuance && detectedIssuance.isDifferentFromSourceMonth
      );
      const moveDirectlyToIssuanceMonth = shouldAutoSchedule && scheduleMode === 'move_to_month';

      const finalStatus: CustomerStatus = moveDirectlyToIssuanceMonth ? 'عميل محتمل' : status;
      const numSalary = parsedSalary > 0 ? parsedSalary : null;
      const numAmount = parseFloat(amount) || null;
      const numFinanceRate = productType === 'finance' && financeRate ? parseFloat(financeRate) : null;
      const strFinanceType = productType === 'finance' ? financeType : null;

      const effectiveFollowUpDate = moveDirectlyToIssuanceMonth && detectedIssuance
        ? detectedIssuance.issuanceDate
        : (followUpDate || (finalStatus === 'متابعة' ? todayStr : null));

      const selectedRegDate = moveDirectlyToIssuanceMonth && detectedIssuance
        ? getExactDateForMonth(detectedIssuance.targetMonth, detectedIssuance.hasExactDay ? detectedIssuance.day : 1)
        : (registrationDate ? new Date(registrationDate + 'T12:00:00') : new Date());

      const computedMonthKey = moveDirectlyToIssuanceMonth && detectedIssuance
        ? detectedIssuance.targetMonth
        : (targetMonth || `${selectedRegDate.getFullYear()}-${String(selectedRegDate.getMonth() + 1).padStart(2, '0')}`);

      const newCustomer = {
        name: name.trim(),
        phone: phone.trim(),
        idNumber: idNumber.trim() || null,
        email: email.trim() || null,
        orderNumber: orderNumber.trim() || generateOrderNumber(),
        productType: moveDirectlyToIssuanceMonth ? ('visa' as ProductType) : productType,
        cardTypeId: (moveDirectlyToIssuanceMonth || productType === 'visa') && cardTypeId ? Number(cardTypeId) : null,
        salary: numSalary,
        amount: moveDirectlyToIssuanceMonth ? null : numAmount,
        financeType: moveDirectlyToIssuanceMonth ? null : strFinanceType,
        financeRate: moveDirectlyToIssuanceMonth ? null : numFinanceRate,
        points: expectedPoints > 0 ? expectedPoints : null,
        status: finalStatus,
        targetMonth: computedMonthKey,
        followUpDate: effectiveFollowUpDate,
        notes: notes.trim() || null,
        salesRepId: currentUser?.id,
        createdAt: selectedRegDate,
        updatedAt: selectedRegDate,
        activatedAt: finalStatus === 'تم التفعيل' ? selectedRegDate : null
      };

      const id = await db.customers.add(newCustomer);
      
      if (effectiveFollowUpDate || finalStatus === 'متابعة') {
        await db.tasks.add({
          customerId: id,
          title: moveDirectlyToIssuanceMonth
            ? (language === 'ar' ? `موعد إصدار بطاقة العميل: ${newCustomer.name}` : `Scheduled card issuance: ${newCustomer.name}`)
            : (language === 'ar' ? `متابعة العميل: ${newCustomer.name}` : `Follow up: ${newCustomer.name}`),
          type: 'followup',
          date: effectiveFollowUpDate || todayStr,
          status: 'pending',
          notes: notes.trim() || (language === 'ar' ? 'موعد متابعة للعميل' : 'Customer follow-up appointment'),
          priority: moveDirectlyToIssuanceMonth ? 'high' : 'medium',
          createdAt: new Date()
        });
      }
      
      if (finalStatus === 'تم التفعيل' && expectedPoints > 0) {
        await db.pointsLog.add({
          customerId: id,
          salesRepId: currentUser?.id,
          points: expectedPoints,
          reason: `إضافة عميل جديد بحالة تم التفعيل (${newCustomer.name})`,
          month: selectedRegDate.getMonth() + 1,
          year: selectedRegDate.getFullYear(),
          timestamp: selectedRegDate
        });
      }

      await logOperation('CREATE', 'customers', id, null, newCustomer, currentUser?.id);

      let scheduledMonthLabel = '';
      if (shouldAutoSchedule && !moveDirectlyToIssuanceMonth && detectedIssuance) {
        const selectedCard = cardTypes.find((c) => c.id === Number(cardTypeId));
        const res = await schedulePotentialCustomerForIssuanceMonth(
          {
            name: newCustomer.name,
            phone: newCustomer.phone,
            idNumber: newCustomer.idNumber,
            email: newCustomer.email,
            salary: newCustomer.salary,
            cardTypeId: newCustomer.cardTypeId,
            cardTypeName: selectedCard?.name || null,
            points: newCustomer.points,
            notes: newCustomer.notes,
            salesRepId: currentUser?.id,
          },
          detectedIssuance,
          { userId: currentUser?.id, language }
        );
        scheduledMonthLabel = language === 'ar' ? res.monthLabelAr : res.monthLabelEn;
      }

      try {
        localStorage.removeItem('sales_crm_add_customer_draft');
      } catch {}

      if (moveDirectlyToIssuanceMonth && detectedIssuance) {
        showToast(
          language === 'ar'
            ? `تم تسجيل العميل كـ «عميل محتمل» في شهر ${formatMonthKeyToArabic(detectedIssuance.targetMonth)} مع تذكير بموعد إصدار البطاقة 📅`
            : `Customer scheduled as Potential in ${detectedIssuance.labelEn} 📅`,
          'success'
        );
      } else if (scheduledMonthLabel) {
        showToast(
          language === 'ar'
            ? `تم حفظ العميل وإضافته تلقائياً كـ «عميل محتمل» في شهر ${scheduledMonthLabel} لإصدار البطاقة 📅✨`
            : `Customer saved & auto-added as Potential in ${scheduledMonthLabel} for card issuance 📅✨`,
          'success'
        );
      } else {
        showToast(t('customerAddedSuccess', 'تمت إضافة العميل بنجاح'), 'success');
      }
      if (computedMonthKey && computedMonthKey.includes('-')) {
        setSelectedMonthKey(computedMonthKey);
      }
      setCurrentPage('customers');
    } catch (err) {
      console.error('Error adding customer:', err);
      showToast(t('errorSavingCustomer', 'حدث خطأ أثناء حفظ العميل'), 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-24 pt-2 px-3 sm:px-4">
      {/* AI Smart Scan Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-purple-950/80 to-zinc-900 border border-indigo-500/40 p-3.5 rounded-2xl flex items-center justify-between flex-wrap sm:flex-nowrap gap-3 min-w-0 shadow-xl">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/40 shrink-0">
            <Camera className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="text-xs font-extrabold text-zinc-100 flex items-center gap-1.5 flex-wrap">
              <span className="break-words">{t('aiCardScan', 'قراءة كارت / صورة بالذكاء الاصطناعي')}</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            </h4>
            <p className="text-[10px] text-zinc-300 mt-0.5 break-words">{t('aiScanSubtitle', 'استخراج الاسم، الجوال والبيانات تلقائياً')}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowScanModal(true)}
          className="w-full sm:w-auto shrink-0 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold text-xs py-2.5 px-3.5 rounded-xl shadow-lg shadow-indigo-600/30 active:scale-95 transition-all flex items-center justify-center gap-1.5 whitespace-nowrap border border-indigo-400/30"
        >
          <Camera className="w-3.5 h-3.5 shrink-0" />
          <span>{t('scanBtn', 'التقاط / مسح')}</span>
        </button>
      </div>

      <div className="bento-card bg-zinc-900 border-zinc-700/80 p-3.5 sm:p-5 min-w-0 shadow-2xl">
        <div className="glow-top" />
        <form onSubmit={handleSubmit} className={`space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
          {/* Customer Name */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <User className="w-4 h-4 text-zinc-300 group-focus-within:text-amber-400 transition-colors" />
                <span>{t('customerName')} <span className="text-rose-400 font-black text-sm">*</span></span>
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                {language === 'ar' ? 'الاسم الكامل' : 'Full Name'}
              </span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t('namePlaceholder', 'اسم العميل الكامل')}
                required
                className={`w-full bg-zinc-900 border border-zinc-600 rounded-xl py-3 text-white text-sm font-bold focus:outline-none focus:border-amber-400 focus:bg-zinc-800 transition-all placeholder:text-zinc-400 shadow-inner ${
                  dir === 'rtl' ? 'pr-10 pl-3.5' : 'pl-10 pr-3.5'
                }`}
              />
              <User className={`w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
            </div>
          </div>

          {/* Customer Phone */}
          <div className={`group bg-zinc-950/90 p-3.5 rounded-2xl border-2 transition-all shadow-md ${
            duplicateCustomer
              ? 'border-amber-500/80 ring-2 ring-amber-500/25'
              : 'border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40'
          }`}>
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-zinc-300 group-focus-within:text-amber-400 transition-colors" />
                <span>{t('phone')} <span className="text-rose-400 font-black text-sm">*</span></span>
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                {language === 'ar' ? 'رقم الجوال' : 'Phone'}
              </span>
            </label>
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="05xxxxxxxx"
                required
                className={`w-full bg-zinc-900 border border-zinc-600 rounded-xl py-3 text-white text-sm font-bold focus:outline-none focus:border-amber-400 focus:bg-zinc-800 transition-all dir-ltr shadow-inner placeholder:text-zinc-400 ${
                  dir === 'rtl' ? 'pr-10 pl-3.5' : 'pl-10 pr-3.5'
                }`}
              />
              <Phone className={`w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
            </div>

            {duplicateCustomer && (
              <div className="mt-2.5 p-3 rounded-xl bg-amber-500/15 border border-amber-500/45 space-y-2.5 animate-fadeIn">
                <div className="flex items-start gap-2 min-w-0">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-black text-amber-200">
                      {language === 'ar' ? 'تنبيه: رقم الجوال مسجل مسبقاً!' : 'Warning: Duplicate Phone Number!'}
                    </div>
                    <div className="text-[11px] text-amber-100/90 mt-0.5 break-words">
                      {language === 'ar' ? 'العميل المسجل:' : 'Existing client:'}{' '}
                      <strong className="text-white">{duplicateCustomer.name}</strong>
                      {' · '}
                      <span className="text-amber-300 font-bold">{getStatusTranslation(duplicateCustomer.status, language)}</span>
                      {duplicateCustomer.orderNumber ? ` (#${duplicateCustomer.orderNumber})` : ''}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-amber-500/25">
                  {onOpenExistingCustomer && duplicateCustomer.id && (
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        onOpenExistingCustomer(duplicateCustomer.id!);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-[11px] flex items-center gap-1.5 transition-all active:scale-95"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'عرض ملف العميل الموجود' : 'Open Existing Profile'}</span>
                    </button>
                  )}

                  <label className="flex items-center gap-1.5 text-[11px] text-amber-200 font-bold cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={confirmDuplicateOverride}
                      onChange={(e) => setConfirmDuplicateOverride(e.target.checked)}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                    <span>{language === 'ar' ? 'متابعة الإضافة كطلب جديد' : 'Add anyway as new order'}</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* Email */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-zinc-300 group-focus-within:text-amber-400 transition-colors" />
                <span>{t('email', 'البريد الإلكتروني')} ({t('optional', 'اختياري')})</span>
              </span>
              <span className="text-[10px] font-bold text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-full border border-zinc-700">
                {t('optional', 'اختياري')}
              </span>
            </label>
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@email.com"
                className={`w-full bg-zinc-900 border border-zinc-600 rounded-xl py-3 text-white text-sm font-bold focus:outline-none focus:border-amber-400 focus:bg-zinc-800 transition-all dir-ltr shadow-inner placeholder:text-zinc-400 ${
                  dir === 'rtl' ? 'pr-10 pl-3.5' : 'pl-10 pr-3.5'
                }`}
              />
              <Mail className={`w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
            </div>
          </div>

          {/* National ID / Iqama */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-zinc-300 group-focus-within:text-amber-400 transition-colors" />
                <span>{language === 'ar' ? 'رقم الهوية الوطنية / الإقامة' : 'National ID / Iqama'} ({t('optional', 'اختياري')})</span>
              </span>
              <span className="text-[10px] font-bold text-zinc-400 bg-zinc-800 px-2 py-0.5 rounded-full border border-zinc-700">
                {t('optional', 'اختياري')}
              </span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={idNumber}
                onChange={(e) => setIdNumber(e.target.value)}
                placeholder="10xxxxxxxx / 20xxxxxxxx"
                className={`w-full bg-zinc-900 border border-zinc-600 rounded-xl py-3 text-white text-sm font-mono font-bold focus:outline-none focus:border-amber-400 focus:bg-zinc-800 transition-all shadow-inner placeholder:text-zinc-400 ${
                  dir === 'rtl' ? 'pr-10 pl-3.5' : 'pl-10 pr-3.5'
                }`}
              />
              <FileText className={`w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
            </div>
          </div>

          {/* Order Number Generator */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-zinc-300 group-focus-within:text-amber-400 transition-colors" />
                <span>{t('orderNumber', 'رقم الطلب / الملف')}</span>
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40 font-mono">
                Auto
              </span>
            </label>
            <div className="relative flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="CRM-2026-1234"
                  className={`w-full bg-zinc-900 border border-zinc-600 rounded-xl py-3 text-amber-300 text-sm font-mono font-black focus:outline-none focus:border-amber-400 focus:bg-zinc-800 transition-all dir-ltr shadow-inner ${
                    dir === 'rtl' ? 'pr-10 pl-3.5' : 'pl-10 pr-3.5'
                  }`}
                />
                <FileText className={`w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3.5' : 'left-3.5'}`} />
              </div>
              <button
                type="button"
                onClick={handleGenerateOrder}
                className="bg-zinc-800 hover:bg-zinc-700 text-zinc-200 p-3 rounded-xl border border-zinc-600 flex items-center justify-center transition-all active:scale-95"
                title={t('generateNewOrderNumber', 'توليد رقم جديد')}
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Product Type Selector */}
          <div className="bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 shadow-md">
            <label className="block text-xs font-black text-zinc-200 mb-2">
              {t('productType', 'نوع المنتج')} <span className="text-rose-400 font-black text-sm">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setProductType('visa')}
                className={`py-3 px-3 rounded-xl border-2 font-black text-xs flex items-center justify-center gap-2 transition-all ${
                  productType === 'visa'
                    ? 'bg-indigo-500/25 text-indigo-200 border-indigo-400 shadow-lg shadow-indigo-500/20'
                    : 'bg-zinc-900 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>{t('cardsProduct')}</span>
              </button>

              <button
                type="button"
                onClick={() => setProductType('finance')}
                className={`py-3 px-3 rounded-xl border-2 font-black text-xs flex items-center justify-center gap-2 transition-all ${
                  productType === 'finance'
                    ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400 shadow-lg shadow-emerald-500/20'
                    : 'bg-zinc-900 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                }`}
              >
                <DollarSign className="w-4 h-4" />
                <span>{t('financeProduct')}</span>
              </button>
            </div>
          </div>

          {/* Dynamic Product Fields */}
          {productType === 'visa' ? (
            <div className="space-y-3 bg-zinc-950 border-2 border-indigo-500/40 p-4 rounded-2xl shadow-inner">
              <div className="group bg-zinc-900/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all">
                <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
                  <span>{language === 'ar' ? 'نوع البطاقة الائتمانية' : 'Credit Card Type'}</span>
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                    Visa
                  </span>
                </label>
                <select
                  value={cardTypeId}
                  onChange={(e) => setCardTypeId(e.target.value ? Number(e.target.value) : '')}
                  className="w-full bg-zinc-950 border-2 border-zinc-600 rounded-xl py-3 px-3 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
                >
                  <option value="" className="bg-zinc-900 text-zinc-400">
                    {language === 'ar' ? 'اختر نوع البطاقة...' : 'Select card type...'}
                  </option>
                  {cardTypes.map((ct) => (
                    <option key={ct.id} value={ct.id} className="bg-zinc-900 text-white font-medium py-1">
                      {getCardTypeName(ct.name, language)} ({typeof ct.points === 'number' ? `${formatNumber(ct.points)} ${t('pointsShort')}` : `50 ${t('pointsShort')}`})
                    </option>
                  ))}
                </select>
              </div>

              <div className="group bg-zinc-900/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all">
                <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
                  <span>{language === 'ar' ? 'الراتب الشهري (ر.س)' : 'Monthly Salary (SAR)'}</span>
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                    {t('sar')}
                  </span>
                </label>
                <input
                  type="number"
                  step="any"
                  value={salary}
                  onChange={(e) => setSalary(e.target.value)}
                  placeholder="15000"
                  min="0"
                  className="w-full bg-zinc-950 border-2 border-zinc-600 rounded-xl py-3 px-3 text-white text-sm font-mono font-black focus:outline-none focus:border-amber-400 dir-ltr text-right placeholder:text-zinc-400"
                />
                {selectedCardType && (
                  <div className="mt-2.5 p-3 bg-zinc-950/90 border border-indigo-500/40 rounded-xl space-y-1.5 text-xs">
                    <div className="flex items-center justify-between font-bold text-zinc-200">
                      <span>{language === 'ar' ? 'نقاط البطاقة الأساسية:' : 'Base Card Points:'}</span>
                      <span className="text-indigo-400 font-mono text-sm font-black">{formatNumber(baseCardPoints)} {t('pointsShort')}</span>
                    </div>

                    <div className="text-zinc-300 leading-relaxed">
                      {parsedSalary <= 0 ? (
                        <span className="text-amber-300">{language === 'ar' ? '💡 أدخل الراتب لحساب النقاط حسب جدول فئات الراتب' : '💡 Enter salary to calculate points based on salary tiers'}</span>
                      ) : parsedSalary <= 15000 ? (
                        <span className="text-rose-300 font-medium">
                          {language === 'ar' 
                            ? <>⚠️ الراتب من 6,000 إلى 15,000 (أو أقل) 👈 النتيجة: <strong className="font-mono text-rose-400">0 نقطة</strong></>
                            : <>⚠️ Salary ≤ 15,000 👈 Result: <strong className="font-mono text-rose-400">0 points</strong></>}
                        </span>
                      ) : parsedSalary <= 30000 ? (
                        <span className="text-emerald-300 font-medium">
                          {language === 'ar'
                            ? <>✨ الراتب من 15,001 إلى 30,000 👈 النسبة <strong>1.25%</strong> ({formatNumber(baseCardPoints)} × 1.25% = <strong className="font-mono text-emerald-300 text-sm">{formatNumber(expectedPoints)} نقطة</strong>)</>
                            : <>✨ Salary 15,001–30,000 👈 Ratio <strong>1.25%</strong> ({formatNumber(baseCardPoints)} × 1.25% = <strong className="font-mono text-emerald-300 text-sm">{formatNumber(expectedPoints)} points</strong>)</>}
                        </span>
                      ) : (
                        <span className="text-cyan-300 font-medium">
                          {language === 'ar'
                            ? <>🚀 الراتب من 30,001 إلى 50,000 فأكثر 👈 النسبة <strong>1.50%</strong> ({formatNumber(baseCardPoints)} × 1.50% = <strong className="font-mono text-cyan-300 text-sm">{formatNumber(expectedPoints)} نقطة</strong>)</>
                            : <>🚀 Salary 30,001+ 👈 Ratio <strong>1.50%</strong> ({formatNumber(baseCardPoints)} × 1.50% = <strong className="font-mono text-cyan-300 text-sm">{formatNumber(expectedPoints)} points</strong>)</>}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-3 bg-zinc-950 border-2 border-emerald-500/40 p-4 rounded-2xl shadow-inner">
              <div className="group bg-zinc-900/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all">
                <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
                  <span>{language === 'ar' ? 'المبلغ المطلوب (ر.س)' : 'Requested Amount (SAR)'} <span className="text-rose-400 font-black text-sm">*</span></span>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/40">
                    {t('sar')}
                  </span>
                </label>
                <input
                  type="number"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="50000"
                  min="0"
                  required={productType === 'finance'}
                  className="w-full bg-zinc-950 border-2 border-zinc-600 rounded-xl py-3 px-3 text-emerald-300 text-base font-mono font-black focus:outline-none focus:border-amber-400 dir-ltr text-right placeholder:text-zinc-400"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-zinc-200 mb-2">
                  {language === 'ar' ? 'نوع التمويل' : 'Finance Type'} <span className="text-rose-400 font-black text-sm">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFinanceType('salary_transfer')}
                    className={`py-3 px-3 rounded-xl border-2 text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                      financeType === 'salary_transfer'
                        ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400 shadow-md shadow-emerald-500/20 ring-2 ring-emerald-500/30'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                    }`}
                  >
                    <span>🏦 {t('salaryTransfer')}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFinanceType('no_salary_transfer')}
                    className={`py-3 px-3 rounded-xl border-2 text-xs font-black flex items-center justify-center gap-1.5 transition-all ${
                      financeType === 'no_salary_transfer'
                        ? 'bg-sky-500/25 text-sky-200 border-sky-400 shadow-md shadow-sky-500/20 ring-2 ring-sky-500/30'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-700 hover:text-zinc-200'
                    }`}
                  >
                    <span>💼 {t('noSalaryTransfer')}</span>
                  </button>
                </div>
              </div>

              <div className="group bg-zinc-900/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300">
                    {language === 'ar' ? 'النسبة المئوية للتمويل (%)' : 'Finance Profit Rate (%)'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowFinanceCalcModal(true)}
                    className="text-[11px] font-bold text-indigo-300 hover:text-indigo-200 bg-indigo-500/20 hover:bg-indigo-500/30 px-2.5 py-1 rounded-lg border border-indigo-500/40 flex items-center gap-1 transition-all active:scale-95 shadow-sm"
                  >
                    <Calculator className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{language === 'ar' ? 'حاسبة الشجرة الذكية للنسبة 🧮' : 'Smart Rate Calculator 🧮'}</span>
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.01"
                    value={financeRate}
                    onChange={(e) => setFinanceRate(e.target.value)}
                    placeholder="مثال: 2.5 أو 3.25"
                    min="0"
                    max="100"
                    className="w-full bg-zinc-950 border-2 border-zinc-600 rounded-xl py-3 pr-3 pl-8 text-amber-300 text-sm focus:outline-none focus:border-amber-400 dir-ltr text-right font-black font-mono placeholder:text-zinc-400"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-extrabold text-sm">%</span>
                </div>

                <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-zinc-800/80">
                  <span className="text-[10px] text-zinc-400">
                    {language === 'ar' ? 'النسبة المعتمدة المقترحة:' : 'Approved Default:'}{' '}
                    <span className="text-amber-400 font-bold font-mono">{suggestedRate}%</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setFinanceRate(String(suggestedRate))}
                    className="text-[10px] text-emerald-300 hover:text-emerald-200 bg-emerald-500/15 hover:bg-emerald-500/25 px-2.5 py-1 rounded-lg border border-emerald-500/30 font-bold transition-all active:scale-95 flex items-center gap-1 shadow-sm"
                  >
                    <span>⚡</span>
                    <span>{language === 'ar' ? `تطبيق النسبة (${suggestedRate}%)` : `Apply (${suggestedRate}%)`}</span>
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-amber-300 font-bold leading-relaxed">
                {language === 'ar'
                  ? '💡 لا يتم احتساب المبلغ المطلوب في الإجمالي التنفيذي إلا عند تحويل حالة الطلب إلى "مكتمل" أو "تم التنفيذ".'
                  : '💡 The requested amount is only added to the executed total when the status becomes "Completed".'}
              </p>
            </div>
          )}

          {/* Status Selector */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span>{t('status', 'حالة الطلب')}</span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                {language === 'ar' ? 'تحديد الحالة' : 'Select Status'}
              </span>
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as CustomerStatus)}
              className="w-full bg-zinc-900 border-2 border-zinc-600 rounded-xl py-3 px-3 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
            >
              {statuses
                .filter((s) => productType === 'visa' || (s.name !== 'تم التفعيل' && s.nameEn !== 'Activated'))
                .map((s) => (
                  <option key={s.id || s.name} value={s.name} className="bg-zinc-900 text-white font-bold py-1">
                    {getStatusTranslation(s.name, language)} {s.description ? `- ${s.description}` : ''}
                  </option>
                ))}
            </select>
            {status === 'عميل معلق' && (
              <p className="text-[11px] text-amber-300 font-bold mt-2 flex items-center gap-1">
                <span>⚠️ {language === 'ar' ? 'عند اختيار (عميل معلق)، يُرجى توضيح سبب التعليق في خانة الملاحظات بالأسفل.' : 'When choosing Pending, please mention the reason in the notes field below.'}</span>
              </p>
            )}
            {status === 'تم التنفيذ' && productType === 'visa' && (
              <p className="text-[11px] text-sky-300 font-bold mt-2 flex items-center gap-1.5 bg-sky-500/10 p-2.5 rounded-xl border border-sky-500/30">
                <span className="text-sky-400 text-sm">💳</span>
                <span>{language === 'ar' ? 'خطوة هامة: البطاقة صُدرت (تم التنفيذ). يلزم تفعيل البطاقة من العميل لتحويلها لـ (تم التفعيل) لكسب النقاط والخصم من الهدف الشهري!' : 'Important: Card is executed. Customer activation is required to reach (Activated) status and count points!'}</span>
              </p>
            )}
            {status === 'تم التفعيل' && (
              <p className="text-[11px] text-emerald-300 font-bold mt-2 flex items-center gap-1.5 bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/30">
                <span className="text-emerald-400 text-sm">🏆</span>
                <span>{language === 'ar' ? 'تم التفعيل: سيتم احتساب نقاط البطاقة فوراً وتحديث نسبة التارجيت والخصم من الهدف الشهري المتبقي.' : 'Activated: Points will be counted immediately towards the monthly target.'}</span>
              </p>
            )}
          </div>

          {/* Target Month Selector & Registration Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
              <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400 group-focus-within:text-amber-400" />
                  <span>{language === 'ar' ? 'شهر العمل المستهدف' : 'Target Working Month'}</span>
                </span>
              </label>
              <select
                value={targetMonth}
                onChange={(e) => handleMonthChange(e.target.value)}
                className="w-full bg-zinc-900 border-2 border-indigo-500/50 rounded-xl py-3 px-3 text-indigo-200 text-xs font-black focus:outline-none focus:border-amber-400 shadow-inner"
              >
                {availableMonths.map((m) => (
                  <option key={m.key} value={m.key} className="bg-zinc-900 text-white font-bold py-1">
                    {language === 'ar' ? m.labelAr : m.labelEn} {m.isCurrent ? (language === 'ar' ? '(الشهر الحالي)' : '(Current Month)') : ''}
                  </option>
                ))}
              </select>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-[10px] font-bold text-indigo-300/90 shrink-0">
                  {language === 'ar' ? 'أو أي شهر/سنة:' : 'Or any month/year:'}
                </span>
                <input
                  type="month"
                  value={targetMonth}
                  onChange={(e) => {
                    if (e.target.value) handleMonthChange(e.target.value);
                  }}
                  className="flex-1 min-w-0 bg-zinc-900 border border-indigo-500/40 rounded-lg py-1.5 px-2 text-[11px] font-mono font-bold text-white focus:outline-none focus:border-amber-400"
                />
              </div>
              <p className="text-[10px] text-indigo-300/90 mt-1.5 font-bold">
                {language === 'ar' ? 'يمكنك إضافة العميل في أي شهر وسنة (سابق أو حالي أو مستقبلي)' : 'Add customer to any past, current, or future month'}
              </p>
            </div>

            <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
              <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-zinc-300 group-focus-within:text-amber-400" />
                  <span>{language === 'ar' ? 'تاريخ التسجيل باليوم' : 'Registration Date'}</span>
                </span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={registrationDate}
                  onChange={(e) => setRegistrationDate(e.target.value)}
                  className="w-full bg-zinc-900 border-2 border-zinc-600 rounded-xl py-3 pr-10 pl-4 text-white text-xs focus:outline-none focus:border-amber-400 shadow-inner font-mono font-bold"
                />
                <Calendar className="w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Follow-up Date */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md">
            <label className="block text-xs font-black text-zinc-200 group-focus-within:text-amber-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-zinc-300 group-focus-within:text-amber-400" />
                <span>{language === 'ar' ? 'تاريخ المتابعة القادم' : 'Next Follow-up Date'}</span>
              </span>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                {language === 'ar' ? 'موعد' : 'Date'}
              </span>
            </label>
            <div className="relative">
              <input
                type="date"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
                className="w-full bg-zinc-900 border-2 border-zinc-600 rounded-xl py-3 pr-10 pl-4 text-white text-xs font-mono font-bold focus:outline-none focus:border-amber-400"
              />
              <Calendar className="w-4 h-4 text-zinc-400 group-focus-within:text-amber-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Notes */}
          <div className="group bg-zinc-950/90 p-3.5 rounded-2xl border-2 border-zinc-700 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/40 transition-all shadow-md space-y-2.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <label className="text-xs font-black text-zinc-200 group-focus-within:text-amber-300">
                {language === 'ar' ? 'ملاحظات إضافية' : 'Additional Notes'} {status === 'عميل معلق' && <span className="text-amber-300">({language === 'ar' ? 'سبب التعليق' : 'Pending Reason'})</span>}
              </label>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('light');
                    setShowQuickIssuancePicker((v) => !v);
                  }}
                  className="text-[10px] font-extrabold text-sky-300 hover:text-sky-200 bg-sky-500/15 hover:bg-sky-500/25 px-2.5 py-1 rounded-full border border-sky-500/35 flex items-center gap-1 transition-colors"
                >
                  <Calendar className="w-3 h-3" />
                  <span>{language === 'ar' ? 'تحديد موعد إصدار بطاقة لاحق' : 'Schedule Card Issuance'}</span>
                </button>
              </div>
            </div>

            {showQuickIssuancePicker && (
              <div className="flex items-center gap-2 bg-sky-950/40 border border-sky-500/30 rounded-xl p-2.5">
                <input
                  type="date"
                  value={quickIssuanceDate}
                  onChange={(e) => {
                    const val = e.target.value;
                    setQuickIssuanceDate(val);
                    if (val) {
                      setNotes((prev) => upsertScheduledIssuanceSnippetInNote(prev, val, language));
                      setAutoScheduleIssuance(true);
                      triggerHaptic('success');
                    }
                  }}
                  className="flex-1 bg-zinc-900 border border-sky-500/40 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-sky-400"
                />
                <button
                  type="button"
                  onClick={() => setShowQuickIssuancePicker(false)}
                  className="px-2.5 py-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-white text-[11px] font-bold"
                >
                  {language === 'ar' ? 'تم' : 'Done'}
                </button>
              </div>
            )}

            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={status === 'عميل معلق' 
                ? (language === 'ar' ? 'اكتب سبب التعليق هنا (مثال: بانتظار استكمال كشف الحساب / يتم إصدار البطاقة بتاريخ 15/01/2027)...' : 'Write reason for pending status (e.g. card issuance scheduled on 2027-01-15)...')
                : (language === 'ar' ? 'أي ملاحظات حول العميل... (مثال: يتم إصدار البطاقة بتاريخ 15/01/2027 أو في شهر فبراير لإدراجه تلقائياً كعميل محتمل)' : 'Any notes... (e.g. card will be issued on 2027-01-15 to auto-schedule as Potential)')}
              rows={3}
              className={`w-full bg-zinc-900 border-2 rounded-xl py-3 px-3 text-white text-sm font-bold focus:outline-none resize-none placeholder:text-zinc-400 ${
                detectedIssuance && detectedIssuance.isDifferentFromSourceMonth
                  ? 'border-sky-500/70 focus:border-sky-400'
                  : status === 'عميل معلق'
                    ? 'border-amber-500/60 focus:border-amber-400'
                    : 'border-zinc-600 focus:border-amber-400'
              }`}
            />

            {/* Smart Detected Future Card Issuance Scheduling Banner */}
            {detectedIssuance && detectedIssuance.isDifferentFromSourceMonth && (
              <div className="rounded-2xl bg-sky-500/10 border border-sky-500/40 p-3 space-y-2.5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2 min-w-0">
                    <div className="p-1.5 rounded-lg bg-sky-500/20 text-sky-300 shrink-0 mt-0.5">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-black text-sky-200">
                        {language === 'ar'
                          ? `تم رصد موعد إصدار بطاقة في شهر ${formatMonthKeyToArabic(detectedIssuance.targetMonth)}`
                          : `Future Card Issuance Detected: ${detectedIssuance.labelEn}`}
                      </div>
                      <div className="text-[11px] text-sky-200/80 mt-0.5">
                        {language === 'ar'
                          ? `التاريخ المرصود: ${detectedIssuance.issuanceDate} — سيتم إدراج العميل تلقائياً كـ «عميل محتمل» في هذا الشهر مع تذكير بالموعد.`
                          : `Detected date: ${detectedIssuance.issuanceDate} — customer will be auto-added as Potential in that month with a reminder.`}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setAutoScheduleIssuance((v) => !v);
                    }}
                    className={`w-11 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 ${
                      autoScheduleIssuance ? 'bg-sky-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
                    }`}
                    title={language === 'ar' ? 'تفعيل أو إيقاف الإضافة التلقائية' : 'Toggle auto-scheduling'}
                  >
                    <div className="w-4 h-4 bg-white rounded-full shadow" />
                  </button>
                </div>

                {autoScheduleIssuance && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setScheduleMode('add_in_month');
                      }}
                      className={`p-2 rounded-xl border text-start transition-all ${
                        scheduleMode === 'add_in_month'
                          ? 'bg-sky-500/20 border-sky-400 text-white'
                          : 'bg-zinc-950/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="text-[11px] font-extrabold">
                        {language === 'ar' ? 'إضافة كـ عميل محتمل في ذلك الشهر أيضاً' : 'Also add as Potential in that month'}
                      </div>
                      <div className="text-[10px] text-zinc-300/80 mt-0.5">
                        {language === 'ar'
                          ? `يحفظ السجل الحالي + يضيف عميلاً محتملاً في ${formatMonthKeyToArabic(detectedIssuance.targetMonth)}`
                          : `Keeps current record + adds Potential in ${detectedIssuance.labelEn}`}
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setScheduleMode('move_to_month');
                      }}
                      className={`p-2 rounded-xl border text-start transition-all ${
                        scheduleMode === 'move_to_month'
                          ? 'bg-emerald-500/20 border-emerald-400 text-white'
                          : 'bg-zinc-950/70 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="text-[11px] font-extrabold">
                        {language === 'ar' ? 'تسجيله مباشرة في ذلك الشهر فقط' : 'Register directly in that month only'}
                      </div>
                      <div className="text-[10px] text-zinc-300/80 mt-0.5">
                        {language === 'ar'
                          ? `ينقل العميل مباشرة كـ «عميل محتمل» إلى ${formatMonthKeyToArabic(detectedIssuance.targetMonth)}`
                          : `Places this customer directly as Potential in ${detectedIssuance.labelEn}`}
                      </div>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-gradient-to-r from-indigo-600 to-emerald-500 hover:from-indigo-500 hover:to-emerald-400 text-white font-black py-4 px-4 rounded-xl shadow-lg shadow-indigo-600/30 active:scale-98 transition-all flex items-center justify-center gap-2 text-sm"
          >
            <Save className="w-5 h-5" />
            <span>{submitting ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (language === 'ar' ? 'حفظ بيانات العميل 💾' : 'Save Customer Data 💾')}</span>
          </button>
        </form>
      </div>

      {showScanModal && (
        <CameraScanModal
          onClose={() => setShowScanModal(false)}
          onExtracted={handleScanExtracted}
        />
      )}

      {showFinanceCalcModal && (
        <FinanceCalculatorModal
          isOpen={showFinanceCalcModal}
          onClose={() => setShowFinanceCalcModal(false)}
          onApplyRate={(r) => setFinanceRate(String(r))}
          initialSalary={salary ? parseFloat(salary) : 12000}
          initialAmount={amount ? parseFloat(amount) : 100000}
        />
      )}
    </div>
  );
};

