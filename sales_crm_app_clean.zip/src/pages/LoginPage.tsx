import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getLockoutState, type LockoutState } from '../utils/security';
import { Eye, EyeOff, Lock, User as UserIcon, Briefcase, Globe, ShieldCheck, AlertTriangle } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [setupError, setSetupError] = useState('');
  const [lockout, setLockout] = useState<LockoutState>(() => getLockoutState('login'));

  const { login, setupInitialAdmin, startTrialLogin, needsAdminSetup } = useAuth();
  const { language, toggleLanguage, t, dir } = useLanguage();
  const isAr = language === 'ar';

  // Live countdown ticker while progressive brute-force lockout is active
  useEffect(() => {
    if (!lockout.isLocked) return;
    const timer = setInterval(() => {
      setLockout(getLockoutState('login'));
    }, 1000);
    return () => clearInterval(timer);
  }, [lockout.isLocked]);

  const passwordStrength =
    password.length === 0
      ? 0
      : password.length < 6
        ? 1
        : /[A-Z]/.test(password) && /[0-9]/.test(password) && password.length >= 10
          ? 3
          : 2;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError('');

    if (needsAdminSetup) {
      if (!username.trim() || password.length < 6) {
        setSetupError(
          isAr ? 'يجب أن تتكون كلمة المرور من 6 أحرف أو أرقام على الأقل' : 'Password must be at least 6 characters'
        );
        return;
      }
      if (password !== confirmPassword) {
        setSetupError(isAr ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match');
        return;
      }
      setLoading(true);
      await setupInitialAdmin(username.trim(), password);
      setLoading(false);
      return;
    }

    const currentLock = getLockoutState('login');
    setLockout(currentLock);
    if (currentLock.isLocked) return;
    if (!username.trim() || !password) return;

    setLoading(true);
    await login(username.trim(), password);
    setLockout(getLockoutState('login'));
    setLoading(false);
  };

  const handleStartTrial = async () => {
    setLoading(true);
    await startTrialLogin(undefined, false);
    setLoading(false);
  };

  return (
    <div className="min-h-screen w-full max-w-full bg-zinc-950 flex flex-col items-center justify-center p-4 sm:p-6 text-zinc-100 relative overflow-x-clip overflow-y-auto">
      {/* Language Switcher Top Button */}
      <div className="absolute top-6 right-6 z-20">
        <button
          type="button"
          onClick={toggleLanguage}
          className="flex items-center gap-2 bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white px-3 py-1.5 rounded-2xl text-xs font-bold transition-all shadow-lg backdrop-blur-md active:scale-95"
        >
          <Globe className="w-4 h-4 text-indigo-400" />
          <span>{isAr ? 'English' : 'العربية'}</span>
        </button>
      </div>

      {/* Background Subtle Radial Glow */}
      <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-sm flex flex-col items-center text-center relative z-10">
        {/* Logo */}
        <div className="w-20 h-20 bg-zinc-900 rounded-3xl flex items-center justify-center shadow-2xl mb-6 border border-zinc-800 relative">
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-indigo-500/20 to-emerald-500/20 opacity-50" />
          <Briefcase className="w-9 h-9 text-indigo-400 relative z-10" />
        </div>

        <h1 className="text-2xl font-light text-white tracking-wide mb-1">{t('appName')}</h1>
        <p className="text-xs text-zinc-400 mb-6">{t('appSubtitle')}</p>

        <form
          onSubmit={handleSubmit}
          className={`bento-card w-full bg-zinc-900 border-zinc-800 p-6 shadow-2xl space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
        >
          <div className="glow-top" />

          {needsAdminSetup && (
            <div className="rounded-xl bg-sky-500/10 border border-sky-500/30 p-3 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-sky-300">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>{isAr ? 'تهيئة حساب المدير لأول مرة' : 'First-Time Admin Setup'}</span>
              </div>
              <p className="text-[11px] text-zinc-300 leading-relaxed">
                {isAr
                  ? 'لحماية بياناتك الأوفلاين، اختر كلمة مرور خاصة بحساب المدير. يتم تشفيرها محلياً بتشفير PBKDF2 ولا تُحفظ أبداً كنص مكشوف.'
                  : 'Create your private Admin password. It is hashed locally with salted PBKDF2-SHA256.'}
              </p>
            </div>
          )}

          {lockout.isLocked && !needsAdminSetup && (
            <div className="rounded-xl bg-amber-500/10 border border-amber-500/35 p-3 flex items-start gap-2.5 text-amber-200">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs space-y-0.5">
                <p className="font-bold">
                  {isAr ? 'قفل أمني مؤقت ضد التخمين' : 'Temporary Brute-Force Lockout'}
                </p>
                <p className="text-[11px] text-amber-200/80 tabular-nums">
                  {isAr
                    ? `يرجى الانتظار ${lockout.remainingSeconds} ثانية قبل المحاولة مجدداً.`
                    : `Please wait ${lockout.remainingSeconds}s before trying again.`}
                </p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-zinc-400 mb-1.5">{t('username')}</label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                autoComplete="username"
                disabled={lockout.isLocked && !needsAdminSetup}
                required
                className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 ${dir === 'rtl' ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} text-zinc-100 text-sm focus:outline-none focus:border-indigo-500 transition-all shadow-inner font-mono disabled:opacity-50`}
              />
              <UserIcon className={`w-5 h-5 text-zinc-500 absolute ${dir === 'rtl' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2`} />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-400 mb-1.5">
              {needsAdminSetup
                ? (isAr ? 'كلمة مرور المدير الجديدة' : 'New Admin Password')
                : t('password')}
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                autoComplete={needsAdminSetup ? 'new-password' : 'current-password'}
                disabled={lockout.isLocked && !needsAdminSetup}
                required
                className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 ${dir === 'rtl' ? 'pr-10 pl-10 text-right' : 'pl-10 pr-10 text-left'} text-zinc-100 text-sm focus:outline-none focus:border-indigo-500 transition-all shadow-inner font-mono disabled:opacity-50`}
              />
              <Lock className={`w-5 h-5 text-zinc-500 absolute ${dir === 'rtl' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2`} />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className={`absolute ${dir === 'rtl' ? 'left-3' : 'right-3'} top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300`}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {needsAdminSetup && password.length > 0 && (
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1 flex gap-1 h-1.5">
                  <div className={`flex-1 rounded-full ${passwordStrength >= 1 ? (passwordStrength === 1 ? 'bg-rose-500' : passwordStrength === 2 ? 'bg-amber-400' : 'bg-emerald-400') : 'bg-zinc-800'}`} />
                  <div className={`flex-1 rounded-full ${passwordStrength >= 2 ? (passwordStrength === 2 ? 'bg-amber-400' : 'bg-emerald-400') : 'bg-zinc-800'}`} />
                  <div className={`flex-1 rounded-full ${passwordStrength >= 3 ? 'bg-emerald-400' : 'bg-zinc-800'}`} />
                </div>
                <span className="text-[10px] font-bold text-zinc-400 shrink-0">
                  {passwordStrength === 1
                    ? (isAr ? 'ضعيفة (6+ أحرف)' : 'Weak (6+ chars)')
                    : passwordStrength === 2
                      ? (isAr ? 'جيدة' : 'Good')
                      : (isAr ? 'قوية' : 'Strong')}
                </span>
              </div>
            )}
          </div>

          {needsAdminSetup && (
            <div>
              <label className="block text-xs font-semibold text-zinc-400 mb-1.5">
                {isAr ? 'تأكيد كلمة المرور' : 'Confirm Password'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••"
                  autoComplete="new-password"
                  required
                  className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 ${dir === 'rtl' ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'} text-zinc-100 text-sm focus:outline-none focus:border-indigo-500 transition-all shadow-inner font-mono`}
                />
                <Lock className={`w-5 h-5 text-zinc-500 absolute ${dir === 'rtl' ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2`} />
              </div>
            </div>
          )}

          {setupError && (
            <p className="text-xs font-bold text-rose-400">{setupError}</p>
          )}

          <button
            type="submit"
            disabled={loading || (lockout.isLocked && !needsAdminSetup)}
            className="w-full min-h-[46px] mt-2 bg-gradient-to-r from-indigo-600 to-emerald-500 hover:from-indigo-500 hover:to-emerald-400 disabled:opacity-50 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-indigo-600/20 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            {loading
              ? t('verifying')
              : needsAdminSetup
                ? (isAr ? 'حفظ وتشفير حساب المدير' : 'Create Encrypted Admin Account')
                : t('login')}
          </button>

          <div className="pt-2 border-t border-zinc-800/80">
            <button
              type="button"
              onClick={handleStartTrial}
              disabled={loading}
              className="w-full min-h-[42px] py-2.5 px-3 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <span>{isAr ? 'دخول وضع المبيعات التجريبي (صلاحية مندوب)' : 'Enter Sales Trial Mode (Rep Role)'}</span>
            </button>
          </div>
        </form>

        <div className="mt-4 text-center text-[11px] text-zinc-400 space-y-1">
          <p>{isAr ? 'للتواصل والدعم الفني والاشتراكات:' : 'Support & Subscriptions:'}</p>
          <a
            href="https://wa.me/966544067585"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-emerald-400 hover:text-emerald-300 font-bold flex items-center justify-center gap-1"
          >
            <span>0544067585</span>
          </a>
        </div>

        <p className="mt-4 text-xs text-zinc-500 font-mono">
          {t('version')}
        </p>
      </div>
    </div>
  );
};
