import React, { useState } from 'react';
import { db } from '../db/db';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useToast } from '../components/Toast';
import { Bell, BellOff, CheckCircle2, PhoneCall, Eye, AlertOctagon, Clock, CalendarCheck, ListCheck, FileText, Loader2 } from 'lucide-react';
import { DailyTasksWidget } from '../components/DailyTasksWidget';
import { triggerHaptic } from '../utils/haptics';
import { exportReportToPDF, type PdfCell } from '../utils/pdfExport';

interface RemindersPageProps {
  onSelectCustomer: (customerId: number) => void;
  onActivateCustomer: (customerId: number) => void;
}

export const RemindersPage: React.FC<RemindersPageProps> = ({
  onSelectCustomer,
  onActivateCustomer
}) => {
  const { pendingReminders, dueTasksCount, settings, updateSettingsState, checkReminders } = useAuth();
  const { t, language, formatNumber, formatPhone, dir } = useLanguage();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'tasks' | 'reminders'>('tasks');
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const reminderEnabled = settings.reminderEnabled !== false;

  const handleToggle = async () => {
    const nextVal = !reminderEnabled;
    await updateSettingsState('reminderEnabled', nextVal);
    await checkReminders();
    showToast(nextVal ? t('remindersEnabled', 'تم تفعيل نظام التذكيرات') : t('remindersDisabled', 'تم تعطيل التذكيرات'));
  };

  const handleDismiss = async (customerId?: number) => {
    if (!customerId) return;
    try {
      await db.customers.update(customerId, {
        lastReminderDismissed: new Date(),
        updatedAt: new Date()
      });
      await checkReminders();
      showToast(t('contactRecorded', 'تم تسجيل التواصل وإرجاء التذكير'));
    } catch (err) {
      console.error('Dismiss error:', err);
    }
  };

  const handleExportRemindersOrTasksPDF = async () => {
    if (isExportingPdf) return;
    triggerHaptic('medium');
    setIsExportingPdf(true);
    try {
      const companyName = settings?.companyName?.trim() || 'SALES CRM SYSTEM';
      const todayStr = new Date().toISOString().split('T')[0];

      if (activeTab === 'tasks') {
        const allTasks = await db.tasks.toArray();
        const sortedTasks = [...allTasks].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
        if (sortedTasks.length === 0) {
          showToast(language === 'ar' ? 'لا توجد مهام يومية مسجلة للتصدير' : 'No daily tasks to export', 'warning');
          return;
        }
        const statusLabelMap: Record<string, string> = {
          completed: language === 'ar' ? 'مكتملة' : 'Completed',
          postponed: language === 'ar' ? 'مؤجلة' : 'Postponed',
          pending: language === 'ar' ? 'قيد الإنجاز' : 'Pending',
        };
        await exportReportToPDF({
          title: language === 'ar' ? 'جدول المهام والمواعيد اليومية' : 'Daily Tasks & Appointments Schedule',
          companyName,
          cycleLabel: new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
          statusLabel: language === 'ar' ? 'المهام اليومية' : 'Daily Tasks',
          statusAccent: 'amber',
          totalCountLabel: language === 'ar' ? 'عدد المهام' : 'Total Tasks',
          totalCountValue: formatNumber(sortedTasks.length),
          dir,
          language,
          orientation: 'portrait',
          summaryCards: [
            { label: language === 'ar' ? 'الإجمالي' : 'Total', value: formatNumber(sortedTasks.length), accent: 'indigo' },
            { label: language === 'ar' ? 'مكتملة' : 'Completed', value: formatNumber(sortedTasks.filter(tk => tk.status === 'completed').length), accent: 'emerald' },
            { label: language === 'ar' ? 'قيد الإنجاز' : 'Pending', value: formatNumber(sortedTasks.filter(tk => tk.status === 'pending').length), accent: 'amber' },
            { label: language === 'ar' ? 'مؤجلة' : 'Postponed', value: formatNumber(sortedTasks.filter(tk => tk.status === 'postponed').length), accent: 'slate' },
          ],
          columns: [
            { label: '#', align: 'center', width: '36px' },
            { label: language === 'ar' ? 'عنوان المهمة' : 'Task Title', align: dir === 'rtl' ? 'right' : 'left' },
            { label: language === 'ar' ? 'التاريخ' : 'Date', align: 'center', width: '95px' },
            { label: language === 'ar' ? 'الحالة' : 'Status', align: 'center', width: '95px' },
            { label: language === 'ar' ? 'ملاحظات' : 'Notes', align: dir === 'rtl' ? 'right' : 'left' },
          ],
          rows: sortedTasks.map((tk, idx): PdfCell[] => [
            { text: formatNumber(idx + 1), mono: true },
            { text: tk.title || '-', bold: true },
            { text: `${tk.date || '-'}${tk.time ? ` ${tk.time}` : ''}`, mono: true },
            {
              text: statusLabelMap[tk.status] || tk.status,
              badgeAccent: tk.status === 'completed' ? 'emerald' : tk.status === 'postponed' ? 'slate' : 'amber',
            },
            { text: tk.notes || '-' },
          ]),
          footerText: language === 'ar' ? 'تم استخراج جدول المهام من نظام إدارة المبيعات Sales CRM' : 'Tasks schedule exported from Sales CRM',
          fileName: `sales-crm-tasks-${todayStr}.pdf`,
        });
      } else {
        if (pendingReminders.length === 0) {
          showToast(language === 'ar' ? 'لا توجد تذكيرات معلقة للتصدير' : 'No pending reminders to export', 'warning');
          return;
        }
        await exportReportToPDF({
          title: language === 'ar' ? 'تقرير التذكيرات والمتابعات المستحقة' : 'Pending Reminders & Follow-ups Report',
          companyName,
          cycleLabel: new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US'),
          statusLabel: language === 'ar' ? 'بانتظار التفعيل' : 'Pending Activation',
          statusAccent: 'amber',
          totalCountLabel: language === 'ar' ? 'عدد التذكيرات' : 'Reminders',
          totalCountValue: formatNumber(pendingReminders.length),
          dir,
          language,
          orientation: 'portrait',
          columns: [
            { label: '#', align: 'center', width: '36px' },
            { label: language === 'ar' ? 'اسم العميل' : 'Customer', align: dir === 'rtl' ? 'right' : 'left' },
            { label: language === 'ar' ? 'الجوال' : 'Phone', align: 'center', width: '110px' },
            { label: language === 'ar' ? 'رقم الطلب' : 'Order #', align: 'center', width: '105px' },
            { label: language === 'ar' ? 'مدة الانتظار' : 'Days Pending', align: 'center', width: '95px' },
          ],
          rows: pendingReminders.map(({ customer, daysPending, isOverdue }, idx): PdfCell[] => [
            { text: formatNumber(idx + 1), mono: true },
            { text: customer.name || '-', bold: true },
            { text: formatPhone(customer.phone || '-'), mono: true, dir: 'ltr' },
            { text: customer.orderNumber ? `#${customer.orderNumber}` : '-', mono: true },
            { text: `${formatNumber(daysPending)} ${t('day', 'يوم')}`, badgeAccent: isOverdue ? 'amber' : 'sky', mono: true },
          ]),
          footerText: language === 'ar' ? 'تم استخراج تقرير التذكيرات من نظام إدارة المبيعات Sales CRM' : 'Reminders report exported from Sales CRM',
          fileName: `sales-crm-reminders-${todayStr}.pdf`,
        });
      }
      showToast(language === 'ar' ? 'تم تصدير ملف PDF بنجاح 📄✨' : 'PDF exported successfully 📄✨', 'success');
    } catch (err) {
      console.error('Reminders PDF export error:', err);
      showToast(language === 'ar' ? 'تعذر تصدير ملف PDF' : 'Failed to export PDF', 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="w-full max-w-full min-w-0 overflow-x-clip space-y-4 pb-24 pt-2 px-3 sm:px-4">
      {/* Page Tabs */}
      <div className="flex items-center bg-zinc-900 border border-zinc-800 p-1 rounded-2xl shadow-xl min-w-0">
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('tasks');
          }}
          className={`flex-1 min-w-0 py-2.5 px-2 sm:px-3 rounded-xl font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 sm:gap-2 ${
            activeTab === 'tasks'
              ? 'bg-amber-500 text-zinc-950 shadow-md font-black'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <ListCheck className="w-4 h-4 shrink-0" />
          <span className="truncate">{t('dailyTasksSchedule', 'جدول المهام اليومية')}</span>
          {dueTasksCount > 0 && (
            <span className={`px-1.5 py-0.2 text-[10px] font-mono tabular-nums rounded-full font-bold shrink-0 ${
              activeTab === 'tasks' ? 'bg-zinc-950 text-amber-400' : 'bg-rose-500 text-white'
            }`}>
              {formatNumber(dueTasksCount)}
            </span>
          )}
        </button>

        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('reminders');
          }}
          className={`flex-1 min-w-0 py-2.5 px-2 sm:px-3 rounded-xl font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 sm:gap-2 relative ${
            activeTab === 'reminders'
              ? 'bg-amber-500 text-zinc-950 shadow-md font-black'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Bell className="w-4 h-4 shrink-0" />
          <span className="truncate">{t('systemReminders', 'تذكيرات النظام')}</span>
          {pendingReminders.length > 0 && (
            <span className={`px-1.5 py-0.2 text-[10px] font-mono rounded-full font-bold shrink-0 ${
              activeTab === 'reminders' ? 'bg-zinc-950 text-amber-400' : 'bg-amber-500 text-zinc-950'
            }`}>
              {formatNumber(pendingReminders.length)}
            </span>
          )}
        </button>
      </div>

      {/* Export / Print Bar */}
      <div className="flex items-center justify-end no-print">
        <button
          type="button"
          onClick={handleExportRemindersOrTasksPDF}
          disabled={isExportingPdf}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-500/15 hover:bg-rose-500/25 disabled:opacity-60 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer"
        >
          {isExportingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />}
          <span>
            {activeTab === 'tasks'
              ? (language === 'ar' ? 'تصدير / طباعة المهام PDF' : 'Export Tasks PDF')
              : (language === 'ar' ? 'تصدير / طباعة التذكيرات PDF' : 'Export Reminders PDF')}
          </span>
        </button>
      </div>

      {activeTab === 'tasks' ? (
        <DailyTasksWidget onSelectCustomer={onSelectCustomer} />
      ) : (
        <>
          {/* Reminder Config Card */}
          <div className="bento-card bg-zinc-900 border-zinc-800 p-4 shadow-xl flex items-center justify-between gap-2 min-w-0">
            <div className="glow-top" />
            <div className="flex items-center gap-3 min-w-0 flex-1">
              <div className={`p-2.5 rounded-xl shrink-0 ${reminderEnabled ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-zinc-800 text-zinc-500'}`}>
                {reminderEnabled ? <Bell className="w-5 h-5" /> : <BellOff className="w-5 h-5" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-bold text-xs text-white truncate">{t('notifications')}</div>
                <div className="text-[11px] text-zinc-500 font-mono truncate">
                  {formatNumber(settings.reminderInterval || 3)} | {formatNumber(settings.reminderEscalationDays || 7)}
                </div>
              </div>
            </div>

            <button
              onClick={handleToggle}
              className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 ${
                reminderEnabled ? 'bg-amber-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
              }`}
            >
              <div className="w-4 h-4 bg-zinc-950 rounded-full shadow-md" />
            </button>
          </div>

          {/* Reminders List */}
          {!reminderEnabled ? (
            <div className="bento-card bg-zinc-900 border-zinc-800 p-8 text-center text-zinc-500 space-y-2">
              <div className="glow-top" />
              <BellOff className="w-10 h-10 mx-auto text-zinc-600 stroke-1" />
              <div className="font-bold text-sm text-zinc-300">{t('remindersDisabled', 'التذكيرات التلقائية معطلة حالياً')}</div>
            </div>
          ) : pendingReminders.length === 0 ? (
            <div className="bento-card bg-zinc-900 border-zinc-800 p-8 text-center text-zinc-500 space-y-2">
              <div className="glow-top" />
              <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 stroke-1" />
              <div className="font-bold text-sm text-emerald-400">{t('allUpToDate', 'جميع العملاء محدثون ومنجزون!')}</div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-xs font-bold text-zinc-400 px-1">
                {t('pendingRemindersText')} ({formatNumber(pendingReminders.length)}):
              </div>

              {pendingReminders.map(({ customer, daysPending, isOverdue, reason, dueDate }) => {
                const isFollowUp = reason === 'followup_due';
                const canActivateVisa = customer.productType === 'visa' && (customer.status === 'تم التنفيذ' || customer.status === 'بانتظار التفعيل');
                return (
                <div
                  key={`${customer.id}-${reason || 'activation'}`}
                  className={`bento-card p-4 transition-all shadow-lg space-y-2.5 ${dir === 'rtl' ? 'text-right' : 'text-left'} ${
                    isOverdue
                      ? 'bg-rose-500/10 border-rose-500/30'
                      : 'bg-zinc-900 border-zinc-800'
                  }`}
                >
                  <div className="glow-top" />
                  <div className="flex items-start justify-between gap-2 min-w-0">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap mb-1">
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-black border ${
                          isFollowUp
                            ? 'bg-sky-500/15 text-sky-300 border-sky-500/30'
                            : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        }`}>
                          {isFollowUp
                            ? (language === 'ar' ? `موعد متابعة مستحق${dueDate ? ` (${dueDate})` : ''}` : `Follow-up Due${dueDate ? ` (${dueDate})` : ''}`)
                            : (language === 'ar' ? 'بطاقة Visa منفذة — بانتظار التفعيل' : 'Visa Executed — Pending Activation')}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-white mb-0.5 break-words">{customer.name}</h4>
                      <div className="text-xs text-zinc-400 font-mono dir-ltr truncate">{formatPhone(customer.phone)}</div>
                      {customer.orderNumber && (
                        <div className="text-[11px] text-indigo-400 font-mono font-bold mt-0.5 truncate">
                          #{customer.orderNumber}
                        </div>
                      )}
                    </div>

                    <div
                      className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1 shrink-0 tabular-nums ${
                        isOverdue
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {isOverdue ? <AlertOctagon className="w-3.5 h-3.5 shrink-0" /> : <Clock className="w-3.5 h-3.5 shrink-0" />}
                      <span>
                        {daysPending > 0
                          ? `${formatNumber(daysPending)} ${t('daysPending', 'يوم')}`
                          : (language === 'ar' ? 'اليوم' : 'Today')}
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center flex-wrap gap-2 pt-2 border-t border-zinc-800">
                    {canActivateVisa && (
                      <button
                        onClick={() => customer.id && onActivateCustomer(customer.id)}
                        className="flex-1 min-w-[100px] min-h-[40px] bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-extrabold py-2 px-2 rounded-xl text-xs flex items-center justify-center gap-1 shadow-md shadow-emerald-500/10"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>{t('activateNow', 'تفعيل الآن')}</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleDismiss(customer.id)}
                      className="flex-1 min-w-[100px] min-h-[40px] bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold py-2 px-2 rounded-xl text-xs border border-zinc-700 flex items-center justify-center gap-1"
                    >
                      <PhoneCall className="w-3.5 h-3.5 shrink-0" />
                      <span>{t('contacted', 'تم التواصل')}</span>
                    </button>

                    <button
                      onClick={() => customer.id && onSelectCustomer(customer.id)}
                      className="min-w-[40px] min-h-[40px] p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 rounded-xl border border-zinc-700 shrink-0 flex items-center justify-center"
                      title={t('details')}
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
};

