import React, { useState, useEffect, useCallback, Suspense } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from './db/db';
import { ToastProvider, useToast } from './components/Toast';
import { AuthProvider, useAuth, useCurrentPage } from './context/AuthContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { PWAInstallPrompt } from './components/PWAInstallPrompt';
import { OfflineStatusBanner } from './components/OfflineStatusBanner';
import { PinLockScreen } from './components/PinLockScreen';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { Plus } from 'lucide-react';
import { triggerHaptic } from './utils/haptics';
import { lazyWithRetry } from './utils/lazyWithRetry';
import type { PageView } from './types';

// Prefetchable dynamic importers for core high-frequency tabs
const loadCustomersPage = () => import('./pages/CustomersPage').then((m) => ({ default: m.CustomersPage }));
const loadReportsPage = () => import('./pages/ReportsPage').then((m) => ({ default: m.ReportsPage }));

// Route-level code splitting with automatic stale-chunk retry & recovery
const CustomersPage = lazyWithRetry(loadCustomersPage);
const AddCustomerPage = lazyWithRetry(() => import('./pages/AddCustomerPage').then((m) => ({ default: m.AddCustomerPage })));
const ReportsPage = lazyWithRetry(loadReportsPage);
const RemindersPage = lazyWithRetry(() => import('./pages/RemindersPage').then((m) => ({ default: m.RemindersPage })));
const SettingsPage = lazyWithRetry(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })));
const AdminPage = lazyWithRetry(() => import('./pages/AdminPage').then((m) => ({ default: m.AdminPage })));
const CustomerDetailsModal = lazyWithRetry(() =>
  import('./components/CustomerDetailsModal').then((m) => ({ default: m.CustomerDetailsModal }))
);
const ActivateModal = lazyWithRetry(() => import('./pages/ActivateModal').then((m) => ({ default: m.ActivateModal })));

const CORE_KEEP_ALIVE_TABS: PageView[] = ['dashboard', 'customers', 'reports'];

const PageLoadingSkeleton: React.FC = () => (
  <div className="w-full px-4 py-6 space-y-3 animate-pulse">
    <div className="h-24 rounded-2xl bg-slate-900/80 border border-sky-500/15" />
    <div className="grid grid-cols-2 gap-3">
      <div className="h-20 rounded-2xl bg-slate-900/70 border border-sky-500/10" />
      <div className="h-20 rounded-2xl bg-slate-900/70 border border-sky-500/10" />
    </div>
    <div className="h-44 rounded-2xl bg-slate-900/60 border border-sky-500/10" />
  </div>
);

const MainContent: React.FC = () => {
  const {
    currentUser,
    permissions,
    setCurrentPage,
    settings,
    isInitialized,
    isAppLocked,
    unlockApp,
    updateSettingsState,
    logout,
  } = useAuth();
  const currentPage = useCurrentPage();
  const { dir, t } = useLanguage();
  const { showToast } = useToast();

  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [openInEditMode, setOpenInEditMode] = useState<boolean>(false);
  const [activatingCustomerId, setActivatingCustomerId] = useState<number | null>(null);

  // Track visited core tabs so switching Dashboard <-> Customers <-> Reports is instantaneous (0ms)
  const [mountedCoreTabs, setMountedCoreTabs] = useState<Record<string, boolean>>(() => ({
    dashboard: true,
    [currentPage]: true,
  }));

  useEffect(() => {
    if (CORE_KEEP_ALIVE_TABS.includes(currentPage) && !mountedCoreTabs[currentPage]) {
      setMountedCoreTabs((prev) => ({ ...prev, [currentPage]: true }));
    }
    // Reset scroll position instantaneously on tab change for crisp mobile UX
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0);
    }
  }, [currentPage, mountedCoreTabs]);

  // Silently warm up Customers & Reports chunks during browser idle time right after login
  useEffect(() => {
    if (!currentUser) return;
    const warmUp = () => {
      loadCustomersPage().catch(() => {});
      loadReportsPage().catch(() => {});
    };
    if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
      const idleId = (window as Window & { requestIdleCallback: (cb: () => void, opts?: { timeout: number }) => number }).requestIdleCallback(
        warmUp,
        { timeout: 1500 }
      );
      return () => {
        if ('cancelIdleCallback' in window) {
          (window as Window & { cancelIdleCallback: (id: number) => void }).cancelIdleCallback(idleId);
        }
      };
    }
    const timer = setTimeout(warmUp, 600);
    return () => clearTimeout(timer);
  }, [currentUser]);

  const handleSelectCustomer = useCallback((id: number, isEdit = false) => {
    setSelectedCustomerId(id);
    setOpenInEditMode(isEdit);
  }, []);

  const handleSelectCustomerSimple = useCallback((id: number) => {
    setSelectedCustomerId(id);
    setOpenInEditMode(false);
  }, []);

  const handleActivateCustomer = useCallback((id: number) => {
    setActivatingCustomerId(id);
  }, []);

  // Apply financial theme to document body
  useEffect(() => {
    const theme = settings.themePreset || 'emerald';
    document.body.setAttribute('data-theme', theme);
  }, [settings.themePreset]);

  // Apply font size preference to root HTML element
  useEffect(() => {
    const fontSize =
      settings.fontSize ||
      (typeof window !== 'undefined' ? localStorage.getItem('sales_crm_font_size') : null) ||
      'normal';
    document.documentElement.setAttribute('data-font-size', fontSize);
  }, [settings.fontSize]);

  // Intercept accidental browser reload keystrokes (F5, Ctrl+R, Cmd+R) to keep active screen safe
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R'))) {
        e.preventDefault();
        triggerHaptic('light');
        showToast(
          dir === 'rtl'
            ? 'تم حفظ وتحديث بياناتك بنجاح دون الحاجة لإعادة تحميل الصفحة 🛡️'
            : 'Data synchronized safely without reloading the page 🛡️',
          'success'
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [dir, showToast]);

  // Handle Android hardware Back button smoothly inside native Capacitor APK
  useEffect(() => {
    const handleNativeBack = (event: Event) => {
      if (activatingCustomerId !== null) {
        event.preventDefault();
        setActivatingCustomerId(null);
        return;
      }
      if (selectedCustomerId !== null) {
        event.preventDefault();
        setSelectedCustomerId(null);
        setOpenInEditMode(false);
        return;
      }
      if (currentPage !== 'dashboard') {
        event.preventDefault();
        setCurrentPage('dashboard');
      }
    };

    window.addEventListener('native-back-button', handleNativeBack);
    return () => window.removeEventListener('native-back-button', handleNativeBack);
  }, [activatingCustomerId, selectedCustomerId, currentPage, setCurrentPage]);

  // Query selected customer reactively from Dexie only when a modal is requested
  const selectedCustomer = useLiveQuery(
    () => (selectedCustomerId ? db.customers.get(selectedCustomerId) : Promise.resolve(undefined)),
    [selectedCustomerId]
  );

  const activatingCustomer = useLiveQuery(
    () => (activatingCustomerId ? db.customers.get(activatingCustomerId) : Promise.resolve(undefined)),
    [activatingCustomerId]
  );

  // Smooth loading splash screen while restoring session from Dexie/storage
  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-[#070e1c] flex flex-col items-center justify-center p-6 text-center select-none">
        <div className="relative mb-5">
          <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-400/30 flex items-center justify-center shadow-xl shadow-sky-500/20">
            <img
              src="/icon.png"
              alt="Sales CRM"
              className="w-11 h-11 object-contain rounded-xl"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
        <h2 className="text-lg font-bold text-white mb-1.5">Sales CRM</h2>
        <p className="text-xs text-sky-400 font-medium">جاري استرجاع ومزامنة البيانات بأمان...</p>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage />;
  }

  const effectivePage: PageView =
    currentPage === 'admin' && !permissions.canAccessAdmin ? 'dashboard' : currentPage;

  const renderSecondaryPage = () => {
    switch (effectivePage) {
      case 'addCustomer':
        return <AddCustomerPage onOpenExistingCustomer={handleSelectCustomerSimple} />;
      case 'reminders':
        return (
          <RemindersPage
            onSelectCustomer={handleSelectCustomerSimple}
            onActivateCustomer={handleActivateCustomer}
          />
        );
      case 'settings':
        return <SettingsPage />;
      case 'admin':
        return <AdminPage />;
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen w-full max-w-full overflow-x-clip bg-transparent text-slate-100 flex flex-col ${
        dir === 'rtl' ? "font-['Tajawal',sans-serif]" : 'font-sans'
      }`}
    >
      {/* Quick Mobile PIN / Biometric Lock Screen */}
      {isAppLocked && settings.pinLockHash && (
        <PinLockScreen
          username={currentUser.username}
          pinHash={settings.pinLockHash}
          pinLength={settings.pinLockLength || 4}
          biometricEnabled={Boolean(settings.biometricLockEnabled)}
          biometricCredentialId={settings.biometricCredentialId || null}
          onUnlock={unlockApp}
          onUpgradePinHash={(newHash) => updateSettingsState('pinLockHash', newHash)}
          onLogout={logout}
        />
      )}

      <Header />
      <OfflineStatusBanner />

      <main className="flex-1 w-full max-w-md sm:max-w-lg md:max-w-2xl mx-auto min-w-0 overflow-x-clip">
        {/* Keep-alive primary tabs: stay mounted once visited for instant 0ms switching */}
        {mountedCoreTabs.dashboard && (
          <div className={effectivePage === 'dashboard' ? 'block' : 'hidden'}>
            <DashboardPage onSelectCustomer={handleSelectCustomerSimple} />
          </div>
        )}

        {mountedCoreTabs.customers && (
          <div className={effectivePage === 'customers' ? 'block' : 'hidden'}>
            <Suspense fallback={<PageLoadingSkeleton />}>
              <CustomersPage
                onSelectCustomer={handleSelectCustomer}
                onActivateCustomer={handleActivateCustomer}
              />
            </Suspense>
          </div>
        )}

        {mountedCoreTabs.reports && (
          <div className={effectivePage === 'reports' ? 'block' : 'hidden'}>
            <Suspense fallback={<PageLoadingSkeleton />}>
              <ReportsPage />
            </Suspense>
          </div>
        )}

        {/* Secondary routes mount on demand */}
        {!CORE_KEEP_ALIVE_TABS.includes(effectivePage) && (
          <Suspense fallback={<PageLoadingSkeleton />}>{renderSecondaryPage()}</Suspense>
        )}
      </main>

      {/* Floating Action Button (FAB) for adding a customer - locked within responsive frame */}
      {effectivePage !== 'addCustomer' && (
        <div className="pointer-events-none fixed inset-x-0 bottom-[calc(5rem+env(safe-area-inset-bottom,0px))] z-40 w-full max-w-md sm:max-w-lg md:max-w-2xl mx-auto px-4 flex justify-end no-print">
          <button
            onClick={() => {
              triggerHaptic('medium');
              setCurrentPage('addCustomer');
            }}
            className="pointer-events-auto w-14 h-14 bg-gradient-to-tr from-sky-500 via-blue-600 to-cyan-400 hover:from-sky-400 hover:to-cyan-300 text-white font-black rounded-2xl shadow-xl shadow-sky-500/35 flex items-center justify-center transition-transform duration-150 active:scale-90 border border-white/30 select-none"
            title={t('addCustomer')}
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* Customer Details Modal */}
      {selectedCustomer && (
        <Suspense fallback={null}>
          <CustomerDetailsModal
            customer={selectedCustomer}
            initialEdit={openInEditMode}
            onClose={() => {
              setSelectedCustomerId(null);
              setOpenInEditMode(false);
            }}
            onRefresh={() => {}}
            onActivate={(id) => {
              setSelectedCustomerId(null);
              setOpenInEditMode(false);
              setActivatingCustomerId(id);
            }}
          />
        </Suspense>
      )}

      {/* Activate Card Modal */}
      {activatingCustomer && (
        <Suspense fallback={null}>
          <ActivateModal
            customer={activatingCustomer}
            onClose={() => setActivatingCustomerId(null)}
            onSuccess={() => {
              setActivatingCustomerId(null);
            }}
          />
        </Suspense>
      )}

      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <ToastProvider>
      <LanguageProvider>
        <AuthProvider>
          <MainContent />
          <div className="no-print">
            <PWAInstallPrompt />
          </div>
        </AuthProvider>
      </LanguageProvider>
    </ToastProvider>
  );
}
