import React, { useMemo, useState, useEffect } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  ReferenceLine,
} from 'recharts';
import {
  Target,
  SlidersHorizontal,
  Check,
  X,
  Plus,
  Minus,
  CheckCircle2,
  Clock,
  TrendingUp,
  UserPlus,
  CalendarDays,
} from 'lucide-react';
import type { Customer } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { triggerHaptic } from '../utils/haptics';

interface OperationsProgressWidgetProps {
  customers: Customer[];
  dailyTarget: number;
  weeklyTarget: number;
  onSaveTargets: (daily: number, weekly: number) => Promise<void> | void;
  onAddCustomer?: () => void;
}

interface DayBucket {
  key: string;
  dayShort: string;
  dayFull: string;
  dateLabel: string;
  isToday: boolean;
  completed: number;
  activated: number;
  executed: number;
  added: number;
  hitTarget: boolean;
}

type PeriodMode = 'daily' | 'weekly';

const ARABIC_WEEKDAYS_SHORT = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
const ARABIC_WEEKDAYS_FULL = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const ENGLISH_WEEKDAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ENGLISH_WEEKDAYS_FULL = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function toLocalDayKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export const OperationsProgressWidget: React.FC<OperationsProgressWidgetProps> = React.memo(({
  customers,
  dailyTarget,
  weeklyTarget,
  onSaveTargets,
  onAddCustomer,
}) => {
  const { language, formatNumber, dir } = useLanguage();
  const isAr = language === 'ar';

  const safeDailyTarget = Math.max(1, Math.round(Number(dailyTarget) || 5));
  const safeWeeklyTarget = Math.max(1, Math.round(Number(weeklyTarget) || 25));

  const [periodMode, setPeriodMode] = useState<PeriodMode>('daily');
  const [isEditingTargets, setIsEditingTargets] = useState(false);
  const [draftDaily, setDraftDaily] = useState<string>(String(safeDailyTarget));
  const [draftWeekly, setDraftWeekly] = useState<string>(String(safeWeeklyTarget));
  const [isSaving, setIsSaving] = useState(false);
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(6); // Defaults to Today (last bar)

  useEffect(() => {
    if (!isEditingTargets) {
      setDraftDaily(String(safeDailyTarget));
      setDraftWeekly(String(safeWeeklyTarget));
    }
  }, [safeDailyTarget, safeWeeklyTarget, isEditingTargets]);

  // Build trailing 7-day operations buckets from live customer records
  const analytics = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const buckets: DayBucket[] = [];
    const bucketMap = new Map<string, DayBucket>();

    for (let offset = 6; offset >= 0; offset--) {
      const d = new Date(today);
      d.setDate(today.getDate() - offset);
      const key = toLocalDayKey(d);
      const dow = d.getDay();
      const isToday = offset === 0;

      const dayShort = isToday
        ? (isAr ? 'اليوم' : 'Today')
        : (isAr ? ARABIC_WEEKDAYS_SHORT[dow] : ENGLISH_WEEKDAYS_SHORT[dow]);
      const dayFull = isToday
        ? (isAr ? 'اليوم' : 'Today')
        : (isAr ? ARABIC_WEEKDAYS_FULL[dow] : ENGLISH_WEEKDAYS_FULL[dow]);
      const dateLabel = `${d.getDate()}/${d.getMonth() + 1}`;

      const bucket: DayBucket = {
        key,
        dayShort,
        dayFull,
        dateLabel,
        isToday,
        completed: 0,
        activated: 0,
        executed: 0,
        added: 0,
        hitTarget: false,
      };
      buckets.push(bucket);
      bucketMap.set(key, bucket);
    }

    for (const c of customers) {
      const status = (c.status || '').trim();
      const isActivated = status === 'تم التفعيل';
      const isExecuted = status === 'تم التنفيذ' || status === 'مكتمل';

      if (c.createdAt) {
        const createdDate = new Date(c.createdAt);
        if (!isNaN(createdDate.getTime())) {
          const createdBucket = bucketMap.get(toLocalDayKey(createdDate));
          if (createdBucket) {
            createdBucket.added += 1;
          }
        }
      }

      if (isActivated || isExecuted) {
        const opDateRaw = isActivated
          ? (c.activatedAt || c.updatedAt || c.createdAt)
          : (c.updatedAt || c.createdAt);
        if (opDateRaw) {
          const opDate = new Date(opDateRaw);
          if (!isNaN(opDate.getTime())) {
            const opBucket = bucketMap.get(toLocalDayKey(opDate));
            if (opBucket) {
              opBucket.completed += 1;
              if (isActivated) {
                opBucket.activated += 1;
              } else {
                opBucket.executed += 1;
              }
            }
          }
        }
      }
    }

    let daysHitTarget = 0;
    let weekCompleted = 0;
    let weekActivated = 0;
    let weekExecuted = 0;
    let weekAdded = 0;
    let maxDayOps = 0;

    for (const b of buckets) {
      b.hitTarget = b.completed >= safeDailyTarget;
      if (b.hitTarget) daysHitTarget += 1;
      weekCompleted += b.completed;
      weekActivated += b.activated;
      weekExecuted += b.executed;
      weekAdded += b.added;
      if (b.completed > maxDayOps) maxDayOps = b.completed;
    }

    const todayBucket = buckets[buckets.length - 1];
    const dailyPctRaw = (todayBucket.completed / safeDailyTarget) * 100;
    const weeklyPctRaw = (weekCompleted / safeWeeklyTarget) * 100;

    return {
      buckets,
      today: todayBucket,
      weekCompleted,
      weekActivated,
      weekExecuted,
      weekAdded,
      daysHitTarget,
      dailyPctRaw,
      dailyPctClamped: Math.min(100, Math.max(0, dailyPctRaw)),
      weeklyPctRaw,
      weeklyPctClamped: Math.min(100, Math.max(0, weeklyPctRaw)),
      yAxisMax: Math.max(safeDailyTarget + 1, maxDayOps + 1, 4),
    };
  }, [customers, safeDailyTarget, safeWeeklyTarget, isAr]);

  const activeAchieved = periodMode === 'daily' ? analytics.today.completed : analytics.weekCompleted;
  const activeTarget = periodMode === 'daily' ? safeDailyTarget : safeWeeklyTarget;
  const activePctRaw = periodMode === 'daily' ? analytics.dailyPctRaw : analytics.weeklyPctRaw;
  const activePctClamped = periodMode === 'daily' ? analytics.dailyPctClamped : analytics.weeklyPctClamped;
  const activeActivated = periodMode === 'daily' ? analytics.today.activated : analytics.weekActivated;
  const activeExecuted = periodMode === 'daily' ? analytics.today.executed : analytics.weekExecuted;
  const activeAdded = periodMode === 'daily' ? analytics.today.added : analytics.weekAdded;
  const activePendingAdded = Math.max(0, activeAdded - activeAchieved);

  const remainingOps = Math.max(0, activeTarget - activeAchieved);
  const surplusOps = Math.max(0, activeAchieved - activeTarget);

  // Explicit status classification (never color-only)
  const statusMeta = useMemo(() => {
    if (activePctRaw >= 100) {
      return {
        label: isAr ? 'تم تحقيق الهدف' : 'Target Achieved',
        textClass: 'text-emerald-400',
        strokeClass: 'text-emerald-400',
        barClass: 'bg-emerald-500',
      };
    }
    if (activePctRaw >= 60) {
      return {
        label: isAr ? 'في المسار الصحيح' : 'On Track',
        textClass: 'text-sky-400',
        strokeClass: 'text-sky-400',
        barClass: 'bg-sky-400',
      };
    }
    if (activeAchieved > 0) {
      return {
        label: isAr ? 'قيد التقدم' : 'In Progress',
        textClass: 'text-amber-400',
        strokeClass: 'text-amber-400',
        barClass: 'bg-amber-400',
      };
    }
    return {
      label: isAr ? 'بانتظار البدء' : 'Not Started',
      textClass: 'text-zinc-400',
      strokeClass: 'text-zinc-600',
      barClass: 'bg-zinc-600',
    };
  }, [activePctRaw, activeAchieved, isAr]);

  const selectedDay = analytics.buckets[selectedDayIndex] || analytics.today;

  const ringRadius = 40;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference * (1 - activePctClamped / 100);

  const totalBreakdown = activeActivated + activeExecuted + activePendingAdded;
  const activatedShare = totalBreakdown > 0 ? (activeActivated / totalBreakdown) * 100 : 0;
  const executedShare = totalBreakdown > 0 ? (activeExecuted / totalBreakdown) * 100 : 0;
  const pendingShare = totalBreakdown > 0 ? (activePendingAdded / totalBreakdown) * 100 : 0;

  const handleStepDraft = (setter: React.Dispatch<React.SetStateAction<string>>, delta: number, maxVal: number) => {
    triggerHaptic('light');
    setter((prev) => {
      const next = Math.min(maxVal, Math.max(1, (parseInt(prev, 10) || 0) + delta));
      return String(next);
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedDaily = Math.min(500, Math.max(1, parseInt(draftDaily, 10) || safeDailyTarget));
    const parsedWeekly = Math.min(2500, Math.max(1, parseInt(draftWeekly, 10) || safeWeeklyTarget));
    setIsSaving(true);
    try {
      await onSaveTargets(parsedDaily, parsedWeekly);
      triggerHaptic('success');
      setIsEditingTargets(false);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <section
      aria-label={isAr ? 'مؤشر إنجاز العمليات اليومي والأسبوعي' : 'Daily and Weekly Operations Achievement'}
      className="bg-zinc-900/95 border border-zinc-800 rounded-2xl p-4 sm:p-5 shadow-lg min-w-0 overflow-x-clip"
    >
      {/* Top Bar: Title + Period Segmented Switcher + Target Config Trigger */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pb-3.5 border-b border-zinc-800/90 min-w-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center shrink-0">
            <Target className="w-4.5 h-4.5" />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-black text-white leading-tight truncate">
              {isAr ? 'مؤشر إنجاز العمليات' : 'Operations Achievement'}
            </h3>
            <p className="text-[11px] text-zinc-400 mt-0.5 truncate">
              {isAr
                ? 'متابعة عدد العمليات المنجزة مقابل الهدف اليومي والأسبوعي'
                : 'Completed operations tracked against daily & weekly targets'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-between sm:justify-end">
          {/* Daily / Weekly Segmented Switcher */}
          <div
            role="tablist"
            aria-label={isAr ? 'نطاق المؤشر' : 'Timeframe'}
            className="inline-flex items-center bg-zinc-950 border border-zinc-800 rounded-xl p-0.5"
          >
            <button
              type="button"
              role="tab"
              aria-selected={periodMode === 'daily'}
              onClick={() => {
                triggerHaptic('light');
                setPeriodMode('daily');
              }}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                periodMode === 'daily'
                  ? 'bg-sky-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {isAr ? 'يومي' : 'Daily'}
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={periodMode === 'weekly'}
              onClick={() => {
                triggerHaptic('light');
                setPeriodMode('weekly');
              }}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${
                periodMode === 'weekly'
                  ? 'bg-sky-500 text-zinc-950 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {isAr ? 'أسبوعي' : 'Weekly'}
            </button>
          </div>

          {/* Configure Operation Targets Button */}
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setIsEditingTargets((prev) => !prev);
            }}
            aria-expanded={isEditingTargets}
            className={`min-h-[38px] px-3 rounded-xl border text-xs font-bold flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors active:scale-95 ${
              isEditingTargets
                ? 'bg-sky-500/20 border-sky-500/40 text-sky-200'
                : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 shrink-0" />
            <span>{isAr ? 'الأهداف' : 'Targets'}</span>
          </button>
        </div>
      </div>

      {/* Collapsible Inline Operations Target Editor */}
      {isEditingTargets && (
        <form
          onSubmit={handleSave}
          className="py-3.5 border-b border-zinc-800/90 space-y-3 min-w-0"
        >
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-extrabold text-zinc-200">
              {isAr ? 'تحديد أهداف عدد العمليات' : 'Set Operation Count Targets'}
            </span>
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                const dailyVal = Math.max(1, parseInt(draftDaily, 10) || safeDailyTarget);
                setDraftWeekly(String(dailyVal * 5));
              }}
              className="text-[11px] font-bold text-sky-400 hover:text-sky-300 underline-offset-4 hover:underline whitespace-nowrap"
            >
              {isAr ? 'احتساب الأسبوعي (× 5 أيام عمل)' : 'Sync Weekly (× 5 workdays)'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Daily Operations Target Input */}
            <div className="space-y-1.5 min-w-0">
              <label className="block text-[11px] font-bold text-zinc-400">
                {isAr ? 'الهدف اليومي (عملية / يوم)' : 'Daily Target (ops / day)'}
              </label>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleStepDraft(setDraftDaily, -1, 500)}
                  aria-label={isAr ? 'إنقاص الهدف اليومي' : 'Decrease daily target'}
                  className="w-11 h-11 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 flex items-center justify-center shrink-0 active:scale-95"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  min={1}
                  max={500}
                  inputMode="numeric"
                  value={draftDaily}
                  onChange={(e) => setDraftDaily(e.target.value)}
                  className="flex-1 min-w-0 h-11 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-sky-500 focus:outline-none text-center text-sm font-black text-white tabular-nums px-2"
                />
                <button
                  type="button"
                  onClick={() => handleStepDraft(setDraftDaily, 1, 500)}
                  aria-label={isAr ? 'زيادة الهدف اليومي' : 'Increase daily target'}
                  className="w-11 h-11 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 flex items-center justify-center shrink-0 active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Weekly Operations Target Input */}
            <div className="space-y-1.5 min-w-0">
              <label className="block text-[11px] font-bold text-zinc-400">
                {isAr ? 'الهدف الأسبوعي (عملية / 7 أيام)' : 'Weekly Target (ops / 7 days)'}
              </label>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleStepDraft(setDraftWeekly, -5, 2500)}
                  aria-label={isAr ? 'إنقاص الهدف الأسبوعي' : 'Decrease weekly target'}
                  className="w-11 h-11 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 flex items-center justify-center shrink-0 active:scale-95"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  min={1}
                  max={2500}
                  inputMode="numeric"
                  value={draftWeekly}
                  onChange={(e) => setDraftWeekly(e.target.value)}
                  className="flex-1 min-w-0 h-11 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-sky-500 focus:outline-none text-center text-sm font-black text-white tabular-nums px-2"
                />
                <button
                  type="button"
                  onClick={() => handleStepDraft(setDraftWeekly, 5, 2500)}
                  aria-label={isAr ? 'زيادة الهدف الأسبوعي' : 'Increase weekly target'}
                  className="w-11 h-11 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-700 text-zinc-300 flex items-center justify-center shrink-0 active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setDraftDaily(String(safeDailyTarget));
                setDraftWeekly(String(safeWeeklyTarget));
                setIsEditingTargets(false);
              }}
              className="min-h-[40px] px-3.5 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-bold flex items-center gap-1.5"
            >
              <X className="w-3.5 h-3.5" />
              <span>{isAr ? 'إلغاء' : 'Cancel'}</span>
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="min-h-[40px] px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-zinc-950 text-xs font-black flex items-center gap-1.5 disabled:opacity-60 active:scale-95 transition-transform"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isAr ? 'حفظ الأهداف' : 'Save Targets'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Main Achievement Overview: Circular Gauge + Dual Daily/Weekly Progress Strips */}
      <div className="py-4 grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-4 items-center border-b border-zinc-800/90 min-w-0">
        {/* Radial Progress Ring */}
        <div className="flex items-center gap-4 sm:gap-0 sm:justify-center min-w-0">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setPeriodMode((prev) => (prev === 'daily' ? 'weekly' : 'daily'));
            }}
            className="relative w-28 h-28 shrink-0 flex items-center justify-center group active:scale-95 transition-transform"
            title={isAr ? 'اضغط للتبديل بين اليومي والأسبوعي' : 'Tap to switch between Daily and Weekly'}
          >
            <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100" aria-hidden="true">
              <circle
                cx="50"
                cy="50"
                r={ringRadius}
                fill="none"
                stroke="currentColor"
                strokeWidth="9"
                className="text-zinc-800"
              />
              <circle
                cx="50"
                cy="50"
                r={ringRadius}
                fill="none"
                stroke="currentColor"
                strokeWidth="9"
                strokeLinecap="round"
                strokeDasharray={ringCircumference}
                strokeDashoffset={ringOffset}
                className={`transition-all duration-700 ${statusMeta.strokeClass}`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-1">
              <span className="text-xl font-black text-white tabular-nums leading-none">
                {formatNumber(Math.round(activePctRaw))}%
              </span>
              <span className="text-[11px] font-bold text-zinc-300 tabular-nums mt-1 leading-none">
                {formatNumber(activeAchieved)} / {formatNumber(activeTarget)}
              </span>
              <span className="text-[9px] font-semibold text-zinc-500 mt-1">
                {periodMode === 'daily'
                  ? (isAr ? 'هدف اليوم' : 'Daily Goal')
                  : (isAr ? 'هدف الأسبوع' : 'Weekly Goal')}
              </span>
            </div>
          </button>

          {/* Compact mobile-only status summary beside the ring */}
          <div className="sm:hidden flex-1 min-w-0 space-y-1">
            <div className={`text-xs font-black flex items-center gap-1.5 ${statusMeta.textClass}`}>
              {activePctRaw >= 100 ? (
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <TrendingUp className="w-3.5 h-3.5 shrink-0" />
              )}
              <span className="truncate">{statusMeta.label}</span>
            </div>
            <p className="text-xs text-zinc-300 font-semibold leading-snug">
              {remainingOps > 0
                ? (isAr
                    ? `متبقي ${formatNumber(remainingOps)} ${remainingOps === 1 ? 'عملية' : 'عمليات'} لتحقيق الهدف`
                    : `${formatNumber(remainingOps)} more ${remainingOps === 1 ? 'operation' : 'operations'} to reach target`)
                : surplusOps > 0
                  ? (isAr
                      ? `تجاوزت الهدف بـ +${formatNumber(surplusOps)} عملية`
                      : `Exceeded target by +${formatNumber(surplusOps)} ops`)
                  : (isAr
                      ? 'تم استيفاء كامل العمليات المستهدفة'
                      : 'Target fully achieved')}
            </p>
            <div className="text-[11px] text-zinc-500 tabular-nums">
              {isAr
                ? `تم التفعيل ${formatNumber(activeActivated)} · تم التنفيذ ${formatNumber(activeExecuted)}`
                : `Activated ${formatNumber(activeActivated)} · Executed ${formatNumber(activeExecuted)}`}
            </div>
          </div>
        </div>

        {/* Right Column: Explicit Status + Dual Daily & Weekly Comparison Bars */}
        <div className="space-y-3 min-w-0">
          {/* Desktop status headline */}
          <div className="hidden sm:flex items-center justify-between gap-2 min-w-0">
            <div className="flex items-center gap-2 min-w-0">
              <span className={`text-xs font-black flex items-center gap-1.5 shrink-0 ${statusMeta.textClass}`}>
                {activePctRaw >= 100 ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <TrendingUp className="w-4 h-4 shrink-0" />
                )}
                {statusMeta.label}
              </span>
              <span className="text-zinc-600">·</span>
              <span className="text-xs text-zinc-300 font-semibold truncate">
                {remainingOps > 0
                  ? (isAr
                      ? `متبقي ${formatNumber(remainingOps)} ${remainingOps === 1 ? 'عملية' : 'عمليات'}`
                      : `${formatNumber(remainingOps)} ops remaining`)
                  : surplusOps > 0
                    ? (isAr
                        ? `فائض +${formatNumber(surplusOps)} عملية`
                        : `+${formatNumber(surplusOps)} above target`)
                    : (isAr ? 'مكتمل 100%' : '100% Complete')}
              </span>
            </div>
            <span className="text-[11px] text-zinc-400 tabular-nums shrink-0">
              {isAr
                ? `تسجيل جديد: ${formatNumber(activeAdded)}`
                : `New leads: ${formatNumber(activeAdded)}`}
            </span>
          </div>

          {/* Interactive Daily vs Weekly Comparison Bars */}
          <div className="space-y-2.5">
            {/* Daily Bar Row */}
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setPeriodMode('daily');
              }}
              className={`w-full text-start rounded-xl px-3 py-2 border transition-colors min-w-0 ${
                periodMode === 'daily'
                  ? 'bg-zinc-950/90 border-sky-500/40'
                  : 'bg-zinc-950/40 border-zinc-800/80 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between gap-2 text-xs mb-1.5">
                <span className={`font-bold truncate ${periodMode === 'daily' ? 'text-white' : 'text-zinc-400'}`}>
                  {isAr ? 'الإنجاز اليومي' : 'Daily Progress'}
                </span>
                <span className="font-mono font-bold text-zinc-200 tabular-nums shrink-0">
                  {formatNumber(analytics.today.completed)} / {formatNumber(safeDailyTarget)}{' '}
                  <span className="text-[11px] text-zinc-400">
                    ({formatNumber(Math.round(analytics.dailyPctRaw))}%)
                  </span>
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    analytics.dailyPctRaw >= 100
                      ? 'bg-emerald-500'
                      : analytics.dailyPctRaw >= 60
                        ? 'bg-sky-400'
                        : 'bg-amber-400'
                  }`}
                  style={{ width: `${analytics.dailyPctClamped}%` }}
                />
              </div>
            </button>

            {/* Weekly Bar Row */}
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setPeriodMode('weekly');
              }}
              className={`w-full text-start rounded-xl px-3 py-2 border transition-colors min-w-0 ${
                periodMode === 'weekly'
                  ? 'bg-zinc-950/90 border-sky-500/40'
                  : 'bg-zinc-950/40 border-zinc-800/80 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between gap-2 text-xs mb-1.5">
                <span className={`font-bold truncate ${periodMode === 'weekly' ? 'text-white' : 'text-zinc-400'}`}>
                  {isAr ? 'الإنجاز الأسبوعي (آخر 7 أيام)' : 'Weekly Progress (Last 7 Days)'}
                </span>
                <span className="font-mono font-bold text-zinc-200 tabular-nums shrink-0">
                  {formatNumber(analytics.weekCompleted)} / {formatNumber(safeWeeklyTarget)}{' '}
                  <span className="text-[11px] text-zinc-400">
                    ({formatNumber(Math.round(analytics.weeklyPctRaw))}%)
                  </span>
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-zinc-800 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    analytics.weeklyPctRaw >= 100
                      ? 'bg-emerald-500'
                      : analytics.weeklyPctRaw >= 60
                        ? 'bg-sky-400'
                        : 'bg-amber-400'
                  }`}
                  style={{ width: `${analytics.weeklyPctClamped}%` }}
                />
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Charts Section: 7-Day Operations Bar Chart + Status Distribution Bar */}
      <div className="pt-4 space-y-3.5 min-w-0">
        {/* 7-Day Chart Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 min-w-0">
          <div className="flex items-center gap-1.5 text-xs font-extrabold text-zinc-200 min-w-0">
            <CalendarDays className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="truncate">
              {isAr ? 'وتيرة العمليات خلال آخر 7 أيام' : '7-Day Operations Trend'}
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-zinc-400 tabular-nums shrink-0">
            <span>
              {isAr
                ? `أيام تحقيق الهدف: ${formatNumber(analytics.daysHitTarget)} / 7`
                : `Target met: ${formatNumber(analytics.daysHitTarget)} / 7 days`}
            </span>
            <span className="text-zinc-700">·</span>
            <span className="text-emerald-400 font-bold">
              {isAr ? `الهدف: ${formatNumber(safeDailyTarget)}/يوم` : `Goal: ${formatNumber(safeDailyTarget)}/d`}
            </span>
          </div>
        </div>

        {/* Simple Interactive 7-Day Recharts BarChart */}
        <div className="w-full min-w-0" dir="ltr">
          <ResponsiveContainer width="100%" height={168}>
            <BarChart
              data={analytics.buckets}
              margin={{ top: 10, right: 6, left: -24, bottom: 2 }}
              barCategoryGap="24%"
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis
                dataKey="dayShort"
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#a1a1aa', fontSize: 11, fontWeight: 700 }}
                dy={4}
              />
              <YAxis
                allowDecimals={false}
                domain={[0, analytics.yAxisMax]}
                axisLine={false}
                tickLine={false}
                tick={{ fill: '#71717a', fontSize: 10 }}
              />
              <Tooltip
                cursor={{ fill: 'rgba(56, 189, 248, 0.08)' }}
                allowEscapeViewBox={{ x: false, y: false }}
                content={({ active, payload }) => {
                  if (!active || !payload || payload.length === 0) return null;
                  const item = payload[0].payload as DayBucket;
                  return (
                    <div
                      dir={dir}
                      className="bg-zinc-950 border border-zinc-700 rounded-xl px-3 py-2 shadow-xl text-xs space-y-1"
                    >
                      <div className="font-black text-white flex items-center justify-between gap-3">
                        <span>{item.dayFull}</span>
                        <span className="text-[10px] font-mono text-zinc-400">{item.dateLabel}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3 tabular-nums">
                        <span className="text-zinc-400">{isAr ? 'عمليات منجزة' : 'Completed'}</span>
                        <span className={`font-black ${item.hitTarget ? 'text-emerald-400' : 'text-sky-400'}`}>
                          {formatNumber(item.completed)} / {formatNumber(safeDailyTarget)}
                        </span>
                      </div>
                      <div className="text-[10px] text-zinc-400 tabular-nums pt-0.5 border-t border-zinc-800">
                        {isAr
                          ? `تفعيل ${formatNumber(item.activated)} · تنفيذ ${formatNumber(item.executed)} · جديد ${formatNumber(item.added)}`
                          : `Act ${formatNumber(item.activated)} · Exec ${formatNumber(item.executed)} · New ${formatNumber(item.added)}`}
                      </div>
                    </div>
                  );
                }}
              />
              <ReferenceLine
                y={safeDailyTarget}
                stroke="#10b981"
                strokeDasharray="4 4"
                strokeOpacity={0.75}
              />
              <Bar
                dataKey="completed"
                radius={[6, 6, 0, 0]}
                maxBarSize={34}
                onClick={(_data, idx) => {
                  if (typeof idx === 'number') {
                    triggerHaptic('light');
                    setSelectedDayIndex(idx);
                  }
                }}
              >
                {analytics.buckets.map((entry, idx) => {
                  const isSelected = idx === selectedDayIndex;
                  const fill = entry.hitTarget
                    ? '#10b981'
                    : entry.completed > 0
                      ? '#38bdf8'
                      : '#3f3f46';
                  return (
                    <Cell
                      key={entry.key}
                      cursor="pointer"
                      fill={fill}
                      fillOpacity={isSelected ? 1 : 0.72}
                      stroke={isSelected ? '#ffffff' : 'none'}
                      strokeWidth={isSelected ? 1.5 : 0}
                    />
                  );
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Interactive Selected Day Inspection Strip */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl bg-zinc-950/75 border border-zinc-800/80 text-[11px] min-w-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="font-black text-white shrink-0">
              {selectedDay.dayFull} ({selectedDay.dateLabel})
            </span>
            <span className="text-zinc-600">·</span>
            <span className={`font-bold shrink-0 ${selectedDay.hitTarget ? 'text-emerald-400' : 'text-zinc-400'}`}>
              {selectedDay.hitTarget
                ? (isAr ? 'حقق الهدف اليومي' : 'Met daily target')
                : (isAr
                    ? `منجز ${formatNumber(selectedDay.completed)} من ${formatNumber(safeDailyTarget)}`
                    : `${formatNumber(selectedDay.completed)} of ${formatNumber(safeDailyTarget)} done`)}
            </span>
          </div>
          <div className="flex items-center gap-2 text-zinc-400 tabular-nums shrink-0">
            <span>{isAr ? `تفعيل ${formatNumber(selectedDay.activated)}` : `Act ${formatNumber(selectedDay.activated)}`}</span>
            <span className="text-zinc-700">·</span>
            <span>{isAr ? `تنفيذ ${formatNumber(selectedDay.executed)}` : `Exec ${formatNumber(selectedDay.executed)}`}</span>
            <span className="text-zinc-700">·</span>
            <span>{isAr ? `جديد ${formatNumber(selectedDay.added)}` : `New ${formatNumber(selectedDay.added)}`}</span>
          </div>
        </div>

        {/* Stacked Status Distribution Bar for Active Period */}
        <div className="space-y-2 pt-1 min-w-0">
          <div className="flex items-center justify-between gap-2 text-[11px]">
            <span className="font-bold text-zinc-300">
              {periodMode === 'daily'
                ? (isAr ? 'توزيع عمليات اليوم' : "Today's Operation Mix")
                : (isAr ? 'توزيع عمليات الأسبوع' : 'Weekly Operation Mix')}
            </span>
            <span className="text-zinc-500 tabular-nums">
              {isAr
                ? `إجمالي النشاط: ${formatNumber(totalBreakdown)}`
                : `Total activity: ${formatNumber(totalBreakdown)}`}
            </span>
          </div>

          {totalBreakdown > 0 ? (
            <>
              <div className="w-full h-2.5 rounded-full bg-zinc-800 overflow-hidden flex gap-0.5">
                {activatedShare > 0 && (
                  <div
                    className="h-full bg-emerald-500 transition-all duration-500"
                    style={{ width: `${activatedShare}%` }}
                  />
                )}
                {executedShare > 0 && (
                  <div
                    className="h-full bg-sky-400 transition-all duration-500"
                    style={{ width: `${executedShare}%` }}
                  />
                )}
                {pendingShare > 0 && (
                  <div
                    className="h-full bg-amber-400/90 transition-all duration-500"
                    style={{ width: `${pendingShare}%` }}
                  />
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-zinc-400 tabular-nums">
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-sm bg-emerald-500 shrink-0" />
                  <span>{isAr ? 'تم التفعيل' : 'Activated'}:</span>
                  <strong className="text-zinc-200">{formatNumber(activeActivated)}</strong>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-sm bg-sky-400 shrink-0" />
                  <span>{isAr ? 'تم التنفيذ' : 'Executed'}:</span>
                  <strong className="text-zinc-200">{formatNumber(activeExecuted)}</strong>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-sm bg-amber-400 shrink-0" />
                  <span>{isAr ? 'مسجل قيد المتابعة' : 'New / In Progress'}:</span>
                  <strong className="text-zinc-200">{formatNumber(activePendingAdded)}</strong>
                </span>
              </div>
            </>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2.5 rounded-xl bg-zinc-950/60 border border-dashed border-zinc-800">
              <div className="flex items-center gap-2 text-xs text-zinc-400 min-w-0">
                <Clock className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                <span className="truncate">
                  {periodMode === 'daily'
                    ? (isAr ? 'لم تُسجّل عمليات اليوم بعد — ابدأ بأول عملية لتحريك المؤشر.' : 'No operations logged today yet.')
                    : (isAr ? 'لا توجد عمليات مسجلة خلال آخر 7 أيام.' : 'No operations recorded in the last 7 days.')}
                </span>
              </div>
              {onAddCustomer && (
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('light');
                    onAddCustomer();
                  }}
                  className="min-h-[36px] px-3 rounded-lg bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-bold flex items-center gap-1.5 shrink-0 transition-colors active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إضافة عملية' : 'Add Operation'}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
});
