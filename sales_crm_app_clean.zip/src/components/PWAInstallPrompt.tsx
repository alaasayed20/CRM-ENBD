import React, { useState, useEffect, useRef } from 'react';
import { Download, Share, PlusSquare, Smartphone, X, Sparkles, CheckCircle2, ArrowDown, HelpCircle, ExternalLink, RefreshCw, Copy, Check, ShieldCheck, Layers } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { triggerHaptic } from '../utils/haptics';
import { forceAppUpdateAndRefresh } from '../utils/appUpdate';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallPrompt: React.FC = () => {
  const { language, dir } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const deferredPromptRef = useRef<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [showBanner, setShowBanner] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);
  const [showAndroidModal, setShowAndroidModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [installedSuccess, setInstalledSuccess] = useState(false);
  const [showUpdateBanner, setShowUpdateBanner] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode (already installed as PWA)
    const isStandaloneMode = 
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      document.referrer.includes('android-app://');

    setIsStandalone(isStandaloneMode);

    // Platform detection
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    const isAndroidDevice = /android/.test(userAgent);

    setIsIOS(isIOSDevice);
    setIsAndroid(isAndroidDevice);

    // If already installed, don't show the prompt
    if (isStandaloneMode) {
      return;
    }

    // Check if user dismissed prompt recently
    const dismissedTime = localStorage.getItem('pwa_prompt_dismissed_at');
    const isDismissed = dismissedTime && Date.now() - parseInt(dismissedTime, 10) < 24 * 60 * 60 * 1000; // 24 hours snooze

    // Listen for Chrome/Android native install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      deferredPromptRef.current = promptEvent;
      setDeferredPrompt(promptEvent);
      if (!isDismissed) {
        setShowBanner(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Listen for successful install
    const handleAppInstalled = () => {
      setIsStandalone(true);
      setShowBanner(false);
      setShowIOSModal(false);
      setShowAndroidModal(false);
      setInstalledSuccess(true);
      deferredPromptRef.current = null;
      setDeferredPrompt(null);
      setTimeout(() => setInstalledSuccess(false), 4000);
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    // On iOS, show banner after a small delay if not dismissed
    let timer: ReturnType<typeof setTimeout> | null = null;
    if ((isIOSDevice || isAndroidDevice) && !isDismissed && !isStandaloneMode) {
      timer = setTimeout(() => {
        setShowBanner(true);
      }, 2500);
    }

    // Listen to custom event for manual trigger from Settings/Header
    const handleManualOpen = () => {
      if (isIOSDevice) {
        setShowIOSModal(true);
      } else if (isAndroidDevice) {
        setShowAndroidModal(true);
      } else if (deferredPromptRef.current) {
        deferredPromptRef.current.prompt();
      } else {
        setShowAndroidModal(true);
      }
    };

    const handleAndroidOpen = () => {
      setShowAndroidModal(true);
    };

    const handleApkOpen = () => {
      setShowApkModal(true);
    };

    // Listen to new version / update event from Service Worker
    const handleUpdateAvailable = () => {
      setShowUpdateBanner(true);
    };

    window.addEventListener('open-pwa-install-dialog', handleManualOpen);
    window.addEventListener('open-android-install-dialog', handleAndroidOpen);
    window.addEventListener('open-apk-dialog', handleApkOpen);
    window.addEventListener('app-update-available', handleUpdateAvailable);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('open-pwa-install-dialog', handleManualOpen);
      window.removeEventListener('open-android-install-dialog', handleAndroidOpen);
      window.removeEventListener('open-apk-dialog', handleApkOpen);
      window.removeEventListener('app-update-available', handleUpdateAvailable);
      if (timer) clearTimeout(timer);
    };
  }, []);

  const handlePerformUpdate = async () => {
    triggerHaptic('success');
    setIsUpdating(true);
    await forceAppUpdateAndRefresh();
  };

  const handleInstallClick = async () => {
    triggerHaptic('medium');
    
    if (isIOS) {
      setShowBanner(false);
      setShowIOSModal(true);
      return;
    }

    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          setShowBanner(false);
          setDeferredPrompt(null);
        }
      } catch {
        setShowAndroidModal(true);
      }
    } else {
      setShowAndroidModal(true);
    }
  };

  const handleDismissBanner = () => {
    triggerHaptic('light');
    setShowBanner(false);
    localStorage.setItem('pwa_prompt_dismissed_at', Date.now().toString());
  };

  const handleCopyAppUrl = () => {
    triggerHaptic('light');
    const url = window.location.origin;
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const hasActiveModal = showAndroidModal || showApkModal || showHelpModal || showIOSModal;

  // Only return null if standalone AND there is nothing to display (no banner, no modal, no toast)
  if (isStandalone && !installedSuccess && !showUpdateBanner && !hasActiveModal) {
    return null;
  }

  return (
    <>
      {/* App Update Available Notification Banner */}
      {showUpdateBanner && (
        <div 
          className="fixed top-3 inset-x-3 sm:inset-x-auto sm:right-4 z-50 max-w-md bg-gradient-to-r from-[#06241a] to-[#0d3b2b] border border-emerald-400/50 p-3.5 rounded-2xl shadow-2xl shadow-emerald-950/90 backdrop-blur-xl animate-in fade-in slide-in-from-top duration-300"
          dir={dir}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0 border border-emerald-500/30">
              <RefreshCw className={`w-5 h-5 ${isUpdating ? 'animate-spin' : ''}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <h4 className="font-extrabold text-xs text-white">
                  {language === 'ar' ? 'يتوفر تحديث جديد للتطبيق! 🚀' : 'New App Update Ready! 🚀'}
                </h4>
                <button
                  onClick={() => setShowUpdateBanner(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg transition-all"
                  aria-label="Close"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-emerald-200/90 mt-0.5 leading-snug">
                {language === 'ar' 
                  ? 'تم تجهيز أحدث إصدار من النظام والتحسينات البرمجية. اضغط للتحديث فوراً.' 
                  : 'Latest features and performance fixes are ready to apply.'}
              </p>
              <div className="mt-2.5 flex items-center gap-2">
                <button
                  onClick={handlePerformUpdate}
                  disabled={isUpdating}
                  className="flex-1 py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/25 active:scale-95 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isUpdating ? 'animate-spin' : ''}`} />
                  <span>{isUpdating ? (language === 'ar' ? 'جاري التحديث...' : 'Updating...') : (language === 'ar' ? 'تحديث وتثبيت النسخة الجديدة ⚡' : 'Update & Apply Now ⚡')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Notification after install */}
      {installedSuccess && (
        <div 
          className="fixed top-4 inset-x-4 z-50 max-w-sm mx-auto bg-emerald-950/95 border border-emerald-500/50 p-4 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-3 animate-in fade-in slide-in-from-top duration-300"
          dir={dir}
        >
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div className="flex-1 text-right">
            <h4 className="font-bold text-xs text-white">
              {language === 'ar' ? 'تم تثبيت التطبيق بنجاح! 🎉' : 'App Installed Successfully! 🎉'}
            </h4>
            <p className="text-[11px] text-emerald-200/80">
              {language === 'ar' ? 'أيقونة التطبيق الآن جاهزة على شاشة هاتفك الرئيسية.' : 'App icon is now ready on your home screen.'}
            </p>
          </div>
        </div>
      )}

      {/* Floating Smart Install Banner */}
      {showBanner && (
        <div 
          className="fixed bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] inset-x-3 sm:inset-x-auto sm:right-4 z-40 mx-auto max-w-[calc(100vw-1.5rem)] sm:max-w-md bg-gradient-to-r from-[#0d1f3d] to-[#12284e] border border-sky-400/40 rounded-2xl p-3.5 shadow-2xl shadow-sky-950/80 backdrop-blur-xl animate-in fade-in slide-in-from-bottom duration-300 overflow-hidden"
          dir={dir}
        >
          <div className="flex items-start gap-3">
            {/* App Icon Preview */}
            <div className="relative shrink-0">
              <img 
                src="/pwa-512x512.png" 
                alt="Sales CRM App Icon" 
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-xl border border-sky-400/30 shadow-md bg-slate-900 object-cover"
              />
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
              </span>
            </div>

            {/* Banner Text */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <h4 className="font-extrabold text-xs text-white flex items-center gap-1 truncate">
                  <span>{language === 'ar' ? 'تثبيت تطبيق أندرويد والأيقونة 🤖' : 'Install Android App & Icon 🤖'}</span>
                </h4>
                <button
                  onClick={handleDismissBanner}
                  className="p-1 text-slate-400 hover:text-white rounded-lg transition-all"
                  aria-label="Close"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-sky-200/80 mt-0.5 leading-snug">
                {language === 'ar' 
                  ? 'أضف أيقونة التطبيق لشاشة جوالك ليعمل كتطبيق أصلي سريع بدون متصفح وبدون إنترنت.' 
                  : 'Add app icon to your Android home screen for native fullscreen and offline experience.'}
              </p>

              {/* Action Buttons */}
              <div className="mt-2.5 flex items-center gap-2">
                <button
                  onClick={handleInstallClick}
                  className="flex-1 py-1.5 px-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/25 active:scale-95 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{language === 'ar' ? 'تثبيت الأيقونة الآن 📲' : 'Install Icon Now 📲'}</span>
                </button>
                <button
                  onClick={() => setShowAndroidModal(true)}
                  className="py-1.5 px-2.5 bg-slate-800/80 hover:bg-slate-700 text-sky-300 font-bold rounded-xl text-xs border border-sky-500/20 flex items-center justify-center transition-all"
                  title="دليل تثبيت الأندرويد"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DEDICATED ANDROID INSTALLATION MODAL */}
      {showAndroidModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
          dir={dir}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowAndroidModal(false);
          }}
        >
          <div className="w-full max-w-sm bg-[#0a172c] border border-emerald-500/40 rounded-3xl p-5 shadow-2xl space-y-4 text-right animate-in slide-in-from-bottom-5 duration-300 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                    <span>{language === 'ar' ? 'تثبيت التطبيق على أندرويد 🤖' : 'Install on Android 🤖'}</span>
                  </h3>
                  <p className="text-[10px] text-emerald-300/80">
                    {language === 'ar' ? 'إضافة الأيقونة الرسمية إلى شاشة هاتفك الرئيسية' : 'Add official icon to your phone screen'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAndroidModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl bg-slate-800/80 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Android Phone Mockup with Icon */}
            <div className="p-3.5 bg-gradient-to-b from-[#0d2242] to-[#08152b] border border-sky-400/25 rounded-2xl flex items-center gap-3.5 shadow-inner">
              <div className="relative shrink-0">
                <img 
                  src="/pwa-512x512.png" 
                  alt="Android App Icon" 
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-2xl shadow-xl border-2 border-emerald-400/40 object-cover bg-slate-950"
                />
                <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-[9px] font-black text-slate-950 px-1 rounded-md shadow">
                  PWA
                </span>
              </div>
              <div className="text-right flex-1 min-w-0">
                <p className="font-extrabold text-xs text-white truncate">Sales CRM</p>
                <p className="text-[11px] text-emerald-400 font-bold">نظام المبيعات والبطاقات</p>
                <div className="flex items-center gap-1 text-[10px] text-slate-300 mt-0.5">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span>تطبيق معتمد • يعمل بدون إنترنت</span>
                </div>
              </div>
            </div>

            {/* Direct 1-Click Android Prompt if Available */}
            {deferredPrompt && (
              <button
                onClick={async () => {
                  try {
                    await deferredPrompt.prompt();
                    const choice = await deferredPrompt.userChoice;
                    if (choice.outcome === 'accepted') {
                      setShowAndroidModal(false);
                      setDeferredPrompt(null);
                    }
                  } catch {
                    // Fallback to manual
                  }
                }}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-2xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/30 active:scale-95 transition-all"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>{language === 'ar' ? 'تثبيت الأيقونة الآن بنقرة واحدة 📥' : 'One-Click Install Now 📥'}</span>
              </button>
            )}

            {/* Visual Steps for Android (Chrome & Samsung) */}
            <div className="space-y-2 text-xs text-slate-200">
              <div className="text-[11px] font-bold text-slate-400">
                {language === 'ar' ? 'طريقة إضافة الأيقونة عبر متصفح Chrome أو سامسونج:' : 'How to add the icon via Chrome or Samsung Browser:'}
              </div>

              {/* Step 1 */}
              <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white flex items-center gap-1.5">
                    <span>اضغط على قائمة النقاط الثلاث</span>
                    <span className="px-1.5 py-0.5 bg-slate-800 rounded text-emerald-300 font-mono font-black border border-slate-700">
                      (⋮)
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-300">
                    ستجدها في أعلى يسار أو أعلى يمين متصفح Chrome بجوالك.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white flex items-center gap-1.5">
                    <span>اختر «تثبيت التطبيق»</span>
                    <span className="text-[10px] text-slate-400 font-normal">أو «إضافة إلى الشاشة الرئيسية»</span>
                  </p>
                  <p className="text-[11px] text-slate-300">
                    ستظهر بالإنجليزية: <b>(Install app)</b> أو <b>(Add to Home screen)</b>.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white">
                    اضغط «تثبيت» (Install)
                  </p>
                  <p className="text-[11px] text-slate-300">
                    ستظهر أيقونة <b>Sales CRM</b> فوراً على شاشة هاتفك وتفتح كتطبيق كامل الشاشة!
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Actions Footer */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <div className="flex gap-2">
                <button
                  onClick={handleCopyAppUrl}
                  className="flex-1 py-2 px-2 bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold rounded-xl text-[11px] border border-sky-500/20 flex items-center justify-center gap-1.5 transition-all"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'تم نسخ الرابط! ✅' : 'نسخ رابط التطبيق 🔗'}</span>
                </button>
                <button
                  onClick={() => {
                    setShowAndroidModal(false);
                    setShowApkModal(true);
                  }}
                  className="py-2 px-3 bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 font-bold rounded-xl text-[11px] border border-indigo-500/30 flex items-center justify-center gap-1 transition-all"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>توليد APK 📦</span>
                </button>
              </div>

              <button
                onClick={() => setShowAndroidModal(false)}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs transition-all active:scale-95"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* APK & TWA PACKAGE BUILDER MODAL */}
      {showApkModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
          dir={dir}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowApkModal(false);
          }}
        >
          <div className="w-full max-w-md bg-[#0a172c] border border-indigo-500/40 rounded-3xl p-5 shadow-2xl space-y-4 text-right max-h-[85vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-indigo-500/20 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">
                    {language === 'ar' ? 'تحويل التطبيق إلى ملف APK للأندرويد 📦' : 'Build Android APK Package 📦'}
                  </h3>
                  <p className="text-[10px] text-indigo-300/80">
                    {language === 'ar' ? 'توليد حزمة APK جاهزة للتثبيت المباشر أو Google Play' : 'Generate standalone APK package for Android'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowApkModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl bg-slate-800/80 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Explanation */}
            <div className="space-y-3 text-xs text-slate-200 leading-relaxed">
              <div className="p-3 bg-indigo-950/40 border border-indigo-500/20 rounded-2xl space-y-1.5">
                <p className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <span>⚡ كيف تحصل على ملف APK رسمي؟</span>
                </p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  بما أن التطبيق مبني كـ <b>Progressive Web App كامل ومطابق للمعايير</b>، يمكنك تحويله إلى ملف <b>APK / TWA (Trusted Web Activity)</b> بنقرة واحدة باستخدام أداة مايكروسوفت وجوجل الرسمية <b>(PWABuilder)</b>:
                </p>
              </div>

              {/* Steps to APK */}
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-start gap-2 text-[11px]">
                  <span className="w-5 h-5 rounded-full bg-indigo-500 text-white font-bold flex items-center justify-center shrink-0 mt-0.5 text-[10px]">1</span>
                  <span>انسخ رابط التطبيق: <code className="bg-slate-950 px-1 py-0.5 rounded text-sky-300 font-mono text-[10px] break-all">{typeof window !== 'undefined' ? window.location.origin : ''}</code></span>
                </div>
                <div className="flex items-start gap-2 text-[11px]">
                  <span className="w-5 h-5 rounded-full bg-indigo-500 text-white font-bold flex items-center justify-center shrink-0 mt-0.5 text-[10px]">2</span>
                  <span>افتح موقع <b>PWABuilder.com</b> واضغط <b>Start</b>.</span>
                </div>
                <div className="flex items-start gap-2 text-[11px]">
                  <span className="w-5 h-5 rounded-full bg-indigo-500 text-white font-bold flex items-center justify-center shrink-0 mt-0.5 text-[10px]">3</span>
                  <span>اختر <b>Android</b> ثم اضغط <b>Generate Package</b> لتحميل ملف APK جاهز للتثبيت على أي هاتف أندرويد!</span>
                </div>
              </div>

              {/* Download project source zip */}
              <div className="p-3 bg-slate-900/80 border border-emerald-500/30 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="font-bold text-xs text-white">ملفات المشروع النظيفة (ZIP)</p>
                  <p className="text-[10px] text-emerald-400">تحميل سورس كود التطبيق المكتمل (تم التحقق من فك الضغط بنجاح 100%)</p>
                </div>
                <a
                  href="/sales_crm_app_clean.zip"
                  download="sales_crm_app_clean.zip"
                  onClick={() => {
                    triggerHaptic('success');
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-md transition-all active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تحميل ZIP</span>
                </a>
              </div>
            </div>

            {/* External Link to PWABuilder */}
            <div className="pt-2 border-t border-indigo-500/20 space-y-2">
              <a
                href={`https://www.pwabuilder.com?url=${encodeURIComponent(typeof window !== 'undefined' ? window.location.origin : '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25 active:scale-95 transition-all"
              >
                <span>فتح أداة PWABuilder لتوليد APK 🚀</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <button
                onClick={() => setShowApkModal(false)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-all"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS Step-by-Step Installation Modal */}
      {showIOSModal && (
        <div 
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200"
          dir={dir}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowIOSModal(false);
          }}
        >
          <div className="w-full max-w-sm bg-[#0c1a30] border border-sky-500/30 rounded-3xl p-5 shadow-2xl space-y-4 text-right animate-in slide-in-from-bottom-5 duration-300">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-sky-500/20 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">
                    {language === 'ar' ? 'تثبيت على آيفون / آيباد 🍎' : 'Install on iPhone / iPad 🍎'}
                  </h3>
                  <p className="text-[10px] text-sky-300/80">
                    {language === 'ar' ? '3 خطوات بسيطة لإضافة أيقونة التطبيق' : '3 simple steps to add app icon'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl bg-slate-800/80 transition-all"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* App Icon Card */}
            <div className="p-3 bg-slate-900/90 border border-sky-500/20 rounded-2xl flex items-center gap-3">
              <img 
                src="/pwa-512x512.png" 
                alt="App Icon" 
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-xl shadow-lg border border-white/20 object-cover"
              />
              <div className="text-right">
                <p className="font-extrabold text-xs text-white">Sales CRM Mobile</p>
                <p className="text-[11px] text-sky-400 font-medium">نظام إدارة ومتابعة المبيعات</p>
              </div>
            </div>

            {/* Visual Steps for iOS Safari */}
            <div className="space-y-2.5 text-xs text-slate-200">
              {/* Step 1 */}
              <div className="p-3 bg-sky-950/40 border border-sky-500/20 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white flex items-center gap-1.5">
                    <span>اضغط على زر المشاركة</span>
                    <span className="p-1 bg-slate-800 rounded-md border border-sky-400/40 inline-flex items-center text-sky-300">
                      <Share className="w-3.5 h-3.5" />
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-300">
                    ستجده في أسفل شاشة متصفح Safari على جهازك.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="p-3 bg-sky-950/40 border border-sky-500/20 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white flex items-center gap-1.5">
                    <span>اختر «إضافة إلى الشاشة الرئيسية»</span>
                    <span className="p-1 bg-slate-800 rounded-md border border-sky-400/40 inline-flex items-center text-sky-300">
                      <PlusSquare className="w-3.5 h-3.5" />
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-300">
                    مرر القائمة لأسفل حتى تجد خيار <b>(Add to Home Screen)</b>.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="p-3 bg-sky-950/40 border border-sky-500/20 rounded-2xl flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-sky-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div className="space-y-0.5 leading-relaxed">
                  <p className="font-bold text-white">
                    اضغط على كلمة «إضافة» (Add)
                  </p>
                  <p className="text-[11px] text-slate-300">
                    في أعلى يمين الشاشة لإتمام التثبيت وظهور أيقونة التطبيق مباشرة!
                  </p>
                </div>
              </div>
            </div>

            {/* Bottom Arrow & Close */}
            <div className="pt-2 border-t border-sky-500/20 text-center space-y-2">
              <div className="flex items-center justify-center gap-1 text-[11px] text-sky-300 font-medium animate-bounce">
                <ArrowDown className="w-3.5 h-3.5 text-sky-400" />
                <span>زر المشاركة موجود في أسفل متصفح Safari</span>
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="w-full py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black rounded-xl text-xs transition-all active:scale-95"
              >
                {language === 'ar' ? 'فهمت، شكراً 👍' : 'Got it, thanks 👍'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
