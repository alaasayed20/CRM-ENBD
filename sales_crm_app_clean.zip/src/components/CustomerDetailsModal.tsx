import React, { useState } from 'react';
import { db, logOperation, calculateCardPoints, calculatePoints, deleteCustomerCascading } from '../db/db';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import { useLanguage, formatPhone, formatNumber, formatCurrency } from '../context/LanguageContext';
import { getStatusTranslation, getCardTypeName } from '../utils/translations';
import { useLiveQuery } from 'dexie-react-hooks';
import { X, Phone, MessageCircle, Mail, Calendar, FileText, CreditCard, DollarSign, Award, Edit3, Trash2, Send, CheckCircle2, Calculator, Loader2 } from 'lucide-react';
import type { Customer, CustomerStatus } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { FinanceCalculatorModal } from './FinanceCalculatorModal';
import { getStoredPersonalFinanceRates, calculateFinanceRateFromSalary, type PersonalFinanceRatesConfig } from '../utils/finance';
import { exportReportToPDF, type PdfAccent } from '../utils/pdfExport';
import {
  buildSafeTelHref,
  buildSafeWhatsAppHref,
  buildSafeMailtoHref,
  safeOpenExternal,
  normalizePhoneForMatch,
} from '../utils/security';
import {
  getCustomerMonthKey,
  getAvailableMonthOptions,
  formatMonthKeyToArabic,
  formatMonthKeyToEnglish,
} from '../utils/monthRollover';
import {
  parseScheduledCardIssuanceFromNote,
  schedulePotentialCustomerForIssuanceMonth,
  upsertScheduledIssuanceSnippetInNote,
} from '../utils/scheduledIssuance';

interface CustomerDetailsModalProps {
  customer: Customer;
  onClose: () => void;
  onRefresh: () => void;
  onActivate: (customerId: number) => void;
  initialEdit?: boolean;
}

export const CustomerDetailsModal: React.FC<CustomerDetailsModalProps> = ({
  customer,
  onClose,
  onRefresh,
  onActivate,
  initialEdit = false
}) => {
  const { isAdmin, permissions, currentUser, settings, setSelectedMonthKey } = useAuth();
  const { showToast } = useToast();
  const { language, dir, t } = useLanguage();
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) || [];
  const templates = useLiveQuery(() => db.messageTemplates.toArray(), []) || [];
  const statuses = useLiveQuery(() => db.statuses.orderBy('order').toArray(), []) || [];
  const salaryTiers = useLiveQuery(() => db.salaryTiers.toArray(), []) || [];
  const allCustomers = useLiveQuery(() => db.customers.toArray(), []) || [];

  const [isEditing, setIsEditing] = useState(initialEdit);
  const [editName, setEditName] = useState(customer.name || '');
  const [editPhone, setEditPhone] = useState(customer.phone || '');
  const [editIdNumber, setEditIdNumber] = useState(customer.idNumber || '');
  const [editOrderNumber, setEditOrderNumber] = useState(customer.orderNumber || '');
  const [editTargetMonth, setEditTargetMonth] = useState(getCustomerMonthKey(customer));
  const [editEmail, setEditEmail] = useState(customer.email || '');
  const [editStatus, setEditStatus] = useState<CustomerStatus>(customer.status);
  const [editSalary, setEditSalary] = useState(customer.salary ? String(customer.salary) : '');
  const [editPoints, setEditPoints] = useState(customer.points !== undefined && customer.points !== null ? String(customer.points) : '');
  const [editAmount, setEditAmount] = useState(customer.amount ? String(customer.amount) : '');
  const [editFinanceType, setEditFinanceType] = useState<'salary_transfer' | 'no_salary_transfer'>(
    customer.financeType === 'no_salary_transfer' ? 'no_salary_transfer' : 'salary_transfer'
  );
  const [editFinanceRate, setEditFinanceRate] = useState(customer.financeRate !== undefined && customer.financeRate !== null ? String(customer.financeRate) : '');
  const [editCardTypeId, setEditCardTypeId] = useState<number | ''>(customer.cardTypeId || '');
  const [editNotes, setEditNotes] = useState(customer.notes || '');
  const [editCreatedAt, setEditCreatedAt] = useState<string>(
    customer.createdAt ? new Date(customer.createdAt).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]
  );

  const [quickPointsEdit, setQuickPointsEdit] = useState(false);
  const [quickPointsVal, setQuickPointsVal] = useState(customer.points !== undefined && customer.points !== null ? String(customer.points) : '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showFinanceCalcModal, setShowFinanceCalcModal] = useState(false);
  const [autoScheduleEditIssuance, setAutoScheduleEditIssuance] = useState(true);
  const [showEditIssuanceDatePicker, setShowEditIssuanceDatePicker] = useState(false);
  const [editQuickIssuanceDate, setEditQuickIssuanceDate] = useState('');
  const [showViewQuickSchedule, setShowViewQuickSchedule] = useState(false);
  const [viewQuickNote, setViewQuickNote] = useState('');
  const [viewQuickDate, setViewQuickDate] = useState('');
  const [schedulingNow, setSchedulingNow] = useState(false);

  const sourceMonthKey = React.useMemo(() => getCustomerMonthKey(customer), [customer]);
  const detectedEditIssuance = React.useMemo(
    () => parseScheduledCardIssuanceFromNote(editNotes, sourceMonthKey),
    [editNotes, sourceMonthKey]
  );
  const detectedViewIssuance = React.useMemo(
    () => parseScheduledCardIssuanceFromNote(customer.notes, sourceMonthKey),
    [customer.notes, sourceMonthKey]
  );
  const existingScheduledInViewTarget = React.useMemo(() => {
    if (!detectedViewIssuance || !detectedViewIssuance.isDifferentFromSourceMonth) return undefined;
    const normPhone = normalizePhoneForMatch(customer.phone);
    if (!normPhone) return undefined;
    return allCustomers.find(
      (c) =>
        c.id !== customer.id &&
        normalizePhoneForMatch(c.phone) === normPhone &&
        getCustomerMonthKey(c) === detectedViewIssuance.targetMonth
    );
  }, [allCustomers, customer.id, customer.phone, detectedViewIssuance]);

  // Live Query personal finance rates
  const liveRatesSetting = useLiveQuery(() => db.settings.get('personalFinanceRates'));
  const activeFinanceRates = React.useMemo<PersonalFinanceRatesConfig>(() => {
    if (liveRatesSetting?.value) return liveRatesSetting.value as PersonalFinanceRatesConfig;
    return getStoredPersonalFinanceRates();
  }, [liveRatesSetting]);

  // Suggested default rate based on salary and transfer type
  const editSuggestedRate = React.useMemo(() => {
    const sal = parseFloat(editSalary) || 0;
    const loan = parseFloat(editAmount) || 100000;
    if (sal > 0) {
      return calculateFinanceRateFromSalary(sal, loan, editFinanceType, activeFinanceRates);
    }
    return editFinanceType === 'salary_transfer' 
      ? activeFinanceRates.quickDefaultStl 
      : activeFinanceRates.quickDefaultNstl;
  }, [editSalary, editAmount, editFinanceType, activeFinanceRates]);

  React.useEffect(() => {
    if (customer) {
      setEditName(customer.name || '');
      setEditPhone(customer.phone || '');
      setEditIdNumber(customer.idNumber || '');
      setEditOrderNumber(customer.orderNumber || '');
      setEditTargetMonth(getCustomerMonthKey(customer));
      setEditEmail(customer.email || '');
      setEditStatus(customer.status);
      setEditSalary(customer.salary ? String(customer.salary) : '');
      setEditPoints(customer.points !== undefined && customer.points !== null ? String(customer.points) : '');
      setEditAmount(customer.amount ? String(customer.amount) : '');
      setEditFinanceType(customer.financeType === 'no_salary_transfer' ? 'no_salary_transfer' : 'salary_transfer');
      setEditFinanceRate(customer.financeRate !== undefined && customer.financeRate !== null ? String(customer.financeRate) : '');
      setEditCardTypeId(customer.cardTypeId || '');
      setEditNotes(customer.notes || '');
      setEditCreatedAt(
        customer.createdAt ? new Date(customer.createdAt).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]
      );
      setQuickPointsVal(customer.points !== undefined && customer.points !== null ? String(customer.points) : '');
    }
  }, [customer]);

  const cardType = cardTypes.find((ct) => ct.id === customer.cardTypeId);

  const handleSendTemplate = (templateContent: string) => {
    let msg = templateContent
      .replace(/{name}/g, customer.name)
      .replace(/{orderNumber}/g, customer.orderNumber || '')
      .replace(/{phone}/g, customer.phone);

    const url = buildSafeWhatsAppHref(customer.phone, msg);
    safeOpenExternal(url);
    showToast(language === 'ar' ? 'تم فتح واتساب مع نص القالب' : 'Opened WhatsApp with template');
  };

  const handleUpdateStatus = async (newStatus: CustomerStatus) => {
    if (!customer.id) return;
    try {
      const now = new Date();
      let calculatedPoints = customer.points || 0;

      if (newStatus === 'تم التفعيل') {
        const selectedCardType = cardTypes.find((ct) => ct.id === (editCardTypeId || customer.cardTypeId));
        const basePoints = selectedCardType && typeof selectedCardType.points === 'number' ? selectedCardType.points : 0;
        const sal = editSalary ? parseFloat(editSalary) : (customer.salary || 0);

        if (!calculatedPoints || calculatedPoints === 0) {
          calculatedPoints = basePoints > 0
            ? calculateCardPoints(basePoints, sal, customer.productType || 'visa', salaryTiers)
            : calculatePoints(sal);
        }
      }

      const updates = {
        status: newStatus,
        points: calculatedPoints > 0 ? calculatedPoints : customer.points,
        activatedAt: newStatus === 'تم التفعيل' ? (customer.activatedAt || now) : null,
        updatedAt: now
      };

      await db.customers.update(customer.id, updates);
      setEditStatus(newStatus);
      if (calculatedPoints > 0) {
        setEditPoints(String(calculatedPoints));
      }

      if (newStatus === 'تم التفعيل' && calculatedPoints > 0) {
        const existingLog = await db.pointsLog.where('customerId').equals(customer.id).first();
        if (!existingLog) {
          await db.pointsLog.add({
            customerId: customer.id,
            salesRepId: currentUser?.id,
            points: calculatedPoints,
            reason: `تغيير حالة العميل إلى تم التفعيل (${customer.name})`,
            month: now.getMonth() + 1,
            year: now.getFullYear(),
            timestamp: now
          });
        }
      } else if (newStatus !== 'تم التفعيل' && customer.status === 'تم التفعيل') {
        await db.pointsLog.where('customerId').equals(customer.id).delete();
      }

      await logOperation('UPDATE_STATUS', 'customers', customer.id, customer, { ...customer, ...updates }, currentUser?.id);
      showToast(language === 'ar' ? `تم تغيير الحالة إلى ${getStatusTranslation(newStatus, 'ar')}` : `Status updated to ${getStatusTranslation(newStatus, 'en')}`);
      onRefresh();
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleDelete = async () => {
    if (!permissions.canDeleteCustomer) {
      showToast(language === 'ar' ? 'صلاحية حذف العملاء متاحة للمدير فقط' : 'Only administrators can delete customers', 'error');
      setShowDeleteConfirm(false);
      return;
    }
    if (!customer.id) return;
    try {
      await deleteCustomerCascading(customer.id, currentUser?.id);
      showToast(language === 'ar' ? 'تم حذف العميل والمهام والسجلات المرتبطة به بنجاح 🗑️' : 'Customer deleted successfully 🗑️', 'success');
      onRefresh();
      onClose();
    } catch (err) {
      console.error('Delete error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء حذف العميل' : 'Error deleting customer', 'error');
    } finally {
      setShowDeleteConfirm(false);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.id) return;

    try {
      const now = new Date();
      const selectedRegDate = editCreatedAt ? new Date(editCreatedAt + 'T12:00:00') : (customer.createdAt ? new Date(customer.createdAt) : now);
      let calculatedPoints = editPoints !== '' ? Number(editPoints) : (customer.points || 0);

      if (editStatus === 'تم التفعيل') {
        const selectedCardType = cardTypes.find((ct) => ct.id === (editCardTypeId || customer.cardTypeId));
        const basePoints = selectedCardType && typeof selectedCardType.points === 'number' ? selectedCardType.points : 0;
        const sal = editSalary ? parseFloat(editSalary) : (customer.salary || 0);

        if (!calculatedPoints || calculatedPoints === 0) {
          calculatedPoints = basePoints > 0
            ? calculateCardPoints(basePoints, sal, customer.productType || 'visa', salaryTiers)
            : calculatePoints(sal);
        }
      }

      const updates = {
        name: editName.trim(),
        phone: editPhone.trim(),
        idNumber: editIdNumber.trim() || null,
        orderNumber: editOrderNumber.trim() || customer.orderNumber,
        targetMonth: editTargetMonth && editTargetMonth.includes('-') ? editTargetMonth : getCustomerMonthKey(customer),
        email: editEmail.trim() || null,
        status: editStatus,
        salary: editSalary ? parseFloat(editSalary) : null,
        points: calculatedPoints > 0 ? calculatedPoints : null,
        amount: editAmount ? parseFloat(editAmount) : null,
        financeType: customer.productType === 'finance' ? editFinanceType : null,
        financeRate: customer.productType === 'finance' && editFinanceRate ? parseFloat(editFinanceRate) : null,
        cardTypeId: editCardTypeId ? Number(editCardTypeId) : null,
        notes: editNotes.trim() || null,
        createdAt: selectedRegDate,
        activatedAt: editStatus === 'تم التفعيل' ? (customer.activatedAt || selectedRegDate) : null,
        updatedAt: now
      };

      await db.customers.update(customer.id, updates);

      if (editStatus === 'تم التفعيل' && calculatedPoints > 0) {
        const existingLog = await db.pointsLog.where('customerId').equals(customer.id).first();
        if (!existingLog) {
          await db.pointsLog.add({
            customerId: customer.id,
            salesRepId: currentUser?.id,
            points: calculatedPoints,
            reason: `تعديل حالة العميل إلى تم التفعيل (${editName.trim()})`,
            month: selectedRegDate.getMonth() + 1,
            year: selectedRegDate.getFullYear(),
            timestamp: selectedRegDate
          });
        }
      } else if (editStatus !== 'تم التفعيل' && customer.status === 'تم التفعيل') {
        await db.pointsLog.where('customerId').equals(customer.id).delete();
      } else if (editStatus === 'تم التفعيل' && editPoints !== '' && Number(editPoints) !== customer.points) {
        await db.pointsLog.add({
          customerId: customer.id,
          salesRepId: currentUser?.id,
          points: Number(editPoints),
          reason: `تعديل النقاط يدوياً لـ (${editName.trim()})`,
          month: selectedRegDate.getMonth() + 1,
          year: selectedRegDate.getFullYear(),
          timestamp: selectedRegDate
        });
      }

      await logOperation('UPDATE', 'customers', customer.id, customer, { ...customer, ...updates }, currentUser?.id);

      let scheduledMonthMsg = '';
      if (detectedEditIssuance && autoScheduleEditIssuance && detectedEditIssuance.isDifferentFromSourceMonth) {
        const selectedCard = cardTypes.find((ct) => ct.id === (updates.cardTypeId || customer.cardTypeId));
        const res = await schedulePotentialCustomerForIssuanceMonth(
          {
            name: updates.name,
            phone: updates.phone,
            idNumber: updates.idNumber,
            email: updates.email,
            salary: updates.salary,
            cardTypeId: updates.cardTypeId,
            cardTypeName: selectedCard?.name || customer.cardTypeName || null,
            points: updates.points,
            notes: updates.notes,
            salesRepId: customer.salesRepId ?? currentUser?.id,
          },
          detectedEditIssuance,
          { userId: currentUser?.id, language }
        );
        scheduledMonthMsg = language === 'ar' ? res.monthLabelAr : res.monthLabelEn;
      }

      if (scheduledMonthMsg) {
        showToast(
          language === 'ar'
            ? `تم حفظ التعديل وإدراج العميل تلقائياً كـ «عميل محتمل» في شهر ${scheduledMonthMsg} 📅✨`
            : `Updated & auto-scheduled as Potential in ${scheduledMonthMsg} 📅✨`,
          'success'
        );
      } else {
        showToast(language === 'ar' ? 'تم تحديث البيانات والنقاط بنجاح ✨' : 'Customer updated successfully ✨');
      }
      setIsEditing(false);
      onRefresh();
    } catch (err) {
      console.error('Update error:', err);
      showToast(language === 'ar' ? 'خطأ أثناء التحديث' : 'Error updating customer', 'error');
    }
  };

  const handleQuickScheduleFromView = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.id) return;

    const noteToAppend = viewQuickDate
      ? upsertScheduledIssuanceSnippetInNote(viewQuickNote, viewQuickDate, language)
      : viewQuickNote.trim();

    const parsed = parseScheduledCardIssuanceFromNote(noteToAppend, sourceMonthKey);
    if (!parsed) {
      showToast(
        language === 'ar'
          ? 'يرجى اختيار تاريخ إصدار البطاقة أو كتابة الشهر في الملاحظة (مثال: يتم إصدار البطاقة في يناير 2027)'
          : 'Please pick an issuance date or mention the card issuance month in the note',
        'warning'
      );
      return;
    }

    setSchedulingNow(true);
    try {
      const updatedNotes = customer.notes?.trim()
        ? `${customer.notes.trim()}\n${noteToAppend}`
        : noteToAppend;

      await db.customers.update(customer.id, {
        notes: updatedNotes,
        updatedAt: new Date(),
      });

      const res = await schedulePotentialCustomerForIssuanceMonth(
        {
          name: customer.name,
          phone: customer.phone,
          idNumber: customer.idNumber,
          email: customer.email,
          salary: customer.salary,
          cardTypeId: customer.cardTypeId,
          cardTypeName: cardType?.name || customer.cardTypeName || null,
          points: customer.points,
          notes: updatedNotes,
          salesRepId: customer.salesRepId ?? currentUser?.id,
        },
        parsed,
        { userId: currentUser?.id, language }
      );

      showToast(
        language === 'ar'
          ? `تمت إضافة الملاحظة وإدراج العميل كـ «عميل محتمل» في شهر ${res.monthLabelAr} مع تذكير بالموعد 📅✨`
          : `Note saved & customer scheduled as Potential in ${res.monthLabelEn} 📅✨`,
        'success'
      );
      setShowViewQuickSchedule(false);
      setViewQuickNote('');
      setViewQuickDate('');
      onRefresh();
    } catch (err) {
      console.error('Quick schedule error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء جدولة العميل' : 'Failed to schedule customer', 'error');
    } finally {
      setSchedulingNow(false);
    }
  };

  const handleScheduleExistingDetectedNote = async () => {
    if (!detectedViewIssuance || schedulingNow) return;
    setSchedulingNow(true);
    try {
      const res = await schedulePotentialCustomerForIssuanceMonth(
        {
          name: customer.name,
          phone: customer.phone,
          idNumber: customer.idNumber,
          email: customer.email,
          salary: customer.salary,
          cardTypeId: customer.cardTypeId,
          cardTypeName: cardType?.name || customer.cardTypeName || null,
          points: customer.points,
          notes: customer.notes,
          salesRepId: customer.salesRepId ?? currentUser?.id,
        },
        detectedViewIssuance,
        { userId: currentUser?.id, language }
      );
      showToast(
        language === 'ar'
          ? `تم إدراج العميل كـ «عميل محتمل» في شهر ${res.monthLabelAr} بنجاح 📅✨`
          : `Scheduled as Potential in ${res.monthLabelEn} 📅✨`,
        'success'
      );
      onRefresh();
    } catch (err) {
      console.error('Schedule detected note error:', err);
      showToast(language === 'ar' ? 'تعذر جدولة العميل' : 'Could not schedule customer', 'error');
    } finally {
      setSchedulingNow(false);
    }
  };

  const handleSaveQuickPoints = async () => {
    if (!customer.id) return;
    try {
      const pts = quickPointsVal !== '' ? Number(quickPointsVal) : 0;
      await db.customers.update(customer.id, {
        points: pts,
        updatedAt: new Date()
      });

      const now = new Date();
      await db.pointsLog.add({
        customerId: customer.id,
        salesRepId: currentUser?.id,
        points: pts,
        reason: `تعديل النقاط السريع لـ (${customer.name})`,
        month: now.getMonth() + 1,
        year: now.getFullYear(),
        timestamp: now
      });

      showToast(language === 'ar' ? `تم تحديث النقاط إلى ${formatNumber(pts)} نقطة 🏆` : `Points updated to ${formatNumber(pts)} 🏆`);
      setQuickPointsEdit(false);
      onRefresh();
    } catch (err) {
      console.error('Quick points edit error:', err);
      showToast(language === 'ar' ? 'خطأ في حفظ النقاط' : 'Error saving points', 'error');
    }
  };

  const getStatusBadge = (status: CustomerStatus) => {
    const label = getStatusTranslation(status, language);
    switch (status as string) {
      case 'تم التفعيل':
        return <span className="px-2.5 py-1 text-xs font-black rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">⚡ {label}</span>;
      case 'تم التنفيذ':
      case 'مكتمل':
        return <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">🟢 {label}</span>;
      case 'بانتظار التفعيل':
        return <span className="px-2.5 py-1 text-xs font-black rounded-full bg-gradient-to-r from-amber-500/30 to-yellow-500/30 text-amber-300 border border-amber-500/50 animate-pulse">⚡ {label}</span>;
      case 'عميل معلق':
      case 'مكتمَل الأوراق':
      case 'مكتمل الأوراق':
      case 'مؤجل':
        return <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">🟠 {label}</span>;
      case 'عميل محتمل':
      case 'متابعة':
      default:
        return <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30">🔵 {label}</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto overflow-x-hidden">
      <div className={`bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-lg min-w-0 shadow-2xl flex flex-col my-auto max-h-[90vh] overflow-hidden relative ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
        <div className="glow-top" />
        
        {/* Fixed Header */}
        <div className="flex items-center justify-between gap-2 p-3.5 sm:p-4 border-b border-zinc-800 bg-zinc-900/90 backdrop-blur-sm shrink-0 z-10 min-w-0">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="text-lg shrink-0">👤</span>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm sm:text-base text-white truncate">{customer.name}</h3>
              <div className={`text-[10px] text-zinc-400 font-mono dir-ltr truncate ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{formatPhone(customer.phone)}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className={`px-2.5 py-1 rounded-xl text-xs font-bold border transition-all ${
                isEditing
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-zinc-800 text-zinc-300 hover:text-white border-zinc-700'
              }`}
            >
              {isEditing ? (language === 'ar' ? 'إلغاء التعديل' : 'Cancel Edit') : (language === 'ar' ? '✏️ تعديل' : '✏️ Edit')}
            </button>
            <button onClick={onClose} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-3.5 sm:p-4 space-y-4 pb-8 overscroll-contain min-w-0">
          {isEditing ? (
            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1 flex items-center justify-between">
                  <span>{t('customerName', 'الاسم')}</span>
                  <span className="hidden group-focus-within:inline-block text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                    {language === 'ar' ? 'تعديل ✏️' : 'Edit ✏️'}
                  </span>
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-white text-sm font-semibold focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-indigo-500/40 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                <label className="block text-xs font-extrabold text-indigo-300 group-focus-within:text-amber-300 mb-1 flex items-center justify-between">
                  <span>{language === 'ar' ? 'حالة العميل 🔄' : 'Customer Status 🔄'}</span>
                  <span className="hidden group-focus-within:inline-block text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                    {language === 'ar' ? 'تغيير الحالة ✏️' : 'Change Status ✏️'}
                  </span>
                </label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as CustomerStatus)}
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-white text-sm font-bold focus:outline-none focus:border-amber-400"
                >
                  {statuses
                    .filter((s) => customer.productType === 'visa' || (s.name !== 'تم التفعيل' && s.nameEn !== 'Activated'))
                    .map((s) => (
                      <option key={s.id || s.name} value={s.name} className="bg-zinc-900 text-white font-medium py-1">
                        {getStatusTranslation(s.name, language)}
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                  <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('phone', 'رقم الجوال')}</label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    required
                    className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-white text-sm dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono font-bold"
                  />
                </div>

                <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-amber-500/40 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                    <label className="block text-xs font-extrabold text-amber-400">🏆 {t('points', 'نقاط العميل')}</label>
                    <button
                      type="button"
                      onClick={() => {
                        const sal = editSalary ? parseFloat(editSalary) : 0;
                        const ct = cardTypes.find((c) => c.id === (editCardTypeId ? Number(editCardTypeId) : null));
                        if (ct && typeof ct.points === 'number' && ct.points > 0) {
                          setEditPoints(String(calculateCardPoints(ct.points, sal)));
                        } else {
                          setEditPoints(String(calculatePoints(sal)));
                        }
                        showToast(language === 'ar' ? 'تمت إعادة حساب النقاط وفق المعادلة ✨' : 'Points recalculated ✨');
                      }}
                      className="text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold"
                    >
                      <span>{language === 'ar' ? 'إعادة احتساب' : 'Recalculate'}</span>
                    </button>
                  </div>
                  <input
                    type="number"
                    step="any"
                    value={editPoints}
                    onChange={(e) => setEditPoints(e.target.value)}
                    placeholder="0"
                    min="0"
                    className="w-full bg-zinc-900 border border-amber-500/50 rounded-xl p-2.5 text-sm font-extrabold text-amber-300 dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-indigo-500/35 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                  <label className="block text-xs font-extrabold text-indigo-300 group-focus-within:text-amber-300 mb-1">
                    {language === 'ar' ? '📁 رقم ملف العميل / الطلب' : '📁 Customer File / Order #'}
                  </label>
                  <input
                    type="text"
                    value={editOrderNumber}
                    onChange={(e) => setEditOrderNumber(e.target.value)}
                    placeholder="FILE-1001"
                    className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-sm text-indigo-200 focus:outline-none focus:border-amber-400 font-mono font-bold"
                  />
                </div>

                <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-indigo-500/35 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                  <label className="block text-xs font-extrabold text-indigo-300 group-focus-within:text-amber-300 mb-1">
                    {language === 'ar' ? '📅 شهر العمل المستهدف' : '📅 Target Work Month'}
                  </label>
                  <div className="space-y-1.5">
                    <select
                      value={editTargetMonth}
                      onChange={(e) => setEditTargetMonth(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2 text-xs text-white font-bold focus:outline-none focus:border-amber-400"
                    >
                      {getAvailableMonthOptions(allCustomers, [editTargetMonth]).filter((m) => m.key !== 'all').map((m) => (
                        <option key={m.key} value={m.key} className="bg-zinc-900 text-white">
                          {language === 'ar' ? m.labelAr : m.labelEn}
                        </option>
                      ))}
                    </select>
                    <input
                      type="month"
                      value={editTargetMonth}
                      onChange={(e) => {
                        if (e.target.value) setEditTargetMonth(e.target.value);
                      }}
                      className="w-full bg-zinc-900 border border-zinc-700/60 rounded-lg px-2 py-1 text-[11px] font-mono text-indigo-200 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                  <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('salary', 'الراتب الشهري')}</label>
                  <input
                    type="number"
                    step="any"
                    value={editSalary}
                    onChange={(e) => setEditSalary(e.target.value)}
                    placeholder="15000"
                    min="0"
                    className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-white text-sm dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono font-bold"
                  />
                </div>

                {customer.productType === 'visa' ? (
                  <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all min-w-0">
                    <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('cardType', 'نوع البطاقة')}</label>
                    <select
                      value={editCardTypeId}
                      onChange={(e) => setEditCardTypeId(e.target.value ? Number(e.target.value) : '')}
                      className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-white text-sm focus:outline-none focus:border-amber-400 font-medium cursor-pointer"
                    >
                      <option value="" className="bg-zinc-900 text-zinc-400">{language === 'ar' ? 'اختر البطاقة...' : 'Select Card...'}</option>
                      {cardTypes.map((ct) => (
                        <option key={ct.id} value={ct.id} className="bg-zinc-900 text-white font-medium py-1">
                          {getCardTypeName(ct.name, language)} ({formatNumber(ct.points || 4250)} {t('pointsUnit')})
                        </option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="space-y-3 col-span-2">
                    <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                      <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('amount', 'المبلغ المطلوب')}</label>
                      <input
                        type="number"
                        step="any"
                        value={editAmount}
                        onChange={(e) => setEditAmount(e.target.value)}
                        placeholder="50000"
                        min="0"
                        className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-emerald-300 text-base dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono font-black"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-zinc-300 mb-1">{language === 'ar' ? 'نوع التمويل' : 'Finance Type'}</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setEditFinanceType('salary_transfer')}
                          className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                            editFinanceType === 'salary_transfer'
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-md'
                              : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                          }`}
                        >
                          <span>🏦 {t('salaryTransfer', 'تحويل راتب')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setEditFinanceType('no_salary_transfer')}
                          className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                            editFinanceType === 'no_salary_transfer'
                              ? 'bg-sky-500/20 text-sky-300 border-sky-500 shadow-md'
                              : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                          }`}
                        >
                          <span>💼 {t('noSalaryTransfer', 'بدون تحويل راتب')}</span>
                        </button>
                      </div>
                    </div>

                    <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300">{language === 'ar' ? 'النسبة المئوية للتمويل (%)' : 'Finance Rate (%)'}</label>
                        <button
                          type="button"
                          onClick={() => setShowFinanceCalcModal(true)}
                          className="text-[10px] font-bold text-indigo-300 hover:text-indigo-200 bg-indigo-500/20 px-2 py-0.5 rounded-lg border border-indigo-500/30 flex items-center gap-1 transition-all active:scale-95"
                        >
                          <Calculator className="w-3 h-3 text-indigo-400" />
                          <span>{language === 'ar' ? 'حاسبة الشجرة الذكية 🧮' : 'Smart Tree Calculator 🧮'}</span>
                        </button>
                      </div>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.01"
                          value={editFinanceRate}
                          onChange={(e) => setEditFinanceRate(e.target.value)}
                          placeholder="2.5"
                          min="0"
                          max="100"
                          className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 pr-3 pl-8 text-sm text-amber-300 dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono font-black"
                        />
                        <span className={`absolute top-1/2 -translate-y-1/2 text-zinc-400 text-xs font-extrabold ${dir === 'rtl' ? 'left-3' : 'right-3'}`}>%</span>
                      </div>

                      <div className="flex items-center justify-between mt-1.5 pt-1.5 border-t border-zinc-800/80">
                        <span className="text-[10px] text-zinc-400">
                          {language === 'ar' ? 'النسبة المعتمدة المقترحة:' : 'Approved Default:'}{' '}
                          <span className="text-amber-400 font-bold font-mono">{editSuggestedRate}%</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => setEditFinanceRate(String(editSuggestedRate))}
                          className="text-[10px] text-emerald-300 hover:text-emerald-200 bg-emerald-500/15 hover:bg-emerald-500/25 px-2 py-0.5 rounded-lg border border-emerald-500/30 font-bold transition-all active:scale-95 flex items-center gap-1 shadow-sm"
                        >
                          <span>⚡</span>
                          <span>{language === 'ar' ? `تطبيق (${editSuggestedRate}%)` : `Apply (${editSuggestedRate}%)`}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{language === 'ar' ? 'تاريخ التسجيل / الشهر المستهدف' : 'Registration Date / Target Month'}</span>
                </label>
                <input
                  type="date"
                  value={editCreatedAt}
                  onChange={(e) => setEditCreatedAt(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:border-amber-400 font-mono font-bold"
                />
              </div>

              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('email', 'البريد الإلكتروني')}</label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-sm text-white dir-ltr text-right focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all">
                <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300 mb-1">{t('idNumber', 'رقم الهوية الوطنية / الإقامة')}</label>
                <input
                  type="text"
                  value={editIdNumber}
                  onChange={(e) => setEditIdNumber(e.target.value)}
                  placeholder="10xxxxxxxx / 20xxxxxxxx"
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:border-amber-400 font-mono font-bold"
                />
              </div>

              <div className="group bg-zinc-950/80 p-3 rounded-2xl border border-zinc-800 focus-within:border-amber-400 focus-within:ring-2 focus-within:ring-amber-500/30 transition-all space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <label className="block text-xs font-extrabold text-zinc-300 group-focus-within:text-amber-300">{t('notes', 'ملاحظات')}</label>
                  <button
                    type="button"
                    onClick={() => setShowEditIssuanceDatePicker((v) => !v)}
                    className="text-[10px] font-bold text-sky-300 hover:text-sky-200 bg-sky-500/15 px-2 py-0.5 rounded-lg border border-sky-500/30 flex items-center gap-1"
                  >
                    <Calendar className="w-3 h-3" />
                    <span>{language === 'ar' ? 'تحديد تاريخ إصدار البطاقة' : 'Set Issuance Date'}</span>
                  </button>
                </div>

                {showEditIssuanceDatePicker && (
                  <div className="flex items-center gap-2 bg-sky-950/40 border border-sky-500/30 rounded-xl p-2">
                    <input
                      type="date"
                      value={editQuickIssuanceDate}
                      onChange={(e) => {
                        const val = e.target.value;
                        setEditQuickIssuanceDate(val);
                        if (val) {
                          setEditNotes((prev) => upsertScheduledIssuanceSnippetInNote(prev, val, language));
                          setAutoScheduleEditIssuance(true);
                        }
                      }}
                      className="flex-1 bg-zinc-900 border border-sky-500/40 rounded-lg px-2 py-1 text-xs text-white font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowEditIssuanceDatePicker(false)}
                      className="px-2 py-1 rounded-lg bg-zinc-800 text-zinc-300 text-[10px] font-bold"
                    >
                      {language === 'ar' ? 'تم' : 'Done'}
                    </button>
                  </div>
                )}

                <textarea
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  rows={3}
                  placeholder={language === 'ar' ? 'مثال: يتم إصدار البطاقة بتاريخ 15/01/2027 (سيُضاف تلقائياً كعميل محتمل في ذلك الشهر)' : 'e.g. Card issuance scheduled on 2027-01-15'}
                  className="w-full bg-zinc-900 border border-zinc-700/60 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:border-amber-400 font-medium"
                />

                {detectedEditIssuance && detectedEditIssuance.isDifferentFromSourceMonth && (
                  <div className="flex items-start justify-between gap-2 rounded-xl bg-sky-500/10 border border-sky-500/35 p-2.5">
                    <div className="min-w-0">
                      <div className="text-[11px] font-extrabold text-sky-200 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                        <span>
                          {language === 'ar'
                            ? `إدراج تلقائي كـ «عميل محتمل» في ${formatMonthKeyToArabic(detectedEditIssuance.targetMonth)}`
                            : `Auto-add as Potential in ${formatMonthKeyToEnglish(detectedEditIssuance.targetMonth)}`}
                        </span>
                      </div>
                      <div className="text-[10px] text-sky-200/80 mt-0.5">
                        {language === 'ar'
                          ? `موعد الإصدار المرصود: ${detectedEditIssuance.issuanceDate} (مع إنشاء تذكير متابعة تلقائي)`
                          : `Detected date: ${detectedEditIssuance.issuanceDate} (with auto reminder)`}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAutoScheduleEditIssuance((v) => !v)}
                      className={`w-10 h-5 rounded-full transition-colors p-0.5 flex items-center shrink-0 ${
                        autoScheduleEditIssuance ? 'bg-sky-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
                      }`}
                    >
                      <div className="w-4 h-4 bg-white rounded-full shadow" />
                    </button>
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-2.5 rounded-xl text-xs font-bold"
                >
                  {t('cancel', 'إلغاء')}
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/20"
                >
                  {language === 'ar' ? 'حفظ التعديلات والنقاط' : 'Save Changes'}
                </button>
              </div>
            </form>
          ) : (
            <>
              {/* Pending Activation High Priority Banner for Visa Cards */}
              {customer.productType === 'visa' && (customer.status === 'تم التنفيذ' || customer.status === 'بانتظار التفعيل') && (
                <div className={`bg-gradient-to-r from-amber-950/80 via-emerald-950/50 to-zinc-950 border border-emerald-500/50 p-3.5 rounded-2xl space-y-2 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg animate-pulse">⚡</span>
                      <span className="font-black text-xs text-emerald-300">
                        {language === 'ar' ? 'بطاقة صُدرت (تم التنفيذ) — بانتظار التفعيل النهائية' : 'Card Issued (Executed) — Pending Final Activation'}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {language === 'ar' ? 'النقاط معلقة للتفعيل' : 'Points Pending Activation'}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-300 leading-relaxed">
                    {language === 'ar'
                      ? 'تم إصدار هذه البطاقة (تم التنفيذ). يلزم تفعيل البطاقة من قبل العميل لتحويل حالتها لـ (تم التفعيل) واحتساب نقاطها مباشرة في الهدف الشهري!'
                      : 'Card has been issued. Activation is required to count points toward monthly goal!'}
                  </p>
                  <button
                    onClick={() => customer.id && onActivate(customer.id)}
                    className="w-full bg-gradient-to-r from-amber-500 via-emerald-500 to-teal-400 hover:from-amber-400 hover:to-emerald-400 text-zinc-950 font-black py-2.5 px-3 rounded-xl text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all active:scale-98"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{language === 'ar' ? 'تفعيل البطاقة الآن (تم التفعيل) وكسب النقاط للهدف 🏆' : 'Activate Card Now & Claim Goal Points 🏆'}</span>
                  </button>
                </div>
              )}

              {/* Status Change Direct Selector Card at Top */}
              <div className="bg-zinc-950/80 border border-indigo-500/30 p-3 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-indigo-300 flex items-center gap-1">
                    <span>🔄 {language === 'ar' ? 'تعديل حالة العميل مباشرة' : 'Change Status Directly'}</span>
                  </span>
                  {getStatusBadge(customer.status)}
                </div>
                <div className="flex gap-1.5 flex-wrap pt-1">
                  {statuses
                    .filter((s) => customer.productType === 'visa' || (s.name !== 'تم التفعيل' && s.nameEn !== 'Activated'))
                    .map((s) => (
                      <button
                        key={s.id || s.name}
                        onClick={() => handleUpdateStatus(s.name)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                          customer.status === s.name
                            ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400'
                            : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
                        }`}
                      >
                        {getStatusTranslation(s.name, language)}
                      </button>
                    ))}
                </div>
              </div>

              {/* Status & Type Badges Header */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-1 text-xs font-bold rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  {customer.productType === 'visa' ? `💳 ${t('productVisa')}` : `💰 ${t('productFinance')}`}
                </span>
                {customer.productType === 'visa' && (customer.status === 'تم التنفيذ' || customer.status === 'بانتظار التفعيل') && (
                  <button
                    onClick={() => customer.id && onActivate(customer.id)}
                    className={`${dir === 'rtl' ? 'mr-auto' : 'ml-auto'} px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-extrabold text-xs rounded-xl flex items-center gap-1 shadow-md shadow-emerald-500/20`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{t('activate')}</span>
                  </button>
                )}
              </div>

              {/* Info Cards */}
              <div className="grid grid-cols-1 gap-2 text-xs">
                <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800 flex items-center justify-between">
                  <div>
                    <div className="text-[11px] text-zinc-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      <span>📅 {language === 'ar' ? 'تاريخ التسجيل / الشهر' : 'Registration Date / Month'}</span>
                    </div>
                    <div className="font-bold text-white mt-0.5 text-xs">
                      {customer.createdAt ? new Date(customer.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' }) : (language === 'ar' ? 'غير محدد' : 'Not set')}
                    </div>
                  </div>
                </div>

                <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                  <div className="text-[11px] text-zinc-500">📱 {t('phone', 'رقم الجوال')}</div>
                  <div className={`font-bold text-white font-mono dir-ltr ${dir === 'rtl' ? 'text-right' : 'text-left'} mt-0.5`}>{formatPhone(customer.phone)}</div>
                </div>

                {customer.idNumber && (
                  <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-[11px] text-zinc-500">🪪 {t('idNumber', 'رقم الهوية الوطنية / الإقامة')}</div>
                    <div className={`font-bold text-indigo-300 font-mono dir-ltr ${dir === 'rtl' ? 'text-right' : 'text-left'} mt-0.5`}>{customer.idNumber}</div>
                  </div>
                )}

                {customer.orderNumber && (
                  <div className="bg-indigo-500/10 border border-indigo-500/20 p-2.5 rounded-xl">
                    <div className="text-[11px] text-indigo-400 font-bold">📁 {language === 'ar' ? 'رقم الطلب / الملف' : 'Order / File Number'}</div>
                    <div className="font-mono font-black text-indigo-300 text-sm mt-0.5">#{customer.orderNumber}</div>
                  </div>
                )}

                {customer.productType === 'visa' && cardType && (
                  <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-[11px] text-zinc-500">💳 {t('cardType', 'نوع البطاقة')}</div>
                    <div className="font-bold text-white mt-0.5">{getCardTypeName(cardType.name, language)}</div>
                  </div>
                )}

                {customer.productType === 'finance' && (
                  <>
                    <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                      <div className="text-[11px] text-zinc-500">💰 {t('amount', 'المبلغ المطلوب')}</div>
                      <div className="font-black text-emerald-400 text-sm mt-0.5 font-mono">
                        {formatCurrency(Number(customer.amount || 0))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                        <div className="text-[11px] text-zinc-500">🏦 {language === 'ar' ? 'نوع التمويل' : 'Finance Type'}</div>
                        <div className="font-bold text-emerald-300 mt-0.5 text-xs">
                          {customer.financeType === 'no_salary_transfer' ? `💼 ${t('noSalaryTransfer')}` : `🏦 ${t('salaryTransfer')}`}
                        </div>
                      </div>

                      <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                        <div className="text-[11px] text-zinc-500">📈 {language === 'ar' ? 'نسبة التمويل' : 'Finance Rate'}</div>
                        <div className={`font-bold text-indigo-300 mt-0.5 text-xs font-mono dir-ltr ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                          {customer.financeRate !== undefined && customer.financeRate !== null ? `${customer.financeRate}%` : (language === 'ar' ? 'غير محددة' : 'Not set')}
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Points Card */}
                <div className="bg-gradient-to-r from-amber-500/10 via-zinc-950 to-zinc-950 p-3 rounded-2xl border border-amber-500/30 flex justify-between items-center">
                  <div>
                    <div className="text-[11px] text-amber-400 font-bold flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      <span>{t('points', 'النقاط الكلية للعميل')}</span>
                    </div>
                    {quickPointsEdit ? (
                      <div className="flex items-center gap-1.5 mt-1">
                        <input
                          type="number"
                          value={quickPointsVal}
                          onChange={(e) => setQuickPointsVal(e.target.value)}
                          className="w-20 bg-zinc-900 border border-amber-500 rounded-lg p-1 text-xs text-amber-300 font-bold text-center dir-ltr"
                          autoFocus
                        />
                        <button
                          onClick={handleSaveQuickPoints}
                          className="px-2 py-1 bg-amber-500 text-zinc-950 rounded-lg text-xs font-bold"
                        >
                          {t('save', 'حفظ')}
                        </button>
                        <button
                          onClick={() => setQuickPointsEdit(false)}
                          className="p-1 bg-zinc-800 text-zinc-400 rounded-lg text-xs"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="font-black text-amber-300 text-lg font-mono mt-0.5">
                        {formatNumber(customer.points ?? 0)} {t('pointsUnit')}
                      </div>
                    )}
                  </div>
                  {!quickPointsEdit && (
                    <button
                      onClick={() => {
                        setQuickPointsVal(String(customer.points ?? 0));
                        setQuickPointsEdit(true);
                      }}
                      className="px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{language === 'ar' ? 'تعديل النقاط' : 'Edit Points'}</span>
                    </button>
                  )}
                </div>

                {customer.salary && (
                  <div className="bg-zinc-950/60 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-[11px] text-zinc-500">💵 {t('salary', 'الراتب الشهري')}</div>
                    <div className="font-bold text-white mt-0.5 font-mono">{formatCurrency(customer.salary)}</div>
                  </div>
                )}

                {customer.notes ? (
                  <div className={`p-2.5 rounded-xl border space-y-2 ${customer.status === 'عميل معلق' ? 'bg-amber-500/10 border-amber-500/30' : 'bg-zinc-950/60 border-zinc-800'}`}>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className={`text-[11px] font-bold ${customer.status === 'عميل معلق' ? 'text-amber-400' : 'text-zinc-500'}`}>
                        📝 {customer.status === 'عميل معلق' ? (language === 'ar' ? 'سبب التعليق والملاحظات' : 'Hold Reason & Notes') : t('notes', 'ملاحظات')}
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowViewQuickSchedule((v) => !v)}
                        className="text-[10px] font-bold text-sky-300 hover:text-sky-200 bg-sky-500/15 px-2 py-0.5 rounded-lg border border-sky-500/30 flex items-center gap-1"
                      >
                        <Calendar className="w-3 h-3" />
                        <span>{language === 'ar' ? 'جدولة إصدار بطاقة' : 'Schedule Issuance'}</span>
                      </button>
                    </div>
                    <div className="text-zinc-300 mt-0.5 whitespace-pre-line font-medium">{customer.notes}</div>

                    {/* Smart status chip if a future issuance month is detected in saved notes */}
                    {detectedViewIssuance && detectedViewIssuance.isDifferentFromSourceMonth && (
                      existingScheduledInViewTarget ? (
                        <div className="flex items-center justify-between gap-2 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-2.5 py-1.5">
                          <span className="text-[11px] font-bold text-emerald-300">
                            {language === 'ar'
                              ? `✅ مُدرج كـ «عميل محتمل» في شهر ${formatMonthKeyToArabic(detectedViewIssuance.targetMonth)}`
                              : `✅ Scheduled as Potential in ${formatMonthKeyToEnglish(detectedViewIssuance.targetMonth)}`}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedMonthKey(detectedViewIssuance.targetMonth);
                              onClose();
                            }}
                            className="text-[10px] font-extrabold text-emerald-200 hover:text-white bg-emerald-500/20 px-2 py-1 rounded-lg border border-emerald-500/30 shrink-0"
                          >
                            {language === 'ar' ? 'عرض الشهر' : 'View Month'}
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between gap-2 bg-sky-500/10 border border-sky-500/30 rounded-xl px-2.5 py-1.5">
                          <span className="text-[11px] font-bold text-sky-200">
                            {language === 'ar'
                              ? `📅 رُصد موعد إصدار في ${formatMonthKeyToArabic(detectedViewIssuance.targetMonth)}`
                              : `📅 Issuance detected for ${formatMonthKeyToEnglish(detectedViewIssuance.targetMonth)}`}
                          </span>
                          <button
                            type="button"
                            disabled={schedulingNow}
                            onClick={handleScheduleExistingDetectedNote}
                            className="text-[10px] font-extrabold text-zinc-950 bg-sky-400 hover:bg-sky-300 px-2.5 py-1 rounded-lg shrink-0"
                          >
                            {schedulingNow
                              ? '...'
                              : (language === 'ar' ? 'إضافة كعميل محتمل الآن' : 'Add as Potential Now')}
                          </button>
                        </div>
                      )
                    )}
                  </div>
                ) : (
                  <div className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 ${customer.status === 'عميل معلق' ? 'bg-amber-500/10 border-amber-500/30' : 'bg-zinc-950/60 border-zinc-800'}`}>
                    <div className="min-w-0">
                      <div className={`text-[11px] font-bold ${customer.status === 'عميل معلق' ? 'text-amber-400' : 'text-zinc-500'}`}>
                        📝 {customer.status === 'عميل معلق' ? (language === 'ar' ? 'سبب التعليق' : 'Hold Reason') : t('notes', 'ملاحظات')}
                      </div>
                      <div className="text-zinc-400 text-[11px] mt-0.5">
                        {customer.status === 'عميل معلق'
                          ? (language === 'ar' ? 'لم يتم تدوين سبب التعليق بعد.' : 'No hold reason entered yet.')
                          : (language === 'ar' ? 'لا توجد ملاحظات — يمكنك جدولة إصدار البطاقة لشهر لاحق.' : 'No notes yet — schedule card issuance for a future month.')}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowViewQuickSchedule((v) => !v)}
                      className="text-[10px] font-bold text-sky-300 hover:text-sky-200 bg-sky-500/15 px-2.5 py-1.5 rounded-lg border border-sky-500/30 flex items-center gap-1 shrink-0"
                    >
                      <Calendar className="w-3 h-3" />
                      <span>{language === 'ar' ? 'جدولة إصدار بطاقة' : 'Schedule Issuance'}</span>
                    </button>
                  </div>
                )}

                {/* Quick inline card issuance note & auto-scheduler in View Mode */}
                {showViewQuickSchedule && (
                  <form
                    onSubmit={handleQuickScheduleFromView}
                    className="p-3 rounded-2xl bg-sky-950/30 border border-sky-500/35 space-y-2.5"
                  >
                    <div className="text-xs font-extrabold text-sky-200 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-sky-400" />
                        <span>{language === 'ar' ? 'إضافة ملاحظة إصدار بطاقة وإدراج كعميل محتمل' : 'Add Deferred Issuance Note & Auto-Schedule'}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowViewQuickSchedule(false)}
                        className="text-zinc-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[10px] font-bold text-sky-200/80 mb-1">
                          {language === 'ar' ? 'تاريخ إصدار البطاقة المتوقع' : 'Expected Card Issuance Date'}
                        </label>
                        <input
                          type="date"
                          value={viewQuickDate}
                          onChange={(e) => setViewQuickDate(e.target.value)}
                          className="w-full bg-zinc-900 border border-sky-500/40 rounded-xl px-2.5 py-2 text-xs text-white font-mono focus:outline-none focus:border-sky-400"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-sky-200/80 mb-1">
                          {language === 'ar' ? 'ملاحظة إضافية (أو اكتب الشهر مباشرة)' : 'Note (or write month directly)'}
                        </label>
                        <input
                          type="text"
                          value={viewQuickNote}
                          onChange={(e) => setViewQuickNote(e.target.value)}
                          placeholder={language === 'ar' ? 'مثال: إصدار البطاقة بعد الترقية...' : 'e.g. Issue card in March 2027'}
                          className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      disabled={schedulingNow}
                      className="w-full py-2 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-zinc-950 font-black text-xs transition-all"
                    >
                      {schedulingNow
                        ? (language === 'ar' ? 'جاري الحفظ والجدولة...' : 'Scheduling...')
                        : (language === 'ar' ? 'حفظ الملاحظة وإضافة العميل كـ «عميل محتمل» في ذلك الشهر 📅' : 'Save Note & Add as Potential in That Month 📅')}
                    </button>
                  </form>
                )}
              </div>

              {/* Export Individual Customer Profile to PDF */}
              <button
                type="button"
                disabled={isExportingPdf}
                onClick={async () => {
                  if (isExportingPdf) return;
                  setIsExportingPdf(true);
                  try {
                    const cardName = cardTypes.find((ct) => ct.id === customer.cardTypeId)?.name;
                    const statusClean = (customer.status || '').trim();
                    const statusAccent: PdfAccent =
                      statusClean === 'تم التفعيل' ? 'emerald' :
                      statusClean === 'تم التنفيذ' ? 'cyan' :
                      statusClean === 'عميل معلق' || statusClean === 'بانتظار التفعيل' ? 'amber' : 'sky';

                    const profileRows = [
                      [{ text: language === 'ar' ? 'اسم العميل' : 'Customer Name', bold: true }, { text: customer.name || '-' }],
                      [{ text: language === 'ar' ? 'رقم الجوال' : 'Phone Number', bold: true }, { text: formatPhone(customer.phone || '-'), mono: true, dir: 'ltr' as const }],
                      ...(customer.idNumber ? [[{ text: language === 'ar' ? 'رقم الهوية' : 'ID Number', bold: true }, { text: customer.idNumber, mono: true }]] : []),
                      ...(customer.orderNumber ? [[{ text: language === 'ar' ? 'رقم الطلب' : 'Order Number', bold: true }, { text: `#${customer.orderNumber}`, mono: true }]] : []),
                      ...(customer.email ? [[{ text: language === 'ar' ? 'البريد الإلكتروني' : 'Email', bold: true }, { text: customer.email, dir: 'ltr' as const }]] : []),
                      [{ text: language === 'ar' ? 'الحالة الحالية' : 'Current Status', bold: true }, { text: getStatusTranslation(customer.status, language), badgeAccent: statusAccent }],
                      [{ text: language === 'ar' ? 'نوع المنتج' : 'Product Type', bold: true }, { text: customer.productType === 'visa' ? (cardName ? getCardTypeName(cardName, language) : 'Visa') : (language === 'ar' ? 'تمويل شخصي' : 'Personal Finance') }],
                      ...(customer.productType === 'finance' ? [
                        [{ text: language === 'ar' ? 'مبلغ التمويل' : 'Finance Amount', bold: true }, { text: formatCurrency(Number(customer.amount || 0)), mono: true }],
                        [{ text: language === 'ar' ? 'نوع التمويل' : 'Finance Type', bold: true }, { text: customer.financeType === 'no_salary_transfer' ? (language === 'ar' ? 'بدون تحويل راتب' : 'No Salary Transfer') : (language === 'ar' ? 'تحويل راتب' : 'Salary Transfer') }],
                      ] : []),
                      ...(customer.salary ? [[{ text: language === 'ar' ? 'الراتب الشهري' : 'Monthly Salary', bold: true }, { text: formatCurrency(customer.salary), mono: true }]] : []),
                      [{ text: language === 'ar' ? 'النقاط المسجلة' : 'Recorded Points', bold: true }, { text: `${formatNumber(customer.points ?? 0)} ${t('pointsUnit', 'نقطة')}`, bold: true, mono: true }],
                      [{ text: language === 'ar' ? 'تاريخ التسجيل' : 'Registration Date', bold: true }, { text: customer.createdAt ? new Date(customer.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US') : '-', mono: true }],
                      ...(customer.notes ? [[{ text: language === 'ar' ? 'الملاحظات' : 'Notes', bold: true }, { text: customer.notes }]] : []),
                    ];

                    await exportReportToPDF({
                      title: `${language === 'ar' ? 'بطاقة وملف العميل:' : 'Customer Profile:'} ${customer.name}`,
                      companyName: settings?.companyName?.trim() || 'SALES CRM SYSTEM',
                      cycleLabel: customer.createdAt ? new Date(customer.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US') : '-',
                      statusLabel: getStatusTranslation(customer.status, language),
                      statusAccent,
                      totalCountLabel: language === 'ar' ? 'النقاط' : 'Points',
                      totalCountValue: formatNumber(customer.points ?? 0),
                      dir,
                      language,
                      orientation: 'portrait',
                      columns: [
                        { label: language === 'ar' ? 'البيان' : 'Field', align: dir === 'rtl' ? 'right' : 'left', width: '34%' },
                        { label: language === 'ar' ? 'التفاصيل' : 'Details', align: dir === 'rtl' ? 'right' : 'left' },
                      ],
                      rows: profileRows,
                      footerText: language === 'ar' ? 'تم استخراج بطاقة العميل من نظام إدارة المبيعات Sales CRM' : 'Customer profile exported from Sales CRM',
                      fileName: `customer-${customer.orderNumber || customer.id || 'profile'}.pdf`,
                    });
                    showToast(language === 'ar' ? 'تم تصدير ملف العميل بصيغة PDF بنجاح 📄✨' : 'Customer PDF exported successfully 📄✨', 'success');
                  } catch (err) {
                    console.error('Customer PDF export error:', err);
                    showToast(language === 'ar' ? 'تعذر تصدير ملف العميل PDF' : 'Failed to export customer PDF', 'error');
                  } finally {
                    setIsExportingPdf(false);
                  }
                }}
                className="w-full bg-gradient-to-r from-rose-600 via-rose-500 to-amber-600 hover:from-rose-500 hover:to-amber-500 disabled:opacity-60 text-white font-extrabold py-2.5 px-3 rounded-xl text-xs shadow-lg shadow-rose-600/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
              >
                {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                <span>{language === 'ar' ? 'تصدير / طباعة ملف العميل (PDF)' : 'Export / Print Customer Profile (PDF)'}</span>
              </button>

              {/* Communication Action Buttons */}
              <div className="grid grid-cols-3 gap-2">
                <a
                  href={buildSafeTelHref(customer.phone)}
                  className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t('call', 'اتصال')}</span>
                </a>

                <a
                  href={buildSafeWhatsAppHref(customer.phone)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>{t('whatsapp', 'واتساب ويب')}</span>
                </a>

                <a
                  href={buildSafeMailtoHref(customer.email)}
                  className="bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>{t('email', 'بريد')}</span>
                </a>
              </div>

              {/* WhatsApp Templates Quick Sender */}
              <div className="space-y-2 pt-2 border-t border-zinc-800">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-extrabold text-indigo-300 flex items-center gap-1">
                    <span>📋 {language === 'ar' ? `قوالب رسائل الواتساب السريعة (${formatNumber(templates.length)})` : `WhatsApp Quick Templates (${formatNumber(templates.length)})`}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500">{language === 'ar' ? 'اضغط للإرسال المباشر' : 'Click to send'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 bg-zinc-950/40 rounded-2xl border border-zinc-800/80">
                  {templates.length === 0 ? (
                    <div className="col-span-2 text-center py-4 text-xs text-zinc-500 italic">
                      {language === 'ar' ? 'لا توجد قوالب رسائل معرفة حالياً' : 'No templates available'}
                    </div>
                  ) : (
                    templates.map((tmpl) => (
                      <button
                        key={tmpl.id}
                        onClick={() => handleSendTemplate(tmpl.content)}
                        className={`p-2.5 bg-zinc-900/90 hover:bg-indigo-950/60 border border-zinc-800 hover:border-indigo-500/50 rounded-xl transition-all group flex flex-col justify-between ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-indigo-300 group-hover:text-indigo-200">{tmpl.name}</span>
                          <Send className="w-3 h-3 text-indigo-400 group-hover:scale-110 transition-transform" />
                        </div>
                        <div className="text-[10px] text-zinc-400 line-clamp-2 mt-1 leading-snug">{tmpl.content}</div>
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Edit / Delete Options */}
              <div className="flex gap-2 pt-3 border-t border-zinc-800">
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-indigo-300 py-2.5 rounded-xl text-xs font-bold border border-zinc-700 flex items-center justify-center gap-1 active:scale-95 transition-all"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{language === 'ar' ? 'تعديل كافة البيانات' : 'Edit Customer'}</span>
                </button>
                {permissions.canDeleteCustomer && (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="flex-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 py-2.5 rounded-xl text-xs font-bold border border-rose-500/20 flex items-center justify-center gap-1 active:scale-95 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t('delete', 'حذف العميل')}</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      <ConfirmModal
        isOpen={showDeleteConfirm}
        title={language === 'ar' ? 'تأكيد حذف العميل' : 'Confirm Delete Customer'}
        message={language === 'ar' ? `هل أنت متأكد من حذف العميل "${customer.name}" وجميع البيانات والمهام المرتبطة به نهائياً؟` : `Are you sure you want to permanently delete customer "${customer.name}" and all associated data?`}
        confirmText={language === 'ar' ? 'نعم، حذف العميل 🗑️' : 'Yes, Delete Customer 🗑️'}
        cancelText={t('cancel', 'إلغاء')}
        isDanger={true}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteConfirm(false)}
      />

      {showFinanceCalcModal && (
        <FinanceCalculatorModal
          isOpen={showFinanceCalcModal}
          onClose={() => setShowFinanceCalcModal(false)}
          onApplyRate={(r) => setEditFinanceRate(String(r))}
          initialSalary={editSalary ? parseFloat(editSalary) : (customer.salary || 12000)}
          initialAmount={editAmount ? parseFloat(editAmount) : (customer.amount || 100000)}
        />
      )}
    </div>
  );
};
