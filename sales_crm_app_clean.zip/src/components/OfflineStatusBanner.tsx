import React, { useState, useEffect } from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useLanguage } from '../context/LanguageContext';
import { db } from '../db/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { Wifi, WifiOff, HardDrive, CheckCircle2, ShieldCheck, Smartphone, X, DownloadCloud } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const OfflineStatusBanner: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { language, formatNumber } = useLanguage();
  const { isInstallable, install, isIOS } = usePWAInstall();
  const [showHealthModal, setShowHealthModal] = useState(false);
  const [isStoragePersisted, setIsStoragePersisted] = useState(false);
  const [cacheStatus, setCacheStatus] = useState<string>('جاري الفحص');

  const customerCount = useLiveQuery(() => db.customers.count(), []) || 0;
  const pointsCount = useLiveQuery(() => db.pointsLog.count(), []) || 0;
  const tasksCount = useLiveQuery(() => db.tasks.count(), []) || 0;

  useEffect(() => {
    // Check Storage Persistence (prevent browser from evicting database)
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      navigator.storage.persisted().then((persisted) => {
        setIsStoragePersisted(persisted);
        if (!persisted) {
          navigator.storage.persist().then((granted) => {
            setIsStoragePersisted(granted);
          });
        }
      }).catch(() => {});
    }

    // Check Cache Storage
    if ('caches' in window) {
      caches.keys().then((keys) => {
        if (keys.length > 0) {
          setCacheStatus(language === 'ar' ? 'محفوظ محلياً بالكامل' : 'Fully Cached Offline');
        } else {
          setCacheStatus(language === 'ar' ? 'قيد التحميل' : 'Caching');
        }
      }).catch(() => {
        setCacheStatus(language === 'ar' ? 'جاهز' : 'Ready');
      });
    }
  }, [language]);

  return (
    <>
      {/* Offline Alert Strip - only visible when disconnected */}
      {!isOnline && (
        <aside
          role="status"
          aria-live="polite"
          className="no-print w-full max-w-full overflow-x-clip bg-amber-500/90 text-zinc-950 font-bold px-3.5 py-2 text-xs flex flex-wrap items-center justify-between gap-2 shadow-lg sticky top-0 z-50 backdrop-blur-sm border-b border-amber-400"
        >
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-zinc-950 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-zinc-900"></span>
            </span>
            <WifiOff className="w-4 h-4 shrink-0" />
            <span className="min-w-0 break-words leading-snug">
              {language === 'ar'
                ? 'وضع العمل دون إنترنت (أوفلاين) نشط - كافة البيانات والعمليات تعمل بكفاءة تامة على هاتفك'
                : 'Offline Mode Active - All data & features run 100% locally on your phone'}
            </span>
          </div>

          <button
            onClick={() => setShowHealthModal(true)}
            className="shrink-0 bg-zinc-950 text-amber-300 hover:bg-zinc-900 px-2.5 py-1 rounded-lg text-[11px] font-black transition-all active:scale-95 flex items-center gap-1 shadow"
          >
            <HardDrive className="w-3 h-3 shrink-0" />
            <span>{language === 'ar' ? 'فحص التخزين' : 'Storage Info'}</span>
          </button>
        </aside>
      )}

      {/* Offline Storage Health & PWA Modal */}
      {showHealthModal && (
        <div className="no-print fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-md p-5 shadow-2xl space-y-4 max-h-[90vh] flex flex-col text-right" dir={language === 'ar' ? 'rtl' : 'ltr'}>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">
                    {language === 'ar' ? 'حالة العمل بدون إنترنت والتخزين' : 'Offline & Storage Status'}
                  </h3>
                  <p className="text-[11px] text-zinc-400">
                    {language === 'ar' ? 'بياناتك محفوظة بالكامل داخل ذاكرة الجوال' : 'Your data is 100% saved locally on phone'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowHealthModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto pr-1">
              {/* Connection Status Card */}
              <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
                isOnline 
                  ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-950/30 border-amber-500/30 text-amber-300'
              }`}>
                <div className="flex items-center gap-2.5">
                  {isOnline ? <Wifi className="w-5 h-5 text-emerald-400" /> : <WifiOff className="w-5 h-5 text-amber-400" />}
                  <div>
                    <div className="text-xs font-bold text-white">
                      {isOnline 
                        ? (language === 'ar' ? 'متصل بالشبكة والإنترنت' : 'Online Connected')
                        : (language === 'ar' ? 'غير متصل (يعمل أوفلاين بالكامل)' : 'Offline (Full Local Mode)')
                      }
                    </div>
                    <div className="text-[10px] text-zinc-400">
                      {isOnline 
                        ? (language === 'ar' ? 'جاهز للتزامن والنسخ الاحتياطي' : 'Ready for backups & updates')
                        : (language === 'ar' ? 'التطبيق يعمل ومتاح بالكامل بدون انقطاع' : 'App runs uninterrupted offline')
                      }
                    </div>
                  </div>
                </div>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-lg border ${
                  isOnline 
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                }`}>
                  {isOnline ? (language === 'ar' ? 'متصل 🟢' : 'Online 🟢') : (language === 'ar' ? 'أوفلاين ⚡' : 'Offline ⚡')}
                </span>
              </div>

              {/* Local Database Statistics */}
              <div className="bg-zinc-950/70 border border-zinc-800/80 rounded-2xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold text-zinc-200">
                  <span className="flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-sky-400" />
                    <span>{language === 'ar' ? 'قاعدة البيانات المحلية (IndexedDB)' : 'Local Database (IndexedDB)'}</span>
                  </span>
                  <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20 font-mono">
                    {language === 'ar' ? 'نشطة ومؤمنة ✅' : 'Active & Secured ✅'}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div className="bg-zinc-900/90 p-2 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'العملاء المحفوظين' : 'Customers'}</div>
                    <div className="text-sm font-black text-amber-300 font-mono mt-0.5">{formatNumber(customerCount)}</div>
                  </div>
                  <div className="bg-zinc-900/90 p-2 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'سجلات النقاط' : 'Points Logs'}</div>
                    <div className="text-sm font-black text-purple-300 font-mono mt-0.5">{formatNumber(pointsCount)}</div>
                  </div>
                  <div className="bg-zinc-900/90 p-2 rounded-xl border border-zinc-800">
                    <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'المهام والتذكيرات' : 'Tasks'}</div>
                    <div className="text-sm font-black text-emerald-300 font-mono mt-0.5">{formatNumber(tasksCount)}</div>
                  </div>
                </div>
              </div>

              {/* System Cache & Persistence */}
              <div className="bg-zinc-950/70 border border-zinc-800/80 rounded-2xl p-3.5 space-y-2 text-xs">
                <div className="flex items-center justify-between text-zinc-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>{language === 'ar' ? 'حماية الذاكرة من الحذف التلقائي' : 'Persistent Storage Protection'}</span>
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400">
                    {isStoragePersisted ? (language === 'ar' ? 'محمي ومثبت' : 'Persisted') : (language === 'ar' ? 'مفعل' : 'Active')}
                  </span>
                </div>
                <p className="text-[10px] text-zinc-400 leading-relaxed">
                  {language === 'ar'
                    ? 'يتم تخزين بيانات العملاء وإعدادات التمويل في الذاكرة الدائمة لهاتفك، ولا يتم حذفها عند إغلاق المتصفح أو انقطاع الإنترنت.'
                    : 'Customer records and finance rates are permanently stored in your device storage and persist through reboots.'}
                </p>
              </div>

              {/* PWA Direct Installation Prompt if available */}
              {isInstallable && (
                <div className="bg-sky-950/30 border border-sky-500/30 rounded-2xl p-3.5 space-y-2">
                  <div className="text-xs font-bold text-sky-200 flex items-center gap-1.5">
                    <DownloadCloud className="w-4 h-4 text-sky-400" />
                    <span>{language === 'ar' ? 'تثبيت التطبيق على الشاشة الرئيسية' : 'Install PWA to Home Screen'}</span>
                  </div>
                  <p className="text-[10px] text-zinc-400">
                    {language === 'ar'
                      ? 'ثبّت التطبيق كأيقونة على الجوال لفتحه بلمسة واحدة وبشاشة كاملة دون شريط المتصفح وبأعلى سرعة.'
                      : 'Install as a standalone app to launch instantly without browser bars.'}
                  </p>
                  <button
                    onClick={() => {
                      install();
                      setShowHealthModal(false);
                    }}
                    className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-bold text-xs shadow-lg shadow-sky-600/30 transition-all active:scale-95 flex items-center justify-center gap-1.5"
                  >
                    <span>📲</span>
                    <span>{language === 'ar' ? 'تثبيت التطبيق الآن على الجوال' : 'Install App on Phone'}</span>
                  </button>
                </div>
              )}

              {/* iOS instructions */}
              {isIOS && (
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-3 text-[11px] space-y-1 text-zinc-300">
                  <div className="font-bold text-white flex items-center gap-1">
                    <span>🍎</span>
                    <span>{language === 'ar' ? 'طريقة التثبيت على أجهزة iPhone / iPad:' : 'Install on iPhone / iPad:'}</span>
                  </div>
                  <p className="text-zinc-400 text-[10px] leading-relaxed">
                    {language === 'ar'
                      ? '1. اضغط على زر المشاركة (Share) أسفل متصفح سفاري.\n2. اختر «إضافة إلى الشاشة الرئيسية» (Add to Home Screen).'
                      : 'Tap the Share button in Safari toolbar, then tap "Add to Home Screen".'}
                  </p>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-zinc-800">
              <button
                onClick={() => setShowHealthModal(false)}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-bold text-xs transition"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
