import React from 'react';
import { useAuth, useCurrentPage } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { LayoutDashboard, Users, BarChart3, Bell, Settings } from 'lucide-react';
import type { PageView } from '../types';
import { triggerHaptic } from '../utils/haptics';

export const BottomNav: React.FC = React.memo(() => {
  const { setCurrentPage, smartAlertsCount } = useAuth();
  const currentPage = useCurrentPage();
  const { t, formatNumber } = useLanguage();

  const navItems: { page: PageView; labelKey: string; icon: React.ReactNode; badge?: number }[] = [
    { page: 'dashboard', labelKey: 'home', icon: <LayoutDashboard className="w-5 h-5" /> },
    { page: 'customers', labelKey: 'customers', icon: <Users className="w-5 h-5" /> },
    { page: 'reports', labelKey: 'reports', icon: <BarChart3 className="w-5 h-5" /> },
    {
      page: 'reminders',
      labelKey: 'notifications',
      icon: <Bell className="w-5 h-5" />,
      badge: smartAlertsCount
    },
    { page: 'settings', labelKey: 'settings', icon: <Settings className="w-5 h-5" /> }
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 w-full max-w-full overflow-x-clip bg-[#0a1628]/95 backdrop-blur-xl border-t border-sky-500/20 shadow-2xl shadow-sky-950/80 select-none no-print">
      <div className="w-full max-w-md sm:max-w-lg md:max-w-2xl mx-auto px-1.5 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] flex items-center justify-between gap-0.5 min-w-0">
        {navItems.map((item) => {
          const isActive = currentPage === item.page;
          return (
            <button
              key={item.page}
              onClick={() => {
                triggerHaptic('light');
                setCurrentPage(item.page);
              }}
              className={`relative flex-1 min-w-0 min-h-[48px] flex flex-col items-center justify-center gap-1 py-1 px-1 rounded-2xl transition-transform duration-150 active:scale-90 ${
                isActive
                  ? 'text-sky-300 font-black'
                  : 'text-slate-400 hover:text-sky-200 font-medium'
              }`}
            >
              <div className={`relative p-1.5 rounded-xl transition-colors ${isActive ? 'bg-sky-500/20 shadow-inner border border-sky-400/30' : ''}`}>
                {item.icon}
                {!!item.badge && item.badge > 0 && (
                  <span className="absolute -top-1 -right-1.5 flex items-center justify-center min-w-[17px] h-[17px] px-1 bg-amber-400 text-slate-950 font-extrabold text-[9px] font-mono tabular-nums rounded-full shadow-md">
                    {item.badge > 99 ? '99+' : formatNumber(item.badge)}
                  </span>
                )}
              </div>
              <span className="text-[10px] leading-tight truncate max-w-full px-0.5">{t(item.labelKey)}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
});

