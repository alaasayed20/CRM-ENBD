import React, { useState, useEffect, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { 
  X, Percent, Save, RotateCcw, Shield, Landmark, Building, Globe, 
  Sparkles, CheckCircle2, Calculator, Info, Check, ArrowRight
} from 'lucide-react';
import { db, logOperation } from '../db/db';
import { 
  DEFAULT_PERSONAL_FINANCE_RATES, 
  getStoredPersonalFinanceRates, 
  setStoredPersonalFinanceRates, 
  calculatePersonalFinanceRate,
  type PersonalFinanceRatesConfig 
} from '../utils/finance';
import { triggerHaptic } from '../utils/haptics';
import { useToast } from './Toast';
import { useLanguage } from '../context/LanguageContext';
import { ConfirmModal } from './ConfirmModal';
import type { User } from '../types';

interface PersonalFinanceRatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: User | null;
}

export const PersonalFinanceRatesModal: React.FC<PersonalFinanceRatesModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const { language, dir, t } = useLanguage();
  const { showToast } = useToast();

  // Query live settings from DB
  const liveRatesSetting = useLiveQuery(() => db.settings.get('personalFinanceRates'));

  // Local draft state for editing
  const [ratesConfig, setRatesConfig] = useState<PersonalFinanceRatesConfig>(() => {
    return getStoredPersonalFinanceRates();
  });

  const [activeTab, setActiveTab] = useState<'quick' | 'saudiStl' | 'expatStl' | 'nstl' | 'military' | 'simulator'>('quick');
  const [isSaving, setIsSaving] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Simulator Test States
  const [simMilitary, setSimMilitary] = useState(false);
  const [simMilitaryType, setSimMilitaryType] = useState<'stl' | 'nstl'>('stl');
  const [simTransfer, setSimTransfer] = useState(true);
  const [simNationality, setSimNationality] = useState<'saudi' | 'expat'>('saudi');
  const [simCategory, setSimCategory] = useState<'A' | 'B' | 'C_D_E' | 'NALE'>('A');
  const [simApproved, setSimApproved] = useState(true);
  const [simSalary, setSimSalary] = useState(15000);
  const [simLoanAmount, setSimLoanAmount] = useState(100000);

  // Synchronize with database or stored rates on mount or update
  useEffect(() => {
    if (liveRatesSetting?.value) {
      setRatesConfig(prev => ({
        ...DEFAULT_PERSONAL_FINANCE_RATES,
        ...prev,
        ...liveRatesSetting.value,
        saudiStl: {
          ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl,
          ...(prev.saudiStl || {}),
          ...(liveRatesSetting.value.saudiStl || {}),
        },
        expatStl: {
          ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl,
          ...(prev.expatStl || {}),
          ...(liveRatesSetting.value.expatStl || {}),
        }
      }));
    }
  }, [liveRatesSetting]);

  // Compute live test simulation using the current uncommitted/committed rates!
  const simResult = useMemo(() => {
    return calculatePersonalFinanceRate({
      isMilitary: simMilitary,
      militaryType: simMilitaryType,
      hasSalaryTransfer: simTransfer,
      nationality: simNationality,
      companyCategory: simCategory,
      isApprovedEmployer: simApproved,
      salary: simSalary,
      loanAmount: simLoanAmount,
    }, ratesConfig);
  }, [simMilitary, simMilitaryType, simTransfer, simNationality, simCategory, simApproved, simSalary, simLoanAmount, ratesConfig]);

  if (!isOpen) return null;

  // Generic helper to update nested rates
  const handleRateChange = (field: keyof PersonalFinanceRatesConfig, value: string | number) => {
    const num = parseFloat(String(value));
    if (isNaN(num)) return;
    setRatesConfig(prev => ({
      ...prev,
      [field]: num,
    }));
  };

  const handleSaudiStlChange = (
    tierKey: keyof PersonalFinanceRatesConfig['saudiStl'],
    cat: 'A' | 'B' | 'C_D_E' | 'NALE',
    value: string | number
  ) => {
    const num = parseFloat(String(value));
    if (isNaN(num)) return;
    setRatesConfig(prev => ({
      ...prev,
      saudiStl: {
        ...prev.saudiStl,
        [tierKey]: {
          ...prev.saudiStl[tierKey],
          [cat]: num,
        }
      }
    }));
  };

  const handleExpatStlChange = (
    tierKey: keyof PersonalFinanceRatesConfig['expatStl'],
    cat: 'A' | 'B' | 'C_D_E' | 'NALE',
    value: string | number
  ) => {
    const num = parseFloat(String(value));
    if (isNaN(num)) return;
    setRatesConfig(prev => ({
      ...prev,
      expatStl: {
        ...prev.expatStl,
        [tierKey]: {
          ...prev.expatStl[tierKey],
          [cat]: num,
        }
      }
    }));
  };

  // Save changes to Dexie and localStorage and broadcast instant link
  const handleSave = async () => {
    try {
      setIsSaving(true);
      triggerHaptic('medium');

      // 1. Update Dexie db.settings
      await db.settings.put({
        key: 'personalFinanceRates',
        value: ratesConfig,
      });

      // 2. Update localStorage and broadcast window event for instant zero-latency link
      setStoredPersonalFinanceRates(ratesConfig);

      // 3. Log the operation in the audit trail
      await logOperation(
        'UPDATE_FINANCE_RATES',
        'settings',
        0,
        null,
        ratesConfig,
        currentUser?.id
      );

      triggerHaptic('success');
      showToast(
        language === 'ar'
          ? 'تم حفظ وتحديث نسب التمويل الشخصي بنجاح وربطها فوراً بالنظام 💰✅'
          : 'Personal finance rates saved and linked to system instantly 💰✅',
        'success'
      );
      onClose();
    } catch (err) {
      console.error('Save finance rates error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء حفظ نسب التمويل' : 'Error saving finance rates', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to default rates
  const handleResetToDefaults = async () => {
    try {
      setRatesConfig(DEFAULT_PERSONAL_FINANCE_RATES);
      await db.settings.put({
        key: 'personalFinanceRates',
        value: DEFAULT_PERSONAL_FINANCE_RATES,
      });
      setStoredPersonalFinanceRates(DEFAULT_PERSONAL_FINANCE_RATES);
      setShowResetConfirm(false);
      triggerHaptic('warning');
      showToast(
        language === 'ar'
          ? 'تمت استعادة نسب التمويل الافتراضية المعتمدة بنجاح 🔄'
          : 'Default finance rates restored successfully 🔄',
        'info'
      );
    } catch (err) {
      console.error('Reset finance rates error:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء استعادة النسب' : 'Error resetting finance rates', 'error');
    }
  };

  const saudiTiersList: { key: keyof PersonalFinanceRatesConfig['saudiStl']; label: string; desc: string }[] = [
    { key: 'tier_50k_plus', label: '50,000 ر.س فأكثر', desc: 'شريحة الدخل المرتفع النخبوية' },
    { key: 'tier_40k_50k', label: '40,000 - 49,999 ر.س', desc: 'شريحة الدخل المميز' },
    { key: 'tier_25k_40k', label: '25,000 - 39,999 ر.س', desc: 'شريحة الدخل المتوسط المرتفع' },
    { key: 'tier_15k_25k', label: '15,000 - 24,999 ر.س', desc: 'شريحة الدخل المتوسط' },
    { key: 'tier_below_15k', label: 'أقل من 15,000 ر.س', desc: 'شريحة الدخل الأساسي' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn" dir={dir}>
      <div className="bg-[#071325] border border-emerald-500/30 rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Modal Header */}
        <div className="p-4 bg-gradient-to-r from-[#0c291d] via-[#091f17] to-[#071325] border-b border-emerald-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-300 rounded-2xl border border-emerald-400/30">
              <Percent className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>{language === 'ar' ? 'نسب التمويل الشخصي ومعدلات المرابحة' : 'Personal Finance Rates & Margins'}</span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono rounded-full border border-emerald-400/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {language === 'ar' ? 'ربط فوري' : 'Instant Link'}
                </span>
              </h2>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                {language === 'ar' 
                  ? 'تعديل هوامش الربح السنوية وشجرة القرارات مع التحديث المباشر فور الحفظ في كافة الحسابات والصفحات' 
                  : 'Update personal finance profit margins and decision tree with immediate live syncing'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-900/80 border border-zinc-800 hover:border-zinc-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-4 pt-3 pb-1 bg-[#09172e]/60 border-b border-zinc-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('quick')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'quick'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                : 'bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span>⚡ {language === 'ar' ? 'النسب الأساسية والسريعة' : 'Quick Base Rates'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('saudiStl')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'saudiStl'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                : 'bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span>🇸🇦 {language === 'ar' ? 'تحويل راتب (سعودي)' : 'Saudi (STL)'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('expatStl')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'expatStl'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                : 'bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span>🌐 {language === 'ar' ? 'تحويل راتب (مقيم)' : 'Expat (STL)'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('nstl')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'nstl'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                : 'bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span>💼 {language === 'ar' ? 'بدون تحويل راتب (NSTL)' : 'No Salary Transfer (NSTL)'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('military')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'military'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20'
                : 'bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
            }`}
          >
            <span>🛡️ {language === 'ar' ? 'القطاع العسكري' : 'Military Sector'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'simulator'
                ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20'
                : 'bg-zinc-900/90 text-sky-400 hover:text-sky-300 border border-sky-500/30'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'اختبار ومحاكاة الشجرة 🧮' : 'Live Simulator 🧮'}</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          
          {/* 1. Quick Base Rates */}
          {activeTab === 'quick' && (
            <div className="space-y-4">
              <div className="bg-emerald-950/20 border border-emerald-500/20 p-3.5 rounded-2xl flex items-start gap-2.5">
                <Info className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-xs text-emerald-200/90 leading-relaxed font-bold">
                  {language === 'ar'
                    ? '💡 هذه النسب السريعة تمثل الهوامش العامة التي تظهر تلقائياً في شاشات إضافة وتعديل العملاء وتحدد القيم الأساسية.'
                    : '💡 These quick rates represent general default values applied automatically across customer entry and editing forms.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 focus-within:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-extrabold text-zinc-200 flex items-center gap-1.5">
                      <span>🏦 {language === 'ar' ? 'النسبة الافتراضية السريعة لتحويل الراتب (STL)' : 'Default STL Rate'}</span>
                    </label>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono">
                      {ratesConfig.quickDefaultStl}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={ratesConfig.quickDefaultStl}
                      onChange={(e) => handleRateChange('quickDefaultStl', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-emerald-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold">%</span>
                  </div>
                </div>

                <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 focus-within:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-extrabold text-zinc-200 flex items-center gap-1.5">
                      <span>💼 {language === 'ar' ? 'النسبة الافتراضية السريعة بدون تحويل (NSTL)' : 'Default NSTL Rate'}</span>
                    </label>
                    <span className="text-[10px] text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-full border border-sky-500/20 font-mono">
                      {ratesConfig.quickDefaultNstl}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={ratesConfig.quickDefaultNstl}
                      onChange={(e) => handleRateChange('quickDefaultNstl', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-sky-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold">%</span>
                  </div>
                </div>

                <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 focus-within:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-extrabold text-zinc-200 flex items-center gap-1.5">
                      <span>🛡️ {language === 'ar' ? 'القطاع العسكري - تحويل راتب (STL)' : 'Military STL Rate'}</span>
                    </label>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono">
                      {ratesConfig.militaryStl}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={ratesConfig.militaryStl}
                      onChange={(e) => handleRateChange('militaryStl', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-emerald-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold">%</span>
                  </div>
                </div>

                <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 focus-within:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-extrabold text-zinc-200 flex items-center gap-1.5">
                      <span>🛡️ {language === 'ar' ? 'القطاع العسكري - بدون تحويل راتب (NSTL)' : 'Military NSTL Rate'}</span>
                    </label>
                    <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20 font-mono">
                      {ratesConfig.militaryNstl}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={ratesConfig.militaryNstl}
                      onChange={(e) => handleRateChange('militaryNstl', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-amber-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold">%</span>
                  </div>
                </div>

                <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 focus-within:border-emerald-400 transition-all sm:col-span-2">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-extrabold text-zinc-200 flex items-center gap-1.5">
                      <span>🌟 {language === 'ar' ? 'تمويل مليون ريال فأكثر بدون تحويل راتب (سعودي معتمد)' : 'Million+ Loan NSTL (Saudi Approved)'}</span>
                    </label>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-mono">
                      {ratesConfig.saudiNstlApprovedMillion}%
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={ratesConfig.saudiNstlApprovedMillion}
                      onChange={(e) => handleRateChange('saudiNstlApprovedMillion', e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-emerald-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                    />
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 text-sm font-bold">%</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. Saudi STL Matrix */}
          {activeTab === 'saudiStl' && (
            <div className="space-y-4">
              <div className="bg-zinc-900/90 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                    <span>🇸🇦 مصفوفة نسب تحويل الراتب للسعوديين (Salary Assigned STL)</span>
                  </h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    تتحدد النسبة آلياً حسب شريحة الراتب وتصنيف جهة العمل (A, B, C-D-E, NALE).
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {saudiTiersList.map((tier) => (
                  <div key={tier.key} className="bg-zinc-900/80 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-emerald-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        {tier.label}
                      </span>
                      <span className="text-[10px] text-zinc-400">{tier.desc}</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {/* Cat A */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          حكومي / شبه / خاص (أ)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.saudiStl[tier.key].A}
                            onChange={(e) => handleSaudiStlChange(tier.key, 'A', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* Cat B */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          خاص معتمد (ب)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.saudiStl[tier.key].B}
                            onChange={(e) => handleSaudiStlChange(tier.key, 'B', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* Cat C_D_E */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          خاص (ج - د - هـ)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.saudiStl[tier.key].C_D_E}
                            onChange={(e) => handleSaudiStlChange(tier.key, 'C_D_E', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* NALE */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          غير معتمد (NALE)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.saudiStl[tier.key].NALE}
                            onChange={(e) => handleSaudiStlChange(tier.key, 'NALE', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. Expat STL Matrix */}
          {activeTab === 'expatStl' && (
            <div className="space-y-4">
              <div className="bg-zinc-900/90 p-3 rounded-2xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                    <span>🌐 مصفوفة نسب تحويل الراتب للمقيمين (Expat STL)</span>
                  </h4>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    تتحدد النسبة آلياً حسب شريحة الراتب وتصنيف جهة العمل (A, B, C-D-E, NALE).
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {saudiTiersList.map((tier) => (
                  <div key={tier.key} className="bg-zinc-900/80 p-3.5 rounded-2xl border border-zinc-800/80 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-sky-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-sky-400" />
                        {tier.label}
                      </span>
                      <span className="text-[10px] text-zinc-400">{tier.desc}</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {/* Cat A */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          حكومي / شبه / خاص (أ)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.expatStl[tier.key].A}
                            onChange={(e) => handleExpatStlChange(tier.key, 'A', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* Cat B */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          خاص معتمد (ب)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.expatStl[tier.key].B}
                            onChange={(e) => handleExpatStlChange(tier.key, 'B', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* Cat C_D_E */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          خاص (ج - د - هـ)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.expatStl[tier.key].C_D_E}
                            onChange={(e) => handleExpatStlChange(tier.key, 'C_D_E', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>

                      {/* NALE */}
                      <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-800">
                        <label className="block text-[10px] font-bold text-zinc-400 mb-1">
                          غير معتمد (NALE)
                        </label>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            value={ratesConfig.expatStl[tier.key].NALE}
                            onChange={(e) => handleExpatStlChange(tier.key, 'NALE', e.target.value)}
                            className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-1.5 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. Without Salary Transfer (NSTL) */}
          {activeTab === 'nstl' && (
            <div className="space-y-4">
              {/* Approved Employer */}
              <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 space-y-3">
                <h4 className="text-xs font-extrabold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>1. جهة العمل المعتمدة (Approved Employer)</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: 25,000 ر.س فأكثر
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlApproved_25k}
                        onChange={(e) => handleRateChange('saudiNstlApproved_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: 15,000 - 24,999 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlApproved_15k_25k}
                        onChange={(e) => handleRateChange('saudiNstlApproved_15k_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: أقل من 15,000 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlApproved_below_15k}
                        onChange={(e) => handleRateChange('saudiNstlApproved_below_15k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-emerald-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  {/* Expat Approved */}
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: 25,000 ر.س فأكثر
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlApproved_25k}
                        onChange={(e) => handleRateChange('expatNstlApproved_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: 15,000 - 24,999 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlApproved_15k_25k}
                        onChange={(e) => handleRateChange('expatNstlApproved_15k_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: أقل من 15,000 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlApproved_below_15k}
                        onChange={(e) => handleRateChange('expatNstlApproved_below_15k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-sky-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Non-Approved Employer */}
              <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 space-y-3">
                <h4 className="text-xs font-extrabold text-amber-400 flex items-center gap-1.5">
                  <Building className="w-4 h-4" />
                  <span>2. جهة العمل غير المعتمدة (Non-Approved Employer)</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: 25,000 ر.س فأكثر
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlNonApproved_25k}
                        onChange={(e) => handleRateChange('saudiNstlNonApproved_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-amber-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: 15,000 - 24,999 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlNonApproved_15k_25k}
                        onChange={(e) => handleRateChange('saudiNstlNonApproved_15k_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-amber-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🇸🇦 سعودي: أقل من 15,000 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.saudiNstlNonApproved_below_15k}
                        onChange={(e) => handleRateChange('saudiNstlNonApproved_below_15k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-amber-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  {/* Expat Non-Approved */}
                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: 25,000 ر.س فأكثر
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlNonApproved_25k}
                        onChange={(e) => handleRateChange('expatNstlNonApproved_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-rose-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: 15,000 - 24,999 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlNonApproved_15k_25k}
                        onChange={(e) => handleRateChange('expatNstlNonApproved_15k_25k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-rose-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800">
                    <label className="block text-[10px] font-bold text-zinc-300 mb-1">
                      🌐 مقيم: أقل من 15,000 ر.س
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.expatNstlNonApproved_below_15k}
                        onChange={(e) => handleRateChange('expatNstlNonApproved_below_15k', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 pr-2 pl-6 text-xs font-mono font-bold text-rose-300 dir-ltr text-right"
                      />
                      <span className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500 text-xs">%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 5. Military Sector */}
          {activeTab === 'military' && (
            <div className="space-y-4">
              <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 space-y-3">
                <h4 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span>نسب تمويل منسوبي القطاع العسكري 🛡️</span>
                </h4>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  يتميز القطاع العسكري بمسار مباشر في شجرة القرارات بنسبتين ثابتتين: بتحويل راتب أو بدون تحويل راتب.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                  <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800">
                    <label className="block text-xs font-extrabold text-emerald-300 mb-2">
                      تحويل راتب (Military STL)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.militaryStl}
                        onChange={(e) => handleRateChange('militaryStl', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-emerald-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                      />
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-bold">%</span>
                    </div>
                  </div>

                  <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800">
                    <label className="block text-xs font-extrabold text-amber-300 mb-2">
                      بدون تحويل راتب (Military NSTL)
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        value={ratesConfig.militaryNstl}
                        onChange={(e) => handleRateChange('militaryNstl', e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-3 pr-3 pl-8 text-amber-300 font-mono font-black text-sm dir-ltr text-right focus:outline-none focus:border-emerald-400"
                      />
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-bold">%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 6. Live Decision Simulator */}
          {activeTab === 'simulator' && (
            <div className="space-y-4">
              <div className="bg-sky-950/30 border border-sky-500/30 p-3.5 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-extrabold text-white flex items-center gap-1.5">
                    <Calculator className="w-4 h-4 text-sky-400" />
                    <span>محاكي شجرة القرارات المباشر (Live Decision Sandbox)</span>
                  </h4>
                  <p className="text-[11px] text-sky-200/80 mt-0.5">
                    قم بتغيير المعطيات أدناه لمشاهدة النتيجة الفورية بالاعتماد على الأرقام الحالية قبل أو بعد الحفظ!
                  </p>
                </div>
              </div>

              {/* Simulation Controls */}
              <div className="bg-zinc-900/90 p-4 rounded-2xl border border-zinc-800 space-y-3.5">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {/* Military Toggle */}
                  <button
                    type="button"
                    onClick={() => setSimMilitary(!simMilitary)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                      simMilitary ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400' : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    🛡️ {simMilitary ? 'قطاع عسكري' : 'قطاع مدني'}
                  </button>

                  {/* Transfer Toggle */}
                  <button
                    type="button"
                    onClick={() => setSimTransfer(!simTransfer)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                      simTransfer ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400' : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    🏦 {simTransfer ? 'بتحويل راتب' : 'بدون تحويل'}
                  </button>

                  {/* Nationality Toggle */}
                  <button
                    type="button"
                    onClick={() => setSimNationality(simNationality === 'saudi' ? 'expat' : 'saudi')}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                      simNationality === 'saudi' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400' : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    {simNationality === 'saudi' ? '🇸🇦 سعودي' : '🌐 مقيم'}
                  </button>

                  {/* Employer Category / Approval */}
                  {simTransfer ? (
                    <select
                      value={simCategory}
                      onChange={(e) => setSimCategory(e.target.value as any)}
                      className="bg-zinc-950 border border-zinc-800 text-xs text-amber-300 font-bold rounded-xl p-2.5 focus:outline-none focus:border-amber-400"
                    >
                      <option value="A">تصنيف (A) حكومي وخاص أ</option>
                      <option value="B">تصنيف (B) خاص ب</option>
                      <option value="C_D_E">تصنيف (C-D-E) خاص</option>
                      <option value="NALE">تصنيف (NALE) غير معتمد</option>
                    </select>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setSimApproved(!simApproved)}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                        simApproved ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400' : 'bg-zinc-950 text-rose-300 border-zinc-800'
                      }`}
                    >
                      {simApproved ? '✅ جهة معتمدة' : '❌ جهة غير معتمدة'}
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">الراتب الشهري (ر.س)</label>
                    <input
                      type="number"
                      value={simSalary}
                      onChange={(e) => setSimSalary(parseFloat(e.target.value) || 0)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono font-bold dir-ltr text-right"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-zinc-400 mb-1">مبلغ التمويل المطلوب (ر.س)</label>
                    <input
                      type="number"
                      value={simLoanAmount}
                      onChange={(e) => setSimLoanAmount(parseFloat(e.target.value) || 0)}
                      className="w-full bg-zinc-950 border border-zinc-700 rounded-xl p-2.5 text-xs text-white font-mono font-bold dir-ltr text-right"
                    />
                  </div>
                </div>

                {/* Simulation Output Card */}
                <div className="bg-gradient-to-r from-emerald-950/40 via-[#0d2319] to-zinc-950 p-4 rounded-2xl border-2 border-emerald-500/40 flex items-center justify-between shadow-lg">
                  <div>
                    <div className="text-[11px] font-bold text-emerald-300 mb-1 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{simResult.reason}</span>
                    </div>
                    <div className="text-xs text-zinc-300 font-mono">
                      الشريحة المحددة: <span className="text-emerald-400 font-bold">{simResult.tierLabel}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-2xl font-black text-emerald-400 font-mono">
                      {simResult.rate}%
                    </div>
                    <div className="text-[10px] text-zinc-400 font-bold">
                      نسبة المرابحة الناتجة
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-zinc-950/90 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setShowResetConfirm(true)}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-zinc-700 bg-zinc-900 text-zinc-400 hover:text-zinc-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>{language === 'ar' ? 'استعادة النسب الافتراضية الرسمية' : 'Reset to Official Defaults'}</span>
          </button>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-bold transition-colors"
            >
              {language === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? (language === 'ar' ? 'جاري الحفظ والربط...' : 'Saving...') : (language === 'ar' ? 'حفظ التغييرات واعتماد النسب فوراً' : 'Save & Link Instantly')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <ConfirmModal
          isOpen={showResetConfirm}
          title={language === 'ar' ? 'استعادة النسب الافتراضية' : 'Reset to Default Rates'}
          message={language === 'ar' 
            ? 'هل أنت متأكد من رغبتك في استعادة جدول نسب التمويل الافتراضي الرسمي المعتمد؟ سيتم تحديث كافة المعدلات فوراً.' 
            : 'Are you sure you want to reset all personal finance rates back to official system defaults?'}
          confirmText={language === 'ar' ? 'نعم، استعادة الافتراضي 🔄' : 'Yes, Reset Defaults 🔄'}
          cancelText={language === 'ar' ? 'إلغاء' : 'Cancel'}
          isDanger={false}
          onConfirm={handleResetToDefaults}
          onCancel={() => setShowResetConfirm(false)}
        />
      )}
    </div>
  );
};
