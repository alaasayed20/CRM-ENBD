import React, { useState, useMemo, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/db';
import { useToast } from '../components/Toast';
import { formatPhone, useLanguage } from '../context/LanguageContext';
import { getStatusTranslation } from '../utils/translations';
import { X, Sliders, FileSpreadsheet, FileText, CheckSquare, Square, Search, Filter, RefreshCw, Loader2 } from 'lucide-react';
import type { Customer, CustomerStatus } from '../types';
import { useAuth } from '../context/AuthContext';
import { exportReportToPDF, type PdfAccent, type PdfCell, type PdfSummaryCard } from '../utils/pdfExport';
import { sanitizeSpreadsheetValue } from '../utils/security';
import { saveWorkbookNativeOrWeb } from '../utils/nativeMobile';

interface CustomReportBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStatusFilter?: string;
}

interface ColumnOption {
  key: string;
  label: string;
  defaultSelected: boolean;
}

const ALL_STATUSES: CustomerStatus[] = ['عميل محتمل', 'عميل معلق', 'تم التنفيذ', 'تم التفعيل'];

export const CustomReportBuilderModal: React.FC<CustomReportBuilderModalProps> = ({ isOpen, onClose, initialStatusFilter }) => {
  const { showToast } = useToast();
  const { t, language, dir, formatCurrency, formatNumber } = useLanguage();
  const { settings } = useAuth();
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);

  const availableColumns: ColumnOption[] = useMemo(() => [
    { key: 'name', label: t('clientFullName', 'اسم العميل'), defaultSelected: true },
    { key: 'phone', label: t('phoneNumber', 'رقم الجوال'), defaultSelected: true },
    { key: 'idNumber', label: t('nationalId', 'رقم الهوية'), defaultSelected: true },
    { key: 'email', label: t('emailOptional', 'البريد الإلكتروني'), defaultSelected: false },
    { key: 'orderNumber', label: t('orderNumberOptional', 'رقم الطلب'), defaultSelected: true },
    { key: 'productType', label: t('productType', 'نوع المنتج'), defaultSelected: true },
    { key: 'cardType', label: t('cardType', 'نوع البطاقة'), defaultSelected: true },
    { key: 'financeType', label: t('financeType', 'نوع التمويل'), defaultSelected: true },
    { key: 'financeRate', label: t('financeProfitRate', 'نسبة التمويل %'), defaultSelected: false },
    { key: 'salary', label: t('salaryMonthly', 'الراتب (ر.س)'), defaultSelected: true },
    { key: 'amount', label: t('amount', 'مبلغ التمويل (ر.س)'), defaultSelected: true },
    { key: 'points', label: t('points', 'النقاط'), defaultSelected: true },
    { key: 'status', label: t('clientStatus', 'حالة الطلب'), defaultSelected: true },
    { key: 'salesRep', label: t('salesRepInCharge', 'موظف المبيعات'), defaultSelected: true },
    { key: 'createdAt', label: t('createdAt', 'تاريخ الإضافة'), defaultSelected: true },
    { key: 'notes', label: t('notes', 'الملاحظات'), defaultSelected: false },
  ], [t]);

  // Load data from DB
  const customers = useLiveQuery(() => db.customers.toArray(), []) || [];
  const cardTypes = useLiveQuery(() => db.cardTypes.toArray(), []) || [];
  const users = useLiveQuery(() => db.users.toArray(), []) || [];

  // Filter States
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | 'all'>('all');
  const [productTypeFilter, setProductTypeFilter] = useState<'all' | 'visa' | 'finance'>('all');
  const [financeTypeFilter, setFinanceTypeFilter] = useState<'all' | 'salary_transfer' | 'no_salary_transfer'>('all');
  const [selectedCardTypeIds, setSelectedCardTypeIds] = useState<number[]>([]);
  const [selectedStatuses, setSelectedStatuses] = useState<CustomerStatus[]>([]);
  const [minSalary, setMinSalary] = useState<string>('');
  const [maxSalary, setMaxSalary] = useState<string>('');
  const [fromDate, setFromDate] = useState<string>('');
  const [toDate, setToDate] = useState<string>('');
  const [salesRepFilter, setSalesRepFilter] = useState<number | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Column Selector State
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    'name', 'phone', 'idNumber', 'orderNumber', 'productType', 'cardType', 'financeType', 'salary', 'amount', 'points', 'status', 'salesRep', 'createdAt'
  ]);

  // Manual Customer Exclusion/Selection State
  const [excludedCustomerIds, setExcludedCustomerIds] = useState<number[]>([]);

  useEffect(() => {
    if (isOpen) {
      if (initialStatusFilter && initialStatusFilter !== 'all') {
        setSelectedStatuses([initialStatusFilter as CustomerStatus]);
      } else {
        setSelectedStatuses([]);
      }
      setExcludedCustomerIds([]);
    }
  }, [isOpen, initialStatusFilter]);

  if (!isOpen) return null;

  // Helper map for card type names
  const cardTypeMap = new Map(cardTypes.map(ct => [ct.id, ct.name]));
  const userMap = new Map(users.map(u => [u.id, u.username]));

  // Compute matching customers based on filters
  const matchingCustomers = customers.filter(c => {
    // Specific Customer Filter
    if (selectedCustomerId !== 'all') {
      if (c.id !== Number(selectedCustomerId)) return false;
    }

    // Search Term
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchName = c.name?.toLowerCase().includes(term);
      const matchPhone = c.phone?.includes(term);
      const matchId = c.idNumber?.toLowerCase().includes(term);
      const matchOrder = c.orderNumber?.toLowerCase().includes(term);
      if (!matchName && !matchPhone && !matchId && !matchOrder) return false;
    }

    // Product Type Filter
    if (productTypeFilter !== 'all' && c.productType !== productTypeFilter) {
      return false;
    }

    // Finance Type Filter (if finance or all)
    if (financeTypeFilter !== 'all') {
      if (c.productType === 'finance') {
        const isNoTransfer = c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب';
        if (financeTypeFilter === 'no_salary_transfer' && !isNoTransfer) return false;
        if (financeTypeFilter === 'salary_transfer' && isNoTransfer) return false;
      }
    }

    // Card Type Filter (if card types selected)
    if (selectedCardTypeIds.length > 0) {
      if (c.productType === 'visa') {
        if (!c.cardTypeId || !selectedCardTypeIds.includes(c.cardTypeId)) return false;
      }
    }

    // Status Filter (strict exact match, never merging executed & activated)
    if (selectedStatuses.length > 0) {
      const normalizedStatus = (c.status || '').trim() as CustomerStatus;
      if (!selectedStatuses.includes(normalizedStatus)) return false;
    }

    // Salary / Amount Filter
    const valSalary = c.salary || (c.productType === 'finance' ? c.amount : 0) || 0;
    if (minSalary && valSalary < Number(minSalary)) return false;
    if (maxSalary && valSalary > Number(maxSalary)) return false;

    // Date Range Filter
    if (fromDate) {
      const cDate = new Date(c.createdAt).setHours(0, 0, 0, 0);
      const fDate = new Date(fromDate).setHours(0, 0, 0, 0);
      if (cDate < fDate) return false;
    }
    if (toDate) {
      const cDate = new Date(c.createdAt).setHours(23, 59, 59, 999);
      const tDate = new Date(toDate).setHours(23, 59, 59, 999);
      if (cDate > tDate) return false;
    }

    // Sales Rep Filter
    if (salesRepFilter !== 'all') {
      if (c.salesRepId !== Number(salesRepFilter)) return false;
    }

    return true;
  });

  // Final selected customers (excluding manually unselected ones)
  const finalSelectedCustomers = matchingCustomers.filter(c => c.id && !excludedCustomerIds.includes(c.id));

  // Toggle card type selection
  const toggleCardType = (id: number) => {
    setSelectedCardTypeIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Toggle status selection
  const toggleStatus = (status: CustomerStatus) => {
    setSelectedStatuses(prev =>
      prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
    );
  };

  // Toggle column selection
  const toggleColumn = (key: string) => {
    if (selectedColumns.includes(key)) {
      if (selectedColumns.length <= 1) {
        showToast('يجب إبقاء عمود واحد على الأقل', 'warning');
        return;
      }
      setSelectedColumns(prev => prev.filter(k => k !== key));
    } else {
      setSelectedColumns(prev => [...prev, key]);
    }
  };

  // Select all or unselect all customers
  const handleSelectAllCustomers = () => {
    if (excludedCustomerIds.length > 0) {
      setExcludedCustomerIds([]);
    } else {
      setExcludedCustomerIds(matchingCustomers.map(c => c.id!).filter(Boolean));
    }
  };

  const toggleCustomerExclusion = (id: number) => {
    setExcludedCustomerIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const resetFilters = () => {
    setSelectedCustomerId('all');
    setProductTypeFilter('all');
    setFinanceTypeFilter('all');
    setSelectedCardTypeIds([]);
    setSelectedStatuses([]);
    setMinSalary('');
    setMaxSalary('');
    setFromDate('');
    setToDate('');
    setSalesRepFilter('all');
    setSearchTerm('');
    setExcludedCustomerIds([]);
    showToast(t('allFiltersResetToast', 'تمت إعادة ضبط جميع الفلاتر'));
  };

  // Get cell text for a given customer and column key
  const getCellValue = (c: Customer, key: string): string => {
    switch (key) {
      case 'name': return c.name || '';
      case 'phone': return formatPhone(c.phone);
      case 'idNumber': return c.idNumber || '-';
      case 'email': return c.email || '-';
      case 'orderNumber': return c.orderNumber || '-';
      case 'productType': return c.productType === 'visa' ? (language === 'ar' ? 'بطاقة Visa' : 'Visa Card') : (language === 'ar' ? 'تمويل شخصي' : 'Personal Finance');
      case 'cardType': return c.productType === 'visa' ? (c.cardTypeId ? (cardTypeMap.get(c.cardTypeId) || '-') : '-') : '-';
      case 'financeType': return c.productType === 'finance' ? (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب' ? t('withoutSalaryTransfer', 'بدون تحويل راتب') : t('salaryTransfer', 'تحويل راتب')) : '-';
      case 'financeRate': return c.productType === 'finance' && c.financeRate ? `${formatNumber(c.financeRate)}%` : '-';
      case 'salary': return c.salary ? formatCurrency(c.salary) : '-';
      case 'amount': return c.amount ? formatCurrency(c.amount) : '-';
      case 'points': return c.points ? `${formatNumber(c.points)} ${t('pts', 'نقطة')}` : '0';
      case 'status': return getStatusTranslation(c.status, language) || '-';
      case 'salesRep': return c.salesRepId ? (userMap.get(c.salesRepId) || `${t('userRole', 'مستخدم')} #${c.salesRepId}`) : '-';
      case 'createdAt': return new Date(c.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US');
      case 'notes': return c.notes || '-';
      default: return '';
    }
  };

  // Export to Excel XLSX (loads SheetJS on demand)
  const handleExportExcel = async () => {
    if (finalSelectedCustomers.length === 0) {
      showToast(t('noMatchingExport', 'لا يوجد عملاء مطابقين للتصدير'), 'warning');
      return;
    }

    const XLSX = await import('xlsx');
    const visibleCols = availableColumns.filter(col => selectedColumns.includes(col.key));
    const headers = [t('seqNumber', 'م'), ...visibleCols.map(col => sanitizeSpreadsheetValue(col.label))];

    const rows = finalSelectedCustomers.map((c, index) => [
      index + 1,
      ...visibleCols.map(col => sanitizeSpreadsheetValue(getCellValue(c, col.key)))
    ]);

    const worksheetData = [headers, ...rows];
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    if (!worksheet['!views']) worksheet['!views'] = [];
    worksheet['!views'].push({ RTL: dir === 'rtl' });

    // Auto widths
    const colWidths = headers.map((h, i) => {
      let maxLen = String(h).length;
      rows.forEach(r => {
        const val = String(r[i] ?? '');
        if (val.length > maxLen) maxLen = val.length;
      });
      return { wch: Math.max(maxLen + 4, 12) };
    });
    worksheet['!cols'] = colWidths;

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, language === 'ar' ? 'تقرير مخصص' : 'Custom Report');

    await saveWorkbookNativeOrWeb(
      XLSX,
      workbook,
      `custom-crm-report-${new Date().toISOString().split('T')[0]}.xlsx`,
      language === 'ar' ? 'تقرير مخصص' : 'Custom Report'
    );
    showToast(t('exportSuccessExcel', 'تم تصدير {count} عميل إلى ملف Excel بنجاح 📊').replace('{count}', String(finalSelectedCustomers.length)));
  };

  const getStatusPdfAccent = (status?: string): PdfAccent => {
    const s = (status || '').trim();
    if (s === 'تم التفعيل') return 'emerald';
    if (s === 'تم التنفيذ') return 'cyan';
    if (s === 'عميل معلق') return 'amber';
    if (s === 'عميل محتمل') return 'sky';
    return 'indigo';
  };

  // Direct formatted in-app PDF export (iFrame-safe, no window.open)
  const handleExportPDF = async () => {
    if (isExportingPdf) return;
    if (finalSelectedCustomers.length === 0) {
      showToast(t('noMatchingPrint', 'لا يوجد عملاء مطابقين للتصدير'), 'warning');
      return;
    }

    const visibleCols = availableColumns.filter((col) => selectedColumns.includes(col.key));
    const singleStatus = selectedStatuses.length === 1 ? selectedStatuses[0] : null;
    const statusLabel = singleStatus
      ? getStatusTranslation(singleStatus, language)
      : selectedStatuses.length > 1
      ? selectedStatuses.map((st) => getStatusTranslation(st, language)).join(' / ')
      : language === 'ar'
      ? 'جميع الحالات (مفصولة)'
      : 'All Statuses (Separated)';
    const statusAccent: PdfAccent = singleStatus ? getStatusPdfAccent(singleStatus) : 'indigo';

    const cycleLabel =
      fromDate || toDate
        ? `${fromDate || '...'} → ${toDate || '...'}`
        : language === 'ar'
        ? 'تقرير مخصص (مفلتر)'
        : 'Custom Filtered Report';

    const execCount = finalSelectedCustomers.filter((c) => (c.status || '').trim() === 'تم التنفيذ').length;
    const actCount = finalSelectedCustomers.filter((c) => (c.status || '').trim() === 'تم التفعيل').length;
    const totalSalarySum = finalSelectedCustomers.reduce((sum, c) => sum + (Number(c.salary) || 0), 0);

    const summaryCards: PdfSummaryCard[] = singleStatus
      ? [
          { label: statusLabel, value: formatNumber(finalSelectedCustomers.length), subtext: language === 'ar' ? 'عميل محدد' : 'Selected Clients', accent: statusAccent },
          { label: t('totalFinanceSum', 'إجمالي التمويل'), value: formatCurrency(totalAmountSum), accent: 'emerald' },
          { label: t('totalSalaries', 'إجمالي الرواتب'), value: formatCurrency(totalSalarySum), accent: 'sky' },
          { label: t('totalPointsSum', 'إجمالي النقاط'), value: formatNumber(totalPointsSum), subtext: t('pts', 'نقطة'), accent: 'amber' },
        ]
      : [
          { label: `🟢 ${getStatusTranslation('تم التنفيذ', language)}`, value: formatNumber(execCount), accent: 'cyan' },
          { label: `⚡ ${getStatusTranslation('تم التفعيل', language)}`, value: formatNumber(actCount), accent: 'emerald' },
          { label: t('totalFinanceSum', 'إجمالي التمويل'), value: formatCurrency(totalAmountSum), accent: 'indigo' },
          { label: t('totalPointsSum', 'إجمالي النقاط'), value: formatNumber(totalPointsSum), subtext: t('pts', 'نقطة'), accent: 'amber' },
        ];

    const monoCols = new Set(['phone', 'idNumber', 'orderNumber', 'salary', 'amount', 'points', 'financeRate', 'createdAt']);
    const ltrCols = new Set(['phone', 'idNumber', 'orderNumber', 'email']);
    const centerCols = new Set(['phone', 'idNumber', 'orderNumber', 'salary', 'amount', 'points', 'financeRate', 'status', 'createdAt']);

    setIsExportingPdf(true);
    try {
      await exportReportToPDF({
        title: language === 'ar' ? 'التقرير المخصص للعملاء' : 'Custom Filtered Client Report',
        subtitle:
          selectedStatuses.length > 0
            ? language === 'ar'
              ? `تصفية مخصصة للحالات المختارة فقط (${statusLabel})`
              : `Custom filter applied for selected statuses (${statusLabel})`
            : undefined,
        companyName: settings?.companyName?.trim() || 'SALES CRM SYSTEM',
        cycleLabel,
        statusLabel,
        statusAccent,
        totalCountLabel: t('selectedCustomersCount', 'إجمالي العملاء'),
        totalCountValue: formatNumber(finalSelectedCustomers.length),
        dir,
        language,
        orientation: visibleCols.length >= 6 ? 'landscape' : 'portrait',
        summaryCards,
        columns: [
          { label: t('seqNumber', 'م'), align: 'center', width: '34px' },
          ...visibleCols.map((col) => ({
            label: col.label,
            align: (centerCols.has(col.key) ? 'center' : dir === 'rtl' ? 'right' : 'left') as 'center' | 'right' | 'left',
          })),
        ],
        rows: finalSelectedCustomers.map((c, idx): PdfCell[] => [
          { text: formatNumber(idx + 1), mono: true },
          ...visibleCols.map((col): PdfCell => {
            const text = getCellValue(c, col.key);
            return {
              text,
              bold: col.key === 'name' || col.key === 'amount' || col.key === 'salary',
              mono: monoCols.has(col.key),
              dir: ltrCols.has(col.key) ? 'ltr' : undefined,
              badgeAccent: col.key === 'status' ? getStatusPdfAccent(c.status) : undefined,
            };
          }),
        ]),
        footerText:
          language === 'ar'
            ? 'تم إنشاء هذا التقرير المخصص تلقائياً بواسطة نظام إدارة المبيعات Sales CRM'
            : 'This custom report was automatically generated by Sales CRM',
        fileName: `custom-crm-report-${new Date().toISOString().split('T')[0]}.pdf`,
      });

      showToast(
        language === 'ar'
          ? `تم تصدير ${finalSelectedCustomers.length} عميل إلى ملف PDF بنجاح 📄✅`
          : `Exported ${finalSelectedCustomers.length} clients to PDF successfully 📄✅`
      );
    } catch (err) {
      console.error('Custom PDF export error:', err);
      showToast(
        language === 'ar' ? 'حدث خطأ أثناء تصدير ملف PDF' : 'Failed to export PDF report',
        'error'
      );
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Stats summary for filtered
  const totalAmountSum = finalSelectedCustomers.reduce((sum, c) => sum + (c.amount || 0), 0);
  const totalPointsSum = finalSelectedCustomers.reduce((sum, c) => sum + (c.points || 0), 0);

  return (
    <div dir={dir} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2.5 sm:p-5 overflow-y-auto overflow-x-hidden">
      <div className={`bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-4xl min-w-0 overflow-x-hidden p-3.5 sm:p-5 shadow-2xl space-y-4 sm:space-y-5 ${dir === 'rtl' ? 'text-right' : 'text-left'} max-h-[92vh] flex flex-col my-auto`}>
        <div className="glow-top" />

        {/* Modal Header */}
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800 shrink-0 min-w-0">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 shrink-0">
              <Sliders className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-sm sm:text-base text-white break-words">{t('customReportBuilderTitle', 'صانع التقارير المخصصة الشامل')}</h3>
              <p className="text-[11px] text-zinc-400 break-words">{t('customReportBuilderSubtitle', 'تصفية متقدمة، اختيار الحقول، واستخراج التقارير للطباعة أو Excel')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 hover:bg-zinc-700 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden min-w-0 space-y-5 px-0.5">
          
          {/* FILTER CRITERIA BOX */}
          <div className="bg-zinc-950/70 border border-zinc-800/80 rounded-2xl p-3 sm:p-4 space-y-4 min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <Filter className="w-4 h-4 shrink-0" /> {t('filterCriteria', 'معايير التصفية والفلترة')}
              </span>
              <button
                onClick={resetFilters}
                className="text-[11px] text-zinc-400 hover:text-amber-400 flex items-center gap-1 bg-zinc-900 px-2.5 py-1 rounded-lg border border-zinc-800 shrink-0"
              >
                <RefreshCw className="w-3 h-3 shrink-0" />
                <span>{t('resetFilters', 'إعادة ضبط الفلاتر')}</span>
              </button>
            </div>

            {/* Row 0: Customer Selection Scope (Single Customer or All Customers) */}
            <div className="bg-zinc-900/90 border border-indigo-500/30 p-3 rounded-2xl space-y-2 min-w-0">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="block text-[11px] text-indigo-300 font-extrabold flex items-center gap-1">
                  <span>🎯 {t('reportScope', 'نطاق التقرير (عميل محدد أو جميع العملاء)')}</span>
                </label>
                {selectedCustomerId !== 'all' && (
                  <button
                    type="button"
                    onClick={() => setSelectedCustomerId('all')}
                    className="text-[10px] text-amber-400 hover:underline font-bold"
                  >
                    {t('showAllCustomers', 'عرض جميع العملاء')}
                  </button>
                )}
              </div>
              <select
                value={selectedCustomerId}
                onChange={(e) => setSelectedCustomerId(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-100 font-bold focus:outline-none focus:border-indigo-500 text-xs"
              >
                <option value="all">👥 {t('allCustomersCount', 'جميع العملاء ({count} عميل)').replace('{count}', String(customers.length))}</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    👤 {c.name} - {formatPhone(c.phone)} {c.salary ? `(${t('salary', 'الراتب')}: ${formatCurrency(c.salary)})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Row 1: Product Type, Finance Type, Sales Rep */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('productType', 'نوع المنتج')}</label>
                <select
                  value={productTypeFilter}
                  onChange={(e) => setProductTypeFilter(e.target.value as any)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">{t('allProductsVisaFinance', 'الكل (Visa + تمويل)')}</option>
                  <option value="visa">{t('visaCardsOnly', 'بطاقات Visa فقط')}</option>
                  <option value="finance">{t('personalFinanceOnly', 'التمويل الشخصي فقط')}</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('financeType', 'نوع التمويل (تحويل الراتب)')}</label>
                <select
                  value={financeTypeFilter}
                  onChange={(e) => setFinanceTypeFilter(e.target.value as any)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">{t('allFinanceTypes', 'جميع أنواع التمويل')}</option>
                  <option value="salary_transfer">🏦 {t('salaryTransferOnly', 'تحويل راتب فقط')}</option>
                  <option value="no_salary_transfer">💼 {t('withoutSalaryTransferOnly', 'بدون تحويل راتب فقط')}</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('salesRepInCharge', 'موظف المبيعات المسؤول')}</label>
                <select
                  value={salesRepFilter}
                  onChange={(e) => setSalesRepFilter(e.target.value === 'all' ? 'all' : Number(e.target.value))}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">{t('allSalesReps', 'جميع الموظفين')}</option>
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.username} ({u.role === 'admin' ? t('roleAdmin', 'مدير') : t('roleStaff', 'مبيعات')})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 2: Card Types Selection (Multi-select Chips) */}
            {(productTypeFilter === 'all' || productTypeFilter === 'visa') && cardTypes.length > 0 && (
              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1.5">
                  {t('selectCardTypes', 'تحديد أنواع البطاقات (Visa Cards)')}
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {cardTypes.map((ct) => {
                    const isSelected = selectedCardTypeIds.includes(ct.id!);
                    return (
                      <button
                        key={ct.id}
                        type="button"
                        onClick={() => toggleCardType(ct.id!)}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all border ${
                          isSelected
                            ? 'bg-indigo-600 border-indigo-500 text-white shadow-md shadow-indigo-600/20'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {ct.name}
                      </button>
                    );
                  })}
                  {selectedCardTypeIds.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setSelectedCardTypeIds([])}
                      className="text-[10px] text-rose-400 hover:underline px-2"
                    >
                      {t('deselectCardTypes', 'إلغاء تحديد البطاقات')}
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Row 3: Statuses Selection (Multi-select Chips) */}
            <div>
              <label className="block text-[11px] text-zinc-400 font-bold mb-1.5">
                {t('selectCustomerStatuses', 'تحديد حالات العملاء (Statuses)')}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {ALL_STATUSES.map((st) => {
                  const isSelected = selectedStatuses.includes(st);
                  const activeStyle =
                    st === 'تم التفعيل'
                      ? 'bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-600/20'
                      : st === 'تم التنفيذ'
                      ? 'bg-cyan-600 border-cyan-500 text-white shadow-md shadow-cyan-600/20'
                      : st === 'عميل معلق'
                      ? 'bg-amber-500 border-amber-400 text-zinc-950 shadow-md shadow-amber-500/20'
                      : 'bg-sky-600 border-sky-500 text-white shadow-md shadow-sky-600/20';
                  return (
                    <button
                      key={st}
                      type="button"
                      onClick={() => toggleStatus(st)}
                      className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all border ${
                        isSelected
                          ? activeStyle
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      {getStatusTranslation(st, language)}
                    </button>
                  );
                })}
                {selectedStatuses.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setSelectedStatuses([])}
                    className="text-[10px] text-rose-400 hover:underline px-2"
                  >
                    {t('deselectStatuses', 'إلغاء تحديد الحالات')}
                  </button>
                )}
              </div>
            </div>

            {/* Row 3.5: Salary Tier Presets */}
            <div>
              <label className="block text-[11px] text-zinc-400 font-bold mb-1.5">
                {t('salaryTiersQuickSelect', 'شرائح الرواتب الجاهزة (اختيار سريع)')}
              </label>
              <div className="flex flex-wrap gap-1.5 text-[10px]">
                <button
                  type="button"
                  onClick={() => { setMinSalary(''); setMaxSalary('10000'); }}
                  className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/50 text-zinc-300 font-bold"
                >
                  {t('lessThan10k', 'أقل من 10,000 ر.س')}
                </button>
                <button
                  type="button"
                  onClick={() => { setMinSalary('10000'); setMaxSalary('20000'); }}
                  className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/50 text-zinc-300 font-bold"
                >
                  {t('from10kTo20k', 'من 10,000 إلى 20,000 ر.س')}
                </button>
                <button
                  type="button"
                  onClick={() => { setMinSalary('20000'); setMaxSalary('30000'); }}
                  className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/50 text-zinc-300 font-bold"
                >
                  {t('from20kTo30k', 'من 20,000 إلى 30,000 ر.س')}
                </button>
                <button
                  type="button"
                  onClick={() => { setMinSalary('30000'); setMaxSalary(''); }}
                  className="px-2.5 py-1 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/50 text-zinc-300 font-bold"
                >
                  {t('moreThan30k', 'أكثر من 30,000 ر.س')}
                </button>
                {(minSalary || maxSalary) && (
                  <button
                    type="button"
                    onClick={() => { setMinSalary(''); setMaxSalary(''); }}
                    className="text-rose-400 font-bold hover:underline px-2"
                  >
                    {t('clearSalaryFilter', 'إلغاء تصفية الرواتب')}
                  </button>
                )}
              </div>
            </div>

            {/* Row 4: Salary/Amount Range & Date Range */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('minSalaryOrAmount', 'الحد الأدنى للراتب/المبلغ')}</label>
                <input
                  type="number"
                  placeholder="6000"
                  value={minSalary}
                  onChange={(e) => setMinSalary(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500 text-left dir-ltr"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('maxSalaryOrAmount', 'الحد الأقصى للراتب/المبلغ')}</label>
                <input
                  type="number"
                  placeholder="50000"
                  value={maxSalary}
                  onChange={(e) => setMaxSalary(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500 text-left dir-ltr"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('fromAddDate', 'من تاريخ الإضافة')}</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 font-bold mb-1">{t('toAddDate', 'إلى تاريخ الإضافة')}</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-zinc-200 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Quick Text Search within Filtered Results */}
            <div className="relative">
              <Search className={`w-4 h-4 text-zinc-500 absolute ${dir === 'rtl' ? 'left-3' : 'right-3'} top-2.5`} />
              <input
                type="text"
                placeholder={t('quickSearchPlaceholder', 'بحث سريع باسم العميل أو رقم الجوال أو رقم الطلب...')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 ${dir === 'rtl' ? 'pr-3 pl-9' : 'pl-3 pr-9'} text-xs text-zinc-200 focus:outline-none focus:border-indigo-500`}
              />
            </div>
          </div>

          {/* COLUMN SELECTION BOX */}
          <div className="bg-zinc-950/70 border border-zinc-800/80 rounded-2xl p-3 sm:p-4 space-y-2 min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-bold text-xs text-amber-400 flex items-center gap-1.5">
                <CheckSquare className="w-4 h-4 shrink-0" /> {t('selectColumnsToDisplay', 'اختيار حقول الأعمدة المعروضة في التقرير')}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedColumns(availableColumns.map(c => c.key))}
                  className="text-[10px] text-indigo-400 hover:underline"
                >
                  {t('selectAll', 'تحديد الكل')}
                </button>
                <span className="text-zinc-600">|</span>
                <button
                  type="button"
                  onClick={() => setSelectedColumns(['name', 'phone', 'status'])}
                  className="text-[10px] text-zinc-400 hover:underline"
                >
                  {t('minColumns', 'الحد الأدنى')}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 pt-1">
              {availableColumns.map((col) => {
                const isChecked = selectedColumns.includes(col.key);
                return (
                  <label
                    key={col.key}
                    onClick={() => toggleColumn(col.key)}
                    className={`flex items-center gap-2 p-2 rounded-xl text-xs cursor-pointer border transition-colors select-none ${
                      isChecked
                        ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 font-bold'
                        : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    {isChecked ? (
                      <CheckSquare className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    ) : (
                      <Square className="w-3.5 h-3.5 shrink-0" />
                    )}
                    <span className="truncate">{col.label}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* LIVE STATS & RESULTS PREVIEW */}
          <div className="space-y-3 min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-2.5 bg-indigo-950/30 border border-indigo-500/20 p-3 sm:p-3.5 rounded-2xl min-w-0">
              <div className="flex flex-wrap items-center gap-3 min-w-0">
                <div className="min-w-0">
                  <div className="text-[10px] text-zinc-400 font-bold">{t('selectedCustomersCount', 'عدد العملاء المحدد')}</div>
                  <div className="text-base sm:text-lg font-black text-indigo-300 font-mono">
                    {finalSelectedCustomers.length} <span className="text-xs font-normal text-zinc-400">{t('metricUnitCustomer', 'عميل')}</span>
                  </div>
                </div>
                <div className="hidden sm:block h-8 w-px bg-zinc-800" />
                <div className="min-w-0">
                  <div className="text-[10px] text-zinc-400 font-bold">{t('totalFinanceSum', 'إجمالي التمويل')}</div>
                  <div className="text-base sm:text-lg font-black text-emerald-400 font-mono break-words">
                    {formatCurrency(totalAmountSum)}
                  </div>
                </div>
                <div className="hidden sm:block h-8 w-px bg-zinc-800" />
                <div className="min-w-0">
                  <div className="text-[10px] text-zinc-400 font-bold">{t('totalPointsSum', 'إجمالي النقاط')}</div>
                  <div className="text-base sm:text-lg font-black text-amber-400 font-mono">
                    {formatNumber(totalPointsSum)} <span className="text-xs font-normal text-zinc-400">{t('pts', 'نقطة')}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSelectAllCustomers}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 px-3 py-1.5 rounded-xl border border-indigo-500/20 shrink-0"
              >
                {excludedCustomerIds.length === 0 ? t('deselectAll', 'إلغاء تحديد الكل') : t('selectAllResults', 'تحديد جميع النتائج')}
              </button>
            </div>

            {/* PREVIEW TABLE */}
            <div className="w-full max-w-full bg-zinc-950/80 border border-zinc-800 rounded-2xl overflow-x-auto max-h-60">
              <table className={`w-full ${dir === 'rtl' ? 'text-right' : 'text-left'} text-xs`}>
                <thead className="bg-zinc-900 border-b border-zinc-800 text-zinc-400 sticky top-0">
                  <tr>
                    <th className="p-2.5 w-8 text-center">
                      <input
                        type="checkbox"
                        checked={excludedCustomerIds.length === 0}
                        onChange={handleSelectAllCustomers}
                        className="rounded accent-indigo-500"
                      />
                    </th>
                    <th className="p-2.5 w-8">{t('seqNumber', 'م')}</th>
                    {availableColumns.filter(c => selectedColumns.includes(c.key)).map(c => (
                      <th key={c.key} className="p-2.5 whitespace-nowrap">{c.label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {matchingCustomers.length === 0 ? (
                    <tr>
                      <td colSpan={selectedColumns.length + 2} className="text-center py-8 text-zinc-500 text-xs">
                        {t('noMatchingResultsForFilter', 'لا توجد نتائج تطابق خيارات التصفية الحالية')}
                      </td>
                    </tr>
                  ) : (
                    matchingCustomers.map((c, index) => {
                      const isSelected = !excludedCustomerIds.includes(c.id!);
                      return (
                        <tr
                          key={c.id}
                          className={`hover:bg-zinc-900/50 transition-colors ${!isSelected ? 'opacity-40 bg-zinc-950/40' : ''}`}
                        >
                          <td className="p-2.5 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleCustomerExclusion(c.id!)}
                              className="rounded accent-indigo-500"
                            />
                          </td>
                          <td className="p-2.5 text-zinc-500 font-mono">{index + 1}</td>
                          {availableColumns.filter(col => selectedColumns.includes(col.key)).map(col => (
                            <td key={col.key} className="p-2.5 whitespace-nowrap text-zinc-200">
                              {getCellValue(c, col.key)}
                            </td>
                          ))}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* MODAL ACTION BUTTONS */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 pt-3 border-t border-zinc-800 shrink-0">
          <button
            type="button"
            onClick={handleExportPDF}
            disabled={finalSelectedCustomers.length === 0 || isExportingPdf}
            className="flex-1 min-w-[125px] bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/25 transition-all"
          >
            {isExportingPdf ? <Loader2 className="w-4 h-4 animate-spin shrink-0" /> : <FileText className="w-4 h-4 shrink-0" />}
            <span>
              {isExportingPdf
                ? language === 'ar'
                  ? 'جاري تجهيز ملف PDF...'
                  : 'Generating PDF...'
                : (language === 'ar' ? `تصدير ملف PDF (${finalSelectedCustomers.length})` : `Export PDF (${finalSelectedCustomers.length})`)}
            </span>
          </button>

          <button
            type="button"
            onClick={handleExportExcel}
            disabled={finalSelectedCustomers.length === 0}
            className="flex-1 min-w-[125px] bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-600/20"
          >
            <FileSpreadsheet className="w-4 h-4 shrink-0" />
            <span>{t('exportExcelXlsx', 'تصدير ملف Excel (XLSX)')}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold border border-zinc-700"
          >
            {t('close', 'إغلاق')}
          </button>
        </div>
      </div>
    </div>
  );
};
