import React from 'react';
import type { Customer, PointLog } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { getStatusTranslation } from '../utils/translations';

interface PrintableReportSheetProps {
  /** 'preview' renders visibly inside a preview modal AND prints; 'print-only' stays hidden on screen and renders exclusively when printing */
  mode?: 'preview' | 'print-only';
  reportTitle: string;
  companyName?: string;
  repName?: string;
  cycleLabel: string;
  statusLabel: string;
  extraFilterNote?: string;
  reportType?: 'customers' | 'points';
  customers: Customer[];
  pointsLog?: PointLog[];
  getCardTypeName: (cardTypeId?: number | null) => string;
  footerText?: string;
}

const getStatusBadgeClasses = (status?: string) => {
  const s = (status || '').trim();
  if (s === 'تم التفعيل' || s === 'Activated') {
    return 'bg-emerald-100 text-emerald-900 border border-emerald-300';
  }
  if (s === 'تم التنفيذ' || s === 'Executed') {
    return 'bg-cyan-100 text-cyan-900 border border-cyan-300';
  }
  if (s === 'عميل معلق' || s === 'Pending') {
    return 'bg-amber-100 text-amber-900 border border-amber-300';
  }
  if (s === 'عميل محتمل' || s === 'Potential') {
    return 'bg-sky-100 text-sky-900 border border-sky-300';
  }
  if (s === 'مرفوض' || s === 'Rejected' || s === 'ملغي') {
    return 'bg-rose-100 text-rose-900 border border-rose-300';
  }
  return 'bg-slate-100 text-slate-800 border border-slate-300';
};

export const PrintableReportSheet: React.FC<PrintableReportSheetProps> = ({
  mode = 'preview',
  reportTitle,
  companyName,
  repName,
  cycleLabel,
  statusLabel,
  extraFilterNote,
  reportType = 'customers',
  customers,
  pointsLog = [],
  getCardTypeName,
  footerText,
}) => {
  const { t, language, dir, formatNumber, formatCurrency, formatPhone } = useLanguage();

  const now = new Date();
  const reportDateFormatted = now.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const reportTimeFormatted = now.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const isPoints = reportType === 'points';
  const totalRecords = isPoints ? pointsLog.length : customers.length;

  // Strictly separated status counts (never merging Executed and Activated)
  const execCount = customers.filter((c) => (c.status || '').trim() === 'تم التنفيذ').length;
  const actCount = customers.filter((c) => (c.status || '').trim() === 'تم التفعيل').length;
  const pendCount = customers.filter((c) => (c.status || '').trim() === 'عميل معلق').length;
  const potCount = customers.filter((c) => (c.status || '').trim() === 'عميل محتمل').length;

  const totalFinanceVolume = customers.reduce((sum, c) => {
    const val = c.productType === 'visa' ? Number(c.salary || 0) : Number(c.amount || 0);
    return sum + (Number.isFinite(val) ? val : 0);
  }, 0);

  const totalCustomerPoints = isPoints
    ? pointsLog.reduce((sum, p) => sum + Number(p.points || 0), 0)
    : customers.reduce((sum, c) => sum + Number(c.points || 0), 0);

  const containerClasses =
    mode === 'print-only'
      ? 'print-only print-a4-sheet printable-area bg-white text-slate-900'
      : 'printable-area print-a4-sheet w-full max-w-4xl min-w-0 overflow-x-hidden bg-white text-slate-900 rounded-2xl p-3.5 sm:p-7 shadow-2xl space-y-4 sm:space-y-5 print:p-0 print:shadow-none print:rounded-none';

  return (
    <section className={containerClasses} dir={dir}>
      {/* Professional A4 Corporate Header with App Logo & Report Date */}
      <div className="print-header flex flex-wrap items-center justify-between gap-3 border-b-2 border-sky-600 pb-3.5">
        <div className="print-logo-wrap flex items-center gap-3 min-w-0 flex-1">
          <div className="shrink-0 w-12 h-12 rounded-xl bg-sky-50 border border-sky-200 p-1.5 flex items-center justify-center">
            <img
              src="/icon.png"
              alt="Sales CRM"
              className="print-logo-img w-full h-full object-contain rounded-lg"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className={`min-w-0 flex-1 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-black text-sky-700 uppercase tracking-wider">
                {companyName?.trim() || 'SALES CRM SYSTEM'}
              </span>
              <span className="text-[10px] font-bold text-slate-400">•</span>
              <span className="text-[10px] font-bold text-slate-500">
                {language === 'ar' ? 'تقرير رسمي جاهز للطباعة A4' : 'Official A4 Report'}
              </span>
            </div>
            <h1 className="text-base sm:text-xl font-black text-slate-900 mt-0.5 leading-snug break-words">
              {reportTitle}
            </h1>
            {repName && (
              <div className="text-[11px] text-slate-600 font-semibold mt-0.5">
                {language === 'ar' ? 'المستخدم / المندوب:' : 'Representative:'}{' '}
                <span className="font-bold text-slate-800">{repName}</span>
              </div>
            )}
          </div>
        </div>

        {/* Report Date & Record Count Box */}
        <div className="flex items-stretch gap-2 shrink-0">
          <div className={`px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
            <div className="text-[10px] text-slate-500 font-bold">
              {t('reportDate', 'تاريخ التقرير')}
            </div>
            <div className="text-xs font-black text-slate-900 mt-0.5">
              {reportDateFormatted}
            </div>
            <div className="text-[10px] text-slate-500 font-mono mt-0.5">
              {reportTimeFormatted}
            </div>
          </div>

          <div className="text-center px-3 py-2 bg-sky-50 border border-sky-200 rounded-xl min-w-[76px] flex flex-col justify-center">
            <div className="text-[10px] text-sky-700 font-bold">
              {t('totalRecordsCount', 'إجمالي السجلات')}
            </div>
            <div className="text-xl font-black text-sky-900 font-mono leading-tight mt-0.5">
              {formatNumber(totalRecords)}
            </div>
          </div>
        </div>
      </div>

      {/* Report Metadata Strip */}
      <div className="print-meta-bar flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-700">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <span>
            <strong className="text-slate-900">{t('cycle', 'الدورة')}:</strong> {cycleLabel}
          </span>
          <span className="text-slate-300">|</span>
          <span>
            <strong className="text-slate-900">{language === 'ar' ? 'الحالة:' : 'Status:'}</strong> {statusLabel}
          </span>
          {extraFilterNote && (
            <>
              <span className="text-slate-300">|</span>
              <span>
                <strong className="text-slate-900">{language === 'ar' ? 'تصفية:' : 'Filter:'}</strong> {extraFilterNote}
              </span>
            </>
          )}
        </div>
        <div className="font-mono text-[10px] text-slate-500">
          {language === 'ar' ? 'صيغة الورق: A4' : 'Format: A4'}
        </div>
      </div>

      {/* Strictly Separated Status Breakdown KPI Strip */}
      {!isPoints && (
        <div className="print-kpi-grid grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="print-kpi-card min-w-0 overflow-hidden p-2 rounded-xl bg-cyan-50 border border-cyan-200">
            <div className="text-[10px] font-bold text-cyan-800 truncate">
              {getStatusTranslation('تم التنفيذ', language)}
            </div>
            <div className="text-base font-black text-cyan-900 font-mono mt-0.5">
              {formatNumber(execCount)}
            </div>
          </div>
          <div className="print-kpi-card min-w-0 overflow-hidden p-2 rounded-xl bg-emerald-50 border border-emerald-200">
            <div className="text-[10px] font-bold text-emerald-800 truncate">
              {getStatusTranslation('تم التفعيل', language)}
            </div>
            <div className="text-base font-black text-emerald-900 font-mono mt-0.5">
              {formatNumber(actCount)}
            </div>
          </div>
          <div className="print-kpi-card min-w-0 overflow-hidden p-2 rounded-xl bg-amber-50 border border-amber-200">
            <div className="text-[10px] font-bold text-amber-800 truncate">
              {getStatusTranslation('عميل معلق', language)}
            </div>
            <div className="text-base font-black text-amber-900 font-mono mt-0.5">
              {formatNumber(pendCount)}
            </div>
          </div>
          <div className="print-kpi-card min-w-0 overflow-hidden p-2 rounded-xl bg-sky-50 border border-sky-200">
            <div className="text-[10px] font-bold text-sky-800 truncate">
              {getStatusTranslation('عميل محتمل', language)}
            </div>
            <div className="text-base font-black text-sky-900 font-mono mt-0.5">
              {formatNumber(potCount)}
            </div>
          </div>
        </div>
      )}

      {/* Full Multi-Page Data Table */}
      <div className="print-table-wrap w-full max-w-full overflow-x-auto">
        <table className="printable-table w-full border-collapse text-xs">
          {isPoints ? (
            <>
              <thead>
                <tr className="bg-slate-100 text-slate-800 border-b border-slate-300">
                  <th className="p-2 text-center border border-slate-200 w-10">{t('seqNumber', 'م')}</th>
                  <th className={`p-2 border border-slate-200 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {t('reasonOrCustomer', 'السبب / العميل')}
                  </th>
                  <th className="p-2 text-center border border-slate-200 w-24">{t('pointsTotal', 'النقاط')}</th>
                  <th className={`p-2 border border-slate-200 w-44 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {t('dateTime', 'التاريخ والوقت')}
                  </th>
                </tr>
              </thead>
              <tbody>
                {pointsLog.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-slate-500 border border-slate-200 font-semibold">
                      {language === 'ar' ? 'لا توجد سجلات نقاط ضمن هذا النطاق' : 'No points records found in this range'}
                    </td>
                  </tr>
                ) : (
                  pointsLog.map((p, index) => (
                    <tr key={p.id || index} className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                      <td className="p-2 text-center border border-slate-200 font-mono">{index + 1}</td>
                      <td className={`p-2 border border-slate-200 font-bold text-slate-900 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                        {p.reason || t('ptsEarnReason', 'كسب نقاط')}
                      </td>
                      <td className="p-2 text-center border border-slate-200 font-black text-emerald-700 font-mono">
                        +{formatNumber(p.points)}
                      </td>
                      <td className={`p-2 border border-slate-200 font-mono text-slate-600 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                        {new Date(p.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </>
          ) : (
            <>
              <thead>
                <tr className="bg-slate-100 text-slate-800 border-b border-slate-300">
                  <th className="p-2 text-center border border-slate-200 w-8">{t('seqNumber', 'م')}</th>
                  <th className={`p-2 border border-slate-200 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {t('customerName', 'اسم العميل')}
                  </th>
                  <th className="p-2 text-center border border-slate-200">{t('phone', 'الجوال')}</th>
                  <th className="p-2 text-center border border-slate-200">{t('orderNumber', 'رقم الطلب')}</th>
                  <th className={`p-2 border border-slate-200 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {t('productOrCardType', 'المنتج / البطاقة')}
                  </th>
                  <th className="p-2 text-center border border-slate-200">{t('salaryOrAmountRequired', 'الراتب / التمويل')}</th>
                  <th className="p-2 text-center border border-slate-200">{t('points', 'النقاط')}</th>
                  <th className="p-2 text-center border border-slate-200">{t('status', 'الحالة')}</th>
                  <th className={`p-2 border border-slate-200 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {t('notes', 'الملاحظات')}
                  </th>
                  <th className="p-2 text-center border border-slate-200">{t('createdDate', 'تاريخ الإضافة')}</th>
                </tr>
              </thead>
              <tbody>
                {customers.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-6 text-center text-slate-500 border border-slate-200 font-semibold">
                      {language === 'ar' ? 'لا توجد سجلات عملاء مطابقة للتصفية الحالية' : 'No matching customer records found'}
                    </td>
                  </tr>
                ) : (
                  customers.map((c, index) => {
                    const cardName = getCardTypeName(c.cardTypeId) || c.cardTypeName || '';
                    return (
                      <tr key={c.id || index} className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                        <td className="p-1.5 text-center border border-slate-200 font-mono">{index + 1}</td>
                        <td className={`p-1.5 border border-slate-200 font-bold text-slate-900 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                          {c.name}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200 font-mono text-slate-700 dir-ltr">
                          {formatPhone(c.phone)}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200 font-mono text-slate-600">
                          {c.orderNumber || '-'}
                        </td>
                        <td className={`p-1.5 border border-slate-200 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                          {c.productType === 'visa'
                            ? `Visa${cardName ? ` (${cardName})` : ''}`
                            : t('personalFinance', 'تمويل شخصي')}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200 font-mono font-bold text-slate-800">
                          {c.productType === 'visa'
                            ? c.salary
                              ? formatCurrency(c.salary)
                              : '-'
                            : formatCurrency(c.amount || 0)}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200 font-mono font-black text-amber-700">
                          {c.points ? formatNumber(c.points) : 0}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200">
                          <span className={`print-status-badge px-2 py-0.5 rounded font-bold text-[10px] ${getStatusBadgeClasses(c.status)}`}>
                            {getStatusTranslation(c.status, language)}
                          </span>
                        </td>
                        <td className={`p-1.5 border border-slate-200 text-slate-700 text-[10px] break-words ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                          {c.notes?.trim() || '-'}
                        </td>
                        <td className="p-1.5 text-center border border-slate-200 font-mono text-slate-600 text-[10px]">
                          {c.createdAt ? new Date(c.createdAt).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US') : '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </>
          )}
        </table>
      </div>

      {/* Financial & Points Summary Strip */}
      <div className="print-summary-strip flex flex-wrap items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-sky-50 border border-sky-200 text-xs">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-bold text-slate-800">
          <span>
            {language === 'ar' ? 'إجمالي السجلات:' : 'Total Records:'}{' '}
            <strong className="font-mono text-sky-900">{formatNumber(totalRecords)}</strong>
          </span>
          {!isPoints && (
            <span>
              {language === 'ar' ? 'إجمالي الرواتب / التمويل:' : 'Total Volume:'}{' '}
              <strong className="font-mono text-sky-900">{formatCurrency(totalFinanceVolume)}</strong>
            </span>
          )}
          <span>
            {language === 'ar' ? 'إجمالي النقاط:' : 'Total Points:'}{' '}
            <strong className="font-mono text-amber-800">{formatNumber(totalCustomerPoints)}</strong>
          </span>
        </div>
        <div className="text-[10px] font-bold text-sky-800">
          {companyName?.trim() || 'Sales CRM'}
        </div>
      </div>

      {/* Official A4 Document Footer */}
      <div className="print-footer pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
        <div>
          {footerText || t('systemGeneratedReportFooter', 'تم استخراج هذا التقرير تلقائياً من نظام إدارة المبيعات Sales CRM')}
        </div>
        <div className="font-mono">
          {reportDateFormatted} — {reportTimeFormatted}
        </div>
      </div>
    </section>
  );
};
