import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { X, Shield, Landmark, Building, Globe, DollarSign, Calculator, CheckCircle2, Sparkles, HelpCircle, ArrowLeft, ArrowRight, Layers, Percent } from 'lucide-react';
import { db } from '../db/db';
import { calculatePersonalFinanceRate, calculateMonthlyInstallment, calculateMaxFinancing, calculateDbrRate, calculateDetailedFinancingBreakdown, getStoredPersonalFinanceRates, type PersonalFinanceRatesConfig } from '../utils/finance';
import { triggerHaptic } from '../utils/haptics';
import { useLanguage } from '../context/LanguageContext';

interface FinanceCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyRate?: (rate: number) => void;
  initialSalary?: number;
  initialAmount?: number;
}

export const FinanceCalculatorModal: React.FC<FinanceCalculatorModalProps> = ({
  isOpen,
  onClose,
  onApplyRate,
  initialSalary = 12000,
  initialAmount = 100000,
}) => {
  const { language, dir, t, formatCurrency, formatNumber } = useLanguage();

  // Live Query to get Personal Finance Rates configured by Admin
  const liveRatesSetting = useLiveQuery(() => db.settings.get('personalFinanceRates'));
  const currentRates: PersonalFinanceRatesConfig = useMemo(() => {
    if (liveRatesSetting?.value) {
      return liveRatesSetting.value as PersonalFinanceRatesConfig;
    }
    return getStoredPersonalFinanceRates();
  }, [liveRatesSetting]);

  // Decision Tree State
  const [isMilitary, setIsMilitary] = useState<boolean>(false);
  const [militaryType, setMilitaryType] = useState<'stl' | 'nstl'>('stl');

  const [hasSalaryTransfer, setHasSalaryTransfer] = useState<boolean>(true);
  const [nationality, setNationality] = useState<'saudi' | 'expat'>('saudi');
  const [companyCategory, setCompanyCategory] = useState<'A' | 'B' | 'C_D_E' | 'NALE'>('A');
  const [isApprovedEmployer, setIsApprovedEmployer] = useState<boolean>(true);

  const [salary, setSalary] = useState<number>(initialSalary);
  const [loanAmount, setLoanAmount] = useState<number>(initialAmount);
  const [durationYears, setDurationYears] = useState<number>(5);

  // Calculate Rate & Decision Result with active live rates
  const decisionResult = useMemo(() => {
    return calculatePersonalFinanceRate({
      isMilitary,
      militaryType,
      hasSalaryTransfer,
      nationality,
      companyCategory,
      isApprovedEmployer,
      salary,
      loanAmount,
    }, currentRates);
  }, [isMilitary, militaryType, hasSalaryTransfer, nationality, companyCategory, isApprovedEmployer, salary, loanAmount, currentRates]);

  // Financial Estimates based on Rate
  const detailedBreakdown = useMemo(() => {
    return calculateDetailedFinancingBreakdown(loanAmount, decisionResult.rate, durationYears);
  }, [loanAmount, decisionResult.rate, durationYears]);

  const monthlyInstallment = detailedBreakdown.monthlyInstallment;

  const dbrRate = useMemo(() => {
    return calculateDbrRate(salary, monthlyInstallment);
  }, [salary, monthlyInstallment]);

  const maxFinancing = useMemo(() => {
    return calculateMaxFinancing(salary, durationYears, 33.33, decisionResult.rate);
  }, [salary, durationYears, decisionResult.rate]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-fadeIn" dir={dir}>
      <div className="bg-[#071325] border border-sky-500/30 rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Modal Header */}
        <div className="p-4 bg-gradient-to-r from-[#0e2242] via-[#09172e] to-[#071325] border-b border-sky-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-500/20 text-sky-300 rounded-2xl border border-sky-400/30">
              <Calculator className="w-6 h-6 text-sky-400" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>{language === 'ar' ? 'حاسبة نسب التمويل الشخصي الذكية' : 'Smart Personal Finance Calculator'}</span>
                <span className="px-2 py-0.5 bg-sky-500/20 text-sky-300 text-[10px] font-mono rounded-full border border-sky-400/30">
                  {language === 'ar' ? 'شجرة القرارات' : 'Decision Tree'}
                </span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono rounded-full border border-emerald-400/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  {language === 'ar' ? 'ربط فوري بالنسب المعتمدة' : 'Live Synced'}
                </span>
              </h2>
              <p className="text-xs text-sky-200/80 mt-0.5">
                {language === 'ar' ? 'تحديد نسبة هامش الربح والقسط المتوقع بدقة حسَب القطاع والجهة والراتب' : 'Accurately determine profit rate and estimated installment by sector and salary'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="p-2 text-sky-300 hover:text-white rounded-xl bg-[#0e2242] border border-sky-400/20 hover:border-sky-400/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className={`p-4 sm:p-5 overflow-y-auto space-y-5 ${dir === 'rtl' ? 'text-right' : 'text-left'} font-sans`}>
          
          {/* Step 1: Military Check */}
          <div className="p-3.5 bg-zinc-900/80 border border-zinc-800 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-amber-400" />
                <span>1. {language === 'ar' ? 'هل التمويل لصالح القطاع العسكري؟' : 'Is financing for the military sector?'}</span>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setIsMilitary(true);
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                  isMilitary
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-lg shadow-amber-500/10'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                }`}
              >
                <span>🛡️ {language === 'ar' ? 'نعم (عسكري)' : 'Yes (Military)'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setIsMilitary(false);
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                  !isMilitary
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500 shadow-lg shadow-indigo-500/10'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                }`}
              >
                <span>👔 {language === 'ar' ? 'لا (مدني / خاص)' : 'No (Civil / Private)'}</span>
              </button>
            </div>

            {/* Sub-branch for Military */}
            {isMilitary && (
              <div className="p-3 bg-zinc-950/80 border border-amber-500/20 rounded-xl space-y-2 mt-2">
                <div className="text-[11px] font-bold text-zinc-300">
                  {language === 'ar' ? 'اختر طريقة الصرف للعسكريين:' : 'Select disbursement method for military:'}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setMilitaryType('stl');
                    }}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                      militaryType === 'stl'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    🏦 {t('salaryTransfer')} (STL) — <span className="font-mono font-black text-emerald-400">3.25%</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setMilitaryType('nstl');
                    }}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                      militaryType === 'nstl'
                        ? 'bg-sky-500/20 text-sky-300 border-sky-500'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    💼 {t('noSalaryTransfer')} (NSTL) — <span className="font-mono font-black text-sky-400">5.99%</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Step 2: Non-Military Branch */}
          {!isMilitary && (
            <div className="space-y-4">
              {/* Salary Transfer Toggle */}
              <div className="p-3.5 bg-zinc-900/80 border border-zinc-800 rounded-2xl space-y-3">
                <span className="text-xs font-black text-indigo-300 flex items-center gap-1.5">
                  <Landmark className="w-4 h-4 text-indigo-400" />
                  <span>2. {language === 'ar' ? 'طريقة خدمة التمويل (تحويل الراتب):' : 'Financing Service Method (Salary Assignment):'}</span>
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setHasSalaryTransfer(true);
                    }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                      hasSalaryTransfer
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-md shadow-emerald-500/10'
                        : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                    }`}
                  >
                    <span>🏦 {language === 'ar' ? 'تحويل راتب (Salary Assigned - STL)' : 'Salary Assigned (STL)'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setHasSalaryTransfer(false);
                    }}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                      !hasSalaryTransfer
                        ? 'bg-sky-500/20 text-sky-300 border-sky-500 shadow-md shadow-sky-500/10'
                        : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                    }`}
                  >
                    <span>💼 {language === 'ar' ? 'بدون تحويل راتب (Non-Salary Assigned - NSTL)' : 'Non-Salary Assigned (NSTL)'}</span>
                  </button>
                </div>
              </div>

              {/* Specific Options for Salary Assigned vs Non-Salary Assigned */}
              <div className="p-3.5 bg-zinc-900/80 border border-zinc-800 rounded-2xl space-y-3">
                <span className="text-xs font-black text-purple-300 flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-purple-400" />
                  <span>3. {language === 'ar' ? 'تفاصيل الجنسية وتصنيف جهة العمل:' : 'Nationality & Employer Category:'}</span>
                </span>

                {/* Nationality Selector */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-400">{t('nationality', 'الجنسية')}:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setNationality('saudi');
                      }}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                        nationality === 'saudi'
                          ? 'bg-purple-500/20 text-purple-300 border-purple-500'
                          : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                      }`}
                    >
                      🇸🇦 {t('saudi', 'سعودي')}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        triggerHaptic('light');
                        setNationality('expat');
                      }}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                        nationality === 'expat'
                          ? 'bg-purple-500/20 text-purple-300 border-purple-500'
                          : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                      }`}
                    >
                      🌐 {t('nonSaudi', 'مقيم')}
                    </button>
                  </div>
                </div>

                {/* Branch A: Salary Transfer Categories */}
                {hasSalaryTransfer && (
                  <div className="space-y-1.5 pt-1">
                    <label className="text-[11px] font-bold text-zinc-400">
                      {language === 'ar' ? 'تصنيف جهة العمل (Company Category):' : 'Company Category:'}
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { code: 'A', nameAr: 'حكومي/خاص (أ)', nameEn: 'Gov/Private (A)' },
                        { code: 'B', nameAr: 'خاص (ب)', nameEn: 'Private (B)' },
                        { code: 'C_D_E', nameAr: 'خاص (ج/د/هـ)', nameEn: 'Private (C/D/E)' },
                        { code: 'NALE', nameAr: 'غير معتمد NALE', nameEn: 'Non-Approved (NALE)' },
                      ].map((item) => (
                        <button
                          key={item.code}
                          type="button"
                          onClick={() => {
                            triggerHaptic('light');
                            setCompanyCategory(item.code as any);
                          }}
                          className={`py-2 px-2.5 rounded-xl border text-xs font-bold transition-all ${
                            companyCategory === item.code
                              ? 'bg-indigo-600 text-white border-indigo-400'
                              : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                          }`}
                        >
                          {language === 'ar' ? item.nameAr : item.nameEn}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Branch B: Non-Salary Assigned Employer Approval Check */}
                {!hasSalaryTransfer && (
                  <div className="space-y-1.5 pt-1">
                    <label className="text-[11px] font-bold text-zinc-400">
                      {language === 'ar' ? 'اعتماد جهة العمل:' : 'Employer Accreditation:'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          triggerHaptic('light');
                          setIsApprovedEmployer(true);
                        }}
                        className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                          isApprovedEmployer
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        ✅ {language === 'ar' ? 'جهة عمل معتمدة (Approved)' : 'Approved Employer'}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          triggerHaptic('light');
                          setIsApprovedEmployer(false);
                        }}
                        className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all ${
                          !isApprovedEmployer
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500'
                            : 'bg-zinc-950 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        ⚠️ {language === 'ar' ? 'جهة غير معتمدة (Non-Approved)' : 'Non-Approved Employer'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 3: Financial Parameters Input */}
          <div className="p-3.5 bg-zinc-900/80 border border-zinc-800 rounded-2xl space-y-3">
            <span className="text-xs font-black text-teal-300 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-teal-400" />
              <span>4. {language === 'ar' ? 'قيم التمويل والراتب للعميل:' : 'Customer Salary & Financing Values:'}</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Salary */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 mb-1">{t('salary')} ({language === 'ar' ? 'ر.س' : 'SAR'})</label>
                <input
                  type="number"
                  step="any"
                  value={salary || ''}
                  onChange={(e) => setSalary(parseFloat(e.target.value) || 0)}
                  className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono font-bold focus:border-indigo-500 dir-ltr ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                  placeholder="12000"
                />
                <span className="text-[10px] text-amber-400 mt-1 block">
                  {language === 'ar' ? `الشريحة: ${decisionResult.tierLabel}` : `Tier: ${decisionResult.tierLabel}`}
                </span>
              </div>

              {/* Loan Amount */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 mb-1">{t('amount')} ({language === 'ar' ? 'ر.س' : 'SAR'})</label>
                <input
                  type="number"
                  step="any"
                  value={loanAmount || ''}
                  onChange={(e) => setLoanAmount(parseFloat(e.target.value) || 0)}
                  className={`w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-mono font-bold focus:border-indigo-500 dir-ltr ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                  placeholder="100000"
                />
                {loanAmount >= 1000000 && !isMilitary && !hasSalaryTransfer && nationality === 'saudi' && isApprovedEmployer && (
                  <span className="text-[10px] text-emerald-400 mt-1 block">✨ {language === 'ar' ? 'يطبق عرض التمويل المليوني (3.99%)' : 'Million SAR Offer Applied (3.99%)'}</span>
                )}
              </div>

              {/* Duration Years */}
              <div>
                <label className="block text-[11px] font-bold text-zinc-400 mb-1">{language === 'ar' ? 'مدة السداد (سنوات)' : 'Tenure (Years)'}</label>
                <select
                  value={durationYears}
                  onChange={(e) => setDurationYears(Number(e.target.value))}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white font-bold focus:border-indigo-500"
                >
                  <option value={1}>{language === 'ar' ? 'سنة واحدة (12 شهراً)' : '1 Year (12 months)'}</option>
                  <option value={2}>{language === 'ar' ? 'سنتان (24 شهراً)' : '2 Years (24 months)'}</option>
                  <option value={3}>{language === 'ar' ? '3 سنوات (36 شهراً)' : '3 Years (36 months)'}</option>
                  <option value={4}>{language === 'ar' ? '4 سنوات (48 شهراً)' : '4 Years (48 months)'}</option>
                  <option value={5}>{language === 'ar' ? '5 سنوات (60 شهراً - الأقصى)' : '5 Years (60 months - Max)'}</option>
                </select>
              </div>
            </div>
          </div>

          {/* Calculated Output Card */}
          <div className="p-4 bg-gradient-to-br from-indigo-950/90 via-zinc-900 to-purple-950/90 border border-indigo-500/50 rounded-2xl shadow-xl space-y-3.5">
            <div className="flex items-center justify-between border-b border-indigo-500/30 pb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
                <span className="font-extrabold text-xs text-indigo-200">{language === 'ar' ? 'النتيجة المحسوبة تلقائياً:' : 'Calculated Output:'}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-amber-300 font-mono">%{decisionResult.rate}</span>
                <span className="text-xs text-zinc-300">{language === 'ar' ? 'نسبة السنة الواحدة' : 'Annual Rate'}</span>
              </div>
            </div>

            {/* Path Steps Visualizer */}
            <div className="space-y-1 bg-zinc-950/70 p-3 rounded-xl border border-zinc-800/80 text-[11px]">
              <div className="font-bold text-indigo-300 mb-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'ar' ? 'المسار البرمجي المتخذ:' : 'Calculation Decision Path:'}</span>
              </div>
              {decisionResult.steps.map((s, idx) => (
                <div key={idx} className="text-zinc-300 font-mono text-[10.5px]">
                  {s}
                </div>
              ))}
            </div>

            {/* Formula Step-by-Step Breakdown */}
            <div className="p-3 bg-zinc-950/80 border border-indigo-500/30 rounded-xl space-y-2 text-xs">
              <div className="font-bold text-amber-300 text-[11px] flex items-center justify-between border-b border-zinc-800 pb-1.5">
                <span className="flex items-center gap-1.5">
                  <Calculator className="w-4 h-4 text-amber-400" />
                  <span>{language === 'ar' ? 'تفاصيل عملية الحساب (معادلة المرابحة والقسط):' : 'Calculation Breakdown (Murabaha & Installment):'}</span>
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">{language === 'ar' ? 'الحد الأقصى 5 سنوات' : 'Max 5 years'}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
                <div className="bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-400 block text-[10px]">{language === 'ar' ? '1. النسبة الكلية للمرابحة:' : '1. Total Profit Rate:'}</span>
                  <span className="text-indigo-300 font-bold">
                    %{decisionResult.rate} ({language === 'ar' ? 'سنوياً' : 'p.a.'}) × {durationYears} {language === 'ar' ? 'سنوات' : 'yrs'} = <span className="text-amber-300 font-black">%{detailedBreakdown.totalProfitPercent}</span>
                  </span>
                </div>

                <div className="bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-400 block text-[10px]">{language === 'ar' ? '2. إجمالي مبلغ المرابحة (الأرباح):' : '2. Total Profit Amount:'}</span>
                  <span className="text-emerald-400 font-bold">
                    {formatCurrency(detailedBreakdown.totalProfitAmount)}
                  </span>
                </div>

                <div className="bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-400 block text-[10px]">{language === 'ar' ? '3. مجموع التمويل مع المرابحة:' : '3. Total Repayment with Profit:'}</span>
                  <span className="text-purple-300 font-bold">
                    {formatCurrency(loanAmount)} + {formatCurrency(detailedBreakdown.totalProfitAmount)} = <span className="text-white font-black">{formatCurrency(detailedBreakdown.totalRepaymentAmount)}</span>
                  </span>
                </div>

                <div className="bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
                  <span className="text-zinc-400 block text-[10px]">{language === 'ar' ? `4. القسط الشهري (قسمة على ${formatNumber(detailedBreakdown.totalMonths)} شهراً):` : `4. Monthly Installment (over ${formatNumber(detailedBreakdown.totalMonths)} mo):`}</span>
                  <span className="text-emerald-300 font-black">
                    {formatCurrency(monthlyInstallment)} / {language === 'ar' ? 'شهرياً' : 'mo'}
                  </span>
                </div>
              </div>
            </div>

            {/* Financial Calculations Summary */}
            <div className="grid grid-cols-3 gap-2 text-center pt-1">
              <div className="p-2 bg-zinc-950/80 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'القسط الشهري المتوقع' : 'Estimated Monthly'}</div>
                <div className="text-xs font-black text-emerald-400 font-mono mt-0.5">
                  {formatCurrency(monthlyInstallment)}
                </div>
              </div>

              <div className="p-2 bg-zinc-950/80 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'نسبة الاستقطاع DBR' : 'DBR Ratio'}</div>
                <div className={`text-xs font-black font-mono mt-0.5 ${dbrRate > 33.33 ? 'text-rose-400' : 'text-sky-300'}`}>
                  %{dbrRate}
                </div>
              </div>

              <div className="p-2 bg-zinc-950/80 rounded-xl border border-zinc-800">
                <div className="text-[10px] text-zinc-400">{language === 'ar' ? 'أقصى تمويل تقريبي' : 'Max Est. Loan'}</div>
                <div className="text-xs font-black text-amber-300 font-mono mt-0.5">
                  {formatCurrency(maxFinancing.maxEstimatedLoanAmount)}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-zinc-900/90 border-t border-zinc-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              onClose();
            }}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl font-bold text-xs transition-colors"
          >
            {t('cancel', 'إغلاق')}
          </button>

          {onApplyRate && (
            <button
              type="button"
              onClick={() => {
                triggerHaptic('medium');
                onApplyRate(decisionResult.rate);
                onClose();
              }}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-extrabold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 active:scale-95 transition-all"
            >
              <span>{language === 'ar' ? `اعتماد النسبة (%${decisionResult.rate}) في نموذج البيانات` : `Apply Rate (%${decisionResult.rate}) to Form`}</span>
              {dir === 'rtl' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
