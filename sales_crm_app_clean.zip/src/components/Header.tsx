import React, { useState, useEffect } from 'react';
import { useAuth, useCurrentPage } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { db } from '../db/db';
import {
  Bell,
  Settings,
  LayoutDashboard,
  Users,
  PlusCircle,
  BarChart3,
  ShieldCheck,
  Globe,
  Calendar,
  ChevronDown,
  Check,
  X,
  Smartphone,
  RefreshCw,
  Lock,
} from 'lucide-react';
import type { PageView } from '../types';
import { triggerHaptic } from '../utils/haptics';
import {
  getAvailableMonthOptions,
  formatMonthKeyToArabic,
  formatMonthKeyToEnglish,
  isValidMonthKey,
  type MonthOption,
} from '../utils/monthRollover';
import { useToast } from './Toast';
import { forceAppUpdateAndRefresh } from '../utils/appUpdate';

export const Header: React.FC = React.memo(() => {
  const {
    setCurrentPage,
    smartAlertsCount,
    selectedMonthKey,
    setSelectedMonthKey,
    settings,
    hasPinLock,
    lockApp,
  } = useAuth();
  const currentPage = useCurrentPage();
  const { t, language, toggleLanguage, formatNumber } = useLanguage();
  const { showToast } = useToast();
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [monthOptions, setMonthOptions] = useState<MonthOption[]>([]);

  // Performance optimization: only query customer month options when the modal is actually opened
  useEffect(() => {
    if (!showMonthDropdown) return;
    let active = true;
    db.customers
      .toArray()
      .then((all) => {
        if (active) setMonthOptions(getAvailableMonthOptions(all, [selectedMonthKey]));
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [showMonthDropdown, selectedMonthKey]);

  const titleMap: Record<PageView, { titleKey: string; icon: React.ReactNode }> = {
    dashboard: { titleKey: 'dashboard', icon: <LayoutDashboard className="w-5 h-5 text-sky-400" /> },
    customers: { titleKey: 'customers', icon: <Users className="w-5 h-5 text-sky-400" /> },
    addCustomer: { titleKey: 'addCustomer', icon: <PlusCircle className="w-5 h-5 text-cyan-400" /> },
    reports: { titleKey: 'reportsAndStats', icon: <BarChart3 className="w-5 h-5 text-blue-400" /> },
    reminders: { titleKey: 'reminders', icon: <Bell className="w-5 h-5 text-amber-400" /> },
    settings: { titleKey: 'settings', icon: <Settings className="w-5 h-5 text-sky-300" /> },
    admin: { titleKey: 'admin', icon: <ShieldCheck className="w-5 h-5 text-rose-400" /> },
  };

  const current = titleMap[currentPage] || titleMap.dashboard;

  return (
    <header className="sticky top-0 z-40 w-full max-w-full overflow-x-clip bg-[#0c1a30]/95 backdrop-blur-xl border-b border-sky-500/20 select-none shadow-lg shadow-sky-950/40 no-print">
      <div className="w-full max-w-md sm:max-w-lg md:max-w-2xl mx-auto px-2.5 sm:px-3.5 py-2 flex items-center justify-between gap-1.5 min-w-0">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-1">
          <div className="p-1.5 bg-[#13284a] rounded-xl border border-sky-400/25 shadow-inner shrink-0">
            {current.icon}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="font-extrabold text-[13px] sm:text-sm text-sky-50 tracking-tight truncate leading-tight">
              {t(current.titleKey)}
            </h1>
            {settings?.companyName && (
              <p className="text-[10px] text-sky-400/80 font-semibold truncate leading-tight">
                {settings.companyName}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {/* Active Month Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                triggerHaptic('light');
                setShowMonthDropdown(!showMonthDropdown);
              }}
              className="flex items-center gap-1 min-h-[36px] px-2 py-1.5 bg-indigo-950/90 hover:bg-indigo-900 text-indigo-100 rounded-xl border border-indigo-500/40 text-[11px] font-bold transition-transform duration-150 shadow-inner active:scale-95 whitespace-nowrap"
              title="اختر شهر العمل للعملاء والإنجازات"
            >
              <Calendar className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span className="font-semibold max-w-[60px] sm:max-w-[96px] truncate">
                {selectedMonthKey === 'all'
                  ? language === 'ar'
                    ? 'الكل'
                    : 'All'
                  : language === 'ar'
                  ? formatMonthKeyToArabic(selectedMonthKey)
                  : formatMonthKeyToEnglish(selectedMonthKey)}
              </span>
              <ChevronDown className="w-3 h-3 text-indigo-300 shrink-0" />
            </button>

            {showMonthDropdown && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
                <div className="absolute inset-0" onClick={() => setShowMonthDropdown(false)} />

                <div
                  className="relative w-full max-w-sm bg-slate-900 border border-sky-500/40 rounded-3xl shadow-2xl p-4 z-10 space-y-3 text-right"
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-indigo-950 rounded-xl border border-indigo-500/30 text-indigo-400">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-sky-100">
                          {t('selectMonthTitle', 'اختر شهر العمل والأنشطة')}
                        </h3>
                        <p className="text-[11px] text-sky-400/80 font-medium">
                          {t('selectMonthDesc', 'عرض وإدارة عملاء الشهر بشكل منفصل')}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowMonthDropdown(false)}
                      className="min-w-[40px] min-h-[40px] flex items-center justify-center text-zinc-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Direct jump to any month & year */}
                  <div className="flex items-center justify-between gap-2 bg-slate-950/70 border border-indigo-500/30 rounded-2xl px-3 py-2">
                    <span className="text-[11px] font-bold text-indigo-200 whitespace-nowrap">
                      {language === 'ar' ? 'انتقال لأي شهر/سنة:' : 'Jump to month/year:'}
                    </span>
                    <input
                      type="month"
                      value={isValidMonthKey(selectedMonthKey) ? selectedMonthKey : ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        if (isValidMonthKey(val)) {
                          triggerHaptic('medium');
                          setSelectedMonthKey(val);
                          setShowMonthDropdown(false);
                          showToast(
                            `${language === 'ar' ? 'تم اختيار شهر العمل:' : 'Selected month:'} ${
                              language === 'ar' ? formatMonthKeyToArabic(val) : formatMonthKeyToEnglish(val)
                            }`,
                            'info'
                          );
                        }
                      }}
                      className="bg-slate-900 border border-indigo-500/40 rounded-xl px-2.5 py-1 text-xs font-mono font-bold text-indigo-100 focus:outline-none focus:border-indigo-400"
                      dir="ltr"
                      aria-label={language === 'ar' ? 'تحديد أي شهر وسنة' : 'Pick any month and year'}
                    />
                  </div>

                  <div className="max-h-72 overflow-y-auto space-y-1.5 pr-0.5">
                    {monthOptions.map((opt) => {
                      const isSelected = selectedMonthKey === opt.key;
                      return (
                        <button
                          key={opt.key}
                          onClick={() => {
                            triggerHaptic('medium');
                            setSelectedMonthKey(opt.key);
                            setShowMonthDropdown(false);
                            showToast(
                              opt.key === 'all'
                                ? language === 'ar'
                                  ? 'تم تحديد عرض جميع الشهور'
                                  : 'Showing all months'
                                : `${language === 'ar' ? 'تم اختيار شهر العمل:' : 'Selected month:'} ${
                                    language === 'ar' ? opt.labelAr : opt.labelEn
                                  }`,
                              'info'
                            );
                          }}
                          className={`w-full min-h-[44px] text-right p-3 rounded-2xl text-xs font-semibold flex items-center justify-between transition-colors border ${
                            isSelected
                              ? 'bg-indigo-600 text-white font-extrabold border-indigo-400 shadow-lg shadow-indigo-600/30'
                              : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700/60 hover:text-white'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {isSelected ? (
                              <Check className="w-4 h-4 text-indigo-200 shrink-0" />
                            ) : (
                              <div className="w-2 h-2 rounded-full bg-slate-600 shrink-0" />
                            )}
                            <span className="text-xs sm:text-sm">
                              {language === 'ar' ? opt.labelAr : opt.labelEn}
                            </span>
                          </div>
                          {opt.count !== undefined && (
                            <span
                              className={`text-[11px] px-2.5 py-1 rounded-full font-bold font-mono tabular-nums ${
                                isSelected
                                  ? 'bg-indigo-700 text-white'
                                  : 'bg-slate-900 text-sky-300 border border-slate-700'
                              }`}
                            >
                              {formatNumber(opt.count)} {t('customersCount', 'عميل')}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="pt-1 border-t border-slate-800 text-center">
                    <button
                      onClick={() => setShowMonthDropdown(false)}
                      className="w-full min-h-[40px] py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-colors"
                    >
                      {t('close', 'إغلاق')}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick PIN Lock Button (Shown when PIN Lock is configured) */}
          {hasPinLock && (
            <button
              onClick={() => {
                triggerHaptic('medium');
                lockApp();
              }}
              className="flex items-center justify-center min-w-[36px] min-h-[36px] p-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 rounded-xl border border-amber-400/35 transition-transform duration-150 active:scale-90"
              title={language === 'ar' ? 'قفل التطبيق فوراً' : 'Lock App Now'}
            >
              <Lock className="w-4 h-4 text-amber-300" />
            </button>
          )}

          {/* Quick PWA Mobile Install Button */}
          <button
            onClick={() => {
              triggerHaptic('medium');
              window.dispatchEvent(new CustomEvent('open-pwa-install-dialog'));
            }}
            className="flex items-center justify-center min-w-[36px] min-h-[36px] p-1.5 bg-gradient-to-r from-sky-500/20 to-blue-600/20 hover:from-sky-500/30 hover:to-blue-600/30 text-sky-300 rounded-xl border border-sky-400/40 transition-transform duration-150 active:scale-90"
            title={language === 'ar' ? 'تثبيت التطبيق على الجوال' : 'Install Mobile App'}
          >
            <Smartphone className="w-4 h-4 text-sky-400" />
          </button>

          {/* Quick App Refresh / Update Button */}
          <button
            onClick={() => {
              triggerHaptic('light');
              showToast(
                language === 'ar'
                  ? 'جاري تحديث التطبيق ومسح الكاش للنسخة الأحدث... 🔄'
                  : 'Refreshing app to latest build... 🔄',
                'info'
              );
              setTimeout(() => {
                forceAppUpdateAndRefresh();
              }, 500);
            }}
            className="flex items-center justify-center min-w-[36px] min-h-[36px] p-1.5 bg-[#13284a]/90 hover:bg-[#1a345e] text-emerald-300 rounded-xl border border-emerald-500/30 transition-transform duration-150 active:scale-90"
            title={language === 'ar' ? 'تحديث التطبيق ومسح الكاش' : 'Refresh App & Clear Cache'}
          >
            <RefreshCw className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Language Switcher Button */}
          <button
            onClick={() => {
              triggerHaptic('light');
              toggleLanguage();
            }}
            className="flex items-center gap-1 min-h-[36px] px-2 py-1.5 bg-[#13284a]/90 hover:bg-[#1a345e] text-sky-200 rounded-xl border border-sky-400/25 text-[11px] font-bold transition-transform duration-150 active:scale-90"
            title={language === 'ar' ? 'Switch to English' : 'التحويل للعربية'}
          >
            <Globe className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="font-mono uppercase">{language === 'ar' ? 'EN' : 'ع'}</span>
          </button>

          {currentPage !== 'reminders' && (
            <button
              onClick={() => {
                triggerHaptic('light');
                setCurrentPage('reminders');
              }}
              className="relative flex items-center justify-center min-w-[36px] min-h-[36px] p-1.5 bg-[#13284a]/90 hover:bg-[#1a345e] text-sky-200 rounded-xl border border-sky-400/25 transition-transform duration-150 active:scale-90"
              title={t('reminders')}
            >
              <Bell className="w-4 h-4 text-sky-200" />
              {smartAlertsCount > 0 && (
                <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-4 h-4 px-1 bg-amber-400 text-slate-950 font-black text-[10px] font-mono tabular-nums rounded-full shadow-lg">
                  {smartAlertsCount > 99 ? '99+' : formatNumber(smartAlertsCount)}
                </span>
              )}
            </button>
          )}
        </div>
      </div>
    </header>
  );
});
