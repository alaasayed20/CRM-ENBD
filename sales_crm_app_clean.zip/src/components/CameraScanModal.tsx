import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, Upload, X, Sparkles, Check, RefreshCw, AlertCircle, 
  Users, Trash2, CheckSquare, Square, Edit3, FileText, Calendar 
} from 'lucide-react';
import { useToast } from './Toast';
import { db, enrichAndAddCustomers } from '../db/db';
import type { CustomerStatus, ProductType } from '../types';
import { parseVCFToCustomers, parseCSVWithMetadata, readImportFileText, downloadSampleCSVTemplate } from '../utils/vcard';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getCurrentMonthKey, getAvailableMonthOptions } from '../utils/monthRollover';
import { getScanSessionToken, clearScanSessionToken } from '../utils/security';

export interface ScannedCustomerData {
  name?: string;
  phone?: string;
  idNumber?: string;
  email?: string;
  productType?: 'visa' | 'finance';
  salary?: number;
  amount?: number;
  cardTypeName?: string;
  cardTypeId?: number;
  financeType?: 'salary_transfer' | 'no_salary_transfer' | string;
  financeRate?: number;
  notes?: string;
  selected?: boolean;
}

interface CameraScanModalProps {
  onClose: () => void;
  onExtracted?: (data: ScannedCustomerData) => void;
  onBatchSaved?: (count: number) => void;
}

export const CameraScanModal: React.FC<CameraScanModalProps> = ({ onClose, onExtracted, onBatchSaved }) => {
  const { showToast } = useToast();
  const { selectedMonthKey } = useAuth();
  const { t, language, dir } = useLanguage();
  
  const [mode, setMode] = useState<'options' | 'camera' | 'preview'>('options');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [scanError, setScanError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [extractedList, setExtractedList] = useState<ScannedCustomerData[]>([]);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [savingBatch, setSavingBatch] = useState(false);

  const [importTargetMonth, setImportTargetMonth] = useState<string>(() => {
    return selectedMonthKey !== 'all' ? selectedMonthKey : getCurrentMonthKey();
  });
  const [importGeneralNotes, setImportGeneralNotes] = useState<string>('');
  const [importedFileName, setImportedFileName] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    setCameraError(null);
    setMode('camera');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setCameraError(language === 'ar' ? 'تعذر فتح الكاميرا، يرجى منح الإذن أو اختيار صورة من المعرض.' : 'Camera access denied.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      setImageMime('image/jpeg');
      stopCamera();
      setMode('preview');
      processImage(dataUrl, 'image/jpeg');
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setScanError(null);
    const fileName = file.name.toLowerCase();

    // استيراد جهات الاتصال وملفات الجداول VCF / CSV محلياً دون أي اتصال خارجي
    if (fileName.endsWith('.vcf') || fileName.endsWith('.csv') || fileName.endsWith('.txt') || fileName.endsWith('.tsv')) {
      try {
        setLoading(true);
        stopCamera();
        setMode('preview');
        const text = await readImportFileText(file);
        const isVCard = /BEGIN:VCARD/i.test(text);
        const parsed = isVCard ? parseVCFToCustomers(text) : parseCSVWithMetadata(text).customers;
        if (parsed.length === 0) {
          setScanError(language === 'ar' ? 'لم يتم العثور على عملاء صالحين بالملف.' : 'No valid customers found.');
          showToast(language === 'ar' ? 'الملف فارغ أو غير متطابق' : 'File is empty', 'warning');
          addManualRow();
        } else {
          const formatted: ScannedCustomerData[] = parsed.map((c) => ({
            name: c.name || '',
            phone: c.phone || '',
            idNumber: c.idNumber || '',
            email: c.email || '',
            productType: (c.productType as any) || 'visa',
            salary: c.salary,
            amount: c.amount,
            cardTypeName: c.cardTypeName,
            cardTypeId: c.cardTypeId,
            notes: c.notes || '',
            selected: true,
          }));
          const notesCount = formatted.filter((c) => Boolean(c.notes && c.notes.trim())).length;
          setImportedFileName(file.name);
          setExtractedList(formatted);
          showToast(
            language === 'ar'
              ? notesCount > 0
                ? `تم استيراد ${formatted.length} عميل (${notesCount} بملاحظات Notes) بنجاح`
                : `تم استيراد ${formatted.length} عميل بنجاح`
              : notesCount > 0
                ? `Imported ${formatted.length} customers (${notesCount} with Notes)`
                : `Imported ${formatted.length} customers`,
            'success'
          );
        }
      } catch (err: any) {
        console.error('File parsing error:', err);
        setScanError(language === 'ar' ? 'حدث خطأ أثناء قراءة الملف.' : 'Error reading file.');
        addManualRow();
      } finally {
        setLoading(false);
        e.target.value = '';
      }
      return;
    }

    if (!file.type.startsWith('image/')) {
      showToast(language === 'ar' ? 'يرجى اختيار صورة أو ملف VCF/CSV' : 'Please select an image or VCF/CSV file', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setImagePreview(result);
      setImageMime(file.type || 'image/jpeg');
      stopCamera();
      setMode('preview');
      processImage(result, file.type || 'image/jpeg');
    };
    reader.readAsDataURL(file);
  };

  /**
   * معالجة الصورة عبر خادم التطبيق المحصّن /api/scan-customer برمز جلسة موقّع في الذاكرة فقط
   */
  const processImage = async (base64Data: string, mime: string) => {
    setLoading(true);
    setScanError(null);
    setExtractedList([]);

    const cleanBase64 = base64Data.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '');
    let rawList: any[] = [];
    let handled = false;
    let serverErrorMessage: string | null = null;

    const callScanApi = async (token: string) => {
      return fetch('/api/scan-customer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'X-Requested-With': 'SalesCRM-Client',
        },
        body: JSON.stringify({ imageBase64: cleanBase64, mimeType: mime }),
      });
    };

    try {
      let token = await getScanSessionToken();
      if (token) {
        let serverRes = await callScanApi(token);
        // Retry once with a fresh token if the previous token expired
        if (serverRes.status === 401) {
          clearScanSessionToken();
          token = await getScanSessionToken();
          if (token) {
            serverRes = await callScanApi(token);
          }
        }

        if (serverRes.ok) {
          const resData = await serverRes.json();
          if (resData && resData.success && resData.data) {
            if (Array.isArray(resData.data.customers)) {
              rawList = resData.data.customers;
              handled = true;
            } else if (typeof resData.data === 'object') {
              rawList = [resData.data];
              handled = true;
            }
          }
        } else {
          try {
            const errBody = await serverRes.json();
            if (errBody?.error) serverErrorMessage = String(errBody.error);
          } catch {
            // ignore non-JSON error
          }
        }
      }
    } catch {
      // Offline or unreachable server — cleanly fall back to manual row entry
    }

    if (handled && rawList.length > 0) {
      const formatted: ScannedCustomerData[] = rawList
        .filter((c) => c && (c.name || c.phone))
        .map((c) => ({
          name: c.name || (language === 'ar' ? 'عميل مستخرج' : 'Extracted Client'),
          phone: c.phone ? String(c.phone).trim() : '',
          idNumber: c.idNumber ? String(c.idNumber).trim() : '',
          email: c.email || '',
          productType: (c.productType === 'finance' ? 'finance' : 'visa') as 'visa' | 'finance',
          salary: typeof c.salary === 'number' ? c.salary : (parseFloat(String(c.salary)) || undefined),
          amount: typeof c.amount === 'number' ? c.amount : (parseFloat(String(c.amount)) || undefined),
          cardTypeName: c.cardTypeName || undefined,
          financeType: (c.financeType === 'no_salary_transfer' || c.financeType === 'بدون تحويل راتب' ? 'no_salary_transfer' : 'salary_transfer') as 'salary_transfer' | 'no_salary_transfer',
          notes: c.notes || '',
          selected: true,
        }));

      setExtractedList(formatted);
      setLoading(false);
      showToast(language === 'ar' ? `تم استخراج ${formatted.length} عميل بنجاح` : `Extracted ${formatted.length} customers`, 'success');
      return;
    }

    setLoading(false);
    setScanError(
      serverErrorMessage ||
        (language === 'ar'
          ? 'لم يتم التعرف التلقائي على الصورة (أو أنت في وضع عدم الاتصال). يمكنك إدخال بيانات العميل يدوياً بالأسفل أو استيراد ملف CSV/VCF.'
          : 'Could not scan automatically (or you are offline). You can enter customer details manually below or import CSV/VCF.')
    );
    addManualRow();
  };

  const addManualRow = () => {
    setExtractedList((prev) => [
      ...prev,
      {
        name: '',
        phone: '',
        productType: 'visa',
        selected: true,
      },
    ]);
    setScanError(null);
  };

  const toggleSelect = (index: number) => {
    setExtractedList((prev) =>
      prev.map((item, idx) => (idx === index ? { ...item, selected: !item.selected } : item))
    );
  };

  const toggleSelectAll = () => {
    const allSelected = extractedList.every((item) => item.selected);
    setExtractedList((prev) => prev.map((item) => ({ ...item, selected: !allSelected })));
  };

  const updateItem = (index: number, field: keyof ScannedCustomerData, value: any) => {
    setExtractedList((prev) =>
      prev.map((item, idx) => (idx === index ? { ...item, [field]: value } : item))
    );
  };

  const removeItem = (index: number) => {
    setExtractedList((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleApplySingle = (item: ScannedCustomerData) => {
    if (onExtracted) {
      onExtracted(item);
      onClose();
    }
  };

  const handleSaveBatch = async () => {
    const selectedCustomers = extractedList.filter((c) => c.selected);
    if (selectedCustomers.length === 0) {
      showToast(language === 'ar' ? 'يرجى تحديد عميل واحد على الأقل' : 'Select at least one client', 'warning');
      return;
    }
    setSavingBatch(true);
    try {
      const generalNote = importGeneralNotes.trim();
      const preparedCustomers = selectedCustomers.map((c) => {
        const custNote = c.notes ? String(c.notes).trim() : '';
        const mergedNotes = [custNote, generalNote].filter(Boolean).join(' | ');
        return {
          ...c,
          notes: mergedNotes || undefined,
        };
      });

      const addedCount = await enrichAndAddCustomers(preparedCustomers, {
        defaultStatus: 'عميل محتمل',
        sourceTag: importedFileName
          ? (language === 'ar' ? `استيراد من ${importedFileName}` : `Import from ${importedFileName}`)
          : 'مسح كاميرا / هاتف',
        targetMonth: importTargetMonth,
      });
      showToast(language === 'ar' ? `تمت إضافة ${addedCount} عميل إلى قاعدة البيانات بنجاح` : `Added ${addedCount} customers successfully`, 'success');
      if (onBatchSaved) {
        onBatchSaved(addedCount);
      } else if (onExtracted && selectedCustomers.length === 1) {
        onExtracted(selectedCustomers[0]);
      }
      onClose();
    } catch (err: any) {
      console.error('Batch add error:', err);
      showToast(language === 'ar' ? 'خطأ أثناء الحفظ في قاعدة البيانات' : 'Error saving batch', 'error');
    } finally {
      setSavingBatch(false);
    }
  };

  const selectedCount = extractedList.filter((c) => c.selected).length;

  return (
    <div dir={dir} className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-['Tajawal',sans-serif] animate-fadeIn">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl relative flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-500/20 rounded-2xl text-indigo-400 border border-indigo-500/30">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-zinc-100 flex items-center gap-2">
                <span>{t('scanCameraAndTable', 'مسح ذكي بالكاميرا والمستندات')}</span>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                  Offline Ready
                </span>
              </h3>
              <p className="text-[11px] text-zinc-400">{t('scanSubtitle', 'استخراج تلقائي بدون سيرفر خارجي')}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                stopCamera();
                onClose();
              }}
              className="p-2 text-zinc-400 hover:text-zinc-100 rounded-xl hover:bg-zinc-800 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {mode === 'options' && (
            <div className="space-y-4 py-4">
              <div className="bg-zinc-950/80 border border-zinc-800 p-4 rounded-2xl text-center space-y-2">
                <Users className="w-8 h-8 text-indigo-400 mx-auto" />
                <h4 className="text-xs font-bold text-zinc-200">{t('scanBatchIntroTitle', 'استيراد ومسح سريع للعملاء')}</h4>
                <p className="text-xs text-zinc-400 leading-relaxed max-w-xs mx-auto">
                  {t('scanBatchIntroDesc', 'يمكنك التقاط صورة، أو رفع ملفات جهات الاتصال (VCF/CSV) مباشرة محلياً دون إنترنت!')}
                </p>
              </div>

              <button
                onClick={startCamera}
                className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold py-3.5 px-4 rounded-2xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-3 active:scale-98 transition-all"
              >
                <Camera className="w-5 h-5" />
                <span>{t('openCamera', 'فتح الكاميرا المباشرة')}</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-bold py-3.5 px-4 rounded-2xl border border-zinc-700 flex items-center justify-center gap-3 active:scale-98 transition-all"
              >
                <Upload className="w-5 h-5 text-emerald-400" />
                <span>{t('uploadImageOrVcf', 'اختيار صورة أو ملف VCF / CSV')}</span>
              </button>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    downloadSampleCSVTemplate();
                    showToast(language === 'ar' ? 'تم تنزيل قالب CSV التجريبي' : 'Sample CSV Template downloaded', 'success');
                  }}
                  className="w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold py-2.5 px-4 rounded-2xl text-xs flex items-center justify-center gap-2 transition-all active:scale-98"
                >
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>{t('downloadSampleCsv', 'تحميل نموذج جاهز للعملاء (.csv)')}</span>
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.vcf,.csv,.txt,.tsv"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          )}

          {mode === 'camera' && (
            <div className="space-y-3">
              {cameraError ? (
                <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-center space-y-2">
                  <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
                  <p className="text-xs text-rose-300 font-bold">{cameraError}</p>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold py-2 px-4 rounded-xl"
                  >
                    {t('chooseImageInstead', 'اختيار صورة من المعرض')}
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.vcf,.csv,.txt,.tsv"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden bg-black aspect-video border border-zinc-800 shadow-inner flex items-center justify-center">
                  <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  <canvas ref={canvasRef} className="hidden" />
                  <div className="absolute inset-4 border-2 border-dashed border-indigo-400/70 rounded-xl pointer-events-none flex items-center justify-center">
                    <span className="bg-black/70 text-indigo-200 text-[11px] px-3 py-1.5 rounded-lg font-bold shadow-lg">
                      {t('cameraGuideText', 'وجّه الكاميرا نحو المستند أو الجدول')}
                    </span>
                  </div>
                </div>
              )}

              {!cameraError && (
                <div className="flex gap-2">
                  <button
                    onClick={capturePhoto}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black py-3 rounded-2xl shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                  >
                    <Camera className="w-5 h-5" />
                    <span>{t('captureAndProcess', 'التقاط ومعالجة')}</span>
                  </button>
                  <button
                    onClick={() => {
                      stopCamera();
                      setMode('options');
                    }}
                    className="px-4 bg-zinc-800 text-zinc-300 font-bold rounded-2xl border border-zinc-700"
                  >
                    {t('cancel', 'إلغاء')}
                  </button>
                </div>
              )}
            </div>
          )}

          {mode === 'preview' && (
            <div className="space-y-4">
              {imagePreview && (
                <div className="relative rounded-2xl overflow-hidden border border-zinc-800 max-h-40 bg-black/80 flex items-center justify-center">
                  <img src={imagePreview} alt="Scanned document" className="max-h-40 object-contain" />
                  {loading && (
                    <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center gap-2 p-4 text-center">
                      <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
                      <span className="text-xs font-bold text-indigo-200 animate-pulse">
                        {t('analyzingImage', 'جاري معالجة البيانات واستخراج العملاء...')}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {!loading && scanError && (
                <div className={`p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl space-y-2 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                  <div className="flex items-center gap-2 text-amber-400 font-extrabold text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{t('warning', 'تنبيه')}</span>
                  </div>
                  <p className="text-xs text-amber-200/90 leading-relaxed font-medium">
                    {scanError}
                  </p>
                  <button
                    type="button"
                    onClick={addManualRow}
                    className="mt-1 bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-black py-2 px-3.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5"
                  >
                    <span>{t('addCustomerManuallyHere', '+ إضافة العميل يدوياً هنا')}</span>
                  </button>
                </div>
              )}

              {!loading && (extractedList.length > 0 || scanError) && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between bg-zinc-950 p-3 rounded-2xl border border-zinc-800">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={toggleSelectAll}
                        className="text-indigo-400 hover:text-indigo-300"
                      >
                        {extractedList.length > 0 && extractedList.every((item) => item.selected) ? (
                          <CheckSquare className="w-5 h-5" />
                        ) : (
                          <Square className="w-5 h-5 text-zinc-500" />
                        )}
                      </button>
                      <span className="text-xs font-bold text-zinc-200">
                        {t('customersInList', 'العملاء المستخرجون')} (<span className="text-indigo-400 font-mono font-extrabold">{extractedList.length}</span>)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={addManualRow}
                      className="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 px-2.5 py-1 rounded-full border border-indigo-500/20"
                    >
                      {t('addRow', '+ إضافة صف')}
                    </button>
                  </div>

                  <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                    {extractedList.map((cust, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-2xl border transition-all flex items-start gap-2.5 ${
                          cust.selected
                            ? 'bg-zinc-950/90 border-indigo-500/40'
                            : 'bg-zinc-950/40 border-zinc-800/60 opacity-60'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => toggleSelect(idx)}
                          className="mt-1 text-indigo-400 hover:text-indigo-300 shrink-0"
                        >
                          {cust.selected ? (
                            <CheckSquare className="w-4 h-4" />
                          ) : (
                            <Square className="w-4 h-4 text-zinc-600" />
                          )}
                        </button>
                        <div className="flex-1 space-y-1 text-xs">
                          <input
                            type="text"
                            value={cust.name || ''}
                            onChange={(e) => updateItem(idx, 'name', e.target.value)}
                            placeholder={t('clientFullName', 'اسم العميل')}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1 text-zinc-100 font-bold text-xs focus:border-indigo-500 focus:outline-none"
                          />
                          <input
                            type="text"
                            value={cust.phone || ''}
                            onChange={(e) => updateItem(idx, 'phone', e.target.value)}
                            placeholder={t('phoneNumber', 'رقم الجوال (05xxxxxxx)')}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1 text-indigo-300 font-mono text-xs focus:border-indigo-500 focus:outline-none dir-ltr text-right"
                          />
                          <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                            <input
                              type="number"
                              value={cust.salary || ''}
                              onChange={(e) => updateItem(idx, 'salary', parseFloat(e.target.value) || undefined)}
                              placeholder="الراتب: 15000"
                              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1 text-emerald-400 font-mono text-[11px] focus:border-indigo-500 focus:outline-none dir-ltr text-right"
                            />
                            <input
                              type="text"
                              value={cust.cardTypeName || ''}
                              onChange={(e) => updateItem(idx, 'cardTypeName', e.target.value)}
                              placeholder="نوع البطاقة"
                              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1 text-amber-300 font-bold text-[11px] focus:border-indigo-500 focus:outline-none"
                            />
                          </div>
                          <div className={`rounded-lg px-2 py-1.5 mt-1 border space-y-1 ${cust.notes && cust.notes.trim() ? 'bg-emerald-950/25 border-emerald-500/35 focus-within:border-emerald-400' : 'bg-zinc-900 border-zinc-800 focus-within:border-indigo-500'}`}>
                            <div className="flex items-center justify-between gap-1 text-[10px]">
                              <span className="font-bold text-amber-300 flex items-center gap-1">
                                <FileText className="w-3 h-3 text-amber-400 shrink-0" />
                                <span>{language === 'ar' ? 'الملاحظات (Notes):' : 'Notes:'}</span>
                              </span>
                              {cust.notes && cust.notes.trim() && (
                                <span className="text-[9px] text-emerald-300 font-bold">✓</span>
                              )}
                            </div>
                            <input
                              type="text"
                              value={cust.notes || ''}
                              onChange={(e) => updateItem(idx, 'notes', e.target.value)}
                              placeholder={language === 'ar' ? 'ملاحظات العميل (اختياري)...' : 'Customer notes (optional)...'}
                              className="w-full bg-transparent text-zinc-100 placeholder:text-zinc-500 text-[11px] focus:outline-none"
                            />
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeItem(idx)}
                          className="p-1.5 text-zinc-500 hover:text-rose-400 rounded-lg hover:bg-zinc-900 transition-all shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* أزرار الحفظ والاستيراد */}
              {!loading && (
                <div className="space-y-2 pt-2">
                  {extractedList.length > 0 && (
                    <>
                      <div className="bg-indigo-950/70 border border-indigo-500/40 p-2.5 rounded-2xl space-y-1.5">
                        <label className="text-[11px] font-bold text-indigo-200 flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{t('targetMonthLabel', 'الشهر المستهدف للإضافة')}:</span>
                        </label>
                        <div className="flex items-center gap-1.5">
                          <select
                            value={importTargetMonth}
                            onChange={(e) => setImportTargetMonth(e.target.value)}
                            className="flex-1 min-w-0 bg-zinc-950 border border-indigo-500/40 rounded-xl py-1.5 px-2.5 text-xs font-bold text-indigo-100 focus:outline-none focus:border-indigo-400 cursor-pointer shadow-sm"
                          >
                            {getAvailableMonthOptions(undefined, [importTargetMonth]).filter(m => m.key !== 'all').map((m) => (
                              <option key={m.key} value={m.key}>
                                {language === 'ar' ? m.labelAr : m.labelEn} {m.isCurrent ? (language === 'ar' ? '(الشهر الحالي)' : '(Current Month)') : ''}
                              </option>
                            ))}
                          </select>
                          <input
                            type="month"
                            value={importTargetMonth}
                            onChange={(e) => {
                              if (e.target.value) setImportTargetMonth(e.target.value);
                            }}
                            className="bg-zinc-950 border border-indigo-500/40 rounded-xl py-1 px-2 text-xs font-mono font-bold text-indigo-100 focus:outline-none focus:border-indigo-400"
                            dir="ltr"
                            aria-label={language === 'ar' ? 'تحديد أي شهر وسنة' : 'Pick any month and year'}
                          />
                        </div>
                      </div>

                      <div className="bg-zinc-950/80 border border-zinc-800 p-2.5 rounded-2xl space-y-1">
                        <label className="text-[11px] font-bold text-amber-300 flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-amber-400" />
                          <span>
                            {language === 'ar'
                              ? 'ملاحظة عامة تضاف لجميع العملاء المستوردين (اختياري):'
                              : 'General note added to all imported customers (optional):'}
                          </span>
                        </label>
                        <input
                          type="text"
                          value={importGeneralNotes}
                          onChange={(e) => setImportGeneralNotes(e.target.value)}
                          placeholder={language === 'ar' ? 'أضف ملاحظة عامة تطبق على جميع العملاء المحددين...' : 'Add a general note applied to all selected customers...'}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-1.5 px-2.5 text-xs text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:border-amber-500/60"
                        />
                      </div>
                      
                      <div className="flex gap-2">
                        {extractedList.length === 1 && onExtracted ? (
                          <button
                            onClick={() => handleApplySingle(extractedList[0])}
                            className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-100 font-bold py-3 rounded-2xl border border-zinc-700 text-xs flex items-center justify-center gap-2"
                          >
                            <Edit3 className="w-4 h-4 text-indigo-400" />
                            <span>{t('fillAddFormWithIt', 'تعبئة استمارة الإضافة به')}</span>
                          </button>
                        ) : null}
                        <button
                          onClick={handleSaveBatch}
                          disabled={savingBatch || selectedCount === 0}
                          className="flex-1 bg-gradient-to-r from-emerald-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-extrabold py-3.5 px-4 rounded-2xl shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 active:scale-95 transition-all text-xs disabled:opacity-50"
                        >
                          {savingBatch ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                          <span>
                            {t('saveAndImportAll', 'حفظ واستيراد ({count}) عملاء').replace('{count}', String(selectedCount))}
                          </span>
                        </button>
                      </div>
                    </>
                  )}

                  <button
                    onClick={() => {
                      setImportedFileName(null);
                      setImportGeneralNotes('');
                      setMode('options');
                    }}
                    className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold py-2.5 rounded-2xl border border-zinc-700 text-xs flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>{t('retakeAnotherPhoto', 'مسح أو اختيار مستند آخر')}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
