import React, { Component, ErrorInfo, ReactNode } from 'react';
import { isChunkLoadError, recoverFromStaleChunk } from '../utils/lazyWithRetry';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error in application:', error, errorInfo);
    if (isChunkLoadError(error)) {
      recoverFromStaleChunk();
    }
  }

  private handleReset = async () => {
    try {
      localStorage.removeItem('selected_active_month');
      if ('serviceWorker' in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map((reg) => reg.unregister()));
      }
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }
    } catch {
      // Ignore
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          className="min-h-screen bg-slate-900 text-slate-100 flex items-center justify-center p-4 font-['Tajawal',sans-serif]"
        >
          <div className="max-w-md w-full bg-slate-800/90 border border-slate-700 p-6 rounded-3xl shadow-2xl text-center space-y-4 backdrop-blur-md">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center text-2xl border border-rose-500/30">
              ⚠️
            </div>
            <div>
              <h2 className="text-base font-black text-white">حدث خطأ غير متوقع أثناء فتح التطبيق</h2>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                يمكنك إعادة تشغيل التطبيق وتحديث الذاكرة بالضغط على الزر أدناه للعودة للعمل بشكل طبيعي.
              </p>
            </div>
            {this.state.error && (
              <div className="p-3 bg-slate-950/80 rounded-xl text-[11px] font-mono text-rose-300 text-left overflow-x-auto max-h-24 border border-rose-500/20">
                {this.state.error.message}
              </div>
            )}
            <button
              onClick={this.handleReset}
              className="w-full py-3 px-4 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-sky-600/30 active:scale-95 transition-all"
            >
              🔄 إعادة تشغيل وتحديث التطبيق الآن
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
