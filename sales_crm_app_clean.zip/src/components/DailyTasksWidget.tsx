import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, logOperation } from '../db/db';
import { useLanguage } from '../context/LanguageContext';
import { useToast } from '../components/Toast';
import { triggerHaptic } from '../utils/haptics';
import { buildSafeTelHref, buildSafeWhatsAppHref } from '../utils/security';
import { ConfirmModal } from '../components/ConfirmModal';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Plus,
  Phone,
  MessageCircle,
  ChevronLeft,
  ChevronRight,
  X,
  FileText,
  UserCheck,
  Check,
  RotateCcw,
  Tag,
  AlertCircle,
  Trash2
} from 'lucide-react';
import type { Customer, DailyTask, TaskStatus, TaskType } from '../types';

interface DailyTasksWidgetProps {
  onSelectCustomer?: (customerId: number) => void;
  externalCustomers?: Customer[];
}

const EMPTY_CUSTOMERS: Customer[] = [];
const EMPTY_TASKS: DailyTask[] = [];

export const DailyTasksWidget: React.FC<DailyTasksWidgetProps> = React.memo(({ onSelectCustomer, externalCustomers }) => {
  const { t, formatNumber, dir, language } = useLanguage();
  const { showToast } = useToast();

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [showPostponeModal, setShowPostponeModal] = useState<DailyTask | null>(null);
  const [postponeNewDate, setPostponeNewDate] = useState<string>('');

  // Form states for new task modal
  const [taskTitle, setTaskTitle] = useState('');
  const [taskType, setTaskType] = useState<TaskType>('followup');
  const [taskTime, setTaskTime] = useState('');
  const [taskPriority, setTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [taskCustomerId, setTaskCustomerId] = useState<number | null>(null);
  const [taskNotes, setTaskNotes] = useState('');

  // Reuse customers passed from DashboardPage to avoid a duplicate full-table IndexedDB scan
  const queriedCustomers = useLiveQuery(
    () => (externalCustomers ? Promise.resolve(externalCustomers) : db.customers.toArray()),
    [Boolean(externalCustomers)]
  );
  const customers = externalCustomers ?? queriedCustomers ?? EMPTY_CUSTOMERS;
  const dbTasks = useLiveQuery(() => db.tasks.toArray(), []) ?? EMPTY_TASKS;

  const todayStr = new Date().toISOString().split('T')[0];
  const isTodaySelected = selectedDate === todayStr;

  // Handle Date Navigation
  const changeDateBy = (days: number) => {
    triggerHaptic('light');
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  // Build merged tasks list using O(1) Set index for maximum performance
  const allDailyTasks = useMemo(() => {
    // 1. Direct DB tasks for selectedDate (excluding soft-deleted tasks)
    const currentDbTasks: DailyTask[] = [];
    const existingTaskKeys = new Set<string>();

    for (const task of dbTasks) {
      if (task.customerId && task.type && task.date) {
        existingTaskKeys.add(`${task.customerId}|${task.type}|${task.date}`);
      }
      if (task.date === selectedDate && (task.status as string) !== 'deleted') {
        currentDbTasks.push(task);
      }
    }

    // 2. Generate dynamic customer follow-up / activation / note tasks for selectedDate if not already explicitly recorded in DB
    const generatedCustomerTasks: DailyTask[] = [];
    const generatedKeys = new Set<string>();

    for (const c of customers) {
      if (!c.id) continue;

      // A. Scheduled Follow Up Date or Status 'متابعة'
      if (c.followUpDate || c.status === 'متابعة') {
        const isSameDate = c.followUpDate === selectedDate;
        const isOverdueFollowup = isTodaySelected && c.followUpDate && c.followUpDate < todayStr && c.status !== 'مكتمل';
        const isFollowupStatusToday = isTodaySelected && c.status === 'متابعة' && (!c.followUpDate || c.followUpDate === todayStr);

        if (isSameDate || isOverdueFollowup || isFollowupStatusToday) {
          const hasExisting =
            existingTaskKeys.has(`${c.id}|followup|${selectedDate}`) ||
            (c.followUpDate ? existingTaskKeys.has(`${c.id}|followup|${c.followUpDate}`) : false);
          if (!hasExisting) {
            generatedCustomerTasks.push({
              customerId: c.id,
              title: language === 'ar'
                ? `متابعة العميل ${c.name} (${c.orderNumber ? '#' + c.orderNumber : ''})`
                : `Follow-up: ${c.name} (${c.orderNumber ? '#' + c.orderNumber : ''})`,
              type: 'followup',
              date: selectedDate,
              status: c.status === 'مكتمل' ? 'completed' : isOverdueFollowup ? 'postponed' : 'pending',
              notes: c.notes || (language === 'ar' ? `موعد متابعة مسجل للعميل` : `Scheduled follow-up for client`),
              priority: isOverdueFollowup ? 'high' : 'medium',
              createdAt: new Date(c.createdAt)
            });
          }
        }
      }

      // B. Pending Activations (تم التنفيذ / بانتظار التفعيل) for today
      if (isTodaySelected && c.productType === 'visa' && (c.status === 'تم التنفيذ' || c.status === 'بانتظار التفعيل')) {
        const actKey = `${c.id}|activation|${selectedDate}`;
        if (!existingTaskKeys.has(actKey) && !generatedKeys.has(actKey)) {
          generatedKeys.add(actKey);
          generatedCustomerTasks.push({
            customerId: c.id,
            title: language === 'ar' ? `متابعة تفعيل طلب العميل ${c.name}` : `Follow up activation: ${c.name}`,
            type: 'activation',
            date: selectedDate,
            status: 'pending',
            notes: language === 'ar' ? 'طلب بانتظار التفعيل النهائي لاستحقاق النقاط' : 'Order pending final activation for points',
            priority: 'high',
            createdAt: new Date(c.createdAt)
          });
        }
      }

      // C. Notes containing specific appointment keywords for selected date
      if (c.notes && c.notes.trim().length > 0 && isTodaySelected) {
        const notesLower = c.notes.toLowerCase();
        const hasAppointmentKeyword =
          c.notes.includes('موعد') ||
          c.notes.includes('اتصال') ||
          c.notes.includes('تذكير') ||
          c.notes.includes('ملاحظة') ||
          notesLower.includes('call') ||
          notesLower.includes('appointment');
        if (hasAppointmentKeyword) {
          const apptKey = `${c.id}|appointment|${selectedDate}`;
          if (!existingTaskKeys.has(apptKey) && !generatedKeys.has(apptKey)) {
            generatedKeys.add(apptKey);
            generatedCustomerTasks.push({
              customerId: c.id,
              title: language === 'ar' ? `ملاحظة/موعد: ${c.name}` : `Note / Appointment: ${c.name}`,
              type: 'appointment',
              date: selectedDate,
              status: 'pending',
              notes: c.notes,
              priority: 'medium',
              createdAt: new Date(c.createdAt)
            });
          }
        }
      }
    }

    return [...currentDbTasks, ...generatedCustomerTasks];
  }, [dbTasks, customers, selectedDate, isTodaySelected, todayStr, language]);

  // Stats Counters memoized
  const completedTasksCount = useMemo(() => allDailyTasks.filter((t) => t.status === 'completed').length, [allDailyTasks]);
  const pendingTasksCount = useMemo(() => allDailyTasks.filter((t) => t.status === 'pending').length, [allDailyTasks]);
  const postponedTasksCount = useMemo(() => allDailyTasks.filter((t) => t.status === 'postponed').length, [allDailyTasks]);

  // Toggle or Update Task Status
  const handleUpdateTaskStatus = async (task: DailyTask, newStatus: TaskStatus) => {
    triggerHaptic('medium');
    try {
      if (task.id) {
        // Update existing task
        await db.tasks.update(task.id, {
          status: newStatus,
          completedAt: newStatus === 'completed' ? new Date() : null
        });
      } else {
        // Add as new DB task record
        await db.tasks.add({
          customerId: task.customerId,
          title: task.title,
          type: task.type,
          date: task.date,
          status: newStatus,
          notes: task.notes,
          priority: task.priority || 'medium',
          createdAt: new Date(),
          completedAt: newStatus === 'completed' ? new Date() : null
        });
      }

      await logOperation('UPDATE_TASK_STATUS', 'tasks', task.id || null, { oldStatus: task.status }, { newStatus });

      if (newStatus === 'completed') {
        showToast(language === 'ar' ? 'تم تعليم المهمة كـ "مُنجزة" بنجاح 🎉' : 'Task marked as completed 🎉', 'success');
      } else if (newStatus === 'pending') {
        showToast(language === 'ar' ? 'تمت إعادة المهمة لحالة "معلقة" ⏳' : 'Task reverted to pending ⏳', 'info');
      } else if (newStatus === 'postponed') {
        showToast(language === 'ar' ? 'تم تحويل المهمة إلى "مؤجلة" 🗓️' : 'Task marked as postponed 🗓️', 'info');
      }
    } catch (err) {
      console.error('Error updating task status:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء تحديث حالة المهمة' : 'Error updating task status', 'error');
    }
  };

  const [taskToDelete, setTaskToDelete] = useState<DailyTask | null>(null);

  // Delete Task
  const handleDeleteTask = (task: DailyTask) => {
    triggerHaptic('medium');
    setTaskToDelete(task);
  };

  const confirmDeleteTask = async () => {
    if (!taskToDelete) return;
    const task = taskToDelete;

    try {
      await db.transaction('rw', [db.tasks, db.customers, db.operationsLog], async () => {
        // 1. Delete task from db.tasks if it has a primary key
        if (task.id) {
          await db.tasks.delete(task.id);
        }

        // 2. Clear customer followUpDate if applicable
        if (task.customerId) {
          const cust = await db.customers.get(task.customerId);
          if (cust && cust.followUpDate) {
            await db.customers.update(task.customerId, { followUpDate: null, updatedAt: new Date() });
          }
        }

        // 3. Add a tombstone 'deleted' task entry to db.tasks so generatedCustomerTasks won't regenerate it
        await db.tasks.add({
          customerId: task.customerId || null,
          title: task.title,
          type: task.type,
          date: task.date || selectedDate,
          status: 'deleted' as any,
          notes: task.notes || null,
          priority: task.priority || 'medium',
          createdAt: new Date()
        });

        // 4. Log operation
        await db.operationsLog.add({
          action: 'DELETE_TASK',
          tableName: 'tasks',
          recordId: task.id || 0,
          oldData: JSON.stringify({ id: task.id, title: task.title, customerId: task.customerId }),
          newData: null,
          userId: null,
          timestamp: new Date()
        });
      });

      showToast('تم حذف المهمة بنجاح 🗑️', 'success');
    } catch (err) {
      console.error('Error deleting task:', err);
      showToast('حدث خطأ أثناء حذف المهمة', 'error');
    } finally {
      setTaskToDelete(null);
    }
  };

  // Create Manual Task
  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) {
      showToast(language === 'ar' ? 'يرجى إدخال عنوان المهمة' : 'Please enter task title', 'error');
      return;
    }

    try {
      triggerHaptic('success');
      await db.tasks.add({
        customerId: taskCustomerId || null,
        title: taskTitle.trim(),
        type: taskType,
        date: selectedDate,
        status: 'pending',
        notes: taskNotes.trim() || null,
        time: taskTime || null,
        priority: taskPriority,
        createdAt: new Date()
      });

      showToast(language === 'ar' ? 'تمت إضافة المهمة اليومية بنجاح 📝' : 'Daily task added successfully 📝', 'success');
      setShowAddTaskModal(false);
      // Reset form
      setTaskTitle('');
      setTaskNotes('');
      setTaskTime('');
      setTaskCustomerId(null);
    } catch (err) {
      console.error('Error creating task:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء إضافة المهمة' : 'Error adding task', 'error');
    }
  };

  // Handle Postpone Task to a new Date
  const handlePostponeTaskSubmit = async () => {
    if (!showPostponeModal || !postponeNewDate) return;

    try {
      triggerHaptic('medium');
      if (showPostponeModal.id) {
        await db.tasks.update(showPostponeModal.id, {
          date: postponeNewDate,
          status: 'postponed',
          notes: `${showPostponeModal.notes || ''} (${language === 'ar' ? 'تأجيل إلى' : 'Postponed to'} ${postponeNewDate})`
        });
      } else {
        await db.tasks.add({
          customerId: showPostponeModal.customerId,
          title: showPostponeModal.title,
          type: showPostponeModal.type,
          date: postponeNewDate,
          status: 'postponed',
          notes: `${showPostponeModal.notes || ''} (${language === 'ar' ? 'تم التأجيل من' : 'Postponed from'} ${selectedDate})`,
          priority: showPostponeModal.priority || 'medium',
          createdAt: new Date()
        });
      }

      // If task is linked to customer followUpDate, update customer followUpDate as well
      if (showPostponeModal.customerId) {
        await db.customers.update(showPostponeModal.customerId, {
          followUpDate: postponeNewDate,
          updatedAt: new Date()
        });
      }

      showToast(language === 'ar' ? `تم تأجيل المهمة إلى تاريخ ${postponeNewDate} 🗓️` : `Task postponed to ${postponeNewDate} 🗓️`, 'info');
      setShowPostponeModal(null);
      setPostponeNewDate('');
    } catch (err) {
      console.error('Error postponing task:', err);
      showToast(language === 'ar' ? 'حدث خطأ أثناء تأجيل المهمة' : 'Error postponing task', 'error');
    }
  };

  const getTaskTypeBadge = (type: TaskType) => {
    switch (type) {
      case 'followup':
        return (
          <span className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-bold flex items-center gap-1">
            <UserCheck className="w-3 h-3" />
            <span>{language === 'ar' ? 'متابعة' : 'Follow-up'}</span>
          </span>
        );
      case 'appointment':
        return (
          <span className="px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20 text-[10px] font-bold flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            <span>{language === 'ar' ? 'موعد' : 'Meeting'}</span>
          </span>
        );
      case 'activation':
        return (
          <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{language === 'ar' ? 'استكمال طلب' : 'Activation'}</span>
          </span>
        );
      case 'note':
        return (
          <span className="px-2 py-0.5 rounded-md bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[10px] font-bold flex items-center gap-1">
            <FileText className="w-3 h-3" />
            <span>{language === 'ar' ? 'ملاحظة' : 'Note'}</span>
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md bg-zinc-800 text-zinc-300 border border-zinc-700 text-[10px] font-bold flex items-center gap-1">
            <Tag className="w-3 h-3" />
            <span>{language === 'ar' ? 'مهمة عامة' : 'General'}</span>
          </span>
        );
    }
  };

  const formattedDateHeading = new Date(selectedDate).toLocaleDateString(language === 'ar' ? 'ar-SA-u-nu-latn' : 'en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  return (
    <div className="bento-card bg-zinc-900 border-zinc-800 p-4 shadow-xl space-y-3.5 rounded-3xl">
      <div className="glow-top" />

      {/* Header & Date Picker Selector */}
      <div className="flex items-center justify-between gap-2 flex-wrap border-b border-zinc-800/80 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 shadow-inner">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-black text-white flex items-center gap-1.5">
              <span>{t('dailyTasks', 'جدول المهام والمواعيد اليومية')}</span>
              {isTodaySelected && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-[9px] font-mono font-bold animate-pulse">
                  {t('today', 'اليوم')}
                </span>
              )}
            </div>
            <div className="text-[10px] text-zinc-400 font-medium">
              {formattedDateHeading}
            </div>
          </div>
        </div>

        {/* Date Selector Controls */}
        <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-2xl border border-zinc-800 text-xs">
          <button
            onClick={() => changeDateBy(dir === 'rtl' ? 1 : -1)}
            className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition-all"
            title={t('prevDay', 'اليوم السابق')}
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              if (e.target.value) {
                triggerHaptic('light');
                setSelectedDate(e.target.value);
              }
            }}
            className="bg-transparent text-[11px] font-mono text-amber-400 font-bold focus:outline-none px-1 cursor-pointer"
          />

          <button
            onClick={() => changeDateBy(dir === 'rtl' ? -1 : 1)}
            className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl transition-all"
            title={t('nextDay', 'اليوم التالي')}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {!isTodaySelected && (
            <button
              onClick={() => {
                triggerHaptic('light');
                setSelectedDate(todayStr);
              }}
              className="px-2 py-1 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 rounded-xl text-[10px] font-bold border border-amber-500/30 transition-all mr-1"
            >
              {t('today', 'اليوم')}
            </button>
          )}
        </div>
      </div>

      {/* Task Summary Badges (Completed, Pending, Postponed) */}
      <div className="grid grid-cols-4 gap-1 sm:gap-1.5 text-center text-[10px] font-bold min-w-0">
        <div className="px-1 py-2 bg-zinc-950/80 border border-zinc-800 rounded-2xl min-w-0 overflow-hidden">
          <div className="text-zinc-500 truncate">{t('totalTasks', 'الإجمالي')}</div>
          <div className="text-xs font-black text-white font-mono mt-0.5 truncate">
            {formatNumber(allDailyTasks.length)}
          </div>
        </div>
        <div className="px-1 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl min-w-0 overflow-hidden">
          <div className="text-emerald-400 flex items-center justify-center gap-0.5 min-w-0">
            <CheckCircle2 className="w-3 h-3 shrink-0" />
            <span className="truncate">{t('completed', 'مُنجزة')}</span>
          </div>
          <div className="text-xs font-black text-emerald-300 font-mono mt-0.5 truncate">
            {formatNumber(completedTasksCount)}
          </div>
        </div>
        <div className="px-1 py-2 bg-amber-500/10 border border-amber-500/20 rounded-2xl min-w-0 overflow-hidden">
          <div className="text-amber-400 flex items-center justify-center gap-0.5 min-w-0">
            <Clock className="w-3 h-3 shrink-0" />
            <span className="truncate">{t('pendingStatus', 'معلقة')}</span>
          </div>
          <div className="text-xs font-black text-amber-300 font-mono mt-0.5 truncate">
            {formatNumber(pendingTasksCount)}
          </div>
        </div>
        <div className="px-1 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-2xl min-w-0 overflow-hidden">
          <div className="text-yellow-400 flex items-center justify-center gap-0.5 min-w-0">
            <AlertTriangle className="w-3 h-3 shrink-0" />
            <span className="truncate">{t('deferred', 'مؤجلة')}</span>
          </div>
          <div className="text-xs font-black text-yellow-300 font-mono mt-0.5 truncate">
            {formatNumber(postponedTasksCount)}
          </div>
        </div>
      </div>

      {/* Add New Task Button */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-[11px] font-bold text-zinc-400">
          {t('dailyTasksList', 'قائمة مهام اليوم')} ({formatNumber(allDailyTasks.length)}):
        </span>

        <button
          onClick={() => {
            triggerHaptic('light');
            setShowAddTaskModal(true);
          }}
          className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold rounded-xl text-xs transition-all shadow-md active:scale-95"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{t('addTask', 'إضافة مهمة')}</span>
        </button>
      </div>

      {/* Daily Tasks List */}
      <div className="space-y-2.5 pt-1">
        {allDailyTasks.length === 0 ? (
          <div className="p-6 bg-zinc-950/60 border border-zinc-800/80 rounded-2xl text-center space-y-2 text-zinc-500">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500/60 stroke-1" />
            <div className="text-xs font-bold text-zinc-300">
              {t('noDailyTasks', 'لا توجد مهام أو مواعيد مسجلة لهذا اليوم 🎉')}
            </div>
            <p className="text-[10px] text-zinc-500">
              {language === 'ar' 
                ? 'يمكنك إضافة مهمة جديدة أو تعيين تاريخ متابعة للعملاء ليظهر تلقائياً هنا.'
                : 'You can add a new task or set follow-up dates for clients to show up here.'}
            </p>
          </div>
        ) : (
          allDailyTasks.map((task, idx) => {
            const customerObj = task.customerId
              ? customers.find((c) => c.id === task.customerId)
              : null;

            return (
              <div
                key={task.id ? `db-${task.id}` : `gen-${idx}`}
                className={`p-3.5 rounded-2xl border transition-all shadow-md space-y-2.5 ${
                  task.status === 'completed'
                    ? 'bg-emerald-950/20 border-emerald-500/30 opacity-80'
                    : task.status === 'postponed'
                    ? 'bg-yellow-950/20 border-yellow-500/30'
                    : 'bg-zinc-950/80 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2 min-w-0">
                  <div className="flex items-start gap-2.5 min-w-0 flex-1">
                    {/* Status Checkbox / Toggle */}
                    <button
                      onClick={() =>
                        handleUpdateTaskStatus(
                          task,
                          task.status === 'completed' ? 'pending' : 'completed'
                        )
                      }
                      className={`p-1.5 rounded-xl border mt-0.5 shrink-0 transition-all active:scale-90 ${
                        task.status === 'completed'
                          ? 'bg-emerald-500 text-zinc-950 border-emerald-400 shadow-md'
                          : 'bg-zinc-900 border-zinc-700 text-zinc-500 hover:text-white'
                      }`}
                      title={task.status === 'completed' ? (language === 'ar' ? 'إعادة كمعلقة' : 'Revert to pending') : (language === 'ar' ? 'تعليم كمُنجزة' : 'Mark as completed')}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="min-w-0 flex-1">
                      <div
                        className={`text-xs font-extrabold break-words ${
                          task.status === 'completed'
                            ? 'line-through text-zinc-400'
                            : 'text-white'
                        }`}
                      >
                        {task.title}
                      </div>

                      {/* Associated Customer Info */}
                      {customerObj && (
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <button
                            onClick={() =>
                              customerObj.id && onSelectCustomer?.(customerObj.id)
                            }
                            className="text-[11px] text-indigo-400 hover:underline font-bold flex items-center gap-1"
                          >
                            <span>👤 {customerObj.name}</span>
                            {customerObj.orderNumber && (
                              <span className="text-[10px] font-mono text-zinc-400">
                                (#{customerObj.orderNumber})
                              </span>
                            )}
                          </button>

                          {/* Quick Contact Links */}
                          <div className="flex items-center gap-1">
                            <a
                              href={buildSafeTelHref(customerObj.phone)}
                              className="p-1 rounded-md bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                              title={language === 'ar' ? 'اتصال' : 'Call'}
                            >
                              <Phone className="w-3 h-3" />
                            </a>
                            <a
                              href={buildSafeWhatsAppHref(customerObj.phone)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 rounded-md bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20"
                              title={language === 'ar' ? 'واتساب' : 'WhatsApp'}
                            >
                              <MessageCircle className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Task Notes */}
                      {task.notes && (
                        <div className="text-[10px] text-zinc-400 mt-1 bg-zinc-900/80 p-1.5 rounded-lg border border-zinc-800/60 leading-relaxed">
                          {task.notes}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Task Type & Priority Badge */}
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    {getTaskTypeBadge(task.type)}
                    {task.time && (
                      <span className="text-[10px] font-mono text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded-md">
                        🕒 {task.time}
                      </span>
                    )}
                  </div>
                </div>

                {/* Status Action Toolbar */}
                <div className="flex items-center justify-between flex-wrap gap-2 border-t border-zinc-800/60 pt-2 text-[10px]">
                  <div className="flex items-center gap-1.5 font-bold">
                    <span>{language === 'ar' ? 'الحالة:' : 'Status:'}</span>
                    {task.status === 'completed' ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> {language === 'ar' ? 'تم إنجازها' : 'Completed'}
                      </span>
                    ) : task.status === 'postponed' ? (
                      <span className="text-yellow-400 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> {language === 'ar' ? 'مؤجلة' : 'Postponed'}
                      </span>
                    ) : (
                      <span className="text-amber-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {language === 'ar' ? 'معلقة' : 'Pending'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Mark as Completed */}
                    {task.status !== 'completed' && (
                      <button
                        onClick={() => handleUpdateTaskStatus(task, 'completed')}
                        className="px-2 py-1 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-bold rounded-lg border border-emerald-500/30 transition-all"
                      >
                        {language === 'ar' ? 'تم الإنجاز' : 'Mark Done'}
                      </button>
                    )}

                    {/* Postpone Button */}
                    <button
                      onClick={() => {
                        triggerHaptic('light');
                        setShowPostponeModal(task);
                        setPostponeNewDate(selectedDate);
                      }}
                      className="px-2 py-1 bg-yellow-500/15 hover:bg-yellow-500/25 text-yellow-300 font-bold rounded-lg border border-yellow-500/30 transition-all"
                      title={language === 'ar' ? 'تأجيل إلى تاريخ آخر' : 'Postpone to another date'}
                    >
                      {language === 'ar' ? 'تأجيل' : 'Postpone'}
                    </button>

                    {/* Delete Task Button */}
                    <button
                      onClick={() => handleDeleteTask(task)}
                      className="p-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 font-bold rounded-lg border border-rose-500/20 transition-all active:scale-95"
                      title={language === 'ar' ? 'حذف المهمة' : 'Delete task'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add New Task Modal */}
      {showAddTaskModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-x-hidden animate-fadeIn">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl max-w-md w-full min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto overflow-x-hidden">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">
                    {language === 'ar' ? 'إضافة مهمة أو موعد جديد' : 'Add New Task or Meeting'}
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    {language === 'ar' ? `تاريخ المهمة: ${selectedDate}` : `Task Date: ${selectedDate}`}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAddTaskModal(false)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">
                  {language === 'ar' ? 'عنوان المهمة/الموعد' : 'Task / Meeting Title'} <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'ar' ? 'مثال: اتصال بالعميل لتأكيد تفاصيل البطاقة...' : 'e.g., Call client to verify card details...'}
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    {language === 'ar' ? 'نوع المهمة' : 'Task Type'}
                  </label>
                  <select
                    value={taskType}
                    onChange={(e) => setTaskType(e.target.value as TaskType)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
                  >
                    <option value="followup">{language === 'ar' ? 'متابعة عميل' : 'Client Follow-up'}</option>
                    <option value="appointment">{language === 'ar' ? 'موعد اتصال/لقاء' : 'Call / Meeting'}</option>
                    <option value="activation">{language === 'ar' ? 'استكمال طلب/تفعيل' : 'Order Activation'}</option>
                    <option value="note">{language === 'ar' ? 'ملاحظة سريعة' : 'Quick Note'}</option>
                    <option value="custom">{language === 'ar' ? 'مهمة عامة' : 'General Task'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    {language === 'ar' ? 'الوقت (اختياري)' : 'Time (Optional)'}
                  </label>
                  <input
                    type="time"
                    value={taskTime}
                    onChange={(e) => setTaskTime(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">
                  {language === 'ar' ? 'ربط بعميل (اختياري)' : 'Link to Client (Optional)'}
                </label>
                <select
                  value={taskCustomerId || ''}
                  onChange={(e) => setTaskCustomerId(e.target.value ? Number(e.target.value) : null)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
                >
                  <option value="">{language === 'ar' ? '-- بدون ربط بعميل --' : '-- No client linked --'}</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.orderNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">
                  {language === 'ar' ? 'تفاصيل وملاحظات إضافية' : 'Details and Notes'}
                </label>
                <textarea
                  rows={2}
                  placeholder={language === 'ar' ? 'ملاحظات تفصيلية حول المهمة...' : 'Detailed notes about the task...'}
                  value={taskNotes}
                  onChange={(e) => setTaskNotes(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="py-2 px-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="py-2 px-5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold rounded-xl text-xs shadow-md active:scale-95 transition-all"
                >
                  {language === 'ar' ? 'حفظ المهمة' : 'Save Task'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Postpone Modal */}
      {showPostponeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-x-hidden animate-fadeIn">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl max-w-sm w-full min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 overflow-x-hidden">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-yellow-500/10 text-yellow-400 rounded-xl border border-yellow-500/20">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-white">
                    {language === 'ar' ? 'تأجيل المهمة اليومية' : 'Postpone Daily Task'}
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    {language === 'ar' ? 'حدد التاريخ الجديد لتنفيذ المهمة' : 'Select new date for execution'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowPostponeModal(null)}
                className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="text-xs font-bold text-amber-300 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                {showPostponeModal.title}
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 mb-1">
                  {language === 'ar' ? 'التاريخ الجديد' : 'New Date'}
                </label>
                <input
                  type="date"
                  required
                  value={postponeNewDate}
                  onChange={(e) => setPostponeNewDate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:border-amber-500 focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setShowPostponeModal(null)}
                  className="py-2 px-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-bold"
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handlePostponeTaskSubmit}
                  className="py-2 px-5 bg-yellow-500 hover:bg-yellow-400 text-zinc-950 font-extrabold rounded-xl text-xs shadow-md active:scale-95 transition-all"
                >
                  {language === 'ar' ? 'تأكيد التأجيل' : 'Confirm Postpone'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!taskToDelete}
        title={language === 'ar' ? 'تأكيد حذف المهمة' : 'Confirm Delete Task'}
        message={language === 'ar' ? `هل أنت متأكد من حذف المهمة "${taskToDelete?.title}"؟` : `Are you sure you want to delete the task "${taskToDelete?.title}"?`}
        confirmText={language === 'ar' ? 'نعم، حذف المهمة 🗑️' : 'Yes, Delete Task 🗑️'}
        cancelText={language === 'ar' ? 'إلغاء' : 'Cancel'}
        isDanger={true}
        onConfirm={confirmDeleteTask}
        onCancel={() => setTaskToDelete(null)}
      />
    </div>
  );
});
