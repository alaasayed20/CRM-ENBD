import React, { useState, useEffect, useCallback } from 'react';
import { Lock, Fingerprint, Delete, LogOut, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import {
  verifyPin,
  hashPin,
  isLegacyPinHash,
  authenticateBiometric,
  getLockoutState,
  recordFailedAttempt,
  clearLockoutAttempts,
  type LockoutState,
} from '../utils/security';
import { triggerHaptic } from '../utils/haptics';

interface PinLockScreenProps {
  username: string;
  pinHash: string;
  pinLength?: number;
  biometricEnabled?: boolean;
  biometricCredentialId?: string | null;
  onUnlock: () => void;
  onUpgradePinHash?: (newHash: string) => Promise<void> | void;
  onLogout: () => void;
}

export const PinLockScreen: React.FC<PinLockScreenProps> = ({
  username,
  pinHash,
  pinLength = 4,
  biometricEnabled = false,
  biometricCredentialId,
  onUnlock,
  onUpgradePinHash,
  onLogout,
}) => {
  const { language, dir } = useLanguage();
  const isAr = language === 'ar';
  const [pin, setPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [shake, setShake] = useState(false);
  const [lockout, setLockout] = useState<LockoutState>(() => getLockoutState('pin'));

  const canUseBiometric = Boolean(biometricEnabled && biometricCredentialId);
  const expectedLength = pinLength >= 4 && pinLength <= 6 ? pinLength : 4;

  // Live countdown ticker during PIN brute-force lockout
  useEffect(() => {
    if (!lockout.isLocked) return;
    const timer = setInterval(() => {
      setLockout(getLockoutState('pin'));
    }, 1000);
    return () => clearInterval(timer);
  }, [lockout.isLocked]);

  const handleBiometricUnlock = useCallback(async () => {
    if (!canUseBiometric || !biometricCredentialId || lockout.isLocked) return;
    triggerHaptic('light');
    setErrorMsg('');
    const ok = await authenticateBiometric(biometricCredentialId);
    if (ok) {
      clearLockoutAttempts('pin');
      triggerHaptic('success');
      onUnlock();
    } else {
      triggerHaptic('warning');
      setErrorMsg(
        isAr
          ? 'لم يتم التحقق بالبصمة، يمكنك إدخال رمز PIN'
          : 'Biometric verification canceled, please enter PIN'
      );
    }
  }, [canUseBiometric, biometricCredentialId, isAr, onUnlock, lockout.isLocked]);

  const checkEnteredPin = useCallback(
    async (value: string) => {
      const currentLock = getLockoutState('pin');
      setLockout(currentLock);
      if (currentLock.isLocked) {
        setPin('');
        return;
      }

      setIsVerifying(true);
      const valid = await verifyPin(value, pinHash);
      setIsVerifying(false);

      if (valid) {
        clearLockoutAttempts('pin');
        setLockout(getLockoutState('pin'));
        // Auto-upgrade legacy SHA-256 PINs to salted PBKDF2-SHA256
        if (isLegacyPinHash(pinHash) && onUpgradePinHash) {
          try {
            const upgraded = await hashPin(value);
            await onUpgradePinHash(upgraded);
          } catch {
            // non-fatal upgrade error
          }
        }
        triggerHaptic('success');
        setPin('');
        setErrorMsg('');
        onUnlock();
      } else {
        const nextLock = recordFailedAttempt('pin');
        setLockout(nextLock);
        triggerHaptic('warning');
        setShake(true);
        setErrorMsg(
          nextLock.isLocked
            ? (isAr
                ? `تم قفل رمز PIN مؤقتاً لمدة ${nextLock.remainingSeconds} ثانية`
                : `PIN temporarily locked for ${nextLock.remainingSeconds}s`)
            : (isAr
                ? `رمز PIN غير صحيح (${Math.max(0, 5 - nextLock.attempts)} محاولات متبقية)`
                : `Incorrect PIN (${Math.max(0, 5 - nextLock.attempts)} attempts left)`)
        );
        setTimeout(() => {
          setPin('');
          setShake(false);
        }, 420);
      }
    },
    [pinHash, onUnlock, onUpgradePinHash, isAr]
  );

  const handleDigit = useCallback(
    (digit: string) => {
      if (isVerifying || lockout.isLocked || pin.length >= expectedLength) return;
      triggerHaptic('light');
      setErrorMsg('');
      const next = pin + digit;
      setPin(next);
      if (next.length === expectedLength) {
        void checkEnteredPin(next);
      }
    },
    [isVerifying, lockout.isLocked, pin, expectedLength, checkEnteredPin]
  );

  const handleBackspace = useCallback(() => {
    if (isVerifying || lockout.isLocked || pin.length === 0) return;
    triggerHaptic('light');
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  }, [isVerifying, lockout.isLocked, pin.length]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (lockout.isLocked) return;
      if (e.key >= '0' && e.key <= '9') {
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleDigit, handleBackspace, lockout.isLocked]);

  const keypadDigits = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

  return (
    <div
      dir={dir}
      className="fixed inset-0 z-[250] bg-[#070e1c]/98 backdrop-blur-2xl flex flex-col items-center justify-center p-5 text-slate-100 select-none no-print"
    >
      <div className="w-full max-w-xs flex flex-col items-center space-y-6">
        {/* App Logo & Lock Identity */}
        <div className="flex flex-col items-center text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-[#0e2242] border border-sky-400/35 flex items-center justify-center shadow-xl shadow-sky-950/60 relative">
            <img
              src="/icon.png"
              alt="Sales CRM"
              className="w-10 h-10 object-contain rounded-xl"
              referrerPolicy="no-referrer"
            />
            <span className="absolute -bottom-1.5 -right-1.5 w-6 h-6 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center shadow-md border-2 border-[#070e1c]">
              <Lock className="w-3.5 h-3.5 stroke-[2.5]" />
            </span>
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-white tracking-tight">
              {isAr ? 'التطبيق مقفل لحماية البيانات' : 'App Locked'}
            </h2>
            <p className="text-xs text-sky-300/80 font-medium mt-0.5 flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
              <span>{username}</span>
            </p>
          </div>
        </div>

        {/* Progressive Lockout Alert */}
        {lockout.isLocked && (
          <div className="w-full rounded-xl bg-amber-500/15 border border-amber-400/40 px-3.5 py-2.5 flex items-center gap-2 text-amber-200 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-bold tabular-nums">
              {isAr
                ? `قفل مؤقت للحماية — حاول بعد ${lockout.remainingSeconds} ثانية`
                : `Locked for security — retry in ${lockout.remainingSeconds}s`}
            </span>
          </div>
        )}

        {/* PIN Dots Indicator */}
        <div
          className={`flex items-center justify-center gap-3.5 py-2 transition-transform duration-150 ${
            shake ? 'translate-x-2' : ''
          }`}
        >
          {Array.from({ length: expectedLength }).map((_, idx) => {
            const filled = idx < pin.length;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-150 border-2 ${
                  filled
                    ? 'bg-sky-400 border-sky-300 scale-110 shadow-md shadow-sky-400/40'
                    : 'bg-slate-900 border-slate-600'
                }`}
              />
            );
          })}
        </div>

        <div className="min-h-[20px] text-center">
          {errorMsg ? (
            <p className="text-xs font-bold text-rose-400 tabular-nums">{errorMsg}</p>
          ) : (
            <p className="text-xs text-slate-400 font-medium">
              {isAr
                ? `أدخل رمز PIN المكون من ${expectedLength} أرقام`
                : `Enter your ${expectedLength}-digit PIN`}
            </p>
          )}
        </div>

        {/* Thumb-friendly 3x4 Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[260px]" dir="ltr">
          {keypadDigits.map((d) => (
            <button
              key={d}
              type="button"
              disabled={lockout.isLocked || isVerifying}
              onClick={() => handleDigit(d)}
              className="h-14 rounded-2xl bg-[#0e2242]/90 hover:bg-[#16325e] disabled:opacity-40 active:scale-92 border border-sky-500/25 text-xl font-black font-mono tabular-nums text-white transition-all flex items-center justify-center shadow-lg"
            >
              {d}
            </button>
          ))}

          {canUseBiometric ? (
            <button
              type="button"
              disabled={lockout.isLocked}
              onClick={handleBiometricUnlock}
              className="h-14 rounded-2xl bg-emerald-500/15 hover:bg-emerald-500/25 disabled:opacity-40 active:scale-92 border border-emerald-400/40 text-emerald-300 transition-all flex items-center justify-center shadow-lg"
              title={isAr ? 'فتح بالبصمة / الوجه' : 'Unlock with Biometrics'}
            >
              <Fingerprint className="w-6 h-6" />
            </button>
          ) : (
            <div />
          )}

          <button
            type="button"
            disabled={lockout.isLocked || isVerifying}
            onClick={() => handleDigit('0')}
            className="h-14 rounded-2xl bg-[#0e2242]/90 hover:bg-[#16325e] disabled:opacity-40 active:scale-92 border border-sky-500/25 text-xl font-black font-mono tabular-nums text-white transition-all flex items-center justify-center shadow-lg"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleBackspace}
            disabled={pin.length === 0 || lockout.isLocked}
            className="h-14 rounded-2xl bg-slate-900/90 hover:bg-slate-800 disabled:opacity-40 active:scale-92 border border-slate-700/70 text-slate-300 transition-all flex items-center justify-center"
            title={isAr ? 'مسح رقم' : 'Backspace'}
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Switch Account / Sign Out Escape Hatch */}
        <button
          type="button"
          onClick={onLogout}
          className="mt-2 min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-rose-300 transition-colors flex items-center gap-1.5"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>{isAr ? 'تبديل الحساب / تسجيل الخروج' : 'Switch Account / Sign Out'}</span>
        </button>
      </div>
    </div>
  );
};
