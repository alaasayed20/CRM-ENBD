import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface ConfirmModalProps {
  isOpen: boolean;
  title?: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDanger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText,
  cancelText,
  isDanger = true,
  onConfirm,
  onCancel
}) => {
  const { t, language, dir } = useLanguage();

  if (!isOpen) return null;

  const displayTitle = title || (language === 'ar' ? 'تأكيد الإجراء' : 'Confirm Action');
  const displayConfirmText = confirmText || (language === 'ar' ? 'نعم، تأكيد الحذف' : 'Yes, Confirm');
  const displayCancelText = cancelText || t('cancel', 'إلغاء');

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className={`bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-sm p-5 shadow-2xl space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'} animate-in fade-in zoom-in duration-150`}>
        <div className="glow-top" />
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <h3 className="font-bold text-sm text-white flex items-center gap-2">
            <AlertTriangle className={`w-4 h-4 ${isDanger ? 'text-rose-500' : 'text-amber-400'}`} />
            <span>{displayTitle}</span>
          </h3>
          <button onClick={onCancel} className="p-1.5 text-zinc-400 hover:text-white rounded-xl bg-zinc-800">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-zinc-300 leading-relaxed font-sans">{message}</p>

        <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95"
          >
            {displayCancelText}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-lg ${
              isDanger
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20'
                : 'bg-amber-500 hover:bg-amber-400 text-zinc-950 shadow-amber-500/20'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{displayConfirmText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

