import React, { useEffect, useState, useRef } from 'react';
import {
  ShieldCheck,
  Lock,
  Unlock,
  Download,
  Upload,
  X,
  Eye,
  EyeOff,
  KeyRound,
  Copy,
  Check,
  Database,
  FileJson,
  AlertTriangle,
  RefreshCw,
  Layers,
  CheckCircle2,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useToast } from './Toast';
import { triggerHaptic } from '../utils/haptics';
import {
  getDatabaseBackupStats,
  exportDatabaseBackupFile,
  inspectBackupFile,
  decryptAndVerifyBackupFile,
  restoreVerifiedBackupToIndexedDB,
  downloadDecryptedBackupJson,
  generateStrongPassphrase,
  evaluatePassphraseStrength,
  formatFileSize,
  type DatabaseTableCounts,
  type InspectedBackupFile,
  type VerifiedBackupPreview,
  type BackupRestoreMode,
} from '../utils/encryptedBackup';

interface EncryptedBackupModalProps {
  isOpen: boolean;
  initialTab: 'export' | 'import';
  canRestoreDatabase: boolean;
  onClose: () => void;
}

export const EncryptedBackupModal: React.FC<EncryptedBackupModalProps> = ({
  isOpen,
  initialTab,
  canRestoreDatabase,
  onClose,
}) => {
  const { language, dir, formatNumber } = useLanguage();
  const { showToast } = useToast();
  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'export' | 'import'>(initialTab);

  // Export state
  const [dbStats, setDbStats] = useState<{ counts: DatabaseTableCounts; totalRecords: number } | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);
  const [encryptEnabled, setEncryptEnabled] = useState(true);
  const [passphrase, setPassphrase] = useState('');
  const [confirmPassphrase, setConfirmPassphrase] = useState('');
  const [showExportPass, setShowExportPass] = useState(false);
  const [copiedGenerated, setCopiedGenerated] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportError, setExportError] = useState('');

  // Import & Decrypt state
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [inspectedFile, setInspectedFile] = useState<InspectedBackupFile | null>(null);
  const [decryptPassphrase, setDecryptPassphrase] = useState('');
  const [showImportPass, setShowImportPass] = useState(false);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [importError, setImportError] = useState('');
  const [verifiedPreview, setVerifiedPreview] = useState<VerifiedBackupPreview | null>(null);
  const [restoreMode, setRestoreMode] = useState<BackupRestoreMode>('replace');
  const [isRestoring, setIsRestoring] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setActiveTab(initialTab);
    setExportError('');
    setImportError('');
    setLoadingStats(true);
    getDatabaseBackupStats()
      .then((stats) => setDbStats(stats))
      .catch(() => setDbStats(null))
      .finally(() => setLoadingStats(false));
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const strength = evaluatePassphraseStrength(passphrase);

  const resetImportFlow = () => {
    setInspectedFile(null);
    setDecryptPassphrase('');
    setImportError('');
    setVerifiedPreview(null);
    setRestoreMode('replace');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleClose = () => {
    setPassphrase('');
    setConfirmPassphrase('');
    setExportError('');
    resetImportFlow();
    onClose();
  };

  const handleGeneratePassphrase = () => {
    triggerHaptic('light');
    const generated = generateStrongPassphrase();
    setPassphrase(generated);
    setConfirmPassphrase(generated);
    setShowExportPass(true);
    setExportError('');
    setCopiedGenerated(false);
  };

  const handleCopyPassphrase = async () => {
    if (!passphrase) return;
    try {
      await navigator.clipboard.writeText(passphrase);
      triggerHaptic('success');
      setCopiedGenerated(true);
      showToast(
        isAr ? 'تم نسخ كلمة مرور التشفير — احفظها في مكان آمن 🔐' : 'Encryption passphrase copied — store it safely 🔐',
        'success'
      );
      setTimeout(() => setCopiedGenerated(false), 2500);
    } catch {
      showToast(isAr ? 'تعذر النسخ التلقائي، يرجى نسخها يدوياً' : 'Could not copy automatically', 'warning');
    }
  };

  const handleExportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setExportError('');

    if (encryptEnabled) {
      if (passphrase.trim().length < 6) {
        setExportError(
          isAr
            ? 'يرجى إدخال كلمة مرور للتشفير لا تقل عن 6 أحرف'
            : 'Please enter an encryption passphrase of at least 6 characters'
        );
        return;
      }
      if (passphrase !== confirmPassphrase) {
        setExportError(
          isAr ? 'كلمتا المرور غير متطابقتين' : 'Passphrases do not match'
        );
        return;
      }
    }

    setIsExporting(true);
    try {
      triggerHaptic('medium');
      const result = await exportDatabaseBackupFile({
        encrypt: encryptEnabled,
        passphrase: encryptEnabled ? passphrase : undefined,
      });
      triggerHaptic('success');
      showToast(
        encryptEnabled
          ? isAr
            ? `تم تشفير وتصدير قاعدة البيانات بنجاح (${formatNumber(result.totalRecords)} سجل · ${formatFileSize(result.byteSize)}) 🔐`
            : `Encrypted backup exported (${result.totalRecords} records · ${formatFileSize(result.byteSize)}) 🔐`
          : isAr
            ? `تم تصدير النسخة الاحتياطية JSON (${formatNumber(result.totalRecords)} سجل)`
            : `Plain JSON backup exported (${result.totalRecords} records)`,
        'success'
      );
      setPassphrase('');
      setConfirmPassphrase('');
      setShowExportPass(false);
    } catch (err) {
      console.error('Encrypted backup export failed:', err);
      setExportError(
        isAr
          ? 'تعذر تشفير أو تصدير قاعدة البيانات. تأكد من دعم المتصفح لـ Web Crypto.'
          : 'Failed to encrypt and export database.'
      );
    } finally {
      setIsExporting(false);
    }
  };

  const processSelectedFile = async (file: File) => {
    setImportError('');
    setVerifiedPreview(null);
    setDecryptPassphrase('');

    try {
      triggerHaptic('light');
      const inspected = await inspectBackupFile(file);
      setInspectedFile(inspected);

      if (!inspected.isEncrypted) {
        // Plain JSON backup: validate and show preview immediately
        const preview = await decryptAndVerifyBackupFile(inspected);
        setVerifiedPreview(preview);
      }
    } catch (err: any) {
      const code = err?.message || '';
      if (code === 'FILE_TOO_LARGE') {
        setImportError(
          isAr ? 'حجم الملف يتجاوز الحد الأقصى المسموح (25 ميجابايت)' : 'File exceeds the 25MB limit'
        );
      } else if (code === 'INVALID_JSON') {
        setImportError(
          isAr ? 'الملف المختار ليس ملف JSON صالحاً' : 'Selected file is not valid JSON'
        );
      } else if (code === 'INVALID_SCHEMA') {
        setImportError(
          isAr
            ? 'الملف لا يطابق هيكل قاعدة بيانات Sales CRM'
            : 'File does not match Sales CRM database schema'
        );
      } else {
        setImportError(
          isAr ? 'تعذر قراءة ملف النسخة الاحتياطية' : 'Could not read backup file'
        );
      }
      setInspectedFile(null);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void processSelectedFile(file);
    }
  };

  const handleDecryptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inspectedFile) return;
    setImportError('');
    setIsDecrypting(true);

    try {
      triggerHaptic('medium');
      const preview = await decryptAndVerifyBackupFile(inspectedFile, decryptPassphrase);
      setVerifiedPreview(preview);
      triggerHaptic('success');
    } catch (err: any) {
      triggerHaptic('warning');
      const code = err?.message || '';
      if (code === 'DECRYPT_FAILED') {
        setImportError(
          isAr
            ? 'كلمة المرور غير صحيحة أو أن الملف المشفر قد تم تعديله/تلفه.'
            : 'Incorrect passphrase or the encrypted file was tampered with.'
        );
      } else if (code === 'INVALID_SCHEMA') {
        setImportError(
          isAr
            ? 'تم فك التشفير لكن محتوى الملف لا يطابق هيكل قاعدة البيانات.'
            : 'Decrypted content does not match the database schema.'
        );
      } else {
        setImportError(
          isAr ? 'تعذر فك تشفير الملف' : 'Failed to decrypt file'
        );
      }
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleConfirmRestore = async () => {
    if (!verifiedPreview) return;
    if (!canRestoreDatabase) {
      showToast(
        isAr ? 'صلاحية استعادة قاعدة البيانات متاحة للمدير فقط' : 'Only administrators can restore the database',
        'error'
      );
      return;
    }

    setIsRestoring(true);
    try {
      triggerHaptic('medium');
      const result = await restoreVerifiedBackupToIndexedDB(verifiedPreview, restoreMode);
      triggerHaptic('success');
      showToast(
        isAr
          ? `تمت استعادة قاعدة البيانات بنجاح (${formatNumber(result.restoredCustomers)} عميل · ${formatNumber(result.totalRestored)} سجل) ✨`
          : `Database restored successfully (${result.restoredCustomers} customers · ${result.totalRestored} records) ✨`,
        'success'
      );
      handleClose();
      setTimeout(() => {
        window.location.reload();
      }, 600);
    } catch (err) {
      console.error('Restore failed:', err);
      setImportError(
        isAr ? 'حدث خطأ أثناء كتابة البيانات إلى قاعدة البيانات المحلية' : 'Failed to restore data into IndexedDB'
      );
    } finally {
      setIsRestoring(false);
    }
  };

  const previewItems = verifiedPreview
    ? [
        { label: isAr ? 'العملاء' : 'Customers', value: verifiedPreview.tableCounts.customers, accent: 'text-emerald-300' },
        { label: isAr ? 'المهام' : 'Tasks', value: verifiedPreview.tableCounts.tasks, accent: 'text-sky-300' },
        { label: isAr ? 'النقاط' : 'Points', value: verifiedPreview.tableCounts.pointsLog, accent: 'text-amber-300' },
        { label: isAr ? 'البطاقات' : 'Cards', value: verifiedPreview.tableCounts.cardTypes, accent: 'text-indigo-300' },
        { label: isAr ? 'القوالب' : 'Templates', value: verifiedPreview.tableCounts.messageTemplates, accent: 'text-purple-300' },
        { label: isAr ? 'الحسابات' : 'Users', value: verifiedPreview.tableCounts.users, accent: 'text-teal-300' },
      ]
    : [];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      dir={dir}
    >
      <div className="bento-card bg-zinc-900 border-zinc-800 rounded-3xl w-full max-w-lg min-w-0 p-4 sm:p-5 shadow-2xl space-y-4 my-auto max-h-[92vh] overflow-y-auto">
        <div className="glow-top" />

        {/* Header */}
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="min-w-0">
              <h3 className="font-black text-sm text-white truncate">
                {isAr ? 'تصدير واستيراد قاعدة البيانات المشفّرة' : 'Encrypted IndexedDB Vault'}
              </h3>
              <p className="text-[10px] text-zinc-400 font-mono">
                AES-256-GCM · PBKDF2-SHA256 · IndexedDB
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-2 text-zinc-400 hover:text-white rounded-xl bg-zinc-800 hover:bg-zinc-700 transition-colors shrink-0"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Switch Tabs */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-zinc-950 border border-zinc-800">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setActiveTab('export');
              setImportError('');
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'export'
                ? 'bg-emerald-500 text-zinc-950 shadow-lg shadow-emerald-500/20'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isAr ? 'تصدير مشفّر (AES-256)' : 'Encrypted Export'}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setActiveTab('import');
              setExportError('');
            }}
            className={`py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'import'
                ? 'bg-sky-500 text-zinc-950 shadow-lg shadow-sky-500/20'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>{isAr ? 'استيراد وفك التشفير' : 'Import & Decrypt'}</span>
          </button>
        </div>

        {/* ==================== EXPORT TAB ==================== */}
        {activeTab === 'export' && (
          <form onSubmit={handleExportSubmit} className="space-y-4">
            {/* Live IndexedDB Stats Preview */}
            <div className="rounded-2xl bg-zinc-950/90 border border-zinc-800 p-3 space-y-2.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-zinc-300 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{isAr ? 'محتوى قاعدة البيانات المحلية (IndexedDB)' : 'Local IndexedDB Snapshot'}</span>
                </span>
                <span className="font-mono text-[10px] text-emerald-400 font-bold">
                  {loadingStats
                    ? '...'
                    : `${formatNumber(dbStats?.totalRecords ?? 0)} ${isAr ? 'سجل' : 'records'}`}
                </span>
              </div>

              {dbStats && (
                <div className="grid grid-cols-3 gap-1.5 text-center">
                  <div className="rounded-xl bg-zinc-900/90 border border-zinc-800/80 py-1.5 px-2">
                    <div className="text-[9px] text-zinc-400">{isAr ? 'العملاء' : 'Customers'}</div>
                    <div className="text-xs font-black text-white font-mono">{formatNumber(dbStats.counts.customers)}</div>
                  </div>
                  <div className="rounded-xl bg-zinc-900/90 border border-zinc-800/80 py-1.5 px-2">
                    <div className="text-[9px] text-zinc-400">{isAr ? 'المهام والنقاط' : 'Tasks & Pts'}</div>
                    <div className="text-xs font-black text-amber-300 font-mono">
                      {formatNumber(dbStats.counts.tasks + dbStats.counts.pointsLog)}
                    </div>
                  </div>
                  <div className="rounded-xl bg-zinc-900/90 border border-zinc-800/80 py-1.5 px-2">
                    <div className="text-[9px] text-zinc-400">{isAr ? 'الجداول الأخرى' : 'Config & Logs'}</div>
                    <div className="text-xs font-black text-indigo-300 font-mono">
                      {formatNumber(
                        dbStats.counts.users +
                          dbStats.counts.cardTypes +
                          dbStats.counts.products +
                          dbStats.counts.statuses +
                          dbStats.counts.messageTemplates +
                          dbStats.counts.settings +
                          dbStats.counts.operationsLog +
                          dbStats.counts.salaryTiers
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Encryption Toggle */}
            <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
              <div className="min-w-0">
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{isAr ? 'تشفير AES-256-GCM بكلمة مرور' : 'AES-256-GCM Password Encryption'}</span>
                </div>
                <div className="text-[10px] text-zinc-400 mt-0.5">
                  {isAr
                    ? 'تشفير محلي كامل مع بصمة تحقق SHA-256 وملح عشوائي 128-bit'
                    : 'Local authenticated encryption with SHA-256 checksum & random 128-bit salt'}
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic('light');
                  setEncryptEnabled((v) => !v);
                  setExportError('');
                }}
                className={`w-12 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 ${
                  encryptEnabled ? 'bg-emerald-500 justify-end' : 'bg-zinc-800 justify-start border border-zinc-700'
                }`}
              >
                <div className="w-4 h-4 bg-white rounded-full shadow" />
              </button>
            </div>

            {encryptEnabled && (
              <div className="space-y-3">
                {/* Passphrase field + Generate/Copy buttons */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-[11px] font-bold text-zinc-300">
                      {isAr ? 'كلمة مرور التشفير (6 أحرف فأكثر)' : 'Encryption Passphrase (min 6 chars)'}
                    </label>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleGeneratePassphrase}
                        className="text-[10px] font-bold text-emerald-300 hover:text-emerald-200 bg-emerald-500/10 border border-emerald-500/25 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>{isAr ? 'توليد قوية' : 'Generate'}</span>
                      </button>
                      {passphrase && (
                        <button
                          type="button"
                          onClick={handleCopyPassphrase}
                          className="text-[10px] font-bold text-zinc-200 hover:text-white bg-zinc-800 border border-zinc-700 px-2 py-1 rounded-lg flex items-center gap-1 transition-colors"
                        >
                          {copiedGenerated ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedGenerated ? (isAr ? 'نُسخت' : 'Copied') : (isAr ? 'نسخ' : 'Copy')}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="relative">
                    <input
                      type={showExportPass ? 'text' : 'password'}
                      value={passphrase}
                      onChange={(e) => {
                        setPassphrase(e.target.value);
                        setExportError('');
                      }}
                      placeholder={isAr ? 'أدخل كلمة مرور قوية لحماية الملف...' : 'Enter strong passphrase...'}
                      required
                      className="w-full h-11 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-emerald-500 focus:outline-none px-3 pe-10 text-sm text-white font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowExportPass((v) => !v)}
                      className="absolute inset-y-0 end-0 px-3 text-zinc-400 hover:text-white flex items-center"
                      aria-label={showExportPass ? 'Hide password' : 'Show password'}
                    >
                      {showExportPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Strength bar */}
                  {passphrase.length > 0 && (
                    <div className="space-y-1 pt-0.5">
                      <div className="grid grid-cols-4 gap-1">
                        {[1, 2, 3, 4].map((step) => (
                          <div
                            key={step}
                            className={`h-1.5 rounded-full transition-colors ${
                              strength.score >= step ? strength.colorClass : 'bg-zinc-800'
                            }`}
                          />
                        ))}
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-zinc-400">{isAr ? 'قوة التشفير:' : 'Strength:'}</span>
                        <span className="font-bold text-zinc-200">
                          {isAr ? strength.labelAr : strength.labelEn}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Confirm Passphrase */}
                <div className="space-y-1">
                  <label className="block text-[11px] font-bold text-zinc-300">
                    {isAr ? 'تأكيد كلمة مرور التشفير' : 'Confirm Passphrase'}
                  </label>
                  <input
                    type={showExportPass ? 'text' : 'password'}
                    value={confirmPassphrase}
                    onChange={(e) => {
                      setConfirmPassphrase(e.target.value);
                      setExportError('');
                    }}
                    placeholder="••••••"
                    required
                    className="w-full h-11 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-emerald-500 focus:outline-none px-3 text-sm text-white font-mono"
                  />
                </div>

                <div className="flex items-start gap-2 rounded-xl bg-amber-500/10 border border-amber-500/25 p-2.5 text-[10px] text-amber-200 leading-relaxed">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    {isAr
                      ? 'التشفير يتم محلياً بالكامل داخل جهازك بدون خادم خارجي. احتفظ بكلمة المرور جيداً لأنه لا يمكن فك تشفير الملف بدونها.'
                      : 'Encryption runs 100% locally in your browser. Keep your passphrase safe — it cannot be recovered if lost.'}
                  </span>
                </div>
              </div>
            )}

            {exportError && (
              <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 p-2.5 text-xs font-bold text-rose-300">
                {exportError}
              </div>
            )}

            <button
              type="submit"
              disabled={isExporting}
              className="w-full min-h-[46px] rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-zinc-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
            >
              {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              <span>
                {isExporting
                  ? isAr
                    ? 'جاري تشفير قاعدة البيانات وتجهيز الملف...'
                    : 'Encrypting & Exporting...'
                  : encryptEnabled
                    ? isAr
                      ? 'تشفير وتصدير قاعدة البيانات (.enc.json)'
                      : 'Encrypt & Export Database (.enc.json)'
                    : isAr
                      ? 'تصدير نسخة JSON غير مشفرة'
                      : 'Export Plain JSON Backup'}
              </span>
            </button>
          </form>
        )}

        {/* ==================== IMPORT & DECRYPT TAB ==================== */}
        {activeTab === 'import' && (
          <div className="space-y-4">
            {/* Step 1: Select or Drop Backup File */}
            {!inspectedFile && (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all relative bg-zinc-950/60 ${
                  isDragging
                    ? 'border-sky-400 bg-sky-500/10'
                    : 'border-zinc-700 hover:border-sky-500/70'
                }`}
              >
                <Upload className="w-10 h-10 mx-auto text-sky-400 mb-2.5" />
                <div className="font-extrabold text-xs text-white mb-1">
                  {isAr
                    ? 'اسحب ملف النسخة المشفرة هنا أو اضغط للاختيار'
                    : 'Drop encrypted backup file here or click to browse'}
                </div>
                <div className="text-[10px] text-zinc-400 font-mono">
                  .enc.json (AES-256-GCM) · .json · Max 25MB
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json,.enc.json,application/json"
                  onChange={handleFileInputChange}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
            )}

            {/* Step 2: File Inspected — Needs Decryption Passphrase */}
            {inspectedFile && inspectedFile.isEncrypted && !verifiedPreview && (
              <form onSubmit={handleDecryptSubmit} className="space-y-3.5">
                <div className="rounded-2xl bg-zinc-950 border border-sky-500/30 p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileJson className="w-4 h-4 text-sky-400 shrink-0" />
                      <span className="text-xs font-bold text-white truncate">{inspectedFile.fileName}</span>
                    </div>
                    <button
                      type="button"
                      onClick={resetImportFlow}
                      className="text-[10px] font-bold text-zinc-400 hover:text-white flex items-center gap-1 shrink-0"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>{isAr ? 'تغيير الملف' : 'Change'}</span>
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-[10px] text-zinc-400 font-mono">
                    <span className="px-2 py-0.5 rounded-md bg-sky-500/15 text-sky-300 border border-sky-500/30 font-bold">
                      AES-256-GCM
                    </span>
                    <span>{formatFileSize(inspectedFile.fileSize)}</span>
                    {inspectedFile.iterations && (
                      <span>· {formatNumber(inspectedFile.iterations)} PBKDF2</span>
                    )}
                    {inspectedFile.createdAt && (
                      <span>· {new Date(inspectedFile.createdAt).toLocaleDateString(isAr ? 'ar-SA' : 'en-US')}</span>
                    )}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-zinc-300 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-sky-400" />
                    <span>{isAr ? 'أدخل كلمة مرور فك التشفير' : 'Enter Decryption Passphrase'}</span>
                  </label>
                  <div className="relative">
                    <input
                      type={showImportPass ? 'text' : 'password'}
                      value={decryptPassphrase}
                      onChange={(e) => {
                        setDecryptPassphrase(e.target.value);
                        setImportError('');
                      }}
                      placeholder="••••••"
                      autoFocus
                      required
                      className="w-full h-11 rounded-xl bg-zinc-950 border border-zinc-800 focus:border-sky-500 focus:outline-none px-3 pe-10 text-sm text-white font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowImportPass((v) => !v)}
                      className="absolute inset-y-0 end-0 px-3 text-zinc-400 hover:text-white flex items-center"
                      aria-label={showImportPass ? 'Hide password' : 'Show password'}
                    >
                      {showImportPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isDecrypting || !decryptPassphrase}
                  className="w-full min-h-[44px] rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-60 text-zinc-950 font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  {isDecrypting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
                  <span>
                    {isDecrypting
                      ? isAr
                        ? 'جاري فك التشفير والتحقق...'
                        : 'Decrypting & Verifying...'
                      : isAr
                        ? 'فك التشفير ومعاينة البيانات'
                        : 'Decrypt & Preview Data'}
                  </span>
                </button>
              </form>
            )}

            {/* Step 3: Decrypted & Verified Preview + Restore Options */}
            {verifiedPreview && (
              <div className="space-y-3.5">
                <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/30 p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-xs font-extrabold text-emerald-300">
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                      <span>
                        {verifiedPreview.wasEncrypted
                          ? isAr
                            ? 'تم فك تشفير الملف والتحقق من سلامته بنجاح'
                            : 'Decrypted & Verified Successfully'
                          : isAr
                            ? 'تم فحص ملف النسخة الاحتياطية بنجاح'
                            : 'Backup File Validated'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={resetImportFlow}
                      className="text-[10px] font-bold text-zinc-400 hover:text-white shrink-0"
                    >
                      {isAr ? 'ملف آخر' : 'Reset'}
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-[10px] text-zinc-300">
                    <span className="font-mono truncate max-w-[200px]">{verifiedPreview.fileName}</span>
                    {verifiedPreview.exportDate && (
                      <span>
                        · {new Date(verifiedPreview.exportDate).toLocaleString(isAr ? 'ar-SA' : 'en-US')}
                      </span>
                    )}
                    {verifiedPreview.integrityVerified === true && (
                      <span className="text-emerald-300 font-bold">· SHA-256 OK</span>
                    )}
                    {verifiedPreview.integrityVerified === false && (
                      <span className="text-amber-300 font-bold">
                        · {isAr ? 'تحذير: البصمة غير مطابقة' : 'Checksum mismatch'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Record Breakdown Grid */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  {previewItems.map((item) => (
                    <div
                      key={item.label}
                      className="rounded-xl bg-zinc-950 border border-zinc-800 p-2"
                    >
                      <div className="text-[10px] text-zinc-400">{item.label}</div>
                      <div className={`text-sm font-black font-mono ${item.accent}`}>
                        {formatNumber(item.value)}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Restore Mode Selector */}
                {canRestoreDatabase ? (
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-zinc-300 flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-indigo-400" />
                      <span>{isAr ? 'طريقة استعادة البيانات إلى قاعدة البيانات:' : 'Restore Mode:'}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          triggerHaptic('light');
                          setRestoreMode('replace');
                        }}
                        className={`p-2.5 rounded-xl border text-start transition-all ${
                          restoreMode === 'replace'
                            ? 'bg-emerald-500/15 border-emerald-500/50 text-white'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <div className="text-xs font-extrabold">
                          {isAr ? 'استبدال كامل' : 'Full Replace'}
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-0.5">
                          {isAr ? 'تطابق تام مع النسخة المستعادة' : 'Clean replace with backup'}
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          triggerHaptic('light');
                          setRestoreMode('merge');
                        }}
                        className={`p-2.5 rounded-xl border text-start transition-all ${
                          restoreMode === 'merge'
                            ? 'bg-sky-500/15 border-sky-500/50 text-white'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                        }`}
                      >
                        <div className="text-xs font-extrabold">
                          {isAr ? 'دمج آمن' : 'Safe Merge'}
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-0.5">
                          {isAr ? 'إضافة وتحديث بدون مسح الحالي' : 'Upsert without wiping'}
                        </div>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-3 text-[11px] text-amber-200">
                    {isAr
                      ? 'تم فك التشفير بنجاح! استعادة البيانات إلى قاعدة البيانات متاحة لحساب المدير فقط، ويمكنك تنزيل النسخة المفكوكة للمعاينة أدناه.'
                      : 'Decrypted successfully! Restoring into the database requires Administrator role; you may still download the decrypted JSON below.'}
                  </div>
                )}

                {/* Final Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-2">
                  {canRestoreDatabase && (
                    <button
                      type="button"
                      onClick={handleConfirmRestore}
                      disabled={isRestoring}
                      className="flex-1 min-h-[44px] rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-zinc-950 font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
                    >
                      {isRestoring ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
                      <span>
                        {isRestoring
                          ? isAr
                            ? 'جاري الاستعادة...'
                            : 'Restoring...'
                          : restoreMode === 'replace'
                            ? isAr
                              ? `استعادة واستبدال (${formatNumber(verifiedPreview.totalRecords)} سجل)`
                              : `Restore & Replace (${verifiedPreview.totalRecords})`
                            : isAr
                              ? `دمج البيانات (${formatNumber(verifiedPreview.totalRecords)} سجل)`
                              : `Merge Data (${verifiedPreview.totalRecords})`}
                      </span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      downloadDecryptedBackupJson(verifiedPreview);
                      showToast(
                        isAr ? 'تم تنزيل ملف JSON مفكوك التشفير بنجاح 📄' : 'Decrypted JSON downloaded 📄',
                        'success'
                      );
                    }}
                    className="min-h-[44px] px-3.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isAr ? 'حفظ JSON مفكوك' : 'Save Decrypted JSON'}</span>
                  </button>
                </div>
              </div>
            )}

            {importError && (
              <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 p-2.5 text-xs font-bold text-rose-300">
                {importError}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
