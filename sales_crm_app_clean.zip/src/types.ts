export type UserRole = 'admin' | 'sales';
export type ProductType = 'visa' | 'finance';
export type CustomerStatus = 'عميل محتمل' | 'عميل معلق' | 'تم التنفيذ' | 'تم التفعيل' | 'بانتظار التفعيل' | 'مكتمل' | 'متابعة' | (string & {});

export interface User {
  id?: number;
  username: string;
  password: string;
  role: UserRole;
  permissions?: string;
  pin?: string | null;
  biometricEnabled?: boolean;
  createdAt: Date;
}

export interface CardType {
  id?: number;
  name: string;
  type: string;
  pointsFormula: string;
  points?: number | null;
  isCustom: boolean;
  createdAt: Date;
}

export interface Product {
  id?: number;
  name: string;
  type: ProductType;
  amount?: number;
  createdAt: Date;
}

export interface StatusConfig {
  id?: number;
  name: string;
  nameEn?: string;
  color: string;
  description?: string;
  order: number;
  isCustom?: boolean;
}

export interface MessageTemplate {
  id?: number;
  name: string;
  content: string;
  type: string;
  createdAt: Date;
}

export interface Customer {
  id?: number;
  name: string;
  phone: string;
  email?: string | null;
  status: CustomerStatus;
  productType: ProductType;
  cardTypeId?: number | null;
  cardTypeName?: string | null;
  salary?: number | null;
  amount?: number | null;
  financeType?: 'salary_transfer' | 'no_salary_transfer' | string | null;
  financeRate?: number | null;
  points?: number | null;
  orderNumber: string;
  idNumber?: string | null;
  createdAt: Date;
  updatedAt: Date;
  followUpDate?: string | null;
  salesRepId?: number;
  notes?: string | null;
  lastReminderDismissed?: Date | null;
  activatedAt?: Date | null;
  targetMonth?: string | null;
}

export interface OperationLog {
  id?: number;
  action: string;
  tableName: string;
  recordId?: number | null;
  oldData?: string | null;
  newData?: string | null;
  userId?: number | null;
  timestamp: Date;
}

export interface Backup {
  id?: number;
  name: string;
  data: string;
  createdAt: Date;
}

export interface AppSetting {
  key: string;
  value: any;
}

export interface PointLog {
  id?: number;
  customerId: number;
  salesRepId?: number;
  points: number;
  reason: string;
  month: number;
  year: number;
  timestamp: Date;
}

export interface PendingReminder {
  customer: Customer;
  daysPending: number;
  isOverdue: boolean;
  nextReminder: Date;
  reason?: 'pending_activation' | 'followup_due';
  dueDate?: string;
}

export type TaskStatus = 'pending' | 'completed' | 'postponed'; // معلقة | تم إنجازها | مؤجلة
export type TaskType = 'followup' | 'appointment' | 'activation' | 'note' | 'custom';

export interface DailyTask {
  id?: number;
  customerId?: number | null;
  title: string;
  type: TaskType;
  date: string; // YYYY-MM-DD
  status: TaskStatus;
  notes?: string | null;
  time?: string | null;
  priority?: 'high' | 'medium' | 'low';
  createdAt: Date;
  completedAt?: Date | null;
}

export interface SalaryTier {
  id?: number;
  minSalary: number;
  maxSalary: number;
  percentage: number; // e.g. 1.25 for 1.25%, 1.5 for 1.5%
  appliesToVisaOnly: boolean;
  description?: string;
  createdAt?: Date;
}

export type PageView = 'dashboard' | 'customers' | 'addCustomer' | 'reports' | 'reminders' | 'settings' | 'admin';
