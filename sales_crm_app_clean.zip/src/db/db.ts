import Dexie, { type Table } from 'dexie';
import { cleanPhoneString } from '../context/LanguageContext';
import { getCurrentMonthKey, getExactDateForMonth } from '../utils/monthRollover';
import { DEFAULT_PERSONAL_FINANCE_RATES } from '../utils/finance';
import { normalizePhoneForMatch, hashPassword, isPasswordHashed, sanitizePlainText } from '../utils/security';
import type {
  Customer,
  User,
  CardType,
  Product,
  StatusConfig,
  MessageTemplate,
  OperationLog,
  Backup,
  AppSetting,
  PointLog,
  DailyTask,
  SalaryTier,
  ProductType,
  CustomerStatus
} from '../types';

export class SalesCRMDatabase extends Dexie {
  customers!: Table<Customer, number>;
  users!: Table<User, number>;
  cardTypes!: Table<CardType, number>;
  products!: Table<Product, number>;
  statuses!: Table<StatusConfig, number>;
  messageTemplates!: Table<MessageTemplate, number>;
  operationsLog!: Table<OperationLog, number>;
  backups!: Table<Backup, number>;
  settings!: Table<AppSetting, string>;
  pointsLog!: Table<PointLog, number>;
  tasks!: Table<DailyTask, number>;
  salaryTiers!: Table<SalaryTier, number>;

  constructor() {
    super('SalesCRM');
    this.version(1).stores({
      customers: '++id, name, phone, email, status, productType, cardTypeId, salary, orderNumber, createdAt, updatedAt, followUpDate, salesRepId',
      users: '++id, username, password, role, permissions, pin, biometricEnabled, createdAt',
      cardTypes: '++id, name, type, pointsFormula, isCustom, createdAt',
      products: '++id, name, type, amount, createdAt',
      statuses: '++id, name, color, description, order',
      messageTemplates: '++id, name, content, type, createdAt',
      operationsLog: '++id, action, tableName, recordId, oldData, newData, userId, timestamp',
      backups: '++id, name, data, createdAt',
      settings: 'key, value',
      pointsLog: '++id, customerId, salesRepId, points, reason, month, year, timestamp',
      tasks: '++id, customerId, date, status, type, priority, createdAt',
      salaryTiers: '++id, minSalary, maxSalary, percentage, appliesToVisaOnly'
    });

    // Version 2: Added high-performance secondary and compound indices for status, dates, customer queries, tasks, and logging
    this.version(2).stores({
      customers: '++id, name, phone, email, status, productType, cardTypeId, salary, orderNumber, createdAt, updatedAt, followUpDate, salesRepId, [status+productType], [salesRepId+status]',
      users: '++id, username, password, role, permissions, pin, biometricEnabled, createdAt',
      cardTypes: '++id, name, type, pointsFormula, isCustom, createdAt',
      products: '++id, name, type, amount, createdAt',
      statuses: '++id, name, color, description, order',
      messageTemplates: '++id, name, content, type, createdAt',
      operationsLog: '++id, action, tableName, recordId, oldData, newData, userId, timestamp, [tableName+recordId]',
      backups: '++id, name, data, createdAt',
      settings: 'key, value',
      pointsLog: '++id, customerId, salesRepId, points, reason, month, year, timestamp, [customerId+timestamp]',
      tasks: '++id, customerId, date, status, type, priority, createdAt, [customerId+date], [date+status]',
      salaryTiers: '++id, minSalary, maxSalary, percentage, appliesToVisaOnly'
    });
  }
}

export const db = new SalesCRMDatabase();

// Default Admin template (password is never hardcoded; set by owner on first launch)
export const DEFAULT_ADMIN_USERNAME = 'admin';

export const DEFAULT_SALARY_TIERS: Omit<SalaryTier, 'id'>[] = [
  { minSalary: 6000, maxSalary: 15000, percentage: 0, appliesToVisaOnly: true, description: 'راتب 6,000 إلى 15,000 ريال (نقاط البطاقة فقط بدون زيادة)', createdAt: new Date() },
  { minSalary: 15001, maxSalary: 30000, percentage: 1.25, appliesToVisaOnly: true, description: 'راتب 15,001 إلى 30,000 ريال (1.25x)', createdAt: new Date() },
  { minSalary: 30001, maxSalary: 999999, percentage: 1.50, appliesToVisaOnly: true, description: 'راتب أكثر من 30,000 ريال (1.50x)', createdAt: new Date() }
];

export const DEFAULT_CARD_TYPES: Omit<CardType, 'id'>[] = [
  { name: 'Infinite', type: 'Infinite', pointsFormula: 'custom', points: 8500, isCustom: false, createdAt: new Date() },
  { name: 'Platinum', type: 'Platinum', pointsFormula: 'custom', points: 4250, isCustom: false, createdAt: new Date() },
  { name: 'Mazeed', type: 'Mazeed', pointsFormula: 'custom', points: 4250, isCustom: false, createdAt: new Date() },
  { name: 'Platinum Plus', type: 'Platinum Plus', pointsFormula: 'custom', points: 4250, isCustom: false, createdAt: new Date() },
  { name: 'Rahala Infinite', type: 'Rahala Infinite', pointsFormula: 'custom', points: 8500, isCustom: false, createdAt: new Date() },
  { name: 'Rahala Platinum', type: 'Rahala Platinum', pointsFormula: 'custom', points: 4250, isCustom: false, createdAt: new Date() },
  { name: 'Jarir Infinite', type: 'Jarir Infinite', pointsFormula: 'custom', points: 8500, isCustom: false, createdAt: new Date() },
  { name: 'Jarir Platinum', type: 'Jarir Platinum', pointsFormula: 'custom', points: 4250, isCustom: false, createdAt: new Date() }
];

export const DEFAULT_STATUSES: Omit<StatusConfig, 'id'>[] = [
  { name: 'عميل محتمل', nameEn: 'Potential', color: '#3b82f6', description: 'عميل محتمل في طور التواصل والمتابعة', order: 1 },
  { name: 'عميل معلق', nameEn: 'Pending', color: '#f59e0b', description: 'عميل معلق (سبب التعليق مذكور في الملاحظات)', order: 2 },
  { name: 'تم التنفيذ', nameEn: 'Executed', color: '#06b6d4', description: 'تم تنفيذ وإنجاز الطلب بنجاح', order: 3 },
  { name: 'تم التفعيل', nameEn: 'Activated', color: '#22c55e', description: 'خاص ببطاقات Visa بجميع أنواعها - تم تفعيل البطاقة واحتساب النقاط للهدف', order: 4 }
];

export const DEFAULT_TEMPLATES: Omit<MessageTemplate, 'id'>[] = [
  { name: 'متابعة عامة', content: 'مرحباً {name}، نود متابعة طلبك رقم {orderNumber}. هل تحتاج مساعدة إضافية؟', type: 'followup', createdAt: new Date() },
  { name: 'موافقة', content: 'تهانينا {name}! تمت الموافقة على طلبك رقم {orderNumber}. سنتواصل معك قريباً.', type: 'approval', createdAt: new Date() },
  { name: 'رفض', content: 'عذراً {name}، لم تتم الموافقة على طلبك رقم {orderNumber}. يرجى التواصل لمزيد من التفاصيل.', type: 'rejection', createdAt: new Date() },
  { name: 'قيد المراجعة', content: 'مرحباً {name}، طلبك رقم {orderNumber} قيد المراجعة. سنُبلغك بالنتيجة قريباً.', type: 'review', createdAt: new Date() },
  { name: 'تذكير', content: 'تذكير {name}: طلبك رقم {orderNumber} بانتظار التفعيل. يرجى إكمال الإجراءات المطلوبة.', type: 'reminder', createdAt: new Date() },
  { name: 'طلب مستندات', content: 'مرحباً {name}، نحتاج مستندات إضافية لطلبك رقم {orderNumber}. يرجى إرسالها في أقرب وقت.', type: 'documents', createdAt: new Date() },
  { name: 'شكر وتقييم', content: 'شكراً {name} لثقتك بنا! نرجو تقييم خدمتنا لتطوير تجربتك.', type: 'thanks', createdAt: new Date() },
  { name: 'تفعيل البطاقة', content: 'تهانينا {name}! تم تفعيل بطاقتك رقم {orderNumber} بنجاح. يمكنك البدء في الاستخدام فوراً.', type: 'activation', createdAt: new Date() }
];

export const DEFAULT_SETTINGS: Record<string, any> = {
  appName: 'Sales CRM',
  logo: '💼',
  primaryColor: '#0ea5e9',
  monthlyTarget: 140000,
  showPoints: true,
  reminderEnabled: true,
  reminderInterval: 3,
  reminderEscalationDays: 7,
  reminderTime: '09:00',
  language: 'ar',
  supportWhatsAppNumber: '0544067585',
  companyName: 'Sales CRM Pro',
  companySubtitle: 'المنظومة الاحترافية لمبيعات التمويل والبطاقات',
  personalFinanceRates: DEFAULT_PERSONAL_FINANCE_RATES
};

export const DEFAULT_CUSTOMERS: Omit<Customer, 'id'>[] = [];

// Database Initialization Helper
let isSeeding = false;

export async function seedDatabase() {
  if (isSeeding) return;
  isSeeding = true;
  try {
    await db.transaction('rw', [db.users, db.cardTypes, db.statuses, db.messageTemplates, db.settings, db.salaryTiers, db.customers, db.pointsLog, db.operationsLog], async () => {
      // Automatically upgrade any legacy plaintext user passwords to salted PBKDF2-SHA256 hashes
      const allUsers = await db.users.toArray();
      for (const u of allUsers) {
        if (u.id && u.password && !isPasswordHashed(u.password) && !u.password.startsWith('pbkdf2_fb$')) {
          const hashed = await hashPassword(u.password);
          await db.users.update(u.id, { password: hashed });
        }
      }

      const cardCount = await db.cardTypes.count();
      if (cardCount === 0) {
        await db.cardTypes.bulkPut(DEFAULT_CARD_TYPES as CardType[]);
      } else {
        const existingCards = await db.cardTypes.toArray();
        for (const ct of existingCards) {
          if (typeof ct.points === 'number' && (ct.points <= 100 || ct.points === 4500)) {
            const isInfinite = ct.name.toLowerCase().includes('infinite');
            await db.cardTypes.update(ct.id!, { points: isInfinite ? 8500 : 4250 });
          }
        }
      }

      const existingStatuses = await db.statuses.toArray();
      if (existingStatuses.length === 0) {
        await db.statuses.bulkPut(DEFAULT_STATUSES as StatusConfig[]);
      } else {
        // Clean up duplicate status entries and retire legacy 'بانتظار التفعيل' status
        const seenStatusNames = new Set<string>();
        for (const st of existingStatuses) {
          if (st.name === 'بانتظار التفعيل' || seenStatusNames.has(st.name)) {
            if (st.id) await db.statuses.delete(st.id);
          } else {
            seenStatusNames.add(st.name);
          }
        }
      }

      const templateCount = await db.messageTemplates.count();
      if (templateCount === 0) {
        await db.messageTemplates.bulkPut(DEFAULT_TEMPLATES as MessageTemplate[]);
      }

      const tierCount = await db.salaryTiers.count();
      if (tierCount === 0) {
        await db.salaryTiers.bulkPut(DEFAULT_SALARY_TIERS as SalaryTier[]);
      } else {
        const existingTiers = await db.salaryTiers.toArray();
        for (const tier of existingTiers) {
          if (tier.minSalary === 0) {
            await db.salaryTiers.update(tier.id!, {
              minSalary: 6000,
              description: 'راتب 6,000 إلى 15,000 ريال (نقاط البطاقة فقط بدون زيادة)'
            });
          }
        }
      }

      for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
        const existing = await db.settings.get(key);
        if (!existing) {
          await db.settings.put({ key, value });
        }
      }

      // Ensure supportWhatsAppNumber is set if empty
      const existingSupportPhone = await db.settings.get('supportWhatsAppNumber');
      if (!existingSupportPhone || !existingSupportPhone.value || existingSupportPhone.value === '+966500000000') {
        await db.settings.put({ key: 'supportWhatsAppNumber', value: '0544067585' });
      }

      // Ensure personalFinanceRates is set if missing
      const existingFinanceRates = await db.settings.get('personalFinanceRates');
      if (!existingFinanceRates || !existingFinanceRates.value) {
        await db.settings.put({ key: 'personalFinanceRates', value: DEFAULT_PERSONAL_FINANCE_RATES });
      }

      // Repair points for ALL customers whose points were calculated as 0 or missing
      const allCardTypes = await db.cardTypes.toArray();
      const updatedTiers = await db.salaryTiers.toArray();
      const allCustomers = await db.customers.toArray();

      for (const cust of allCustomers) {
        // Silently migrate legacy 'بانتظار التفعيل' status to unified 'تم التنفيذ'
        if ((cust.status || '').trim() === 'بانتظار التفعيل' && cust.id) {
          await db.customers.update(cust.id, { status: 'تم التنفيذ' });
          cust.status = 'تم التنفيذ';
        }

        const cardType = allCardTypes.find(ct => ct.id === cust.cardTypeId);
        const basePoints = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
        const sal = cust.salary || 0;
        
        let computedPts = cust.points || 0;
        if (computedPts === 0 || computedPts % 1 !== 0) {
          if (basePoints > 0) {
            computedPts = calculateCardPoints(basePoints, sal, cust.productType || 'visa', updatedTiers);
          } else if (sal >= 6000) {
            computedPts = calculatePoints(sal);
          } else if (computedPts > 0) {
            computedPts = Math.round(computedPts);
          }
          if (computedPts > 0) {
            await db.customers.update(cust.id!, { points: computedPts });
            cust.points = computedPts;
          }
        }

        if (cust.status === 'تم التفعيل' && computedPts > 0 && cust.id) {
          const existingLog = await db.pointsLog.where('customerId').equals(cust.id).first();
          if (!existingLog) {
            const actDate = cust.activatedAt ? new Date(cust.activatedAt) : (cust.updatedAt ? new Date(cust.updatedAt) : new Date(cust.createdAt));
            await db.pointsLog.add({
              customerId: cust.id,
              salesRepId: cust.salesRepId,
              points: computedPts,
              reason: `تفعيل بطاقة Visa (${cust.name})`,
              month: actDate.getMonth() + 1,
              year: actDate.getFullYear(),
              timestamp: actDate
            });
          }
        }
      }
      // Note: No customer data is seeded automatically on startup or reload.
      // Customer tables remain strictly clean after wiping.
    });
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    isSeeding = false;
  }
}

export async function generateDemoData(force: boolean = false) {
  const count = await db.customers.count();
  if (!force && count > 0) return;

  await db.settings.put({ key: 'data_wiped_clean', value: 'false' });
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.removeItem('sales_crm_data_wiped_clean');
    } catch {
      // Ignore
    }
  }

  const now = new Date();
  const prevMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 15, 12, 0, 0);
  const prevMonthKey = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}`;
  const prevMonthNameAr = prevMonthDate.toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' });
  const prevMonthNameEn = prevMonthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const cardTypes = await db.cardTypes.toArray();
  const infiniteCard = cardTypes.find(c => c.name.toLowerCase().includes('infinite')) || cardTypes[0];
  const platinumCard = cardTypes.find(c => c.name.toLowerCase().includes('platinum')) || cardTypes[1] || cardTypes[0];

  const adminUser = await db.users.where('role').equals('admin').first();
  const salesRepId = adminUser?.id || 1;

  const demoCustomers: Omit<Customer, 'id'>[] = [
    // Potential Customers
    {
      name: 'عبد الرحمن الغامدي',
      phone: '0501234567',
      email: 'a.alghamdi@example.com',
      status: 'عميل محتمل',
      productType: 'visa',
      cardTypeId: infiniteCard?.id || 1,
      salary: 18500,
      orderNumber: '100201',
      notes: 'مهتم ببطاقة Jarir Infinite، تم إرسال الميزات وتحديد موعد متابعة',
      followUpDate: new Date(now.getTime() + 86400000 * 2).toISOString().split('T')[0],
      salesRepId,
      points: 8500,
      createdAt: new Date(now.getTime() - 86400000 * 5),
      updatedAt: new Date(now.getTime() - 86400000 * 5)
    },
    {
      name: 'سارة الشهري',
      phone: '0559876543',
      email: 's.alshehri@example.com',
      status: 'عميل محتمل',
      productType: 'finance',
      financeType: 'salary_transfer',
      amount: 120000,
      salary: 12500,
      orderNumber: '100202',
      notes: 'استفسار عن تمويل شخصي بضمان تحويل الراتب',
      salesRepId,
      createdAt: new Date(now.getTime() - 86400000 * 4),
      updatedAt: new Date(now.getTime() - 86400000 * 4)
    },
    {
      name: 'خالد الدوسري',
      phone: '0541122334',
      status: 'متابعة',
      productType: 'visa',
      cardTypeId: platinumCard?.id || 2,
      salary: 9500,
      orderNumber: '100203',
      notes: 'متابعة لإرسال صورة الهوية الوطنية وتأكيد الطلب',
      followUpDate: new Date(now.getTime() + 86400000).toISOString().split('T')[0],
      salesRepId,
      points: 4250,
      createdAt: new Date(now.getTime() - 86400000 * 3),
      updatedAt: new Date(now.getTime() - 86400000 * 3)
    },
    {
      name: 'نوف المطيري',
      phone: '0503344556',
      status: 'عميل محتمل',
      productType: 'finance',
      financeType: 'no_salary_transfer',
      amount: 95000,
      salary: 15000,
      orderNumber: '100204',
      notes: 'تم تقديم شرح شروط التمويل بدون تحويل راتب',
      salesRepId,
      createdAt: new Date(now.getTime() - 86400000 * 2),
      updatedAt: new Date(now.getTime() - 86400000 * 2)
    },

    // Pending & Postponed Customers
    {
      name: 'فهد العتيبي',
      phone: '0563344556',
      status: 'عميل معلق',
      productType: 'visa',
      cardTypeId: infiniteCard?.id || 1,
      salary: 22000,
      orderNumber: '100205',
      notes: 'بانتظار تزويدنا بخطاب تعريف الراتب المحدث موثق من الغرفة التجارية',
      salesRepId,
      points: 8500,
      createdAt: new Date(now.getTime() - 86400000 * 7),
      updatedAt: new Date(now.getTime() - 86400000 * 1)
    },
    {
      name: 'منيرة القحطاني',
      phone: '0507788990',
      status: 'مؤجل',
      productType: 'finance',
      financeType: 'no_salary_transfer',
      amount: 85000,
      salary: 11000,
      orderNumber: '100206',
      notes: 'تم تأجيل التواصل بناءً على رغبة العميل إلى بداية الأسبوع القادم',
      followUpDate: new Date(now.getTime() + 86400000 * 5).toISOString().split('T')[0],
      salesRepId,
      createdAt: new Date(now.getTime() - 86400000 * 8),
      updatedAt: new Date(now.getTime() - 86400000 * 2)
    },
    {
      name: 'سلطان الشمري',
      phone: '0534455667',
      status: 'مكتمَل الأوراق',
      productType: 'visa',
      cardTypeId: platinumCard?.id || 2,
      salary: 14000,
      orderNumber: '100207',
      notes: 'جميع الأوراق مكتملة وبانتظار الموافقة النهائية من قسم الائتمان',
      salesRepId,
      points: 4250,
      createdAt: new Date(now.getTime() - 86400000 * 6),
      updatedAt: new Date(now.getTime() - 86400000 * 1)
    },

    // Current Month Executed & Activated
    {
      name: 'محمد المطيري',
      phone: '0512233445',
      status: 'تم التفعيل',
      productType: 'visa',
      cardTypeId: infiniteCard?.id || 1,
      salary: 25000,
      orderNumber: '100208',
      notes: 'تم تفعيل بطاقة Jarir Infinite بنجاح واحتساب النقاط',
      salesRepId,
      points: 8500,
      createdAt: new Date(now.getTime() - 86400000 * 10),
      updatedAt: now,
      activatedAt: now
    },
    {
      name: 'فيصل السبيعي',
      phone: '0598877665',
      status: 'تم التفعيل',
      productType: 'visa',
      cardTypeId: platinumCard?.id || 2,
      salary: 16000,
      orderNumber: '100209',
      notes: 'تم تفعيل بطاقة Jarir Platinum بنجاح',
      salesRepId,
      points: 4250,
      createdAt: new Date(now.getTime() - 86400000 * 9),
      updatedAt: now,
      activatedAt: now
    },
    {
      name: 'عبد الله الزهراني',
      phone: '0581122334',
      status: 'تم التنفيذ',
      productType: 'finance',
      financeType: 'salary_transfer',
      amount: 150000,
      salary: 14500,
      orderNumber: '100210',
      notes: 'تم صرف مبلغ التمويل وتحويل الراتب بنجاح',
      salesRepId,
      createdAt: new Date(now.getTime() - 86400000 * 11),
      updatedAt: now,
      activatedAt: now
    },

    // Previous Month Executed & Activated
    {
      name: 'سلمان العنيزي',
      phone: '0509988776',
      status: 'تم التفعيل',
      productType: 'visa',
      cardTypeId: infiniteCard?.id || 1,
      salary: 30000,
      orderNumber: '100101',
      notes: 'تم التفعيل في الشهر السابق - Jarir Infinite',
      salesRepId,
      points: 8500,
      createdAt: new Date(prevMonthDate.getTime() - 86400000 * 5),
      updatedAt: prevMonthDate,
      activatedAt: prevMonthDate
    },
    {
      name: 'نورة العتيبي',
      phone: '0554433221',
      status: 'تم التفعيل',
      productType: 'visa',
      cardTypeId: platinumCard?.id || 2,
      salary: 17500,
      orderNumber: '100102',
      notes: 'تم التفعيل في الشهر السابق - Jarir Platinum',
      salesRepId,
      points: 4250,
      createdAt: new Date(prevMonthDate.getTime() - 86400000 * 4),
      updatedAt: prevMonthDate,
      activatedAt: prevMonthDate
    },
    {
      name: 'ماجد المالكي',
      phone: '0531122334',
      status: 'تم التنفيذ',
      productType: 'finance',
      financeType: 'salary_transfer',
      amount: 200000,
      salary: 21000,
      orderNumber: '100103',
      notes: 'تم التنفيذ في الشهر السابق - تمويل شخصي',
      salesRepId,
      createdAt: new Date(prevMonthDate.getTime() - 86400000 * 6),
      updatedAt: prevMonthDate,
      activatedAt: prevMonthDate
    }
  ];

  for (const cust of demoCustomers) {
    const newId = await db.customers.add(cust as Customer);
    if ((cust.status === 'تم التفعيل' || cust.status === 'تم التنفيذ') && cust.points && cust.points > 0 && newId) {
      const actDate = cust.activatedAt ? new Date(cust.activatedAt) : new Date(cust.createdAt);
      await db.pointsLog.add({
        customerId: newId,
        salesRepId: cust.salesRepId,
        points: cust.points,
        reason: `تفعيل / تنفيذ (${cust.name})`,
        month: actDate.getMonth() + 1,
        year: actDate.getFullYear(),
        timestamp: actDate
      });
    }
  }

  // Create previous month snapshot entry in db.settings
  const existingSnapshotsSetting = await db.settings.get('monthlySnapshots');
  let snapshots: any[] = [];
  if (existingSnapshotsSetting?.value) {
    try {
      snapshots = JSON.parse(existingSnapshotsSetting.value);
    } catch (e) {
      snapshots = [];
    }
  }

  const prevSnapshotExists = snapshots.some((s: any) => s.monthKey === prevMonthKey);
  if (!prevSnapshotExists) {
    snapshots.push({
      monthKey: prevMonthKey,
      monthNameAr: prevMonthNameAr,
      monthNameEn: prevMonthNameEn,
      totalExecuted: 3,
      totalPoints: 12750,
      totalSalesRevenue: 200000,
      carriedOverCount: 7,
      archivedAt: prevMonthDate.toISOString()
    });
    await db.settings.put({ key: 'monthlySnapshots', value: JSON.stringify(snapshots) });
  }
}

export async function clearDemoData() {
  const targetOrderNumbers = JULY_2026_TARGET_CUSTOMERS.map(c => c.orderNumber);
  const demoOrderNumbers = ['100201', '100202', '100203', '100204', '100205', '100206', '100207', '100208', '100209', '100210', '100101', '100102', '100103', ...targetOrderNumbers];
  const demoCustomers = await db.customers.filter(c => 
    demoOrderNumbers.includes(c.orderNumber || '') || 
    (c.email ? c.email.endsWith('@example.com') : false) ||
    (c.notes ? c.notes.includes('عميل مستهدف لشهر يوليو') : false)
  ).toArray();

  for (const c of demoCustomers) {
    if (c.id) {
      await deleteCustomerCascading(c.id);
    }
  }
}

/**
 * Completely wipes all customer records, follow-up tasks, points logs, and audit logs.
 * Keeps system configuration (users, card types, statuses, message templates, salary tiers, and settings) intact.
 * Prepares the application for fresh delivery to new clients.
 */
export async function wipeAllDataAndPrepareFreshCleanVersion(userId?: number): Promise<{ customersDeleted: number; tasksDeleted: number; logsDeleted: number }> {
  const custCount = await db.customers.count();
  const taskCount = await db.tasks.count();
  const pointsCount = await db.pointsLog.count();
  const opsCount = await db.operationsLog.count();

  await db.transaction('rw', [db.customers, db.tasks, db.pointsLog, db.operationsLog, db.settings], async () => {
    await db.customers.clear();
    await db.tasks.clear();
    await db.pointsLog.clear();
    await db.operationsLog.clear();
    // Persistently mark that data was cleared so it never auto-seeds demo data on reload
    await db.settings.put({ key: 'data_wiped_clean', value: 'true' });
    await db.settings.put({ key: 'data_wiped_clean_at', value: new Date().toISOString() });
    await db.settings.put({ key: 'sample_customers_seeded', value: 'wiped' });
    await db.settings.put({ key: 'monthlySnapshots', value: '[]' });
  });

  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem('sales_crm_data_wiped_clean', 'true');
    } catch (e) {
      console.error(e);
    }
  }

  if (typeof sessionStorage !== 'undefined') {
    try {
      sessionStorage.clear();
    } catch (e) {
      console.error(e);
    }
  }

  return {
    customersDeleted: custCount,
    tasksDeleted: taskCount,
    logsDeleted: pointsCount + opsCount
  };
}

// Points Calculation Formula based on Card Base Points, Salary, and Visa-Only Percentage Tiers:
export function calculateCardPoints(
  basePoints: number,
  salary: number | null | undefined,
  productType: string = 'visa',
  salaryTiers?: SalaryTier[]
): number {
  if (!salary || salary < 6000 || !basePoints || basePoints <= 0) {
    return 0;
  }

  const tiers = salaryTiers && salaryTiers.length > 0 ? salaryTiers : (DEFAULT_SALARY_TIERS as SalaryTier[]);
  
  // Find matching salary tier
  const matchingTier = tiers.find(t => salary >= t.minSalary && salary <= t.maxSalary);
  
  // If salary >= 6000 but no tier matched, default to 100% of base card points
  if (!matchingTier) {
    return basePoints;
  }

  // Check if this tier is active for Visa Card Customers Only
  if (matchingTier.appliesToVisaOnly && productType !== 'visa') {
    return 0;
  }

  // If percentage is 0 (meaning 0% extra percentage increase), return 100% of base card points
  if (matchingTier.percentage === undefined || matchingTier.percentage === null || matchingTier.percentage === 0) {
    return basePoints;
  }

  // Calculate multiplier (e.g. 1.25x or 125%)
  let multiplier = matchingTier.percentage;
  if (multiplier > 10) {
    multiplier = multiplier / 100;
  }

  const result = basePoints * multiplier;
  return Math.round(result);
}

export function calculatePoints(salary: number | null | undefined): number {
  if (!salary || salary <= 0) return 0;
  if (salary <= 10000) return 50;
  if (salary <= 20000) return 40;
  if (salary <= 30000) return 30;
  return 20;
}

export function getPointsForCardOrSalary(
  cardType?: CardType | null,
  salary?: number | null,
  productType: string = 'visa',
  salaryTiers?: SalaryTier[]
): number {
  if (cardType && typeof cardType.points === 'number' && cardType.points > 0) {
    return calculateCardPoints(cardType.points, salary, productType, salaryTiers);
  }
  return calculatePoints(salary);
}

// Order Number Generator
export function generateOrderNumber(): string {
  const prefix = 'CRM';
  const year = new Date().getFullYear();
  const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  return `${prefix}-${year}-${random}`;
}

// Audit Trail Logger
export async function logOperation(
  action: string,
  tableName: string,
  recordId?: number | null,
  oldData?: any,
  newData?: any,
  userId?: number | null
) {
  try {
    await db.operationsLog.add({
      action,
      tableName,
      recordId: recordId || null,
      oldData: oldData ? JSON.stringify(oldData) : null,
      newData: newData ? JSON.stringify(newData) : null,
      userId: userId || null,
      timestamp: new Date()
    });
  } catch (err) {
    console.error('Failed to log operation:', err);
  }
}

// Cascading Customer Delete Helper (Deletes customer, tasks, points logs)
export async function deleteCustomerCascading(customerId: number | string, userId?: number | null) {
  const numId = Number(customerId);
  if (isNaN(numId) || !numId) return;

  const customer = await db.customers.get(numId);
  if (!customer) return;

  await db.transaction('rw', [db.tasks, db.pointsLog, db.customers, db.operationsLog], async () => {
    // Delete all tasks for this customer
    await db.tasks.where('customerId').equals(numId).delete();

    // Delete all pointsLog entries for this customer
    await db.pointsLog.where('customerId').equals(numId).delete();

    // Delete customer record
    await db.customers.delete(numId);

    // Log operation concisely
    await db.operationsLog.add({
      action: 'DELETE_CUSTOMER_CASCADE',
      tableName: 'customers',
      recordId: numId,
      oldData: JSON.stringify({ id: customer.id, name: customer.name, phone: customer.phone }),
      newData: null,
      userId: userId || null,
      timestamp: new Date()
    });
  });
}

// Bulk Cascading Delete Helper for High Performance Batch Operations
export async function bulkDeleteCustomersCascading(customerIds: (number | string)[], userId?: number | null) {
  const numIds = customerIds.map(id => Number(id)).filter(id => !isNaN(id) && id > 0);
  if (numIds.length === 0) return;

  await db.transaction('rw', [db.tasks, db.pointsLog, db.customers, db.operationsLog], async () => {
    // Delete all related tasks in one query using indexed anyOf
    await db.tasks.where('customerId').anyOf(numIds).delete();

    // Delete all related pointsLog entries in one query using indexed anyOf
    await db.pointsLog.where('customerId').anyOf(numIds).delete();

    // Delete customer records in bulk
    await db.customers.bulkDelete(numIds);

    // Add operation log
    await db.operationsLog.add({
      action: 'BULK_DELETE_CUSTOMERS_CASCADE',
      tableName: 'customers',
      recordId: null,
      oldData: JSON.stringify({ deletedCount: numIds.length, customerIds: numIds }),
      newData: null,
      userId: userId || null,
      timestamp: new Date()
    });
  });
}

// Fast Canonical Duplicate Phone Lookup
export async function findCustomerByNormalizedPhone(
  phone: string,
  excludeCustomerId?: number
): Promise<Customer | undefined> {
  const targetKey = normalizePhoneForMatch(phone);
  if (!targetKey || targetKey.length < 7) return undefined;
  const all = await db.customers.toArray();
  return all.find(
    (c) =>
      c.id !== excludeCustomerId &&
      normalizePhoneForMatch(c.phone) === targetKey
  );
}

// Atomic Bulk Status Update with Automatic Points Log Sync
export async function bulkUpdateCustomerStatus(
  customerIds: number[],
  newStatus: CustomerStatus,
  userId?: number | null
): Promise<number> {
  const validIds = customerIds.filter((id) => Number.isFinite(id) && id > 0);
  if (validIds.length === 0) return 0;

  let updatedCount = 0;
  const now = new Date();
  const cardTypes = await db.cardTypes.toArray();
  const salaryTiers = await db.salaryTiers.toArray();

  await db.transaction('rw', [db.customers, db.pointsLog, db.operationsLog], async () => {
    const targets = await db.customers.where('id').anyOf(validIds).toArray();

    for (const c of targets) {
      if (!c.id) continue;
      // Keep 'تم التفعيل' strictly for Visa cards; non-Visa stays executed
      const effectiveStatus: CustomerStatus =
        newStatus === 'تم التفعيل' && c.productType !== 'visa' ? 'تم التنفيذ' : newStatus;

      const cardType = cardTypes.find((ct) => ct.id === c.cardTypeId);
      const basePts = cardType && typeof cardType.points === 'number' ? cardType.points : 0;
      const computedPts =
        c.points && c.points > 0
          ? c.points
          : basePts > 0
          ? calculateCardPoints(basePts, c.salary, c.productType || 'visa', salaryTiers)
          : calculatePoints(c.salary);

      const updates: Partial<Customer> = {
        status: effectiveStatus,
        updatedAt: now,
        points: computedPts,
      };
      if (effectiveStatus === 'تم التفعيل') {
        updates.activatedAt = c.activatedAt || now;
      }

      await db.customers.update(c.id, updates);

      if (effectiveStatus === 'تم التفعيل' && computedPts > 0) {
        const existingLog = await db.pointsLog.where('customerId').equals(c.id).first();
        if (!existingLog) {
          await db.pointsLog.add({
            customerId: c.id,
            salesRepId: userId || c.salesRepId,
            points: computedPts,
            reason: `تحديث حالة جماعي إلى تم التفعيل (${c.name})`,
            month: now.getMonth() + 1,
            year: now.getFullYear(),
            timestamp: now,
          });
        }
      } else if (effectiveStatus !== 'تم التفعيل' && c.status === 'تم التفعيل') {
        await db.pointsLog.where('customerId').equals(c.id).delete();
      }

      updatedCount++;
    }

    await db.operationsLog.add({
      action: 'BULK_UPDATE_STATUS',
      tableName: 'customers',
      recordId: null,
      oldData: null,
      newData: JSON.stringify({ updatedCount, newStatus, customerIds: validIds }),
      userId: userId || null,
      timestamp: now,
    });
  });

  return updatedCount;
}

// Backup Generator (strips sensitive client API keys and never stores plaintext passwords)
export async function createBackup(name?: string): Promise<number> {
  const safeSettings = (await db.settings.toArray()).filter((s) => s.key !== 'geminiApiKey');
  const safeUsers = (await db.users.toArray()).map((u) => ({
    ...u,
    password: isPasswordHashed(u.password) ? u.password : '[PROTECTED]',
  }));

  const backup = {
    customers: await db.customers.toArray(),
    users: safeUsers,
    cardTypes: await db.cardTypes.toArray(),
    products: await db.products.toArray(),
    statuses: await db.statuses.toArray(),
    messageTemplates: await db.messageTemplates.toArray(),
    settings: safeSettings,
    pointsLog: await db.pointsLog.toArray(),
    createdAt: new Date().toISOString()
  };

  const id = await db.backups.add({
    name: sanitizePlainText(name || `نسخة احتياطية ${new Date().toLocaleString('ar-SA')}`, 120),
    data: JSON.stringify(backup),
    createdAt: new Date()
  });

  return id;
}

/**
 * Enriches raw imported customer data (from CSV, VCF, AI Scan, Excel),
 * matches or creates card types, calculates points based on salary tiers,
 * and bulk-inserts them into db.customers.
 */
export async function enrichAndAddCustomers(
  rawCustomers: Array<{
    name?: string;
    phone?: string;
    email?: string | null;
    salary?: number | null;
    amount?: number | null;
    cardTypeName?: string | null;
    cardTypeId?: number | null;
    status?: string | null;
    productType?: ProductType | null;
    financeType?: string | null;
    financeRate?: number | null;
    notes?: string | null;
    [key: string]: any;
  }>,
  options?: {
    defaultStatus?: CustomerStatus;
    defaultProductType?: ProductType;
    sourceTag?: string;
    userId?: number | null;
    targetMonth?: string;
  }
): Promise<number> {
  if (!rawCustomers || rawCustomers.length === 0) return 0;

  const defaultStatus = options?.defaultStatus || 'عميل محتمل';
  const defaultProductType = options?.defaultProductType || 'visa';
  const sourceTag = options?.sourceTag || 'مستورد من ملف';
  const targetMonthKey = options?.targetMonth || getCurrentMonthKey();

  const cardTypes = await db.cardTypes.toArray();
  const salaryTiers = await db.salaryTiers.toArray();
  const lastCustomer = await db.customers.orderBy('id').last();
  let counter = lastCustomer && lastCustomer.id ? lastCustomer.id + 1 : 1;
  const now = new Date();

  let recordCreatedAt = now;
  if (targetMonthKey && targetMonthKey.includes('-')) {
    recordCreatedAt = getExactDateForMonth(targetMonthKey, 15);
  }

  const newRecords: Customer[] = [];

  for (let idx = 0; idx < rawCustomers.length; idx++) {
    const raw = rawCustomers[idx];
    if (!raw.name && !raw.phone) continue;

    const rawName = sanitizePlainText(raw.name || raw.phone || `عميل مستورد ${counter + idx}`, 120);
    const rawPhone = cleanPhoneString(raw.phone);
    const rawEmail = raw.email ? sanitizePlainText(raw.email, 160) : null;
    const rawSalaryNum = raw.salary !== undefined && raw.salary !== null ? parseFloat(String(raw.salary).replace(/[^\d.]/g, '')) : null;
    const parsedSalary = (rawSalaryNum && !isNaN(rawSalaryNum) && rawSalaryNum > 0) ? rawSalaryNum : null;
    
    const rawAmountNum = raw.amount !== undefined && raw.amount !== null ? parseFloat(String(raw.amount).replace(/[^\d.]/g, '')) : null;
    const parsedAmount = (rawAmountNum && !isNaN(rawAmountNum) && rawAmountNum > 0) ? rawAmountNum : null;

    const productType: ProductType = (raw.productType === 'finance' || defaultProductType === 'finance') ? 'finance' : 'visa';
    const status: CustomerStatus = (raw.status as CustomerStatus) || defaultStatus;

    let matchedCardTypeId: number | null = raw.cardTypeId ? Number(raw.cardTypeId) : null;
    let basePoints = 0;

    const cardNameCandidate = raw.cardTypeName || (typeof raw.cardType === 'string' ? raw.cardType : null);

    if (cardNameCandidate && !matchedCardTypeId) {
      const searchName = cardNameCandidate.toLowerCase().trim();
      const cleanSearch = searchName.replace(/^visa\s*/i, '').trim();

      // 1. Try exact match or clean match
      let match = cardTypes.find((ct) => ct.name.toLowerCase() === searchName || ct.name.toLowerCase() === cleanSearch);

      // 2. Try English/Arabic alias keywords
      if (!match) {
        if (searchName.includes('infinite') || searchName.includes('إنفينيت') || searchName.includes('انفينيت')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('infinite'));
        } else if (searchName.includes('platinum') || searchName.includes('بلاتينيوم') || searchName.includes('بلاتينوم')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('platinum'));
        } else if (searchName.includes('mazeed') || searchName.includes('مزيد')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('mazeed'));
        } else if (searchName.includes('signature') || searchName.includes('سيجنتشر') || searchName.includes('سغنتشر')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('signature'));
        } else if (searchName.includes('rahala') || searchName.includes('رحالة') || searchName.includes('رحاله')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('rahala'));
        } else if (searchName.includes('fursan') || searchName.includes('فرسان')) {
          match = cardTypes.find((ct) => ct.name.toLowerCase().includes('fursan'));
        }
      }

      // 3. Substring match
      if (!match) {
        match = cardTypes.find((ct) =>
          searchName.includes(ct.name.toLowerCase()) ||
          ct.name.toLowerCase().includes(cleanSearch)
        );
      }

      if (match) {
        matchedCardTypeId = match.id || null;
        basePoints = match.points || 0;
      } else {
        // Create new CardType for this unknown visa card
        const isInfinite = searchName.includes('infinite') || searchName.includes('إنفينيت') || searchName.includes('انفينيت');
        const pts = isInfinite ? 8500 : 4250;
        const newCardName = cardNameCandidate.trim();

        try {
          const newCardId = await db.cardTypes.add({
            name: newCardName,
            type: newCardName,
            pointsFormula: 'custom',
            points: pts,
            isCustom: true,
            createdAt: new Date(),
          });
          matchedCardTypeId = newCardId;
          basePoints = pts;
          cardTypes.push({
            id: newCardId,
            name: newCardName,
            type: newCardName,
            pointsFormula: 'custom',
            points: pts,
            isCustom: true,
            createdAt: new Date(),
          });
        } catch {
          // Ignore fallback errors
        }
      }
    } else if (matchedCardTypeId) {
      const existing = cardTypes.find((ct) => ct.id === matchedCardTypeId);
      if (existing) basePoints = existing.points || 0;
    }

    // Compute Points
    let computedPoints: number | null = null;
    if (productType === 'visa') {
      if (basePoints > 0) {
        computedPoints = calculateCardPoints(basePoints, parsedSalary, 'visa', salaryTiers);
      } else if (parsedSalary) {
        computedPoints = calculatePoints(parsedSalary);
      }
    }

    const orderNum =
      raw.orderNumber && String(raw.orderNumber).trim() && !String(raw.orderNumber).startsWith('VCF-') && !String(raw.orderNumber).startsWith('CSV-')
        ? sanitizePlainText(raw.orderNumber, 64)
        : `ORD-${Date.now().toString().slice(-6)}-${counter + idx}`;

    const finalNotes = raw.notes ? sanitizePlainText(raw.notes, 1500) : '';
    const effectiveRowMonth =
      raw.targetMonth && /^\d{4}-(0[1-9]|1[0-2])$/.test(String(raw.targetMonth).trim())
        ? String(raw.targetMonth).trim()
        : targetMonthKey;
    const effectiveRowDate =
      effectiveRowMonth && effectiveRowMonth.includes('-')
        ? getExactDateForMonth(effectiveRowMonth, 15)
        : recordCreatedAt;

    newRecords.push({
      name: rawName,
      phone: rawPhone,
      idNumber: raw.idNumber ? sanitizePlainText(raw.idNumber, 32) : null,
      email: rawEmail,
      status: status,
      productType: productType,
      cardTypeId: matchedCardTypeId,
      salary: parsedSalary,
      amount: parsedAmount,
      points: computedPoints && computedPoints > 0 ? computedPoints : null,
      financeType: productType === 'finance' ? (raw.financeType || 'salary_transfer') : null,
      financeRate: productType === 'finance' && raw.financeRate ? Number(raw.financeRate) : null,
      notes: finalNotes || null,
      orderNumber: orderNum,
      targetMonth: effectiveRowMonth,
      salesRepId: options?.userId ?? null,
      createdAt: effectiveRowDate,
      updatedAt: now,
    });
  }

  if (newRecords.length > 0) {
    const ids = await db.customers.bulkAdd(newRecords, { allKeys: true });
    
    // Add pointsLog entries for any imported customers with status 'تم التفعيل'
    // and auto-schedule potential customers in future months if notes mention a scheduled card issuance date
    let scheduledIssuanceMod: typeof import('../utils/scheduledIssuance') | null = null;
    for (let i = 0; i < newRecords.length; i++) {
      const rec = newRecords[i];
      const insertedId = ids[i];
      if (rec.status === 'تم التفعيل' && rec.points && rec.points > 0 && insertedId) {
        await db.pointsLog.add({
          customerId: insertedId,
          salesRepId: options?.userId,
          points: rec.points,
          reason: `استيراد عميل مفعل (${rec.name})`,
          month: now.getMonth() + 1,
          year: now.getFullYear(),
          timestamp: now
        });
      }

      if (rec.notes) {
        if (!scheduledIssuanceMod) {
          scheduledIssuanceMod = await import('../utils/scheduledIssuance');
        }
        const detected = scheduledIssuanceMod.parseScheduledCardIssuanceFromNote(rec.notes, rec.targetMonth);
        if (detected && detected.isDifferentFromSourceMonth) {
          await scheduledIssuanceMod.schedulePotentialCustomerForIssuanceMonth(
            {
              name: rec.name,
              phone: rec.phone,
              idNumber: rec.idNumber,
              email: rec.email,
              salary: rec.salary,
              cardTypeId: rec.cardTypeId,
              points: rec.points,
              notes: rec.notes,
              salesRepId: options?.userId ?? undefined,
            },
            detected,
            { userId: options?.userId }
          );
        }
      }
    }

    await logOperation('BULK_IMPORT_CUSTOMERS', 'customers', null, null, { count: newRecords.length, source: sourceTag }, options?.userId);
  }

  return newRecords.length;
}

export const JULY_2026_TARGET_CUSTOMERS: Array<{
  orderNumber: string;
  idNumber?: string;
  name: string;
  phone: string;
  cardType: 'Infinite' | 'Platinum';
  salary: number;
}> = [
  { orderNumber: 'DEMO-1001', idNumber: '1000000001', name: 'عميل تجريبي أول', phone: '0500000001', cardType: 'Infinite', salary: 24000 },
  { orderNumber: 'DEMO-1002', idNumber: '1000000002', name: 'عميل تجريبي ثانٍ', phone: '0500000002', cardType: 'Platinum', salary: 14500 },
  { orderNumber: 'DEMO-1003', idNumber: '1000000003', name: 'عميل تجريبي ثالث', phone: '0500000003', cardType: 'Infinite', salary: 31000 },
  { orderNumber: 'DEMO-1004', idNumber: '1000000004', name: 'عميل تجريبي رابع', phone: '0500000004', cardType: 'Platinum', salary: 11000 },
];

export async function seedJuly2026TargetCustomers(force: boolean = false) {
  // Only seed when explicitly forced (e.g. from generate demo data)
  if (!force) {
    return;
  }

  const july2026Date = new Date(2026, 6, 15, 12, 0, 0); // July 15, 2026
  const cardTypes = await db.cardTypes.toArray();
  const tiers = await db.salaryTiers.toArray();
  const adminUser = await db.users.where('role').equals('admin').first();
  const salesRepId = adminUser?.id || 1;

  const infiniteCard = cardTypes.find(c => c.name.toLowerCase().includes('infinite')) || cardTypes[0];
  const platinumCard = cardTypes.find(c => c.name.toLowerCase().includes('platinum')) || cardTypes[1] || cardTypes[0];

  for (const item of JULY_2026_TARGET_CUSTOMERS) {
    const existing = await db.customers.where('orderNumber').equals(item.orderNumber).first();
    if (!existing) {
      const selectedCard = item.cardType === 'Infinite' ? infiniteCard : platinumCard;
      const basePts = selectedCard && typeof selectedCard.points === 'number' ? selectedCard.points : (item.cardType === 'Infinite' ? 8500 : 4250);
      const computedPts = calculateCardPoints(basePts, item.salary, 'visa', tiers);

      await db.customers.add({
        name: item.name,
        phone: item.phone,
        status: 'عميل محتمل',
        productType: 'visa',
        cardTypeId: selectedCard?.id || (item.cardType === 'Infinite' ? 1 : 2),
        salary: item.salary,
        orderNumber: item.orderNumber,
        idNumber: item.idNumber || null,
        notes: 'عميل مستهدف لشهر يوليو',
        salesRepId,
        points: computedPts,
        createdAt: july2026Date,
        updatedAt: july2026Date
      });
    } else {
      if (existing.id && item.idNumber && (!existing.idNumber || existing.idNumber !== item.idNumber)) {
        await db.customers.update(existing.id, {
          idNumber: item.idNumber
        });
      }
    }
  }

  // Also migrate any customer where idNumber is missing but stored in notes
  const allCustomers = await db.customers.toArray();
  for (const c of allCustomers) {
    if (c.id && !c.idNumber && c.notes) {
      const match = c.notes.match(/الهوية الوطنية:\s*(\d+)/) || c.notes.match(/الهوية:\s*(\d+)/);
      if (match && match[1]) {
        await db.customers.update(c.id, { idNumber: match[1] });
      }
    }
  }
}

