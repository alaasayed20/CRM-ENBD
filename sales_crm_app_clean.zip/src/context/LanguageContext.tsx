import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { translations, Language } from '../utils/translations';

export const cleanPhoneString = (phone: string | number | null | undefined): string => {
  if (phone === null || phone === undefined || phone === '') return '';
  let str = String(phone).trim();

  // If scientific notation e.g. 5.01234567e8
  if (str.includes('e+') || str.includes('E+') || str.includes('e-') || str.includes('E-')) {
    const num = Number(str);
    if (!isNaN(num)) str = Math.round(num).toString();
  }

  // Strip float decimal part from Excel export (e.g. "0501234567.0")
  if (str.includes('.')) {
    str = str.split('.')[0];
  }

  // Keep digits and +
  str = str.replace(/[^\d+]/g, '');

  // Add leading 0 if 9 digits starting with 5 (Saudi mobile format)
  if (str.length === 9 && str.startsWith('5')) {
    str = '0' + str;
  }

  return str;
};

export const formatPhone = (phone: string | number | null | undefined): string => {
  const cleaned = cleanPhoneString(phone);
  return cleaned || (phone ? String(phone) : '-');
};

export const formatNumber = (value: number | string | null | undefined, _lang: Language = 'ar'): string => {
  if (value === null || value === undefined || value === '') return '0';
  const num = typeof value === 'number' ? value : parseFloat(value.toString());
  if (isNaN(num)) return '0';

  // Always use standard Western/English digits (en-US format) across all languages
  return num.toLocaleString('en-US');
};

export const formatCurrency = (value: number | string | null | undefined, lang: Language = 'ar'): string => {
  const formatted = formatNumber(value, lang);
  return lang === 'ar' ? `${formatted} ر.س` : `${formatted} SAR`;
};

interface LanguageContextType {
  language: Language;
  dir: 'rtl' | 'ltr';
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string, fallback?: string) => string;
  formatNumber: (value: number | string | null | undefined) => string;
  formatCurrency: (value: number | string | null | undefined) => string;
  formatPhone: (phone: string | number | null | undefined) => string;
  formatDate: (date: Date | string | number) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('app_language');
    return saved === 'en' ? 'en' : 'ar';
  });

  const dir: 'rtl' | 'ltr' = language === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    localStorage.setItem('app_language', language);
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
  }, [language, dir]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
  }, []);

  const toggleLanguage = useCallback(() => {
    setLanguageState(prev => (prev === 'ar' ? 'en' : 'ar'));
  }, []);

  const t = useCallback((key: string, fallback?: string): string => {
    const langDict = translations[language] || translations.ar;
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    // Handle English language fallbacks without displaying raw Arabic
    if (language === 'en') {
      if (fallback && !/[\u0600-\u06FF]/.test(fallback)) {
        return fallback;
      }
      // Convert camelCase key to Start Case (e.g. "totalCustomers" -> "Total Customers")
      return key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, (str) => str.toUpperCase())
        .trim();
    }
    return fallback || key;
  }, [language]);

  const contextFormatNumber = useCallback((value: number | string | null | undefined): string => {
    return formatNumber(value, language);
  }, [language]);

  const contextFormatCurrency = useCallback((value: number | string | null | undefined): string => {
    return formatCurrency(value, language);
  }, [language]);

  const formatDate = useCallback((date: Date | string | number): string => {
    if (!date) return '-';
    const d = new Date(date);
    if (isNaN(d.getTime())) return '-';

    if (language === 'ar') {
      return d.toLocaleDateString('ar-SA-u-nu-latn');
    } else {
      return d.toLocaleDateString('en-US');
    }
  }, [language]);

  const contextValue = useMemo<LanguageContextType>(() => ({
    language,
    dir,
    setLanguage,
    toggleLanguage,
    t,
    formatNumber: contextFormatNumber,
    formatCurrency: contextFormatCurrency,
    formatPhone,
    formatDate,
  }), [language, dir, setLanguage, toggleLanguage, t, contextFormatNumber, contextFormatCurrency, formatDate]);

  return (
    <LanguageContext.Provider value={contextValue}>
      <div dir={dir} className={language === 'en' ? 'font-sans' : 'font-["Tajawal",sans-serif]'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
