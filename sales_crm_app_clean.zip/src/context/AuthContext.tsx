import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { db, seedDatabase, createBackup, wipeAllDataAndPrepareFreshCleanVersion } from '../db/db';
import type { User, PageView, PendingReminder } from '../types';
import { useToast } from '../components/Toast';
import { getCurrentMonthKey } from '../utils/monthRollover';
import {
  getPermissions,
  type RolePermissions,
  hashPassword,
  verifyPassword,
  getLockoutState,
  recordFailedAttempt,
  clearLockoutAttempts,
  sanitizePlainText,
  clearScanSessionToken,
} from '../utils/security';

interface AuthContextType {
  currentUser: User | null;
  isAdmin: boolean;
  permissions: RolePermissions;
  isInitialized: boolean;
  needsAdminSetup: boolean;
  isAppLocked: boolean;
  hasPinLock: boolean;
  lockApp: () => void;
  unlockApp: () => void;
  setCurrentPage: (page: PageView, filter?: string) => void;
  customerStatusFilter: string;
  setCustomerStatusFilter: (status: string) => void;
  selectedMonthKey: string;
  setSelectedMonthKey: (monthKey: string) => void;
  pendingReminders: PendingReminder[];
  dueTasksCount: number;
  smartAlertsCount: number;
  settings: Record<string, any>;
  setupInitialAdmin: (username: string, password: string) => Promise<boolean>;
  login: (username: string, pass: string) => Promise<boolean>;
  startTrialLogin: (guestName?: string, shouldWipeData?: boolean) => Promise<boolean>;
  logout: () => void;
  updateSettingsState: (key: string, value: any) => Promise<void>;
  checkReminders: () => Promise<void>;
  refreshSettings: () => Promise<Record<string, any>>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const CurrentPageContext = createContext<PageView>('dashboard');

const VALID_PAGES: PageView[] = ['dashboard', 'customers', 'addCustomer', 'reports', 'reminders', 'settings', 'admin'];

function toSafeSessionUser(user: User): User {
  return {
    ...user,
    password: '', // Never retain password hash or plaintext in React memory
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [needsAdminSetup, setNeedsAdminSetup] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAppLocked, setIsAppLocked] = useState<boolean>(false);

  // Restore active page reliably from localStorage so page refresh never resets user to home
  const [currentPage, setCurrentPageRaw] = useState<PageView>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('sales_crm_current_page') as PageView;
        if (saved && VALID_PAGES.includes(saved)) {
          return saved;
        }
      } catch {
        // ignore
      }
    }
    return 'dashboard';
  });

  // Restore customer status filter reliably from localStorage
  const [customerStatusFilter, setCustomerStatusFilterRaw] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      try {
        return localStorage.getItem('sales_crm_customer_status_filter') || 'all';
      } catch {
        // ignore
      }
    }
    return 'all';
  });

  const [selectedMonthKey, setSelectedMonthKeyRaw] = useState<string>(() => {
    return localStorage.getItem('selected_active_month') || getCurrentMonthKey();
  });

  const setSelectedMonthKey = useCallback((monthKey: string) => {
    setSelectedMonthKeyRaw(monthKey);
    localStorage.setItem('selected_active_month', monthKey);
  }, []);

  const setCustomerStatusFilter = useCallback((status: string) => {
    setCustomerStatusFilterRaw(status);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('sales_crm_customer_status_filter', status);
      } catch {
        // ignore
      }
    }
  }, []);

  const permissions = useMemo(() => getPermissions(currentUser), [currentUser]);
  const isAdmin = permissions.isAdmin;

  const [pendingReminders, setPendingReminders] = useState<PendingReminder[]>([]);
  const [dueTasksCount, setDueTasksCount] = useState<number>(0);
  const [settings, setSettings] = useState<Record<string, any>>({});
  const { showToast } = useToast();

  const setCurrentPage = useCallback(
    (page: PageView, filter?: string) => {
      // Strict RBAC guard: block non-admins from navigating to Admin Panel
      if (page === 'admin' && currentUser && currentUser.role !== 'admin') {
        showToast('عذراً، لوحة الإدارة مخصصة للمدير فقط 🔒', 'warning');
        setCurrentPageRaw('dashboard');
        try {
          localStorage.setItem('sales_crm_current_page', 'dashboard');
        } catch {
          // ignore
        }
        return;
      }

      if (filter !== undefined) {
        setCustomerStatusFilter(filter);
      }
      setCurrentPageRaw(page);
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('sales_crm_current_page', page);
        } catch {
          // ignore
        }
      }
    },
    [currentUser, setCustomerStatusFilter, showToast]
  );

  // Enforce RBAC if a non-admin session restores 'admin' page
  useEffect(() => {
    if (currentUser && currentUser.role !== 'admin' && currentPage === 'admin') {
      setCurrentPageRaw('dashboard');
      try {
        localStorage.setItem('sales_crm_current_page', 'dashboard');
      } catch {
        // ignore
      }
    }
  }, [currentUser, currentPage]);

  const hasPinLock = Boolean(settings.pinLockEnabled && settings.pinLockHash);

  const lockApp = useCallback(() => {
    if (!hasPinLock) return;
    setIsAppLocked(true);
    clearScanSessionToken();
    try {
      sessionStorage.removeItem('sales_crm_pin_unlocked');
    } catch {
      // ignore
    }
  }, [hasPinLock]);

  const unlockApp = useCallback(() => {
    setIsAppLocked(false);
    try {
      sessionStorage.setItem('sales_crm_pin_unlocked', 'true');
    } catch {
      // ignore
    }
  }, []);

  const logout = useCallback(() => {
    setCurrentUser(null);
    setIsAppLocked(false);
    setCurrentPageRaw('dashboard');
    clearScanSessionToken();
    try {
      sessionStorage.removeItem('sales_crm_active_session');
      sessionStorage.removeItem('sales_crm_pin_unlocked');
      localStorage.removeItem('sales_crm_logged_user_id');
      localStorage.removeItem('sales_crm_logged_username');
      localStorage.removeItem('sales_crm_trial_active');
      localStorage.removeItem('sales_crm_current_page');
    } catch {
      // ignore
    }
    showToast('تم تسجيل الخروج بنجاح', 'info');
  }, [showToast]);

  // ============================================================================
  // AUTOMATIC INACTIVITY LOCK & TAB-HIDE LOCK
  // ============================================================================
  const lastActivityRef = useRef<number>(Date.now());
  const inactivityMinutes = Math.max(0, Number(settings.inactivityLockMinutes) || 0);
  const lockOnTabHide = Boolean(settings.lockOnTabHide);

  useEffect(() => {
    if (!currentUser || isAppLocked) return;
    if (inactivityMinutes <= 0 && !lockOnTabHide) return;

    const triggerLockOrLogout = () => {
      if (hasPinLock) {
        lockApp();
      } else {
        logout();
        showToast('تم إنهاء الجلسة تلقائياً بعد فترة الخمول لحماية بياناتك 🔒', 'info');
      }
    };

    const markActive = () => {
      lastActivityRef.current = Date.now();
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'hidden' && lockOnTabHide && hasPinLock) {
        lockApp();
      } else if (document.visibilityState === 'visible') {
        if (inactivityMinutes > 0 && Date.now() - lastActivityRef.current >= inactivityMinutes * 60_000) {
          triggerLockOrLogout();
        }
      }
    };

    const events: Array<keyof WindowEventMap> = ['pointerdown', 'keydown', 'touchstart', 'scroll'];
    events.forEach((ev) => window.addEventListener(ev, markActive, { passive: true }));
    document.addEventListener('visibilitychange', handleVisibility);

    let timer: ReturnType<typeof setInterval> | null = null;
    if (inactivityMinutes > 0) {
      lastActivityRef.current = Date.now();
      timer = setInterval(() => {
        if (Date.now() - lastActivityRef.current >= inactivityMinutes * 60_000) {
          triggerLockOrLogout();
        }
      }, 15_000);
    }

    return () => {
      events.forEach((ev) => window.removeEventListener(ev, markActive));
      document.removeEventListener('visibilitychange', handleVisibility);
      if (timer) clearInterval(timer);
    };
  }, [currentUser, isAppLocked, inactivityMinutes, lockOnTabHide, hasPinLock, lockApp, logout, showToast]);

  const refreshSettings = useCallback(async (): Promise<Record<string, any>> => {
    try {
      const allSettings = await db.settings.toArray();
      const map: Record<string, any> = {};
      allSettings.forEach((s) => {
        if (s.key !== 'geminiApiKey') {
          map[s.key] = s.value;
        }
      });
      setSettings(map);
      return map;
    } catch (err) {
      console.error('Error loading settings:', err);
      return {};
    }
  }, []);

  // Unified Smart Reminders Engine
  const checkReminders = useCallback(async () => {
    try {
      const enabled = settings.reminderEnabled !== false;
      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      const pendingTasks = await db.tasks
        .where('status')
        .anyOf(['pending', 'postponed'])
        .toArray();
      const dueOrOverdueTasks = pendingTasks.filter((tk) => tk.date && tk.date <= todayStr);
      setDueTasksCount(dueOrOverdueTasks.length);

      if (!enabled) {
        setPendingReminders([]);
      } else {
        const interval = Number(settings.reminderInterval) || 3;
        const escalation = Number(settings.reminderEscalationDays) || 7;
        const allCustomers = await db.customers.toArray();
        const reminders: PendingReminder[] = [];
        const includedIds = new Set<number>();

        for (const customer of allCustomers) {
          const st = (customer.status || '').trim();
          const isVisaAwaitingActivation =
            customer.productType === 'visa' && (st === 'تم التنفيذ' || st === 'بانتظار التفعيل');

          if (isVisaAwaitingActivation) {
            const refDate = new Date(customer.lastReminderDismissed || customer.updatedAt || customer.createdAt);
            const daysPending = Math.max(
              0,
              Math.floor((now.getTime() - refDate.getTime()) / (1000 * 60 * 60 * 24))
            );
            if (daysPending >= interval) {
              if (customer.id) includedIds.add(customer.id);
              reminders.push({
                customer,
                daysPending,
                isOverdue: daysPending >= escalation,
                nextReminder: new Date(refDate.getTime() + interval * 24 * 60 * 60 * 1000),
                reason: 'pending_activation',
              });
            }
          }
        }

        for (const customer of allCustomers) {
          if (customer.id && includedIds.has(customer.id)) continue;
          const st = (customer.status || '').trim();
          if (customer.followUpDate && customer.followUpDate <= todayStr && st !== 'تم التفعيل') {
            const dueMs = new Date(customer.followUpDate + 'T00:00:00').getTime();
            const daysOverdue = Math.max(0, Math.floor((now.getTime() - dueMs) / (1000 * 60 * 60 * 24)));
            reminders.push({
              customer,
              daysPending: daysOverdue,
              isOverdue: customer.followUpDate < todayStr,
              nextReminder: new Date(dueMs),
              reason: 'followup_due',
              dueDate: customer.followUpDate,
            });
          }
        }

        reminders.sort((a, b) => {
          if (a.isOverdue !== b.isOverdue) return a.isOverdue ? -1 : 1;
          return b.daysPending - a.daysPending;
        });

        setPendingReminders(reminders);
      }

      if (
        settings.browserNotificationsEnabled &&
        typeof window !== 'undefined' &&
        'Notification' in window &&
        Notification.permission === 'granted'
      ) {
        const approachingTasks = pendingTasks.filter((t) => t.date && t.date <= tomorrowStr);
        const allCustomers = await db.customers.toArray();
        const approachingCustomers = allCustomers.filter(
          (c) => c.followUpDate && c.followUpDate <= tomorrowStr && c.status !== 'تم التفعيل'
        );

        const sessionNotifiedKey = `notified_reminders_${todayStr}`;
        let notifiedSet: Set<string> = new Set();
        try {
          const raw = sessionStorage.getItem(sessionNotifiedKey);
          if (raw) notifiedSet = new Set(JSON.parse(raw));
        } catch {
          // ignore
        }

        let newNotifiedCount = 0;

        for (const task of approachingTasks) {
          const key = `task_${task.id}_${task.date}`;
          if (!notifiedSet.has(key)) {
            notifiedSet.add(key);
            newNotifiedCount++;
            const isToday = task.date === todayStr;
            const isOverdue = task.date < todayStr;
            const timingText = isOverdue ? 'متأخرة' : isToday ? 'اليوم' : 'غداً';

            try {
              new Notification(`🔔 تذكير مهمة (${timingText}): ${task.title}`, {
                body: task.notes || `تاريخ المهمة: ${task.date}`,
                icon: '/pwa-192x192.png',
                tag: key,
              });
            } catch {
              // ignore
            }
          }
        }

        for (const cust of approachingCustomers) {
          const key = `cust_${cust.id}_${cust.followUpDate}`;
          if (!notifiedSet.has(key)) {
            notifiedSet.add(key);
            newNotifiedCount++;
            const isToday = cust.followUpDate === todayStr;
            const isOverdue = Boolean(cust.followUpDate && cust.followUpDate < todayStr);
            const timingText = isOverdue ? 'متأخرة' : isToday ? 'اليوم' : 'غداً';

            try {
              new Notification(`🔔 موعد متابعة عميل (${timingText}): ${cust.name}`, {
                body: cust.notes || `تاريخ المتابعة: ${cust.followUpDate}`,
                icon: '/pwa-192x192.png',
                tag: key,
              });
            } catch {
              // ignore
            }
          }
        }

        if (newNotifiedCount > 0) {
          try {
            sessionStorage.setItem(sessionNotifiedKey, JSON.stringify(Array.from(notifiedSet)));
          } catch {
            // ignore
          }
        }
      }
    } catch (err) {
      console.error('Error checking reminders:', err);
    }
  }, [settings]);

  const extractUrlParam = (paramName: string): string | null => {
    if (typeof window === 'undefined') return null;
    const searchParams = new URLSearchParams(window.location.search);
    const valFromSearch = searchParams.get(paramName);
    if (valFromSearch) return valFromSearch;

    if (window.location.hash.includes('?')) {
      const hashPart = window.location.hash.split('?')[1];
      const hashParams = new URLSearchParams(hashPart);
      const valFromHash = hashParams.get(paramName);
      if (valFromHash) return valFromHash;
    }

    try {
      const fullUrl = new URL(window.location.href);
      return fullUrl.searchParams.get(paramName);
    } catch {
      return null;
    }
  };

  /**
   * Resolves an isolated least-privilege trial user (`role: 'sales'`, `permissions: 'trial'`).
   * Strictly prevents URL `?trial=true&name=admin` from ever binding to an existing admin or staff account.
   */
  const resolveIsolatedTrialUser = async (requestedName?: string | null): Promise<User | undefined> => {
    const cleanName = sanitizePlainText(requestedName || '', 50) || 'مندوب مبيعات تجريبي';
    const existing = await db.users.where('username').equals(cleanName).first();

    // Only reuse an existing account if it is explicitly an isolated trial sales account
    if (existing && existing.role === 'sales' && existing.permissions === 'trial') {
      return existing;
    }

    // Never impersonate an existing admin or regular user — isolate with a trial suffix
    const safeTrialUsername = existing ? `${cleanName} (تجريبي)` : cleanName;
    const existingTrial = await db.users.where('username').equals(safeTrialUsername).first();
    if (existingTrial && existingTrial.role === 'sales' && existingTrial.permissions === 'trial') {
      return existingTrial;
    }

    const randomSecret =
      typeof window !== 'undefined' && window.crypto?.getRandomValues
        ? Array.from(window.crypto.getRandomValues(new Uint8Array(16)))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('')
        : `${Date.now()}-${Math.random()}`;
    const hashedSecret = await hashPassword(randomSecret);

    const newId = await db.users.add({
      username: safeTrialUsername,
      password: hashedSecret,
      role: 'sales',
      permissions: 'trial',
      createdAt: new Date(),
    });
    return db.users.get(newId);
  };

  useEffect(() => {
    async function init() {
      try {
        await seedDatabase();
        const loadedSettings = await refreshSettings();

        // Check whether an admin account already exists locally
        const adminCount = await db.users.where('role').equals('admin').count();
        setNeedsAdminSetup(adminCount === 0);

        if (typeof window !== 'undefined') {
          const isTrialLink =
            extractUrlParam('trial') === 'true' ||
            extractUrlParam('trial') === '1' ||
            extractUrlParam('mode') === 'trial';

          const clientNameFromUrl = extractUrlParam('name');
          const shortcutAction = extractUrlParam('action');
          const shortcutPage = extractUrlParam('page') as PageView | null;

          let resolvedUser: User | null = null;

          if (isTrialLink) {
            const trialUser = await resolveIsolatedTrialUser(clientNameFromUrl);
            if (trialUser) {
              resolvedUser = toSafeSessionUser(trialUser);
              setCurrentUser(resolvedUser);
              sessionStorage.setItem('sales_crm_active_session', 'true');
              localStorage.setItem('sales_crm_logged_user_id', String(trialUser.id));
              localStorage.setItem('sales_crm_logged_username', trialUser.username);
              localStorage.setItem('sales_crm_trial_active', 'true');
            }
          } else {
            const savedUserId = localStorage.getItem('sales_crm_logged_user_id');
            const savedUsername = localStorage.getItem('sales_crm_logged_username');
            const sessionActive = sessionStorage.getItem('sales_crm_active_session') === 'true';
            const requireLoginOnStart = loadedSettings.requireLoginOnStart !== false;

            let savedUser: User | undefined | null = null;
            if (savedUserId) {
              savedUser = await db.users.get(Number(savedUserId));
            }
            if (!savedUser && savedUsername) {
              savedUser = await db.users.where('username').equals(savedUsername).first();
            }

            if (requireLoginOnStart) {
              resolvedUser = savedUser && sessionActive ? toSafeSessionUser(savedUser) : null;
            } else {
              resolvedUser = savedUser ? toSafeSessionUser(savedUser) : null;
            }
            setCurrentUser(resolvedUser);
          }

          // Check PIN Quick Lock state on startup
          const pinEnabled = Boolean(loadedSettings.pinLockEnabled && loadedSettings.pinLockHash);
          const alreadyUnlocked = sessionStorage.getItem('sales_crm_pin_unlocked') === 'true';
          if (resolvedUser && pinEnabled && !alreadyUnlocked) {
            setIsAppLocked(true);
          }

          // Wire PWA Home-Screen Shortcuts with strict role check
          let targetPage: PageView | null = null;
          if (shortcutAction === 'add_customer') {
            targetPage = 'addCustomer';
          } else if (shortcutPage && VALID_PAGES.includes(shortcutPage)) {
            if (shortcutPage === 'admin' && resolvedUser?.role !== 'admin') {
              targetPage = 'dashboard';
            } else {
              targetPage = shortcutPage;
            }
          } else {
            try {
              const savedPage = localStorage.getItem('sales_crm_current_page') as PageView;
              if (savedPage && VALID_PAGES.includes(savedPage)) {
                targetPage = savedPage === 'admin' && resolvedUser?.role !== 'admin' ? 'dashboard' : savedPage;
              }
            } catch {
              // ignore
            }
          }

          if (targetPage) {
            setCurrentPageRaw(targetPage);
          }

          // Clean URL query params cleanly without reloading
          try {
            if (
              window.location.search &&
              (isTrialLink ||
                shortcutAction ||
                shortcutPage ||
                window.location.search.includes('clean') ||
                window.location.search.includes('fresh'))
            ) {
              const cleanUrl = window.location.origin + window.location.pathname;
              window.history.replaceState({}, document.title, cleanUrl);
            }
          } catch {
            // ignore
          }
        }
      } catch (err) {
        console.error('Failed initializing auth/database state:', err);
      } finally {
        setIsInitialized(true);
      }
    }
    init();
  }, [refreshSettings]);

  useEffect(() => {
    if (currentUser) {
      checkReminders();
      const interval = setInterval(() => {
        checkReminders();
      }, 60000);
      return () => clearInterval(interval);
    }
  }, [currentUser, checkReminders]);

  /**
   * One-time initial Admin setup for fresh offline installations (replaces hardcoded credentials).
   */
  const setupInitialAdmin = async (rawUsername: string, rawPassword: string): Promise<boolean> => {
    try {
      const existingAdmins = await db.users.where('role').equals('admin').count();
      if (existingAdmins > 0) {
        setNeedsAdminSetup(false);
        showToast('حساب المدير مهيأ مسبقاً، يرجى تسجيل الدخول', 'warning');
        return false;
      }

      const username = sanitizePlainText(rawUsername, 40) || 'admin';
      if (rawPassword.length < 6) {
        showToast('كلمة المرور يجب أن تتكون من 6 أحرف أو أرقام على الأقل', 'error');
        return false;
      }

      const hashedPassword = await hashPassword(rawPassword);
      const newId = await db.users.add({
        username,
        password: hashedPassword,
        role: 'admin',
        permissions: 'all',
        pin: null,
        biometricEnabled: false,
        createdAt: new Date(),
      });

      const created = await db.users.get(newId);
      if (!created) return false;

      clearLockoutAttempts('login');
      setNeedsAdminSetup(false);
      setCurrentUser(toSafeSessionUser(created));
      setIsAppLocked(false);
      setCurrentPageRaw('dashboard');
      sessionStorage.setItem('sales_crm_active_session', 'true');
      sessionStorage.setItem('sales_crm_pin_unlocked', 'true');
      localStorage.setItem('sales_crm_logged_user_id', String(created.id));
      localStorage.setItem('sales_crm_logged_username', created.username);
      localStorage.setItem('sales_crm_current_page', 'dashboard');

      showToast(`تم تهيئة وتشفير حساب المدير (${created.username}) بنجاح 🔐`, 'success');
      return true;
    } catch (err) {
      console.error('Initial admin setup error:', err);
      showToast('تعذر إعداد حساب المدير', 'error');
      return false;
    }
  };

  const startTrialLogin = async (guestName?: string, shouldWipeData = false): Promise<boolean> => {
    try {
      if (shouldWipeData) {
        await wipeAllDataAndPrepareFreshCleanVersion();
      }
      const user = await resolveIsolatedTrialUser(guestName);

      if (user) {
        setCurrentUser(toSafeSessionUser(user));
        setIsAppLocked(false);
        setCurrentPageRaw('dashboard');
        sessionStorage.setItem('sales_crm_active_session', 'true');
        sessionStorage.setItem('sales_crm_pin_unlocked', 'true');
        localStorage.setItem('sales_crm_logged_user_id', String(user.id));
        localStorage.setItem('sales_crm_logged_username', user.username);
        localStorage.setItem('sales_crm_trial_active', 'true');
        localStorage.setItem('sales_crm_current_page', 'dashboard');
        showToast('أهلاً بك! تم فتح نسخة المبيعات التجريبية الآمنة (صلاحية مندوب) 🚀', 'success');
        return true;
      }
      return false;
    } catch (err) {
      console.error('Trial login error:', err);
      showToast('تعذر بدء فترة التجربة', 'error');
      return false;
    }
  };

  const login = async (username: string, pass: string): Promise<boolean> => {
    try {
      const lockout = getLockoutState('login');
      if (lockout.isLocked) {
        showToast(
          `تم قفل تسجيل الدخول مؤقتاً للحماية من التخمين. حاول بعد ${lockout.remainingSeconds} ثانية.`,
          'warning'
        );
        return false;
      }

      const cleanUsername = sanitizePlainText(username, 60);
      const user = await db.users.where('username').equals(cleanUsername).first();

      if (!user) {
        const nextLock = recordFailedAttempt('login');
        if (nextLock.isLocked) {
          showToast(`محاولات خاطئة متكررة — تم قفل الدخول لمدة ${nextLock.remainingSeconds} ثانية 🔒`, 'error');
        } else {
          showToast('اسم المستخدم أو كلمة المرور غير صحيحة', 'error');
        }
        return false;
      }

      const { valid, needsUpgrade } = await verifyPassword(pass, user.password);
      if (!valid) {
        const nextLock = recordFailedAttempt('login');
        if (nextLock.isLocked) {
          showToast(`محاولات خاطئة متكررة — تم قفل الدخول لمدة ${nextLock.remainingSeconds} ثانية 🔒`, 'error');
        } else {
          showToast('اسم المستخدم أو كلمة المرور غير صحيحة', 'error');
        }
        return false;
      }

      // Transparently upgrade any legacy plaintext password to PBKDF2-SHA256
      if (needsUpgrade && user.id) {
        const upgradedHash = await hashPassword(pass);
        await db.users.update(user.id, { password: upgradedHash });
      }

      clearLockoutAttempts('login');
      setCurrentUser(toSafeSessionUser(user));
      setIsAppLocked(false);
      setCurrentPageRaw('dashboard');
      sessionStorage.setItem('sales_crm_active_session', 'true');
      sessionStorage.setItem('sales_crm_pin_unlocked', 'true');
      localStorage.setItem('sales_crm_logged_user_id', String(user.id));
      localStorage.setItem('sales_crm_logged_username', user.username);
      localStorage.setItem('sales_crm_current_page', 'dashboard');

      await createBackup('تسجيل دخول تلقائي');
      showToast(`مرحباً بك ${user.username}!`);
      return true;
    } catch (err) {
      console.error('Login error:', err);
      showToast('حدث خطأ أثناء تسجيل الدخول', 'error');
      return false;
    }
  };

  const updateSettingsState = useCallback(async (key: string, value: any) => {
    try {
      // Never persist raw API keys in local client settings
      if (key === 'geminiApiKey') return;
      await db.settings.put({ key, value });
      setSettings((prev) => ({ ...prev, [key]: value }));
    } catch (err) {
      console.error('Failed to update setting:', err);
    }
  }, []);

  const smartAlertsCount = pendingReminders.length + dueTasksCount;

  const contextValue = useMemo<AuthContextType>(
    () => ({
      currentUser,
      isAdmin,
      permissions,
      isInitialized,
      needsAdminSetup,
      isAppLocked,
      hasPinLock,
      lockApp,
      unlockApp,
      setCurrentPage,
      customerStatusFilter,
      setCustomerStatusFilter,
      selectedMonthKey,
      setSelectedMonthKey,
      pendingReminders,
      dueTasksCount,
      smartAlertsCount,
      settings,
      setupInitialAdmin,
      login,
      startTrialLogin,
      logout,
      updateSettingsState,
      checkReminders,
      refreshSettings,
    }),
    [
      currentUser,
      isAdmin,
      permissions,
      isInitialized,
      needsAdminSetup,
      isAppLocked,
      hasPinLock,
      lockApp,
      unlockApp,
      setCurrentPage,
      customerStatusFilter,
      setCustomerStatusFilter,
      selectedMonthKey,
      setSelectedMonthKey,
      pendingReminders,
      dueTasksCount,
      smartAlertsCount,
      settings,
      logout,
      updateSettingsState,
      checkReminders,
      refreshSettings,
    ]
  );

  return (
    <AuthContext.Provider value={contextValue}>
      <CurrentPageContext.Provider value={currentPage}>{children}</CurrentPageContext.Provider>
    </AuthContext.Provider>
  );
};

export const useCurrentPage = (): PageView => {
  return useContext(CurrentPageContext);
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
