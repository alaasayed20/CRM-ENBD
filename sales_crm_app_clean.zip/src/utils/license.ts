/**
 * Sales CRM - License, Subscription & White-label Management Engine
 * Provides offline-verifiable license keys, trial management, renewal reminders, and B2B white-labeling.
 */

export type LicensePlan = 'trial' | 'monthly' | 'quarterly' | 'annual' | 'lifetime';

export interface LicenseDetails {
  key: string;
  plan: LicensePlan;
  planNameAr: string;
  planNameEn: string;
  clientName: string;
  issuedAt: number;
  expiresAt: number | null; // null for lifetime
  daysRemaining: number;
  isExpired: boolean;
  isValid: boolean;
}

export interface GeneratedLicense {
  key: string;
  plan: LicensePlan;
  clientName: string;
  clientPhone?: string;
  issuedAt: number;
  expiresAt: number | null;
  durationDays: number;
  notes?: string;
}

// Simple deterministic hash for checksum verification
function generateChecksum(payload: string): string {
  let hash = 5381;
  for (let i = 0; i < payload.length; i++) {
    hash = ((hash << 5) + hash) + payload.charCodeAt(i);
    hash = hash & hash; // Convert to 32bit integer
  }
  const hex = Math.abs(hash).toString(36).toUpperCase().padStart(4, '0');
  return hex.slice(-4);
}

/**
 * Generate an offline verifiable license key for commercial subscriptions
 */
export function generateLicenseKey(plan: LicensePlan, clientName: string, customDays?: number): string {
  const planPrefixMap: Record<LicensePlan, string> = {
    trial: 'TRL14',
    monthly: 'M30D',
    quarterly: 'Q90D',
    annual: 'Y365',
    lifetime: 'VIPL'
  };

  const prefix = planPrefixMap[plan] || 'M30D';
  const timestamp = Math.floor(Date.now() / 1000).toString(36).toUpperCase().padStart(6, '0').slice(-6);
  const cleanName = (clientName.trim().replace(/[^a-zA-Z0-9]/g, '') || 'CLIENT').slice(0, 4).toUpperCase().padEnd(4, 'X');
  
  const payload = `CRM-${prefix}-${timestamp}-${cleanName}`;
  const checksum = generateChecksum(payload);

  return `${payload}-${checksum}`;
}

/**
 * Verify and parse a license key
 */
export function verifyLicenseKey(key: string, installDateTimestamp?: number): LicenseDetails {
  const cleanKey = (key || '').trim().toUpperCase();

  if (!cleanKey) {
    // Default Trial calculation
    const installDate = installDateTimestamp || Date.now();
    const trialDurationMs = 14 * 24 * 60 * 60 * 1000;
    const expiresAt = installDate + trialDurationMs;
    const diffMs = expiresAt - Date.now();
    const daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    const isExpired = daysRemaining <= 0;

    return {
      key: '',
      plan: 'trial',
      planNameAr: 'فترة تجريبية مجانية (14 يوم)',
      planNameEn: 'Free Trial (14 Days)',
      clientName: 'مستخدم تجريبي',
      issuedAt: installDate,
      expiresAt,
      daysRemaining,
      isExpired,
      isValid: !isExpired
    };
  }

  // Lifetime VIP Key bypasses expiration
  if (cleanKey.includes('-VIPL-')) {
    return {
      key: cleanKey,
      plan: 'lifetime',
      planNameAr: 'ترخيص غير محدود مدى الحياة (VIP)',
      planNameEn: 'Lifetime VIP License',
      clientName: 'مشترك دائم VIP',
      issuedAt: Date.now(),
      expiresAt: null,
      daysRemaining: 9999,
      isExpired: false,
      isValid: true
    };
  }

  const parts = cleanKey.split('-');
  if (parts.length < 5 || parts[0] !== 'CRM') {
    return {
      key: cleanKey,
      plan: 'trial',
      planNameAr: 'كود ترخيص غير صالح',
      planNameEn: 'Invalid License Key',
      clientName: 'غير معروف',
      issuedAt: Date.now(),
      expiresAt: Date.now(),
      daysRemaining: 0,
      isExpired: true,
      isValid: false
    };
  }

  const [, planCode, timestampStr, clientPart, checksum] = parts;
  const payload = `CRM-${planCode}-${timestampStr}-${clientPart}`;
  const expectedChecksum = generateChecksum(payload);

  if (checksum !== expectedChecksum) {
    return {
      key: cleanKey,
      plan: 'trial',
      planNameAr: 'كود ترخيص غير متطابق',
      planNameEn: 'Corrupted License Key',
      clientName: 'غير معروف',
      issuedAt: Date.now(),
      expiresAt: Date.now(),
      daysRemaining: 0,
      isExpired: true,
      isValid: false
    };
  }

  let durationDays = 30;
  let plan: LicensePlan = 'monthly';
  let planNameAr = 'اشتراك شهري احترافي (30 يوم)';
  let planNameEn = 'Monthly Pro License (30 Days)';

  if (planCode === 'TRL14') {
    durationDays = 14;
    plan = 'trial';
    planNameAr = 'فترة تجريبية مفعلة (14 يوم)';
    planNameEn = 'Activated Trial (14 Days)';
  } else if (planCode === 'M30D') {
    durationDays = 30;
    plan = 'monthly';
    planNameAr = 'اشتراك شهري احترافي (30 يوم)';
    planNameEn = 'Monthly Pro License (30 Days)';
  } else if (planCode === 'Q90D') {
    durationDays = 90;
    plan = 'quarterly';
    planNameAr = 'اشتراك ربع سنوي (90 يوم)';
    planNameEn = 'Quarterly Pro License (90 Days)';
  } else if (planCode === 'Y365') {
    durationDays = 365;
    plan = 'annual';
    planNameAr = 'اشتراك سنوي شامل (365 يوم)';
    planNameEn = 'Annual VIP License (365 Days)';
  }

  // Parse issued date from timestamp string
  const issuedSec = parseInt(timestampStr, 36);
  const issuedAt = !isNaN(issuedSec) && issuedSec > 1000000 ? issuedSec * 1000 : Date.now();
  const expiresAt = issuedAt + (durationDays * 24 * 60 * 60 * 1000);
  const diffMs = expiresAt - Date.now();
  const daysRemaining = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
  const isExpired = daysRemaining <= 0;

  return {
    key: cleanKey,
    plan,
    planNameAr,
    planNameEn,
    clientName: clientPart || 'مشترك معتمد',
    issuedAt,
    expiresAt,
    daysRemaining,
    isExpired,
    isValid: !isExpired
  };
}
