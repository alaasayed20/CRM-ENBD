// Mobile Haptic Feedback Helper for Samsung S24 Ultra & Android devices
export function triggerHaptic(type: 'light' | 'medium' | 'success' | 'warning' = 'light') {
  if (typeof window !== 'undefined' && 'navigator' in window && 'vibrate' in navigator) {
    try {
      if (type === 'light') {
        navigator.vibrate(8);
      } else if (type === 'medium') {
        navigator.vibrate(18);
      } else if (type === 'success') {
        navigator.vibrate([10, 40, 20]);
      } else if (type === 'warning') {
        navigator.vibrate([25, 50, 25]);
      }
    } catch {
      // Ignore if not permitted
    }
  }
}
