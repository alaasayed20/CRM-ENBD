import { db } from '../db/db';

export const getCurrentMonthKey = (): string => {
  const d = new Date();
  const yr = d.getFullYear();
  const mo = String(d.getMonth() + 1).padStart(2, '0');
  return `${yr}-${mo}`;
};

export const ARABIC_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export const ENGLISH_MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const formatMonthKeyToArabic = (monthKey: string): string => {
  if (!monthKey || !monthKey.includes('-')) return monthKey || '';
  const [yearStr, monthStr] = monthKey.split('-');
  const mIndex = parseInt(monthStr, 10) - 1;
  const monthName = ARABIC_MONTHS[mIndex] || monthStr;
  return `${monthName} ${yearStr}`;
};

export const formatMonthKeyToEnglish = (monthKey: string): string => {
  if (!monthKey || !monthKey.includes('-')) return monthKey || '';
  const [yearStr, monthStr] = monthKey.split('-');
  const mIndex = parseInt(monthStr, 10) - 1;
  const monthName = ENGLISH_MONTHS[mIndex] || monthStr;
  return `${monthName} ${yearStr}`;
};

export const formatMonthKey = (monthKey: string, lang: 'ar' | 'en' = 'ar'): string => {
  if (!monthKey) return '';
  if (monthKey === 'all') return lang === 'en' ? 'All Months' : 'جميع الشهور';
  return lang === 'en' ? formatMonthKeyToEnglish(monthKey) : formatMonthKeyToArabic(monthKey);
};

export const getCustomerMonthKey = (c: { targetMonth?: string | null; createdAt?: Date | string | null }): string => {
  if (c.targetMonth && c.targetMonth.includes('-')) return c.targetMonth;
  if (c.createdAt) {
    const d = new Date(c.createdAt);
    if (!isNaN(d.getTime())) {
      const yr = d.getFullYear();
      const mo = String(d.getMonth() + 1).padStart(2, '0');
      return `${yr}-${mo}`;
    }
  }
  return getCurrentMonthKey();
};

export const getExactDateForMonth = (monthKey: string, day: number = 15): Date => {
  if (!monthKey || !monthKey.includes('-')) return new Date();
  const [yearStr, monthStr] = monthKey.split('-');
  const yr = parseInt(yearStr, 10) || new Date().getFullYear();
  const mo = (parseInt(monthStr, 10) || (new Date().getMonth() + 1)) - 1;
  return new Date(yr, mo, Math.min(day, 28), 12, 0, 0);
};

export interface MonthOption {
  key: string; // '2026-07' or 'all'
  labelAr: string;
  labelEn: string;
  count?: number;
  isCurrent?: boolean;
}

export const isValidMonthKey = (value?: string | null): value is string => {
  return Boolean(value && /^\d{4}-(0[1-9]|1[0-2])$/.test(value.trim()));
};

export const getAvailableMonthOptions = (
  customers: Array<{ targetMonth?: string | null; createdAt?: Date | string | null }> = [],
  extraMonthKeys: Array<string | null | undefined> = []
): MonthOption[] => {
  const currentKey = getCurrentMonthKey();
  const keysSet = new Set<string>();

  // Always include current month
  keysSet.add(currentKey);

  // Generate full 12 months for previous year, current year, and next year so users can target any past or future month effortlessly
  const d = new Date();
  const currentYear = d.getFullYear();
  for (let yr = currentYear - 1; yr <= currentYear + 1; yr++) {
    for (let m = 1; m <= 12; m++) {
      const mo = String(m).padStart(2, '0');
      keysSet.add(`${yr}-${mo}`);
    }
  }

  // Include any custom month keys passed explicitly (e.g., from <input type="month">)
  extraMonthKeys.forEach((mk) => {
    if (isValidMonthKey(mk)) {
      keysSet.add(mk.trim());
    }
  });

  // Include any extra months/years present in customers
  customers.forEach((c) => {
    const mk = getCustomerMonthKey(c);
    if (mk && mk.includes('-')) {
      keysSet.add(mk);
      const [yrStr] = mk.split('-');
      const yr = parseInt(yrStr, 10);
      if (!isNaN(yr)) {
        for (let m = 1; m <= 12; m++) {
          const mo = String(m).padStart(2, '0');
          keysSet.add(`${yr}-${mo}`);
        }
      }
    }
  });

  // Count customers per month
  const countsMap: Record<string, number> = {};
  customers.forEach((c) => {
    const mk = getCustomerMonthKey(c);
    countsMap[mk] = (countsMap[mk] || 0) + 1;
  });

  // Sort keys by year (latest year first), then by month 1 to 12 ascending (01 to 12)
  const sortedKeys = Array.from(keysSet).sort((a, b) => {
    const [yrA, moA] = a.split('-').map(Number);
    const [yrB, moB] = b.split('-').map(Number);
    if (yrA !== yrB) {
      return yrB - yrA; // Newest year top
    }
    return moA - moB; // Month 1 to 12 ascending
  });

  const options: MonthOption[] = [
    {
      key: 'all',
      labelAr: 'جميع الشهور (عرض شامل)',
      labelEn: 'All Months (Full View)',
      count: customers.length
    },
    ...sortedKeys.map((key) => ({
      key,
      labelAr: formatMonthKeyToArabic(key),
      labelEn: formatMonthKeyToEnglish(key),
      count: countsMap[key] || 0,
      isCurrent: key === currentKey
    }))
  ];

  return options;
};

export interface MonthlySnapshot {
  monthKey: string;
  monthNameAr: string;
  monthNameEn: string;
  totalExecuted: number;
  totalPoints: number;
  totalSalesRevenue: number;
  carriedOverCount: number;
  archivedAt: string;
}

export interface RolloverResult {
  rolledOver: boolean;
  prevMonth?: string;
  newMonth: string;
  carriedCount: number;
  archivedCount: number;
}

/**
 * Checks if a new month has started and applies month rollover logic:
 * 1. Activated/Completed customers from previous month are preserved/archived for that month.
 * 2. All remaining active/in-progress customers are rolled over into the current month.
 * 3. Stats, achievements, and target calculations reset for the new month.
 */
export async function checkAndApplyMonthRollover(forceManual: boolean = false): Promise<RolloverResult> {
  const currentMonth = getCurrentMonthKey();

  // Get last recorded month setting
  const lastMonthSetting = await db.settings.get('lastActiveMonth');
  const lastActiveMonth = lastMonthSetting ? String(lastMonthSetting.value) : null;

  if (!forceManual && lastActiveMonth === currentMonth) {
    return { rolledOver: false, newMonth: currentMonth, carriedCount: 0, archivedCount: 0 };
  }

  let carriedCount = 0;
  let archivedCount = 0;
  let prevTotalPoints = 0;
  let prevTotalRevenue = 0;
  const now = new Date();

  await db.transaction('rw', [db.customers, db.settings, db.operationsLog, db.pointsLog], async () => {
    const allCustomers = await db.customers.toArray();
    const prevMonthKey = lastActiveMonth || currentMonth;
    const [prevYearStr, prevMonthStr] = prevMonthKey.split('-');
    const prevYearNum = parseInt(prevYearStr, 10) || now.getFullYear();
    const prevMonthNum = parseInt(prevMonthStr, 10) || (now.getMonth() + 1);

    for (const c of allCustomers) {
      if (!c.id) continue;

      const isActivated = c.status === 'تم التفعيل' || c.status === 'مكتمل' || c.status === 'تم التنفيذ';

      if (isActivated) {
        // Preserved in previous month archive
        archivedCount++;
        prevTotalRevenue += Number(c.amount) || Number(c.salary) || 0;
        prevTotalPoints += Number(c.points) || 0;
      } else {
        // Active/In-progress customer carried over to current month
        carriedCount++;
        await db.customers.update(c.id, {
          updatedAt: now
        });
      }
    }

    // Save previous month snapshot
    const existingSnapshotsSetting = await db.settings.get('monthlySnapshots');
    const existingSnapshots: MonthlySnapshot[] = existingSnapshotsSetting?.value ? JSON.parse(existingSnapshotsSetting.value) : [];

    if (lastActiveMonth && lastActiveMonth !== currentMonth) {
      const newSnapshot: MonthlySnapshot = {
        monthKey: lastActiveMonth,
        monthNameAr: formatMonthKeyToArabic(lastActiveMonth),
        monthNameEn: formatMonthKeyToEnglish(lastActiveMonth),
        totalExecuted: archivedCount,
        totalPoints: prevTotalPoints,
        totalSalesRevenue: prevTotalRevenue,
        carriedOverCount: carriedCount,
        archivedAt: now.toISOString()
      };

      // Filter out duplicate if already exists
      const updatedSnapshots = [
        newSnapshot,
        ...existingSnapshots.filter((s) => s.monthKey !== lastActiveMonth)
      ];

      await db.settings.put({ key: 'monthlySnapshots', value: JSON.stringify(updatedSnapshots) });
    }

    // Save current active month in settings
    await db.settings.put({ key: 'lastActiveMonth', value: currentMonth });

    // Add operation log
    await db.operationsLog.add({
      action: 'MONTH_ROLLOVER',
      tableName: 'customers',
      newData: JSON.stringify({ currentMonth, prevMonth: lastActiveMonth, carriedCount, archivedCount }),
      timestamp: now
    });
  });

  return {
    rolledOver: true,
    prevMonth: lastActiveMonth ? formatMonthKeyToArabic(lastActiveMonth) : 'الشهر السابق',
    newMonth: currentMonth,
    carriedCount,
    archivedCount
  };
}

