/**
 * Utility for checking and applying app updates in PWA / Web environments
 */

export const forceAppUpdateAndRefresh = async (): Promise<void> => {
  try {
    // 1. Tell Service Worker to skip waiting if any is waiting
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const registration of registrations) {
        if (registration.waiting) {
          registration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
        await registration.update().catch(() => {});
      }
    }

    // 2. Clear application caches
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map((name) => caches.delete(name)));
    }
  } catch (err) {
    console.error('Failed to clear caches during update:', err);
  } finally {
    // 3. Force reload the window
    window.location.reload();
  }
};

export const checkServiceWorkerUpdate = async (): Promise<boolean> => {
  if (!('serviceWorker' in navigator)) return false;
  try {
    const registration = await navigator.serviceWorker.getRegistration();
    if (!registration) return false;
    await registration.update();
    return !!registration.waiting;
  } catch {
    return false;
  }
};
