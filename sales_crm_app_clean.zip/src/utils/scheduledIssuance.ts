import { db, logOperation } from '../db/db';
import type { Customer } from '../types';
import {
  formatMonthKeyToArabic,
  formatMonthKeyToEnglish,
  getCurrentMonthKey,
  getCustomerMonthKey,
  getExactDateForMonth,
} from './monthRollover';
import { normalizePhoneForMatch, sanitizePlainText } from './security';

export interface ParsedScheduledIssuance {
  targetMonth: string; // YYYY-MM
  issuanceDate: string; // YYYY-MM-DD
  hasExactDay: boolean;
  day: number;
  year: number;
  month: number; // 1..12
  matchedText: string;
  labelAr: string;
  labelEn: string;
  isDifferentFromSourceMonth: boolean;
}

export interface ScheduleIssuanceResult {
  action: 'created' | 'updated';
  customerId: number;
  targetMonth: string;
  issuanceDate: string;
  monthLabelAr: string;
  monthLabelEn: string;
}

const ARABIC_INDIC_MAP: Record<string, string> = {
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
  '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
  '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
};

function toAsciiDigits(text: string): string {
  return text.replace(/[٠-٩۰-۹]/g, (ch) => ARABIC_INDIC_MAP[ch] ?? ch);
}

function normalizeArabicForMatch(text: string): string {
  return toAsciiDigits(text)
    .toLowerCase()
    // Remove Arabic diacritics (tashkeel) and tatweel
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    // Normalize alef variants, ta marbuta, alef maqsura
    .replace(/[إأآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/\s+/g, ' ')
    .trim();
}

const MONTH_NAME_MAP: Array<{ pattern: string; month: number }> = [
  // January
  { pattern: 'كانون الثاني', month: 1 },
  { pattern: 'يناير', month: 1 },
  { pattern: 'جانفي', month: 1 },
  { pattern: 'january', month: 1 },
  { pattern: 'jan', month: 1 },
  // February
  { pattern: 'فبراير', month: 2 },
  { pattern: 'فيفري', month: 2 },
  { pattern: 'شباط', month: 2 },
  { pattern: 'february', month: 2 },
  { pattern: 'feb', month: 2 },
  // March
  { pattern: 'مارس', month: 3 },
  { pattern: 'اذار', month: 3 },
  { pattern: 'march', month: 3 },
  { pattern: 'mar', month: 3 },
  // April
  { pattern: 'ابريل', month: 4 },
  { pattern: 'افريل', month: 4 },
  { pattern: 'نيسان', month: 4 },
  { pattern: 'april', month: 4 },
  { pattern: 'apr', month: 4 },
  // May
  { pattern: 'مايو', month: 5 },
  { pattern: 'ماي', month: 5 },
  { pattern: 'ايار', month: 5 },
  { pattern: 'may', month: 5 },
  // June
  { pattern: 'يونيو', month: 6 },
  { pattern: 'جوان', month: 6 },
  { pattern: 'حزيران', month: 6 },
  { pattern: 'june', month: 6 },
  { pattern: 'jun', month: 6 },
  // July
  { pattern: 'يوليو', month: 7 },
  { pattern: 'جويليه', month: 7 },
  { pattern: 'تموز', month: 7 },
  { pattern: 'july', month: 7 },
  { pattern: 'jul', month: 7 },
  // August
  { pattern: 'اغسطس', month: 8 },
  { pattern: 'اوت', month: 8 },
  { pattern: 'august', month: 8 },
  { pattern: 'aug', month: 8 },
  // September
  { pattern: 'سبتمبر', month: 9 },
  { pattern: 'ايلول', month: 9 },
  { pattern: 'september', month: 9 },
  { pattern: 'sept', month: 9 },
  { pattern: 'sep', month: 9 },
  // October
  { pattern: 'تشرين الاول', month: 10 },
  { pattern: 'اكتوبر', month: 10 },
  { pattern: 'october', month: 10 },
  { pattern: 'oct', month: 10 },
  // November
  { pattern: 'تشرين الثاني', month: 11 },
  { pattern: 'نوفمبر', month: 11 },
  { pattern: 'november', month: 11 },
  { pattern: 'nov', month: 11 },
  // December
  { pattern: 'كانون الاول', month: 12 },
  { pattern: 'ديسمبر', month: 12 },
  { pattern: 'december', month: 12 },
  { pattern: 'dec', month: 12 },
];

// Positive intent cues indicating card issuance / deferred scheduling
const ISSUANCE_INTENT_KEYWORDS = [
  'اصدار',
  'اصدر',
  'تصدر',
  'تصدير',
  'سيتم اصدار',
  'يتم اصدار',
  'استخراج',
  'تستخرج',
  'بطاقه',
  'البطاقه',
  'بطاقته',
  'فيزا',
  'الفيزا',
  'تاجيل',
  'مؤجل',
  'يؤجل',
  'تؤجل',
  'ليس الان',
  'مو الان',
  'مش الان',
  'لاحقا',
  'تقديم',
  'اعاده التقديم',
  'رفع الطلب',
  'جدوله',
  'مجدول',
  'issue',
  'issuance',
  'issued',
  'card',
  'visa',
  'postpone',
  'defer',
  'schedule',
  'scheduled',
];

// Negative context cues right before a date (avoid mistaking DOB or ID expiry for card issuance)
const NON_ISSUANCE_DATE_PREFIXES = [
  'ميلاد',
  'تاريخ الميلاد',
  'انتهاء الهويه',
  'انتهاء الاقامه',
  'تاريخ الانتهاء',
  'dob',
  'birth',
  'id expiry',
];

function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

function clampDayForMonth(year: number, month: number, day: number): number {
  const maxDay = new Date(year, month, 0).getDate();
  return Math.max(1, Math.min(day, maxDay));
}

function parseTwoOrFourDigitYear(rawYear: string): number {
  const num = parseInt(rawYear, 10);
  if (rawYear.length === 2) {
    return 2000 + num;
  }
  return num;
}

function inferYearForMonth(month: number, refDate: Date, forceNextYear = false): number {
  const refYear = refDate.getFullYear();
  const refMonth = refDate.getMonth() + 1;
  if (forceNextYear) return refYear + 1;
  // If the named/numbered month is earlier than current month, assume next year
  if (month < refMonth) {
    return refYear + 1;
  }
  return refYear;
}

function hasCardIssuanceIntent(normalized: string): boolean {
  return ISSUANCE_INTENT_KEYWORDS.some((kw) => normalized.includes(kw));
}

function isPrecededByExcludedPrefix(normalized: string, matchIndex: number): boolean {
  const lookback = normalized.slice(Math.max(0, matchIndex - 28), matchIndex);
  return NON_ISSUANCE_DATE_PREFIXES.some((prefix) => lookback.includes(prefix));
}

function buildResult(
  year: number,
  month: number,
  day: number,
  hasExactDay: boolean,
  matchedText: string,
  sourceMonthKey?: string
): ParsedScheduledIssuance | null {
  if (year < 2020 || year > 2100 || month < 1 || month > 12) {
    return null;
  }
  const safeDay = clampDayForMonth(year, month, day);
  const targetMonth = `${year}-${pad2(month)}`;
  const issuanceDate = `${year}-${pad2(month)}-${pad2(safeDay)}`;
  const monthLabelAr = formatMonthKeyToArabic(targetMonth);
  const monthLabelEn = formatMonthKeyToEnglish(targetMonth);
  const baseMonth = sourceMonthKey && sourceMonthKey.includes('-') ? sourceMonthKey : getCurrentMonthKey();

  return {
    targetMonth,
    issuanceDate,
    hasExactDay,
    day: safeDay,
    year,
    month,
    matchedText: matchedText.trim(),
    labelAr: hasExactDay ? `${monthLabelAr} (${issuanceDate})` : monthLabelAr,
    labelEn: hasExactDay ? `${monthLabelEn} (${issuanceDate})` : monthLabelEn,
    isDifferentFromSourceMonth: targetMonth !== baseMonth,
  };
}

/**
 * Parses a customer note (Arabic or English) to detect if it specifies
 * a future/specific card issuance date or month.
 */
export function parseScheduledCardIssuanceFromNote(
  note?: string | null,
  sourceMonthKey?: string,
  referenceDate: Date = new Date()
): ParsedScheduledIssuance | null {
  if (!note || !note.trim()) return null;

  const normalized = normalizeArabicForMatch(note);
  if (!hasCardIssuanceIntent(normalized)) {
    return null;
  }

  // Strip any already-appended auto-schedule marker only if there's nothing else?
  // No — keeping it allows View Mode to still recognize the scheduled month on saved notes!

  // 1. YYYY-MM-DD or YYYY/MM/DD or YYYY.MM.DD
  const isoRegex = /\b(20\d{2})[-/.](0?[1-9]|1[0-2])[-/.](0?[1-9]|[12]\d|3[01])\b/g;
  for (const m of normalized.matchAll(isoRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const year = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const day = parseInt(m[3], 10);
    const res = buildResult(year, month, day, true, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 2. DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY (also 2-digit year DD/MM/YY)
  const dmyRegex = /\b(0?[1-9]|[12]\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.](20\d{2}|\d{2})\b/g;
  for (const m of normalized.matchAll(dmyRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const day = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const year = parseTwoOrFourDigitYear(m[3]);
    const res = buildResult(year, month, day, true, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 3. YYYY-MM or YYYY/MM
  const ymRegex = /\b(20\d{2})[-/.](0?[1-9]|1[0-2])\b/g;
  for (const m of normalized.matchAll(ymRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const year = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const res = buildResult(year, month, 1, false, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 4. MM/YYYY or MM-YYYY
  const myRegex = /\b(0?[1-9]|1[0-2])[-/.](20\d{2})\b/g;
  for (const m of normalized.matchAll(myRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const month = parseInt(m[1], 10);
    const year = parseInt(m[2], 10);
    const res = buildResult(year, month, 1, false, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 5. Named Month (Arabic or English), with optional day before and optional year after
  // Examples: "15 يناير 2027", "يوم 5 مارس", "شهر فبراير 2027", "في يوليو", "March 2027"
  for (const { pattern, month } of MONTH_NAME_MAP) {
    const escaped = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(
      `(?:(?:يوم|تاريخ|بتاريخ)?\\s*(0?[1-9]|[12]\\d|3[01])\\s+)?(?:شهر\\s+)?${escaped}(?:\\s+(20\\d{2}))?(?:\\s+(القادم|الجاي|المقبل))?`,
      'i'
    );
    const match = normalized.match(regex);
    if (match) {
      // Ensure word boundary for short English abbreviations like 'mar', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'jan', 'feb', 'apr'
      if (/^[a-z]+$/.test(pattern)) {
        const boundaryRegex = new RegExp(
          `(?:\\b(0?[1-9]|[12]\\d|3[01])\\s+)?\\b${escaped}\\b(?:\\s+(20\\d{2}))?`,
          'i'
        );
        const bm = normalized.match(boundaryRegex);
        if (!bm) continue;
        if (bm.index !== undefined && isPrecededByExcludedPrefix(normalized, bm.index)) continue;
        const day = bm[1] ? parseInt(bm[1], 10) : 1;
        const year = bm[2] ? parseInt(bm[2], 10) : inferYearForMonth(month, referenceDate);
        const res = buildResult(year, month, day, Boolean(bm[1]), bm[0], sourceMonthKey);
        if (res) return res;
        continue;
      }

      if (match.index !== undefined && isPrecededByExcludedPrefix(normalized, match.index)) continue;
      const day = match[1] ? parseInt(match[1], 10) : 1;
      const forceNextYear = Boolean(match[3]) && month === referenceDate.getMonth() + 1;
      const year = match[2] ? parseInt(match[2], 10) : inferYearForMonth(month, referenceDate, forceNextYear);
      const res = buildResult(year, month, day, Boolean(match[1]), match[0], sourceMonthKey);
      if (res) return res;
    }
  }

  // 6. Numeric Arabic month phrase: "شهر 1", "في شهر 03 2027", "شهر 12 القادم"
  const numericMonthRegex = /(?:في\s+)?(?:شهر|الشهر)\s*(0?[1-9]|1[0-2])\b(?:\s*(?:سنه|عام)?\s*(20\d{2}))?/g;
  for (const m of normalized.matchAll(numericMonthRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const month = parseInt(m[1], 10);
    const year = m[2] ? parseInt(m[2], 10) : inferYearForMonth(month, referenceDate);
    const res = buildResult(year, month, 1, false, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 7. Short DD/MM without year (e.g., "بتاريخ 15/1" or "يوم 20/03")
  const shortDmRegex = /(?:بتاريخ|تاريخ|يوم|في)\s*(0?[1-9]|[12]\d|3[01])[-/](0?[1-9]|1[0-2])\b/g;
  for (const m of normalized.matchAll(shortDmRegex)) {
    if (m.index !== undefined && isPrecededByExcludedPrefix(normalized, m.index)) continue;
    const day = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const year = inferYearForMonth(month, referenceDate);
    const res = buildResult(year, month, day, true, m[0], sourceMonthKey);
    if (res) return res;
  }

  // 8. Relative month phrases
  // "بعد N شهور / اشهر / شهر" or "in N months"
  const afterNMonthsRegex = /(?:بعد|خلال|in|after)\s+(\d{1,2})\s*(?:شهور|اشهر|شهر|months?|mos?)\b/;
  const afterNMatch = normalized.match(afterNMonthsRegex);
  if (afterNMatch) {
    const offset = parseInt(afterNMatch[1], 10);
    if (offset >= 1 && offset <= 24) {
      const target = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + offset, 1);
      return buildResult(target.getFullYear(), target.getMonth() + 1, 1, false, afterNMatch[0], sourceMonthKey);
    }
  }

  if (/(?:بعد شهرين|الشهر اللي بعده|الشهر الذي يليه|in two months)/.test(normalized)) {
    const target = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 2, 1);
    return buildResult(target.getFullYear(), target.getMonth() + 1, 1, false, 'بعد شهرين', sourceMonthKey);
  }

  if (/(?:الشهر القادم|الشهر الجاي|الشهر المقبل|شهر قادم|بعد شهر|next month)/.test(normalized)) {
    const target = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 1, 1);
    return buildResult(target.getFullYear(), target.getMonth() + 1, 1, false, 'الشهر القادم', sourceMonthKey);
  }

  if (/(?:السنه القادمه|السنه الجايه|العام القادم|بعد سنه|next year)/.test(normalized)) {
    const target = new Date(referenceDate.getFullYear() + 1, referenceDate.getMonth(), 1);
    return buildResult(target.getFullYear(), target.getMonth() + 1, 1, false, 'السنة القادمة', sourceMonthKey);
  }

  return null;
}

/**
 * Formats a clean issuance schedule note snippet from an ISO YYYY-MM-DD date.
 */
export function buildScheduledIssuanceNoteSnippet(isoDate: string, language: 'ar' | 'en' = 'ar'): string {
  if (!isoDate) return '';
  return language === 'ar'
    ? `يتم إصدار البطاقة بتاريخ ${isoDate}`
    : `Card issuance scheduled on ${isoDate}`;
}

/**
 * Appends or replaces an existing scheduled-issuance date snippet inside a note cleanly.
 */
export function upsertScheduledIssuanceSnippetInNote(
  currentNote: string,
  isoDate: string,
  language: 'ar' | 'en' = 'ar'
): string {
  const snippet = buildScheduledIssuanceNoteSnippet(isoDate, language);
  const trimmed = (currentNote || '').trim();
  if (!trimmed) return snippet;

  const replacePattern = /(?:يتم إصدار البطاقة بتاريخ|Card issuance scheduled on)\s+\d{4}-\d{2}-\d{2}/i;
  if (replacePattern.test(trimmed)) {
    return trimmed.replace(replacePattern, snippet);
  }
  return `${trimmed}\n${snippet}`;
}

/**
 * Checks whether a customer with the same normalized phone already exists in targetMonth.
 */
export async function findExistingCustomerInMonth(
  phone: string,
  targetMonth: string
): Promise<Customer | undefined> {
  const targetNorm = normalizePhoneForMatch(phone);
  if (!targetNorm) return undefined;
  const all = await db.customers.toArray();
  return all.find(
    (c) => normalizePhoneForMatch(c.phone) === targetNorm && getCustomerMonthKey(c) === targetMonth
  );
}

/**
 * Creates (or updates if already scheduled) a Potential Customer ('عميل محتمل')
 * in the detected card issuance month, plus a high-priority follow-up task on the issuance date.
 */
export async function schedulePotentialCustomerForIssuanceMonth(
  source: {
    name: string;
    phone: string;
    idNumber?: string | null;
    email?: string | null;
    salary?: number | null;
    cardTypeId?: number | null;
    cardTypeName?: string | null;
    points?: number | null;
    notes?: string | null;
    salesRepId?: number | null;
  },
  parsed: ParsedScheduledIssuance,
  options?: {
    userId?: number;
    language?: 'ar' | 'en';
  }
): Promise<ScheduleIssuanceResult> {
  const now = new Date();
  const lang = options?.language || 'ar';
  const monthLabelAr = formatMonthKeyToArabic(parsed.targetMonth);
  const monthLabelEn = formatMonthKeyToEnglish(parsed.targetMonth);
  const scheduleTag = `[مجدول تلقائياً لإصدار البطاقة بتاريخ ${parsed.issuanceDate}]`;

  const cleanSourceNote = sanitizePlainText(source.notes || '', 1200);
  const combinedNote = cleanSourceNote.includes(scheduleTag)
    ? cleanSourceNote
    : cleanSourceNote
      ? `${cleanSourceNote}\n${scheduleTag}`
      : scheduleTag;

  const existingInTarget = await findExistingCustomerInMonth(source.phone, parsed.targetMonth);

  if (existingInTarget?.id) {
    // Avoid creating duplicates; refresh follow-up date and note cleanly if still potential/pending
    const existingNotes = existingInTarget.notes || '';
    const nextNotes = existingNotes.includes(scheduleTag)
      ? existingNotes
      : existingNotes
        ? `${existingNotes}\n${scheduleTag}`
        : combinedNote;

    await db.customers.update(existingInTarget.id, {
      followUpDate: parsed.issuanceDate,
      notes: nextNotes,
      updatedAt: now,
    });

    await ensureIssuanceReminderTask(existingInTarget.id, source.name, parsed.issuanceDate, combinedNote, lang);

    return {
      action: 'updated',
      customerId: existingInTarget.id,
      targetMonth: parsed.targetMonth,
      issuanceDate: parsed.issuanceDate,
      monthLabelAr,
      monthLabelEn,
    };
  }

  const orderNumber = `SCH-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
  const targetCreatedAt = getExactDateForMonth(parsed.targetMonth, parsed.hasExactDay ? parsed.day : 1);

  const newRecord: Omit<Customer, 'id'> = {
    name: sanitizePlainText(source.name, 160),
    phone: sanitizePlainText(source.phone, 40),
    idNumber: source.idNumber ? sanitizePlainText(source.idNumber, 32) : null,
    email: source.email ? sanitizePlainText(source.email, 120) : null,
    orderNumber,
    productType: 'visa',
    cardTypeId: source.cardTypeId ?? null,
    cardTypeName: source.cardTypeName ?? null,
    salary: source.salary ?? null,
    amount: null,
    financeType: null,
    financeRate: null,
    points: source.points ?? null,
    status: 'عميل محتمل',
    targetMonth: parsed.targetMonth,
    followUpDate: parsed.issuanceDate,
    notes: combinedNote,
    salesRepId: source.salesRepId ?? options?.userId ?? undefined,
    createdAt: targetCreatedAt,
    updatedAt: now,
    activatedAt: null,
  };

  const newId = await db.customers.add(newRecord as Customer);

  await ensureIssuanceReminderTask(newId, newRecord.name, parsed.issuanceDate, combinedNote, lang);
  await logOperation('CREATE', 'customers', newId, null, { ...newRecord, autoScheduledFromNote: true }, options?.userId);

  return {
    action: 'created',
    customerId: newId,
    targetMonth: parsed.targetMonth,
    issuanceDate: parsed.issuanceDate,
    monthLabelAr,
    monthLabelEn,
  };
}

async function ensureIssuanceReminderTask(
  customerId: number,
  customerName: string,
  issuanceDate: string,
  notes: string,
  language: 'ar' | 'en'
): Promise<void> {
  const existingTasks = await db.tasks.where('customerId').equals(customerId).toArray();
  const alreadyHasTask = existingTasks.some((t) => t.date === issuanceDate);
  if (alreadyHasTask) return;

  await db.tasks.add({
    customerId,
    title:
      language === 'ar'
        ? `موعد إصدار بطاقة العميل: ${customerName}`
        : `Scheduled card issuance: ${customerName}`,
    type: 'followup',
    date: issuanceDate,
    status: 'pending',
    notes,
    priority: 'high',
    createdAt: new Date(),
  });
}
