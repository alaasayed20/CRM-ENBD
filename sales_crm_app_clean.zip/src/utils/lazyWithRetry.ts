import React, { lazy, ComponentType } from 'react';

const RELOAD_GUARD_KEY = 'sales_crm_chunk_reload_ts';
const RELOAD_COOLDOWN_MS = 15_000;

export function isChunkLoadError(error: unknown): boolean {
  if (!error) return false;
  const message =
    typeof error === 'string'
      ? error
      : error instanceof Error
      ? `${error.name} ${error.message}`
      : String(error);

  const normalized = message.toLowerCase();
  return (
    normalized.includes('failed to fetch dynamically imported module') ||
    normalized.includes('importing a module script failed') ||
    normalized.includes('error loading dynamically imported module') ||
    normalized.includes('loading chunk') ||
    normalized.includes('loading css chunk') ||
    normalized.includes('unable to preload css') ||
    normalized.includes('chunkloaderror')
  );
}

/**
 * Clears stale Cache Storage entries and reloads once (guarded by a 15s cooldown)
 * to recover seamlessly when a new app build replaces hashed JS chunk filenames.
 * Returns true if a reload was initiated.
 */
export function recoverFromStaleChunk(): boolean {
  if (typeof window === 'undefined') return false;

  try {
    const now = Date.now();
    const lastReloadRaw = sessionStorage.getItem(RELOAD_GUARD_KEY);
    const lastReload = lastReloadRaw ? Number(lastReloadRaw) : 0;

    if (Number.isFinite(lastReload) && now - lastReload < RELOAD_COOLDOWN_MS) {
      return false;
    }

    sessionStorage.setItem(RELOAD_GUARD_KEY, String(now));
  } catch {
    // Ignore storage access errors in restricted contexts
  }

  const performReload = () => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('_v', String(Date.now()));
      window.location.replace(url.toString());
    } catch {
      window.location.reload();
    }
  };

  // Clear any stale Service Worker caches before reloading so fresh index.html is loaded
  if ('caches' in window) {
    caches
      .keys()
      .then((keys) => Promise.all(keys.map((key) => caches.delete(key))))
      .catch(() => {})
      .finally(performReload);
  } else {
    performReload();
  }

  return true;
}

/**
 * Resilient wrapper around React.lazy that retries transient network failures
 * and auto-recovers when a deployment updates hashed chunk URLs.
 */
export function lazyWithRetry<T extends ComponentType<any>>(
  importer: () => Promise<{ default: T }>
): React.LazyExoticComponent<T> {
  return lazy(async () => {
    try {
      return await importer();
    } catch (firstError) {
      // Brief retry for transient network hiccups
      await new Promise((resolve) => setTimeout(resolve, 250));
      try {
        return await importer();
      } catch (secondError) {
        if (isChunkLoadError(secondError) || isChunkLoadError(firstError)) {
          const reloaded = recoverFromStaleChunk();
          if (reloaded) {
            // Keep Suspense fallback visible while page reloads instead of flashing an error screen
            return new Promise<{ default: T }>(() => {});
          }
        }
        throw secondError;
      }
    }
  });
}
