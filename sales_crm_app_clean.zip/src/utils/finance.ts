/**
 * Utility functions for Personal Financing Calculations
 * حسابات التمويل الشخصي ونسبة الاستقطاع وهامش الربح
 */

export interface FinancingCalculationResult {
  dbrRate: number; // نسبة الاستقطاع % (Debt Burden Ratio)
  maxMonthlyInstallment: number; // أقصى قسط شهري مسموح (ر.س)
  maxEstimatedLoanAmount: number; // أقصى مبلغ تمويل تقريبي (ر.س)
  estimatedMonthlyInstallment: number; // القسط الشهري المتوقع بناء على مبلغ التمويل والنسبة
  profitRateAnnual: number; // نسبة هامش الربح السنوي (%)
}

/**
 * بنية إعدادات نسب التمويل الشخصي القابلة للتعديل من لوحة الإدارة
 */
export interface PersonalFinanceRatesConfig {
  // 1. القطاع العسكري
  militaryStl: number; // تحويل راتب (STL)
  militaryNstl: number; // بدون تحويل راتب (NSTL)

  // 2. تحويل راتب (سعودي) حسب الشريحة وتصنيف جهة العمل
  saudiStl: {
    tier_50k_plus: { A: number; B: number; C_D_E: number; NALE: number };
    tier_40k_50k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_25k_40k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_15k_25k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_below_15k: { A: number; B: number; C_D_E: number; NALE: number };
  };

  // 3. تحويل راتب (مقيم) حسب الشريحة وتصنيف جهة العمل
  expatStl: {
    tier_50k_plus: { A: number; B: number; C_D_E: number; NALE: number };
    tier_40k_50k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_25k_40k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_15k_25k: { A: number; B: number; C_D_E: number; NALE: number };
    tier_below_15k: { A: number; B: number; C_D_E: number; NALE: number };
  };

  // 4. بدون تحويل راتب - جهة معتمدة (Approved)
  saudiNstlApprovedMillion: number; // تمويل مليون فأكثر (سعودي)
  saudiNstlApproved_25k: number; // 25,000 فأكثر
  saudiNstlApproved_15k_25k: number; // 15,000 إلى 24,999
  saudiNstlApproved_below_15k: number; // أقل من 15,000

  expatNstlApproved_25k: number;
  expatNstlApproved_15k_25k: number;
  expatNstlApproved_below_15k: number;

  // 5. بدون تحويل راتب - جهة غير معتمدة (Non-Approved)
  saudiNstlNonApproved_25k: number;
  saudiNstlNonApproved_15k_25k: number;
  saudiNstlNonApproved_below_15k: number;

  expatNstlNonApproved_25k: number;
  expatNstlNonApproved_15k_25k: number;
  expatNstlNonApproved_below_15k: number;

  // 6. نسب سريعة افتراضية لتعبئة النماذج
  quickDefaultStl: number; // افتراضي تحويل راتب
  quickDefaultNstl: number; // افتراضي بدون تحويل راتب
}

export const DEFAULT_PERSONAL_FINANCE_RATES: PersonalFinanceRatesConfig = {
  militaryStl: 3.25,
  militaryNstl: 5.99,

  saudiStl: {
    tier_50k_plus: { A: 1.99, B: 1.99, C_D_E: 2.49, NALE: 3.49 },
    tier_40k_50k: { A: 1.99, B: 2.25, C_D_E: 2.75, NALE: 3.75 },
    tier_25k_40k: { A: 2.49, B: 2.75, C_D_E: 3.49, NALE: 4.49 },
    tier_15k_25k: { A: 3.25, B: 3.35, C_D_E: 3.99, NALE: 4.99 },
    tier_below_15k: { A: 3.49, B: 3.49, C_D_E: 4.09, NALE: 5.09 },
  },

  expatStl: {
    tier_50k_plus: { A: 2.25, B: 2.75, C_D_E: 2.99, NALE: 3.99 },
    tier_40k_50k: { A: 2.49, B: 2.99, C_D_E: 3.15, NALE: 4.15 },
    tier_25k_40k: { A: 2.79, B: 3.49, C_D_E: 3.75, NALE: 4.75 },
    tier_15k_25k: { A: 3.49, B: 3.69, C_D_E: 3.99, NALE: 4.99 },
    tier_below_15k: { A: 3.59, B: 3.79, C_D_E: 4.29, NALE: 5.29 },
  },

  saudiNstlApprovedMillion: 3.99,
  saudiNstlApproved_25k: 4.69,
  saudiNstlApproved_15k_25k: 5.00,
  saudiNstlApproved_below_15k: 5.69,

  expatNstlApproved_25k: 6.79,
  expatNstlApproved_15k_25k: 6.99,
  expatNstlApproved_below_15k: 7.25,

  saudiNstlNonApproved_25k: 6.54,
  saudiNstlNonApproved_15k_25k: 6.74,
  saudiNstlNonApproved_below_15k: 7.14,

  expatNstlNonApproved_25k: 7.99,
  expatNstlNonApproved_15k_25k: 8.49,
  expatNstlNonApproved_below_15k: 8.99,

  quickDefaultStl: 3.49,
  quickDefaultNstl: 5.69,
};

/**
 * جلب إعدادات نسب التمويل الحالية المحفوظة في المتصفح أو الافتراضية
 */
export function getStoredPersonalFinanceRates(): PersonalFinanceRatesConfig {
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem('sales_crm_personal_finance_rates');
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_PERSONAL_FINANCE_RATES,
          ...parsed,
          saudiStl: {
            ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl,
            ...(parsed.saudiStl || {}),
            tier_50k_plus: { ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl.tier_50k_plus, ...(parsed.saudiStl?.tier_50k_plus || {}) },
            tier_40k_50k: { ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl.tier_40k_50k, ...(parsed.saudiStl?.tier_40k_50k || {}) },
            tier_25k_40k: { ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl.tier_25k_40k, ...(parsed.saudiStl?.tier_25k_40k || {}) },
            tier_15k_25k: { ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl.tier_15k_25k, ...(parsed.saudiStl?.tier_15k_25k || {}) },
            tier_below_15k: { ...DEFAULT_PERSONAL_FINANCE_RATES.saudiStl.tier_below_15k, ...(parsed.saudiStl?.tier_below_15k || {}) },
          },
          expatStl: {
            ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl,
            ...(parsed.expatStl || {}),
            tier_50k_plus: { ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl.tier_50k_plus, ...(parsed.expatStl?.tier_50k_plus || {}) },
            tier_40k_50k: { ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl.tier_40k_50k, ...(parsed.expatStl?.tier_40k_50k || {}) },
            tier_25k_40k: { ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl.tier_25k_40k, ...(parsed.expatStl?.tier_25k_40k || {}) },
            tier_15k_25k: { ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl.tier_15k_25k, ...(parsed.expatStl?.tier_15k_25k || {}) },
            tier_below_15k: { ...DEFAULT_PERSONAL_FINANCE_RATES.expatStl.tier_below_15k, ...(parsed.expatStl?.tier_below_15k || {}) },
          }
        };
      }
    } catch (e) {
      console.error('Failed to parse stored finance rates:', e);
    }
  }
  return DEFAULT_PERSONAL_FINANCE_RATES;
}

/**
 * حفظ وتحديث نسب التمويل وبث حدث الربط الفوري
 */
export function setStoredPersonalFinanceRates(rates: PersonalFinanceRatesConfig): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('sales_crm_personal_finance_rates', JSON.stringify(rates));
      window.dispatchEvent(new CustomEvent('personalFinanceRatesUpdated', { detail: rates }));
    } catch (e) {
      console.error('Failed to save stored finance rates:', e);
    }
  }
}

export interface PersonalFinanceDecisionInput {
  isMilitary: boolean; // 1. هل التمويل عسكري؟
  militaryType?: 'stl' | 'nstl'; // نعم (STL / تحويل): 3.25% ، نعم (NSTL / بدون تحويل): 5.99%

  hasSalaryTransfer?: boolean; // 2. تحويل راتب أم بدون؟

  nationality?: 'saudi' | 'expat'; // سعودي أم مقيم
  companyCategory?: 'A' | 'B' | 'C_D_E' | 'NALE'; // التصنيف (A / B / C-D-E / NALE)
  isApprovedEmployer?: boolean; // هل جهة العمل معتمدة؟

  salary?: number; // الراتب الشهري (لتحديد الشريحة: <15k, 15k-25k, >25k)
  loanAmount?: number; // مبلغ التمويل (لمعرفة هل التمويل ≥ 1,000,000 ر.س)
}

export interface PersonalFinanceDecisionResult {
  rate: number; // نسبة التمويل (%)
  reason: string; // ملخص اتخاذ القرار
  steps: string[]; // تسلسل مسار الشجرة الرقمية
  tierLabel: string; // شريحة الراتب
}

/**
 * حساب نسبة التمويل الشخصي الدقيقة حسب الجدول المعتمد ونسب الإدارة
 */
export function calculatePersonalFinanceRate(
  input: PersonalFinanceDecisionInput,
  ratesConfig?: PersonalFinanceRatesConfig
): PersonalFinanceDecisionResult {
  const cfg = ratesConfig || getStoredPersonalFinanceRates();
  const steps: string[] = [];
  const nationality = input.nationality || 'saudi';
  const salary = input.salary || 0;
  const loanAmount = input.loanAmount || 0;
  const isApproved = input.isApprovedEmployer !== undefined ? input.isApprovedEmployer : true;
  const category = input.companyCategory || 'A';

  // 1. هل التمويل عسكري؟
  if (input.isMilitary) {
    steps.push('1. قطاع التمويل: عسكري 🛡️');
    const isStl = input.militaryType === 'stl' || input.hasSalaryTransfer === true;
    if (isStl) {
      steps.push('└─ تحويل راتب (STL)');
      return {
        rate: cfg.militaryStl,
        reason: `تمويل القطاع العسكري (تحويل راتب STL) - نسبة ${cfg.militaryStl}%`,
        steps,
        tierLabel: 'القطاع العسكري (STL)',
      };
    } else {
      steps.push('└─ بدون تحويل راتب (NSTL)');
      return {
        rate: cfg.militaryNstl,
        reason: `تمويل القطاع العسكري (بدون تحويل راتب NSTL) - نسبة ${cfg.militaryNstl}%`,
        steps,
        tierLabel: 'القطاع العسكري (NSTL)',
      };
    }
  }

  // 2. مدني / قطاع خاص / متقاعدين
  steps.push('1. قطاع التمويل: مدني / قطاع خاص / متقاعدين 👔');
  const hasTransfer = input.hasSalaryTransfer !== undefined ? input.hasSalaryTransfer : true;

  if (hasTransfer) {
    // أ. بتحويل راتب - Salary Assigned
    steps.push('2. نوع الخدمة: بتحويل راتب (Salary Assigned - STL)');
    steps.push(`├─ الجنسية: ${nationality === 'saudi' ? 'سعودي 🇸🇦' : 'مقيم 🌐'}`);
    steps.push(`├─ التصنيف: ${category === 'A' ? 'حكومي/شبه حكومي/متقاعدين/خاص (أ)' : category === 'B' ? 'خاص (ب)' : category === 'C_D_E' ? 'خاص (ج - د - هـ)' : 'غير معتمد NALE'}`);

    let tierLabel = 'أقل من 15,000 ر.س';
    let rate = cfg.quickDefaultStl;

    if (nationality === 'saudi') {
      if (salary >= 50000) {
        tierLabel = '50,000 ر.س فأكثر';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.saudiStl.tier_50k_plus[category];
      } else if (salary >= 40000) {
        tierLabel = 'من 40,000 إلى 49,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.saudiStl.tier_40k_50k[category];
      } else if (salary >= 25000) {
        tierLabel = 'من 25,000 إلى 39,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.saudiStl.tier_25k_40k[category];
      } else if (salary >= 15000) {
        tierLabel = 'من 15,000 إلى 24,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.saudiStl.tier_15k_25k[category];
      } else {
        tierLabel = 'أقل من 15,000 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.saudiStl.tier_below_15k[category];
      }
    } else {
      // مقيم Expat
      if (salary >= 50000) {
        tierLabel = '50,000 ر.س فأكثر';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.expatStl.tier_50k_plus[category];
      } else if (salary >= 40000) {
        tierLabel = 'من 40,000 إلى 49,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.expatStl.tier_40k_50k[category];
      } else if (salary >= 25000) {
        tierLabel = 'من 25,000 إلى 39,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.expatStl.tier_25k_40k[category];
      } else if (salary >= 15000) {
        tierLabel = 'من 15,000 إلى 24,999 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.expatStl.tier_15k_25k[category];
      } else {
        tierLabel = 'أقل من 15,000 ر.س';
        steps.push(`└─ شريحة الراتب: ${tierLabel}`);
        rate = cfg.expatStl.tier_below_15k[category];
      }
    }

    return {
      rate,
      reason: `بتحويل راتب (${nationality === 'saudi' ? 'سعودي' : 'مقيم'}) - تصنيف (${category}) - ${tierLabel}`,
      steps,
      tierLabel,
    };
  } else {
    // ب. بدون تحويل راتب - Non-Salary Assigned
    steps.push('2. نوع الخدمة: بدون تحويل راتب (Non-Salary Assigned - NSTL)');

    if (!isApproved) {
      // جهة غير معتمدة Non-Approved Employer
      steps.push('├─ جهة العمل: غير معتمدة (Non-Approved Employer)');
      steps.push(`├─ الجنسية: ${nationality === 'saudi' ? 'سعودي 🇸🇦' : 'مقيم 🌐'}`);

      let tierLabel = 'أقل من 15,000 ر.س';
      let rate = nationality === 'saudi' ? cfg.saudiNstlNonApproved_below_15k : cfg.expatNstlNonApproved_below_15k;

      if (nationality === 'saudi') {
        if (salary >= 25000) {
          tierLabel = '25,000 ر.س فأكثر';
          rate = cfg.saudiNstlNonApproved_25k;
        } else if (salary >= 15000) {
          tierLabel = 'من 15,000 إلى 24,999 ر.س';
          rate = cfg.saudiNstlNonApproved_15k_25k;
        } else {
          tierLabel = 'أقل من 15,000 ر.س';
          rate = cfg.saudiNstlNonApproved_below_15k;
        }
      } else {
        // Expat
        if (salary >= 25000) {
          tierLabel = '25,000 ر.س فأكثر';
          rate = cfg.expatNstlNonApproved_25k;
        } else if (salary >= 15000) {
          tierLabel = 'من 15,000 إلى 24,999 ر.س';
          rate = cfg.expatNstlNonApproved_15k_25k;
        } else {
          tierLabel = 'أقل من 15,000 ر.س';
          rate = cfg.expatNstlNonApproved_below_15k;
        }
      }

      steps.push(`└─ شريحة الراتب: ${tierLabel}`);

      return {
        rate,
        reason: `بدون تحويل راتب (جهة غير معتمدة) - ${nationality === 'saudi' ? 'سعودي' : 'مقيم'} - ${tierLabel}`,
        steps,
        tierLabel,
      };
    } else {
      // جهة معتمدة Approved Employer
      steps.push('├─ جهة العمل: معتمدة (Approved Employer)');
      steps.push(`├─ الجنسية: ${nationality === 'saudi' ? 'سعودي 🇸🇦' : 'مقيم 🌐'}`);

      if (nationality === 'saudi') {
        if (loanAmount >= 1000000) {
          steps.push('└─ تمويل مليون فأكثر (≥ 1,000,000 ر.س) 🌟');
          return {
            rate: cfg.saudiNstlApprovedMillion,
            reason: `بدون تحويل راتب (سعودي) - تمويل مليوني مميز (${cfg.saudiNstlApprovedMillion}%)`,
            steps,
            tierLabel: 'تمويل مليون فأكثر',
          };
        }

        let tierLabel = 'أقل من 15,000 ر.س';
        let rate = cfg.saudiNstlApproved_below_15k;

        if (salary >= 25000) {
          tierLabel = '25,000 ر.س فأكثر';
          rate = cfg.saudiNstlApproved_25k;
        } else if (salary >= 15000) {
          tierLabel = 'من 15,000 إلى 24,999 ر.س';
          rate = cfg.saudiNstlApproved_15k_25k;
        } else {
          tierLabel = 'أقل من 15,000 ر.س';
          rate = cfg.saudiNstlApproved_below_15k;
        }

        steps.push(`└─ شريحة الراتب: ${tierLabel}`);

        return {
          rate,
          reason: `بدون تحويل راتب (سعودي معتمد) - ${tierLabel}`,
          steps,
          tierLabel,
        };
      } else {
        // Expat Approved
        let tierLabel = 'أقل من 15,000 ر.س';
        let rate = cfg.expatNstlApproved_below_15k;

        if (salary >= 25000) {
          tierLabel = '25,000 ر.س فأكثر';
          rate = cfg.expatNstlApproved_25k;
        } else if (salary >= 15000) {
          tierLabel = 'من 15,000 إلى 24,999 ر.س';
          rate = cfg.expatNstlApproved_15k_25k;
        } else {
          tierLabel = 'أقل من 15,000 ر.س';
          rate = cfg.expatNstlApproved_below_15k;
        }

        steps.push(`└─ شريحة الراتب: ${tierLabel}`);

        return {
          rate,
          reason: `بدون تحويل راتب (مقيم معتمد) - ${tierLabel}`,
          steps,
          tierLabel,
        };
      }
    }
  }
}

/**
 * حساب نسبة الاستقطاع (DBR %) من الراتب
 * @param salary الراتب الشهري (ر.س)
 * @param monthlyInstallment القسط الشهري (ر.س)
 */
export function calculateDbrRate(salary: number, monthlyInstallment: number): number {
  if (!salary || salary <= 0 || !monthlyInstallment || monthlyInstallment <= 0) return 0;
  const rate = (monthlyInstallment / salary) * 100;
  return Math.round(rate * 100) / 100;
}

/**
 * حساب أقصى مبلغ تمويل مسموح وقسط شهري بناءً على سقف الاستقطاع المسموح به
 * @param salary الراتب الشهري (ر.س)
 * @param durationYears مدة التمويل بالسنوات (الافتراضي 5 سنوات - 60 شهراً)
 * @param dbrLimitPercent سقف نسبة الاستقطاع المسموحة (الافتراضي 33.33%)
 * @param profitRatePercent نسبة هامش الربح الإجمالية أو السنوية التقريبية
 */
export function calculateMaxFinancing(
  salary: number,
  durationYears: number = 5,
  dbrLimitPercent: number = 33.33,
  profitRatePercent: number = 2.5
): { maxMonthlyInstallment: number; maxEstimatedLoanAmount: number } {
  if (!salary || salary <= 0) return { maxMonthlyInstallment: 0, maxEstimatedLoanAmount: 0 };

  const maxInstallment = (salary * dbrLimitPercent) / 100;
  const totalMonths = durationYears * 12;
  const totalAmountWithProfit = maxInstallment * totalMonths;
  
  // خصم نسبة هامش الربح التقديرية للوصول لمبلغ التمويل الأصلي
  const totalProfitFactor = 1 + (profitRatePercent * durationYears) / 100;
  const maxLoanAmount = totalAmountWithProfit / totalProfitFactor;

  return {
    maxMonthlyInstallment: Math.round(maxInstallment * 100) / 100,
    maxEstimatedLoanAmount: Math.round(maxLoanAmount),
  };
}

/**
 * حساب التفاصيل الدقيقة للتمويل بحسب المعادلة:
 * - النسبة السنوية تحسب لسنة واحدة فقط (الحد الأقصى 5 سنوات)
 * - إجمالي نسبة المرابحة = النسبة السنوية × عدد السنوات
 * - إجمالي مبلغ المرابحة = مبلغ التمويل × النسبة السنوية × عدد السنوات
 * - مجموع التمويل مع المرابحة = مبلغ التمويل الأصلي + إجمالي مبلغ المرابحة
 * - القسط الشهري = مجموع التمويل مع المرابحة ÷ (عدد السنوات × 12)
 */
export interface DetailedFinancingBreakdown {
  loanAmount: number;
  annualRatePercent: number;
  durationYears: number;
  totalMonths: number;
  totalProfitPercent: number;
  totalProfitAmount: number;
  totalRepaymentAmount: number;
  monthlyInstallment: number;
}

export function calculateDetailedFinancingBreakdown(
  loanAmount: number,
  annualRatePercent: number = 2.5,
  durationYears: number = 5
): DetailedFinancingBreakdown {
  const safeLoan = Math.max(0, loanAmount || 0);
  const safeYears = Math.min(5, Math.max(1, durationYears || 5)); // الحد الأقصى 5 سنوات
  const safeRate = Math.max(0, annualRatePercent || 0);

  const totalMonths = safeYears * 12;
  const totalProfitPercent = safeRate * safeYears;
  const totalProfitAmount = safeLoan * (safeRate / 100) * safeYears;
  const totalRepaymentAmount = safeLoan + totalProfitAmount;
  const monthlyInstallment = totalMonths > 0 ? totalRepaymentAmount / totalMonths : 0;

  return {
    loanAmount: safeLoan,
    annualRatePercent: safeRate,
    durationYears: safeYears,
    totalMonths,
    totalProfitPercent: Math.round(totalProfitPercent * 100) / 100,
    totalProfitAmount: Math.round(totalProfitAmount * 100) / 100,
    totalRepaymentAmount: Math.round(totalRepaymentAmount * 100) / 100,
    monthlyInstallment: Math.round(monthlyInstallment * 100) / 100,
  };
}

/**
 * حساب القسط الشهري التقريبي بناءً على مبلغ التمويل ونسبة التمويل وعدد السنوات
 */
export function calculateMonthlyInstallment(
  loanAmount: number,
  annualRatePercent: number = 2.5,
  durationYears: number = 5
): number {
  return calculateDetailedFinancingBreakdown(loanAmount, annualRatePercent, durationYears).monthlyInstallment;
}

/**
 * حساب نسبة التمويل / الهامش التلقائية بناءً على الراتب والمبلغ القائم
 */
export function calculateFinanceRateFromSalary(
  salary: number,
  loanAmount: number,
  financeType: string = 'salary_transfer',
  ratesConfig?: PersonalFinanceRatesConfig
): number {
  return calculatePersonalFinanceRate({
    isMilitary: false,
    hasSalaryTransfer: financeType === 'salary_transfer',
    salary,
    loanAmount,
  }, ratesConfig).rate;
}

