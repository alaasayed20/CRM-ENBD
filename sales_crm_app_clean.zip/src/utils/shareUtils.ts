import { sanitizePlainText, sanitizeSafeExternalUrl } from './security';

/**
 * Utility functions for generating reliable, validated trial links and WhatsApp invitation messages.
 */

/**
 * Returns the current active Origin of the application.
 */
export function getCurrentAppUrl(): string {
  if (typeof window === 'undefined') return '';
  return window.location.origin.replace(/\/+$/, '');
}

/**
 * Returns the public, accessible Base URL for the application.
 */
export function getPublicBaseAppUrl(): string {
  return getCurrentAppUrl();
}

/**
 * Returns the AI Studio shared preview URL (ais-pre-*) if on an ais-dev-* domain.
 */
export function getAISharedPreviewUrl(): string {
  if (typeof window === 'undefined') return '';
  let origin = window.location.origin;
  if (origin.includes('ais-dev-')) {
    origin = origin.replace('ais-dev-', 'ais-pre-');
  }
  return origin.replace(/\/+$/, '');
}

/**
 * Generates a validated client trial URL (blocks unsafe javascript:/data: custom base URLs).
 */
export function generateTrialLink(
  clientName?: string,
  customBaseUrl?: string,
  useSharedPreview: boolean = false
): string {
  let base = sanitizeSafeExternalUrl(customBaseUrl)?.replace(/\/+$/, '') || '';
  if (!base) {
    base = useSharedPreview ? getAISharedPreviewUrl() : getCurrentAppUrl();
  }
  base = base.replace(/\/+$/, '');
  const safeName = sanitizePlainText(clientName || '', 60) || 'عميل تجريبي';
  const name = encodeURIComponent(safeName);
  return `${base}/?trial=true&clean=true&mode=trial&name=${name}`;
}

/**
 * Generates the bilingual (Arabic & English) WhatsApp invitation message.
 */
export function buildTrialWhatsAppMessage(clientName: string, trialLink: string): string {
  const name = sanitizePlainText(clientName, 60) || 'عزيزي المشترك / Valued Client';
  return `🌟 مرحباً ${name} / Hello ${name} 🌟

يسعدنا دعوتك لتجربة المنظومة الذكية لإدارة ومبيعات التمويل وبطاقات الائتمان (Sales CRM) مجاناً لمدة 14 يوماً! 🚀
You are invited to experience the intelligent Sales CRM application with a 14-Day Free Trial! 🚀

📲 رابط التطبيق للتجربة الفورية والتثبيت / App Access & Installation Link:
${trialLink}

💡 ملاحظة سهلة لفتح الرابط / Quick Tip:
• يُفضل فتح الرابط في متصفح Chrome أو Safari (أو الضغط على "Authenticate in new window" عند ظهورها لأول مرة).
• Open in Chrome or Safari browser for the smoothest experience.

✨ مميزات نسختك الخاصة / Key Features:
• إدارة ومتابعة العملاء والحالات لحظياً / Real-time client & status management
• حساب النقاط والعمولات آلياً / Automated points & commission calculation
• تنبيهات وتذكيرات ذكية للمتابعة / Smart follow-up alerts & reminders
• يعمل كتطبيق مستقل أوفلاين على هاتفك (آيفون وأندرويد) / Works offline on iOS & Android
• خصوصية وأمان تام لبياناتك / 100% private and secure

📞 للدعم الفني والتجديد والاستفسارات / Support & Activation:
0544067585 (WhatsApp / Call)
https://wa.me/966544067585

نتمنى لك كل التوفيق ومبيعات قياسية! 💼📈
Wishing you outstanding sales and great success! 💼📈`;
}
