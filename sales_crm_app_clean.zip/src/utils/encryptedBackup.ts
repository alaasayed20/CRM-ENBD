import { db } from '../db/db';
import { saveOrShareBlob } from './nativeMobile';
import {
  encryptBackupPayload,
  decryptBackupPayload,
  isEncryptedBackup,
  validateAndSanitizeBackupObject,
  isPasswordHashed,
  hashPassword,
  sanitizeDownloadFilename,
  type EncryptedBackupEnvelope,
} from './security';

export type BackupRestoreMode = 'replace' | 'merge';

export interface DatabaseTableCounts {
  customers: number;
  users: number;
  cardTypes: number;
  products: number;
  statuses: number;
  messageTemplates: number;
  settings: number;
  pointsLog: number;
  operationsLog: number;
  tasks: number;
  salaryTiers: number;
}

export interface DatabaseBackupPayload {
  appName: string;
  dbName: string;
  version: string;
  exportDate: string;
  integrityHash: string;
  summary: DatabaseTableCounts;
  customers: any[];
  users: any[];
  cardTypes: any[];
  products: any[];
  statuses: any[];
  messageTemplates: any[];
  settings: any[];
  pointsLog: any[];
  operationsLog: any[];
  tasks: any[];
  salaryTiers: any[];
}

export interface InspectedBackupFile {
  fileName: string;
  fileSize: number;
  isEncrypted: boolean;
  envelope?: EncryptedBackupEnvelope;
  plainRaw?: unknown;
  createdAt?: string;
  iterations?: number;
  format?: string;
}

export interface VerifiedBackupPreview {
  fileName: string;
  wasEncrypted: boolean;
  exportDate?: string;
  version?: string;
  integrityVerified: boolean | null; // null if legacy backup without integrityHash
  tableCounts: DatabaseTableCounts;
  totalRecords: number;
  tables: Record<string, any[]>;
}

export interface PassphraseStrength {
  score: 0 | 1 | 2 | 3 | 4;
  labelAr: string;
  labelEn: string;
  colorClass: string;
}

const MAX_BACKUP_FILE_BYTES = 25 * 1024 * 1024; // 25MB

const TABLE_DATE_FIELDS: Record<string, string[]> = {
  customers: ['createdAt', 'updatedAt', 'lastReminderDismissed', 'activatedAt'],
  users: ['createdAt'],
  cardTypes: ['createdAt'],
  products: ['createdAt'],
  messageTemplates: ['createdAt'],
  operationsLog: ['timestamp'],
  pointsLog: ['timestamp'],
  tasks: ['createdAt', 'completedAt'],
  salaryTiers: ['createdAt'],
};

async function computeSha256Hex(text: string): Promise<string> {
  if (!window.crypto?.subtle) return '';
  const bytes = new TextEncoder().encode(text);
  const digest = await window.crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function hydrateTableDates(tableName: string, rows: any[]): any[] {
  const dateFields = TABLE_DATE_FIELDS[tableName];
  if (!dateFields || !dateFields.length) return rows;

  return rows.map((row) => {
    const copy = { ...row };
    for (const field of dateFields) {
      const value = copy[field];
      if (typeof value === 'string' && value.trim().length > 0) {
        const parsed = new Date(value);
        if (!Number.isNaN(parsed.getTime())) {
          copy[field] = parsed;
        }
      }
    }
    return copy;
  });
}

export async function getDatabaseBackupStats(): Promise<{
  counts: DatabaseTableCounts;
  totalRecords: number;
}> {
  const [
    customers,
    users,
    cardTypes,
    products,
    statuses,
    messageTemplates,
    settings,
    pointsLog,
    operationsLog,
    tasks,
    salaryTiers,
  ] = await Promise.all([
    db.customers.count(),
    db.users.count(),
    db.cardTypes.count(),
    db.products.count(),
    db.statuses.count(),
    db.messageTemplates.count(),
    db.settings.count(),
    db.pointsLog.count(),
    db.operationsLog.count(),
    db.tasks.count(),
    db.salaryTiers.count(),
  ]);

  const counts: DatabaseTableCounts = {
    customers,
    users,
    cardTypes,
    products,
    statuses,
    messageTemplates,
    settings,
    pointsLog,
    operationsLog,
    tasks,
    salaryTiers,
  };

  const totalRecords = Object.values(counts).reduce((sum, n) => sum + n, 0);
  return { counts, totalRecords };
}

export async function collectDatabaseSnapshot(): Promise<DatabaseBackupPayload> {
  const [
    customers,
    rawUsers,
    cardTypes,
    products,
    statuses,
    messageTemplates,
    rawSettings,
    pointsLog,
    operationsLog,
    tasks,
    salaryTiers,
  ] = await Promise.all([
    db.customers.toArray(),
    db.users.toArray(),
    db.cardTypes.toArray(),
    db.products.toArray(),
    db.statuses.toArray(),
    db.messageTemplates.toArray(),
    db.settings.toArray(),
    db.pointsLog.toArray(),
    db.operationsLog.toArray(),
    db.tasks.toArray(),
    db.salaryTiers.toArray(),
  ]);

  // Ensure passwords are never exported in plaintext (PBKDF2 hashes remain intact so login works after restore)
  const users = await Promise.all(
    rawUsers.map(async (u) => {
      if (u.password && !isPasswordHashed(u.password) && u.password !== '[PROTECTED]') {
        return { ...u, password: await hashPassword(String(u.password)) };
      }
      return u;
    })
  );

  // Never include sensitive client-side API key settings
  const settings = rawSettings.filter((s) => s.key !== 'geminiApiKey');

  const tablesBundle = {
    customers,
    users,
    cardTypes,
    products,
    statuses,
    messageTemplates,
    settings,
    pointsLog,
    operationsLog,
    tasks,
    salaryTiers,
  };

  const integrityHash = await computeSha256Hex(JSON.stringify(tablesBundle));

  const summary: DatabaseTableCounts = {
    customers: customers.length,
    users: users.length,
    cardTypes: cardTypes.length,
    products: products.length,
    statuses: statuses.length,
    messageTemplates: messageTemplates.length,
    settings: settings.length,
    pointsLog: pointsLog.length,
    operationsLog: operationsLog.length,
    tasks: tasks.length,
    salaryTiers: salaryTiers.length,
  };

  return {
    appName: 'Sales CRM - Encrypted IndexedDB Backup',
    dbName: 'SalesCRM',
    version: '2.2.0',
    exportDate: new Date().toISOString(),
    integrityHash,
    summary,
    ...tablesBundle,
  };
}

async function triggerJsonFileDownload(content: unknown, fileName: string): Promise<number> {
  const jsonStr = JSON.stringify(content, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
  const safeName = sanitizeDownloadFilename(fileName, 'sales_crm_backup.json');
  await saveOrShareBlob(blob, safeName, {
    title: safeName,
    text: 'Sales CRM Encrypted Database Backup',
    fallbackName: 'sales_crm_backup.json',
  });
  return blob.size;
}

export async function exportDatabaseBackupFile(options: {
  encrypt: boolean;
  passphrase?: string;
}): Promise<{
  fileName: string;
  byteSize: number;
  summary: DatabaseTableCounts;
  totalRecords: number;
}> {
  const snapshot = await collectDatabaseSnapshot();
  const dateStr = new Date().toISOString().split('T')[0];

  let payloadToDownload: unknown = snapshot;
  let fileName = `SalesCRM_Backup_${dateStr}.json`;

  if (options.encrypt) {
    const passphrase = options.passphrase || '';
    if (passphrase.trim().length < 6) {
      throw new Error('PASSPHRASE_TOO_SHORT');
    }
    const envelope = await encryptBackupPayload(snapshot, passphrase);
    payloadToDownload = {
      ...envelope,
      algorithm: 'AES-256-GCM',
      kdf: 'PBKDF2-SHA256',
      dbName: 'SalesCRM',
    };
    fileName = `SalesCRM_Encrypted_${dateStr}.enc.json`;
  }

  const byteSize = await triggerJsonFileDownload(payloadToDownload, fileName);
  const totalRecords = Object.values(snapshot.summary).reduce((sum, n) => sum + n, 0);

  return {
    fileName,
    byteSize,
    summary: snapshot.summary,
    totalRecords,
  };
}

export async function inspectBackupFile(file: File): Promise<InspectedBackupFile> {
  if (file.size > MAX_BACKUP_FILE_BYTES) {
    throw new Error('FILE_TOO_LARGE');
  }
  const text = await file.text();
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('INVALID_JSON');
  }

  if (isEncryptedBackup(parsed)) {
    return {
      fileName: file.name,
      fileSize: file.size,
      isEncrypted: true,
      envelope: parsed,
      createdAt: parsed.createdAt,
      iterations: parsed.iterations,
      format: parsed.format,
    };
  }

  return {
    fileName: file.name,
    fileSize: file.size,
    isEncrypted: false,
    plainRaw: parsed,
    createdAt:
      typeof (parsed as Record<string, unknown>)?.exportDate === 'string'
        ? String((parsed as Record<string, unknown>).exportDate)
        : undefined,
  };
}

async function buildVerifiedPreview(
  rawPayload: unknown,
  fileName: string,
  wasEncrypted: boolean
): Promise<VerifiedBackupPreview> {
  const validation = validateAndSanitizeBackupObject(rawPayload);
  if (!validation.valid || !validation.data) {
    throw new Error('INVALID_SCHEMA');
  }

  const tables = validation.data;
  const rawObj = rawPayload as Record<string, unknown>;

  let integrityVerified: boolean | null = null;
  if (typeof rawObj.integrityHash === 'string' && rawObj.integrityHash.length === 64) {
    const tablesBundle = {
      customers: tables.customers ?? [],
      users: tables.users ?? [],
      cardTypes: tables.cardTypes ?? [],
      products: tables.products ?? [],
      statuses: tables.statuses ?? [],
      messageTemplates: tables.messageTemplates ?? [],
      settings: tables.settings ?? [],
      pointsLog: tables.pointsLog ?? [],
      operationsLog: tables.operationsLog ?? [],
      tasks: tables.tasks ?? [],
      salaryTiers: tables.salaryTiers ?? [],
    };
    const recomputed = await computeSha256Hex(JSON.stringify(tablesBundle));
    integrityVerified = recomputed === rawObj.integrityHash;
  }

  const tableCounts: DatabaseTableCounts = {
    customers: tables.customers?.length ?? 0,
    users: tables.users?.length ?? 0,
    cardTypes: tables.cardTypes?.length ?? 0,
    products: tables.products?.length ?? 0,
    statuses: tables.statuses?.length ?? 0,
    messageTemplates: tables.messageTemplates?.length ?? 0,
    settings: tables.settings?.length ?? 0,
    pointsLog: tables.pointsLog?.length ?? 0,
    operationsLog: tables.operationsLog?.length ?? 0,
    tasks: tables.tasks?.length ?? 0,
    salaryTiers: tables.salaryTiers?.length ?? 0,
  };

  const totalRecords = Object.values(tableCounts).reduce((sum, n) => sum + n, 0);

  return {
    fileName,
    wasEncrypted,
    exportDate: typeof rawObj.exportDate === 'string' ? rawObj.exportDate : undefined,
    version: typeof rawObj.version === 'string' ? rawObj.version : undefined,
    integrityVerified,
    tableCounts,
    totalRecords,
    tables,
  };
}

export async function decryptAndVerifyBackupFile(
  inspected: InspectedBackupFile,
  passphrase?: string
): Promise<VerifiedBackupPreview> {
  if (inspected.isEncrypted) {
    if (!inspected.envelope || !passphrase) {
      throw new Error('MISSING_PASSPHRASE');
    }
    let decrypted: unknown;
    try {
      decrypted = await decryptBackupPayload(inspected.envelope, passphrase);
    } catch {
      throw new Error('DECRYPT_FAILED');
    }
    return buildVerifiedPreview(decrypted, inspected.fileName, true);
  }

  return buildVerifiedPreview(inspected.plainRaw, inspected.fileName, false);
}

export function downloadDecryptedBackupJson(preview: VerifiedBackupPreview): void {
  const dateStr = new Date().toISOString().split('T')[0];
  const output = {
    appName: 'Sales CRM - Decrypted Database Backup',
    dbName: 'SalesCRM',
    version: preview.version || '2.2.0',
    exportDate: preview.exportDate || new Date().toISOString(),
    summary: preview.tableCounts,
    ...preview.tables,
  };
  triggerJsonFileDownload(output, `SalesCRM_Decrypted_${dateStr}.json`);
}

export async function restoreVerifiedBackupToIndexedDB(
  preview: VerifiedBackupPreview,
  mode: BackupRestoreMode
): Promise<{ restoredCustomers: number; totalRestored: number }> {
  const tables = preview.tables;

  const safeSettings = Array.isArray(tables.settings)
    ? tables.settings.filter((s) => s && s.key !== 'geminiApiKey')
    : [];

  // Re-hash any legacy plaintext user passwords; protect against overwriting valid local admins with '[PROTECTED]'
  const existingUsers = await db.users.toArray();
  const existingUsersByName = new Map(existingUsers.map((u) => [u.username.toLowerCase(), u]));

  const hydratedUsers = hydrateTableDates('users', tables.users || []);
  const safeUsers = await Promise.all(
    hydratedUsers.map(async (u) => {
      if (u.password === '[PROTECTED]') {
        const existing = existingUsersByName.get(String(u.username || '').toLowerCase());
        if (existing && isPasswordHashed(existing.password)) {
          return { ...u, password: existing.password };
        }
        return null;
      }
      if (u.password && !isPasswordHashed(u.password)) {
        return { ...u, password: await hashPassword(String(u.password)) };
      }
      return u;
    })
  );
  const validUsers = safeUsers.filter((u): u is NonNullable<typeof u> => Boolean(u && u.username && u.password));
  const hasRestorableAdmin = validUsers.some((u) => u.role === 'admin' && isPasswordHashed(u.password));

  const hydratedCustomers = hydrateTableDates('customers', tables.customers || []);
  const hydratedCardTypes = hydrateTableDates('cardTypes', tables.cardTypes || []);
  const hydratedProducts = hydrateTableDates('products', tables.products || []);
  const hydratedStatuses = tables.statuses || [];
  const hydratedTemplates = hydrateTableDates('messageTemplates', tables.messageTemplates || []);
  const hydratedPointsLog = hydrateTableDates('pointsLog', tables.pointsLog || []);
  const hydratedOperationsLog = hydrateTableDates('operationsLog', tables.operationsLog || []);
  const hydratedTasks = hydrateTableDates('tasks', tables.tasks || []);
  const hydratedSalaryTiers = hydrateTableDates('salaryTiers', tables.salaryTiers || []);

  await db.transaction(
    'rw',
    [
      db.customers,
      db.users,
      db.cardTypes,
      db.products,
      db.statuses,
      db.messageTemplates,
      db.settings,
      db.pointsLog,
      db.operationsLog,
      db.tasks,
      db.salaryTiers,
    ],
    async () => {
      if (mode === 'replace') {
        await db.customers.clear();
        if (hasRestorableAdmin) {
          await db.users.clear();
        }
        await db.cardTypes.clear();
        await db.products.clear();
        await db.statuses.clear();
        await db.messageTemplates.clear();
        await db.settings.clear();
        await db.pointsLog.clear();
        await db.operationsLog.clear();
        await db.tasks.clear();
        await db.salaryTiers.clear();
      }

      if (hydratedCustomers.length) await db.customers.bulkPut(hydratedCustomers);
      if (validUsers.length && (mode === 'merge' || hasRestorableAdmin)) {
        await db.users.bulkPut(validUsers);
      }
      if (hydratedCardTypes.length) await db.cardTypes.bulkPut(hydratedCardTypes);
      if (hydratedProducts.length) await db.products.bulkPut(hydratedProducts);
      if (hydratedStatuses.length) await db.statuses.bulkPut(hydratedStatuses);
      if (hydratedTemplates.length) await db.messageTemplates.bulkPut(hydratedTemplates);
      if (safeSettings.length) await db.settings.bulkPut(safeSettings);
      if (hydratedPointsLog.length) await db.pointsLog.bulkPut(hydratedPointsLog);
      if (hydratedOperationsLog.length) await db.operationsLog.bulkPut(hydratedOperationsLog);
      if (hydratedTasks.length) await db.tasks.bulkPut(hydratedTasks);
      if (hydratedSalaryTiers.length) await db.salaryTiers.bulkPut(hydratedSalaryTiers);
    }
  );

  return {
    restoredCustomers: hydratedCustomers.length,
    totalRestored: preview.totalRecords,
  };
}

export function generateStrongPassphrase(): string {
  const charset = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#';
  const randomBytes = new Uint8Array(16);
  window.crypto.getRandomValues(randomBytes);
  const chars = Array.from(randomBytes, (b) => charset[b % charset.length]);
  return [
    chars.slice(0, 4).join(''),
    chars.slice(4, 8).join(''),
    chars.slice(8, 12).join(''),
    chars.slice(12, 16).join(''),
  ].join('-');
}

export function evaluatePassphraseStrength(passphrase: string): PassphraseStrength {
  if (!passphrase) {
    return { score: 0, labelAr: 'أدخل كلمة مرور', labelEn: 'Enter passphrase', colorClass: 'bg-zinc-700' };
  }
  let score = 0;
  if (passphrase.length >= 6) score += 1;
  if (passphrase.length >= 10) score += 1;
  if (/[A-Z]/.test(passphrase) && /[a-z]/.test(passphrase)) score += 1;
  if (/[0-9]/.test(passphrase) && /[^A-Za-z0-9]/.test(passphrase)) score += 1;

  const clamped = Math.min(4, Math.max(1, score)) as 1 | 2 | 3 | 4;
  switch (clamped) {
    case 1:
      return { score: 1, labelAr: 'ضعيفة', labelEn: 'Weak', colorClass: 'bg-rose-500' };
    case 2:
      return { score: 2, labelAr: 'متوسطة', labelEn: 'Fair', colorClass: 'bg-amber-500' };
    case 3:
      return { score: 3, labelAr: 'قوية', labelEn: 'Strong', colorClass: 'bg-sky-500' };
    case 4:
      return { score: 4, labelAr: 'قوية جداً', labelEn: 'Very Strong', colorClass: 'bg-emerald-500' };
  }
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
