import { sanitizeDownloadFilename } from './security';
import { saveOrShareBlob } from './nativeMobile';

export type PdfAccent = 'cyan' | 'emerald' | 'amber' | 'sky' | 'indigo' | 'slate';

export interface PdfSummaryCard {
  label: string;
  value: string;
  subtext?: string;
  accent?: PdfAccent;
}

export interface PdfColumn {
  label: string;
  align?: 'right' | 'left' | 'center';
  width?: string;
}

export interface PdfCell {
  text: string;
  badgeAccent?: PdfAccent;
  bold?: boolean;
  mono?: boolean;
  dir?: 'ltr' | 'rtl';
}

export interface PdfReportOptions {
  title: string;
  subtitle?: string;
  companyName?: string;
  cycleLabel: string;
  statusLabel: string;
  statusAccent?: PdfAccent;
  totalCountLabel: string;
  totalCountValue: string;
  dir: 'rtl' | 'ltr';
  language: 'ar' | 'en';
  summaryCards?: PdfSummaryCard[];
  columns: PdfColumn[];
  rows: PdfCell[][];
  footerText: string;
  fileName: string;
  orientation?: 'portrait' | 'landscape';
}

const ACCENT_PALETTE: Record<PdfAccent, { bg: string; border: string; text: string; value: string }> = {
  cyan: { bg: '#ecfeff', border: '#a5f3fc', text: '#155e75', value: '#0e7490' },
  emerald: { bg: '#ecfdf5', border: '#a7f3d0', text: '#065f46', value: '#047857' },
  amber: { bg: '#fffbeb', border: '#fde68a', text: '#92400e', value: '#b45309' },
  sky: { bg: '#f0f9ff', border: '#bae6fd', text: '#075985', value: '#0369a1' },
  indigo: { bg: '#eef2ff', border: '#c7d2fe', text: '#3730a3', value: '#4338ca' },
  slate: { bg: '#f8fafc', border: '#cbd5e1', text: '#334155', value: '#0f172a' },
};

function escapeHtml(raw: string): string {
  return String(raw ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function safeAlign(align?: string, fallback: 'right' | 'left' = 'right'): 'right' | 'left' | 'center' {
  if (align === 'left' || align === 'right' || align === 'center') return align;
  return fallback;
}

function safeDir(dir?: string): 'rtl' | 'ltr' {
  return dir === 'ltr' ? 'ltr' : 'rtl';
}

function safeCssWidth(width?: string): string {
  if (!width) return '';
  const trimmed = String(width).trim();
  return /^\d{1,4}(px|%|mm|cm|em|rem)$/.test(trimmed) ? `width:${trimmed};` : '';
}

function chunkRows<T>(rows: T[], firstPageSize: number, nextPageSize: number): T[][] {
  if (rows.length === 0) return [[]];
  const pages: T[][] = [];
  pages.push(rows.slice(0, firstPageSize));
  let offset = firstPageSize;
  while (offset < rows.length) {
    pages.push(rows.slice(offset, offset + nextPageSize));
    offset += nextPageSize;
  }
  return pages;
}

function buildPageHtml(
  opts: PdfReportOptions,
  pageRows: PdfCell[][],
  pageIndex: number,
  totalPages: number,
  pageWidthPx: number,
  pageMinHeightPx: number
): string {
  const pageDirection = safeDir(opts.dir);
  const isRtl = pageDirection === 'rtl';
  const defaultAlign = isRtl ? 'right' : 'left';
  const isFirstPage = pageIndex === 0;
  const statusPalette = ACCENT_PALETTE[opts.statusAccent || 'indigo'] || ACCENT_PALETTE.indigo;
  const generatedDate = new Date().toLocaleString(opts.language === 'ar' ? 'ar-SA' : 'en-US');

  const summaryHtml =
    isFirstPage && opts.summaryCards && opts.summaryCards.length > 0
      ? `
        <div style="display:grid;grid-template-columns:repeat(${Math.min(opts.summaryCards.length, 4)}, minmax(0, 1fr));gap:10px;margin-bottom:16px;">
          ${opts.summaryCards
            .map((card) => {
              const p = ACCENT_PALETTE[card.accent || 'slate'] || ACCENT_PALETTE.slate;
              return `
                <div style="background:${p.bg};border:1px solid ${p.border};border-radius:10px;padding:10px 12px;text-align:center;">
                  <div style="font-size:11px;font-weight:700;color:${p.text};margin-bottom:4px;">${escapeHtml(card.label)}</div>
                  <div style="font-size:17px;font-weight:900;color:${p.value};line-height:1.2;">${escapeHtml(card.value)}</div>
                  ${card.subtext ? `<div style="font-size:10px;color:${p.text};opacity:0.85;margin-top:3px;">${escapeHtml(card.subtext)}</div>` : ''}
                </div>
              `;
            })
            .join('')}
        </div>
      `
      : '';

  const headerHtml = isFirstPage
    ? `
      <div style="display:flex;align-items:flex-start;justify-content:space-between;border-bottom:2.5px solid #0284c7;padding-bottom:12px;margin-bottom:14px;gap:16px;">
        <div style="text-align:${defaultAlign};flex:1;">
          <div style="font-size:11px;font-weight:800;color:#0284c7;letter-spacing:0.06em;text-transform:uppercase;">
            ${escapeHtml(opts.companyName || 'SALES CRM SYSTEM')}
          </div>
          <h1 style="margin:4px 0 6px;font-size:20px;font-weight:900;color:#0f172a;line-height:1.3;">
            ${escapeHtml(opts.title)}
          </h1>
          <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:11px;color:#475569;">
            <span><strong>${opts.language === 'ar' ? 'الدورة:' : 'Cycle:'}</strong> ${escapeHtml(opts.cycleLabel)}</span>
            <span style="color:#cbd5e1;">|</span>
            <span style="display:inline-block;padding:2px 8px;border-radius:6px;background:${statusPalette.bg};border:1px solid ${statusPalette.border};color:${statusPalette.text};font-weight:800;">
              ${opts.language === 'ar' ? 'الحالة:' : 'Status:'} ${escapeHtml(opts.statusLabel)}
            </span>
            <span style="color:#cbd5e1;">|</span>
            <span><strong>${opts.language === 'ar' ? 'تاريخ الاستخراج:' : 'Generated:'}</strong> ${escapeHtml(generatedDate)}</span>
          </div>
          ${opts.subtitle ? `<div style="font-size:11px;color:#64748b;margin-top:4px;">${escapeHtml(opts.subtitle)}</div>` : ''}
        </div>
        <div style="background:#f0f9ff;border:1.5px solid #bae6fd;border-radius:12px;padding:10px 16px;text-align:center;min-width:110px;">
          <div style="font-size:10px;font-weight:700;color:#0369a1;">${escapeHtml(opts.totalCountLabel)}</div>
          <div style="font-size:22px;font-weight:900;color:#0c4a6e;line-height:1.25;">${escapeHtml(opts.totalCountValue)}</div>
        </div>
      </div>
    `
    : `
      <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #0284c7;padding-bottom:8px;margin-bottom:12px;">
        <div style="font-size:14px;font-weight:800;color:#0f172a;">
          ${escapeHtml(opts.title)} — <span style="color:#0369a1;">${escapeHtml(opts.statusLabel)}</span>
        </div>
        <div style="font-size:11px;font-weight:700;color:#64748b;">
          ${escapeHtml(opts.cycleLabel)}
        </div>
      </div>
    `;

  const theadHtml = `
    <thead>
      <tr style="background:#0f172a;color:#ffffff;">
        ${opts.columns
          .map(
            (col) => `
              <th style="padding:8px 7px;border:1px solid #334155;text-align:${safeAlign(col.align, defaultAlign)};font-size:11px;font-weight:800;white-space:nowrap;${safeCssWidth(col.width)}">
                ${escapeHtml(col.label)}
              </th>
            `
          )
          .join('')}
      </tr>
    </thead>
  `;

  const tbodyHtml =
    pageRows.length === 0
      ? `
        <tbody>
          <tr>
            <td colspan="${opts.columns.length}" style="padding:28px;text-align:center;border:1px solid #e2e8f0;color:#64748b;font-size:13px;font-weight:600;">
              ${opts.language === 'ar' ? 'لا توجد سجلات مطابقة لهذا الفلتر' : 'No records matching this filter'}
            </td>
          </tr>
        </tbody>
      `
      : `
        <tbody>
          ${pageRows
            .map((row, rIdx) => {
              const rowBg = rIdx % 2 === 0 ? '#ffffff' : '#f8fafc';
              return `
                <tr style="background:${rowBg};">
                  ${row
                    .map((cell, cIdx) => {
                      const align = safeAlign(opts.columns[cIdx]?.align, defaultAlign);
                      const fontFamily = cell.mono
                        ? `'Tajawal', ui-monospace, SFMono-Regular, Menlo, monospace`
                        : `'Tajawal', -apple-system, BlinkMacSystemFont, sans-serif`;
                      const fontWeight = cell.bold ? '800' : '500';
                      const directionStyle = cell.dir ? `direction:${safeDir(cell.dir)};unicode-bidi:embed;` : '';

                      let innerContent = escapeHtml(cell.text);
                      if (cell.badgeAccent) {
                        const bp = ACCENT_PALETTE[cell.badgeAccent] || ACCENT_PALETTE.slate;
                        innerContent = `<span style="display:inline-block;padding:2px 8px;border-radius:6px;background:${bp.bg};border:1px solid ${bp.border};color:${bp.text};font-weight:800;font-size:10px;white-space:nowrap;">${innerContent}</span>`;
                      }

                      return `
                        <td style="padding:7px 7px;border:1px solid #cbd5e1;text-align:${align};font-size:11px;color:#0f172a;font-weight:${fontWeight};font-family:${fontFamily};vertical-align:middle;line-height:1.4;word-break:break-word;${directionStyle}">
                          ${innerContent}
                        </td>
                      `;
                    })
                    .join('')}
                </tr>
              `;
            })
            .join('')}
        </tbody>
      `;

  const pageLabel =
    opts.language === 'ar'
      ? `صفحة ${pageIndex + 1} من ${totalPages}`
      : `Page ${pageIndex + 1} of ${totalPages}`;

  return `
    <div style="width:${pageWidthPx}px;min-height:${pageMinHeightPx}px;box-sizing:border-box;padding:26px 28px;background:#ffffff;color:#0f172a;direction:${pageDirection};font-family:'Tajawal', -apple-system, BlinkMacSystemFont, sans-serif;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        ${headerHtml}
        ${summaryHtml}
        <table style="width:100%;border-collapse:collapse;table-layout:auto;">
          ${theadHtml}
          ${tbodyHtml}
        </table>
      </div>
      <div style="margin-top:16px;padding-top:10px;border-top:1px solid #cbd5e1;display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#64748b;">
        <span>${escapeHtml(opts.footerText)}</span>
        <span style="font-weight:800;color:#334155;">${escapeHtml(pageLabel)}</span>
      </div>
    </div>
  `;
}

/**
 * Generates and downloads a print-ready, RTL-safe multi-page A4 PDF directly inside the app.
 */
export async function exportReportToPDF(opts: PdfReportOptions): Promise<void> {
  if (typeof document !== 'undefined' && document.fonts?.ready) {
    try {
      await document.fonts.ready;
    } catch {
      // Proceed even if font readiness rejects
    }
  }

  const orientation = opts.orientation || (opts.columns.length >= 7 ? 'landscape' : 'portrait');
  const isLandscape = orientation === 'landscape';

  // Exact A4 proportions at 96 DPI
  const pageWidthPx = isLandscape ? 1122 : 794;
  const pageMinHeightPx = isLandscape ? 793 : 1123;

  // Conservative row counts per page so tables stay crisp and never clip
  const hasSummary = Boolean(opts.summaryCards && opts.summaryCards.length > 0);
  const firstPageRows = isLandscape ? (hasSummary ? 10 : 12) : (hasSummary ? 16 : 20);
  const nextPageRows = isLandscape ? 14 : 24;

  const rowChunks = chunkRows(opts.rows, firstPageRows, nextPageRows);

  const [{ jsPDF }, { default: html2canvas }] = await Promise.all([
    import('jspdf'),
    import('html2canvas-pro'),
  ]);

  const pdf = new jsPDF({
    orientation,
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const pdfPageWidth = pdf.internal.pageSize.getWidth();
  const pdfPageHeight = pdf.internal.pageSize.getHeight();

  // Isolated offscreen mount container
  const mount = document.createElement('div');
  mount.style.position = 'fixed';
  mount.style.left = '-10000px';
  mount.style.top = '0';
  mount.style.zIndex = '-1';
  mount.style.background = '#ffffff';
  mount.style.pointerEvents = 'none';
  document.body.appendChild(mount);

  try {
    for (let i = 0; i < rowChunks.length; i++) {
      mount.innerHTML = buildPageHtml(opts, rowChunks[i], i, rowChunks.length, pageWidthPx, pageMinHeightPx);
      const pageEl = mount.firstElementChild as HTMLElement;

      const canvas = await html2canvas(pageEl, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
        windowWidth: pageWidthPx,
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      const imgRatio = canvas.height / canvas.width;

      let renderWidth = pdfPageWidth;
      let renderHeight = renderWidth * imgRatio;

      // If long notes expanded the page height slightly beyond A4 height, fit cleanly within page bounds
      if (renderHeight > pdfPageHeight) {
        renderHeight = pdfPageHeight;
        renderWidth = renderHeight / imgRatio;
      }

      const xOffset = (pdfPageWidth - renderWidth) / 2;

      if (i > 0) {
        pdf.addPage('a4', orientation);
      }

      pdf.addImage(imgData, 'JPEG', xOffset, 0, renderWidth, renderHeight, undefined, 'FAST');
    }

    const cleanedName = sanitizeDownloadFilename(opts.fileName, 'sales-crm-report');
    const safeFileName = cleanedName.endsWith('.pdf') ? cleanedName : `${cleanedName}.pdf`;
    const pdfBlob = pdf.output('blob');
    await saveOrShareBlob(pdfBlob, safeFileName, {
      title: opts.title,
      text: opts.title,
      fallbackName: 'sales-crm-report.pdf',
    });
  } finally {
    if (mount.parentNode) {
      mount.parentNode.removeChild(mount);
    }
  }
}
