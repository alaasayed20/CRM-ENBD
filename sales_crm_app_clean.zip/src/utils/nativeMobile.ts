import { Capacitor } from '@capacitor/core';
import { sanitizeDownloadFilename } from './security';

/**
 * Returns true when running inside a compiled native Android/iOS Capacitor APK/IPA shell.
 */
export function isNativeCapacitor(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

export function isNativeAndroid(): boolean {
  try {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

let runtimeInitialized = false;

/**
 * Initializes native Android StatusBar styling and hardware Back button routing.
 * Safe no-op on standard web browsers.
 */
export async function initNativeAndroidRuntime(): Promise<void> {
  if (runtimeInitialized || !isNativeCapacitor()) return;
  runtimeInitialized = true;

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setStyle({ style: Style.Dark });
    if (isNativeAndroid()) {
      await StatusBar.setBackgroundColor({ color: '#070e1c' });
      await StatusBar.setOverlaysWebView({ overlay: false });
    }
  } catch {
    // Ignore if StatusBar plugin is unavailable on current host
  }

  try {
    const { App } = await import('@capacitor/app');
    await App.addListener('backButton', ({ canGoBack }) => {
      const event = new CustomEvent('native-back-button', {
        cancelable: true,
        detail: { canGoBack },
      });
      window.dispatchEvent(event);

      if (!event.defaultPrevented) {
        if (canGoBack) {
          window.history.back();
        } else {
          App.minimizeApp().catch(() => {});
        }
      }
    });
  } catch {
    // Ignore if App plugin is unavailable
  }
}

async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to encode file for native export'));
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIndex = result.indexOf(',');
      resolve(commaIndex >= 0 ? result.slice(commaIndex + 1) : result);
    };
    reader.readAsDataURL(blob);
  });
}

/**
 * Saves or shares a Blob cleanly on both Web browsers and Native Android/iOS APK shells.
 * Inside Android WebView, `<a download>` often silently fails — this writes to native
 * Filesystem and opens Android's native Share/Save sheet instead.
 */
export async function saveOrShareBlob(
  blob: Blob,
  fileName: string,
  options?: { title?: string; text?: string; fallbackName?: string }
): Promise<void> {
  const safeName = sanitizeDownloadFilename(fileName, options?.fallbackName || 'sales-crm-export');

  if (isNativeCapacitor()) {
    const { Filesystem, Directory } = await import('@capacitor/filesystem');
    const base64Data = await blobToBase64(blob);

    // Save into Cache first so Android Share sheet can read it via FileProvider URI
    const written = await Filesystem.writeFile({
      path: safeName,
      data: base64Data,
      directory: Directory.Cache,
      recursive: true,
    });

    try {
      const { Share } = await import('@capacitor/share');
      await Share.share({
        title: options?.title || safeName,
        text: options?.text || safeName,
        url: written.uri,
        dialogTitle: options?.title || safeName,
      });
      return;
    } catch {
      // If share sheet is dismissed or unavailable, persist a copy to Documents
      await Filesystem.writeFile({
        path: `SalesCRM/${safeName}`,
        data: base64Data,
        directory: Directory.Documents,
        recursive: true,
      });
      return;
    }
  }

  // Standard Web browser download
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

/**
 * Exports a SheetJS (XLSX) workbook cleanly on both Web and Native Android APK.
 */
export async function saveWorkbookNativeOrWeb(
  XLSX: typeof import('xlsx'),
  workbook: import('xlsx').WorkBook,
  fileName: string,
  title?: string
): Promise<void> {
  const safeName = sanitizeDownloadFilename(
    fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`,
    'sales-crm-report.xlsx'
  );

  if (isNativeCapacitor()) {
    const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([wbout], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    await saveOrShareBlob(blob, safeName, {
      title: title || safeName,
      text: title || safeName,
      fallbackName: 'sales-crm-report.xlsx',
    });
    return;
  }

  XLSX.writeFile(workbook, safeName);
}
