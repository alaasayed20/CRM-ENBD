import type { Customer } from '../types';
import { saveOrShareBlob } from './nativeMobile';
import { cleanPhoneString } from '../context/LanguageContext';

/**
 * Decodes Quoted-Printable strings (e.g. =D8=A3=D8=AD=D9=85=D8=AF)
 */
function decodeQuotedPrintable(str: string): string {
  try {
    const hexClean = str.replace(/=[\r\n]+/g, '').replace(/=/g, '%');
    return decodeURIComponent(hexClean);
  } catch {
    return str.replace(/=/g, '');
  }
}

/**
 * Unfolds vCard multi-line extensions (lines beginning with space or tab)
 */
function unfoldVCard(vcfText: string): string {
  return vcfText.replace(/\r?\n[ \t]/g, '');
}

/**
 * Helper to generate vCard 3.0 string compatible with Samsung Galaxy S24 Ultra & Android Contacts (.vcf)
 */
export async function exportCustomersToVCF(customers: Customer[], filename = 'samsung_contacts_crm.vcf') {
  if (!customers || customers.length === 0) {
    throw new Error('لا يوجد عملاء لتصديرهم');
  }

  let vcfContent = '';

  customers.forEach((c) => {
    const cleanPhone = cleanPhoneString(c.phone);
    const cleanName = (c.name || '').trim();
    const cleanEmail = (c.email || '').trim();
    const idNoStr = c.idNumber ? `رقم الهوية: ${c.idNumber}` : '';
    const orderNo = c.orderNumber || '';
    const prodType = c.productType === 'visa' ? 'بطاقة فيزا' : 'تمويل شخصي/عقاري';
    const statusStr = c.status || 'متابعة';
    const salaryStr = c.salary ? `الراتب: ${c.salary}` : '';
    const amountStr = c.amount ? `المبلغ: ${c.amount}` : '';
    const pointsStr = c.points ? `النقاط: ${c.points}` : '';
    const notesStr = c.notes ? `ملاحظات: ${c.notes}` : '';

    const noteLine = [
      idNoStr,
      `رقم الطلب: #${orderNo}`,
      `نوع الخدمة: ${prodType}`,
      `الحالة: ${statusStr}`,
      salaryStr,
      amountStr,
      pointsStr,
      notesStr
    ].filter(Boolean).join(' | ');

    vcfContent += 'BEGIN:VCARD\r\n';
    vcfContent += 'VERSION:3.0\r\n';
    vcfContent += `FN;CHARSET=UTF-8:${cleanName}\r\n`;
    vcfContent += `N;CHARSET=UTF-8:${cleanName};;;;\r\n`;
    vcfContent += `TEL;TYPE=CELL,VOICE:${cleanPhone}\r\n`;
    if (cleanEmail) {
      vcfContent += `EMAIL;TYPE=INTERNET:${cleanEmail}\r\n`;
    }
    vcfContent += `NOTE;CHARSET=UTF-8:${noteLine}\r\n`;
    vcfContent += 'END:VCARD\r\n';
  });

  const blob = new Blob([vcfContent], { type: 'text/vcard;charset=utf-8;' });

  // If running on mobile (Samsung / Android) and Web Share API is available with file sharing, trigger native share sheet!
  if (typeof navigator !== 'undefined' && typeof File !== 'undefined' && navigator.canShare) {
    try {
      const file = new File([blob], filename, { type: 'text/vcard;charset=utf-8;' });
      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'جهات اتصال العملاء (VCF)',
          text: 'ملف جهات اتصال العملاء لنظام Sales CRM'
        });
        return;
      }
    } catch (e: any) {
      if (e.name === 'AbortError') return;
      console.warn('Native share failed, falling back to download:', e);
    }
  }

  // Fallback / Native Capacitor export (Android Share & Filesystem or browser download)
  await saveOrShareBlob(blob, filename, {
    title: 'جهات اتصال العملاء (VCF)',
    text: 'ملف جهات اتصال العملاء لنظام Sales CRM',
    fallbackName: 'contacts.vcf',
  });
}

/**
 * Helper to extract salary, card type name, and amount from unstructured text (vCard NOTE/ORG, etc.)
 */
export function extractSalaryAndCardFromText(text: string): {
  salary?: number;
  amount?: number;
  cardTypeName?: string;
  status?: string;
  productType?: 'visa' | 'finance';
  orderNumber?: string;
  idNumber?: string;
} {
  if (!text) return {};
  let salary: number | undefined;
  let amount: number | undefined;
  let cardTypeName: string | undefined;
  let status: string | undefined;
  let productType: 'visa' | 'finance' | undefined;
  let orderNumber: string | undefined;
  let idNumber: string | undefined;

  // 0. Extract Customer File Number / Order Number & National ID if present in vCard NOTE
  const fileNoMatch = text.match(/(?:رقم\s*ملف\s*العميل|رقم\s*الملف|ملف\s*العميل|رقم\s*الطلب|file\s*(?:no|number|id)|cif|order\s*(?:no|number))\s*[:=#]?\s*([A-Za-z0-9\-_/]+)/i);
  if (fileNoMatch && fileNoMatch[1]) {
    orderNumber = fileNoMatch[1].replace(/^#/, '').trim();
  }
  const idMatch = text.match(/(?:رقم\s*الهوية|الهوية\s*الوطنية|الهوية|الإقامة|national\s*id|iqama)\s*[:=#]?\s*(\d{8,14})/i);
  if (idMatch && idMatch[1]) {
    idNumber = idMatch[1].trim();
  }

  // 1. Extract Salary: "الراتب: 15000", "الراتب 15000", "Salary: 15000", "ssalary: 15000", "15000 ر.س"
  const salaryMatch = text.match(/(?:الراتب|salary|ssalary|دخل)\s*[:=]?\s*([\d,.]+)/i) || text.match(/([\d,.]+)\s*(?:ر\.س|ريال|SAR)/i);
  if (salaryMatch) {
    const val = parseFloat(salaryMatch[1].replace(/,/g, ''));
    if (!isNaN(val) && val >= 1000 && val <= 1000000) {
      salary = val;
    }
  }

  // 2. Extract Amount: "المبلغ: 180000", "Amount: 180000"
  const amountMatch = text.match(/(?:المبلغ|amount|مبلغ)\s*[:=]?\s*([\d,.]+)/i);
  if (amountMatch) {
    const val = parseFloat(amountMatch[1].replace(/,/g, ''));
    if (!isNaN(val) && val >= 5000) {
      amount = val;
    }
  }

  // 3. Extract Card Type: Visa Infinite, Visa Platinum, Visa Mazeed, Visa Signature, Infinite, Platinum, بلاتينيوم, إنفينيت, مزيد, رحالة, فرسان
  const cardPatterns = [
    /visa\s+infinite/i, /visa\s+platinum/i, /visa\s+mazeed/i, /visa\s+signature/i,
    /visa\s+rahala/i, /visa\s+fursan/i, /infinite/i, /platinum/i, /mazeed/i, /signature/i,
    /إنفينيت/, /انفينيت/, /بلاتينيوم/, /بلاتينوم/, /مزيد/, /سيجنتشر/, /سغنتشر/, /رحالة/, /رحاله/, /فرسان/
  ];
  for (const pattern of cardPatterns) {
    const match = text.match(pattern);
    if (match) {
      cardTypeName = match[0].trim();
      break;
    }
  }

  // 4. Extract Product Type
  if (text.includes('تمويل') || text.toLowerCase().includes('finance')) {
    productType = 'finance';
  } else if (text.includes('فيزا') || text.toLowerCase().includes('visa') || cardTypeName) {
    productType = 'visa';
  }

  return { salary, amount, cardTypeName, status, productType, orderNumber, idNumber };
}

/**
 * Parses vCard (.vcf) text from Samsung Contacts, Google Contacts, or Android export
 */
export function parseVCFToCustomers(vcfText: string): (Partial<Customer> & { cardTypeName?: string })[] {
  if (!vcfText || typeof vcfText !== 'string') return [];

  const unfoldedText = unfoldVCard(vcfText);
  const cards = unfoldedText.split(/END:VCARD/i);
  const parsedCustomers: (Partial<Customer> & { cardTypeName?: string })[] = [];

  cards.forEach((card) => {
    if (!card.includes('BEGIN:VCARD')) return;

    let name = '';
    let phone = '';
    let email = '';
    let notes = '';
    let organization = '';

    const lines = card.split(/\r?\n/);
    lines.forEach((line) => {
      const trimmed = line.trim();
      if (!trimmed) return;

      const colonIdx = trimmed.indexOf(':');
      if (colonIdx === -1) return;

      const keyPart = trimmed.substring(0, colonIdx).toUpperCase();
      let valPart = trimmed.substring(colonIdx + 1).trim();

      const isQuotedPrintable = keyPart.includes('QUOTED-PRINTABLE');
      if (isQuotedPrintable) {
        valPart = decodeQuotedPrintable(valPart);
      }

      // Extract Name (FN or N)
      if (keyPart.startsWith('FN') && !name) {
        name = valPart.trim();
      } else if ((keyPart.startsWith('N;') || keyPart.startsWith('N:')) && !name) {
        const nameParts = valPart.split(';').filter(Boolean);
        // N is Surname;GivenName;Additional;Prefix;Suffix
        name = nameParts.reverse().join(' ').trim();
      }

      // Extract Organization
      if (keyPart.startsWith('ORG')) {
        organization = valPart.replace(/;/g, ' ').trim();
      }

      // Extract TEL
      if (keyPart.startsWith('TEL')) {
        const rawPhone = cleanPhoneString(valPart);
        if (rawPhone) {
          if (!phone) {
            phone = rawPhone;
          }
        }
      }

      // Extract EMAIL
      if (keyPart.startsWith('EMAIL') && !email) {
        email = valPart.trim();
      }

      // Extract NOTE
      if (keyPart.startsWith('NOTE')) {
        notes = (notes ? notes + ' | ' : '') + valPart.trim();
      }
    });

    if (organization && notes && !notes.includes(organization)) {
      notes = `الجهة: ${organization} | ${notes}`;
    } else if (organization && !notes) {
      notes = `الجهة: ${organization}`;
    }

    if (name || phone || email) {
      const extraExtracted = extractSalaryAndCardFromText(`${notes} ${organization}`);

      parsedCustomers.push({
        name: name || phone || 'عميل مستورد',
        phone: phone || '0500000000',
        idNumber: extraExtracted.idNumber || undefined,
        email: email || undefined,
        salary: extraExtracted.salary,
        amount: extraExtracted.amount,
        cardTypeName: extraExtracted.cardTypeName,
        notes: notes || undefined,
        status: (extraExtracted.status as any) || 'عميل محتمل',
        productType: extraExtracted.productType || 'visa',
        orderNumber: extraExtracted.orderNumber || `VCF-${Math.floor(100000 + Math.random() * 900000)}`,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }
  });

  // Fallback: If VCF parser produced nothing, try parsing as CSV/Text
  if (parsedCustomers.length === 0) {
    return parseCSVToCustomers(vcfText);
  }

  return parsedCustomers;
}

export type ParsedImportCustomer = Partial<Customer> & {
  cardTypeName?: string;
  hasNotesFromFile?: boolean;
};

export interface CSVParseResult {
  customers: ParsedImportCustomer[];
  detectedNotesColumn: boolean;
  notesColumnNames: string[];
  customersWithNotesCount: number;
  detectedFileNumberColumn: boolean;
  fileNumberColumnName: string | null;
  customersWithFileNumberCount: number;
  delimiter: string;
}

/**
 * Reads an uploaded CSV/VCF/TXT file safely with UTF-8 first and automatic Windows-1256 (Arabic Excel ANSI) fallback
 */
export async function readImportFileText(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const utf8Text = new TextDecoder('utf-8', { fatal: false }).decode(buffer);

  // If UTF-8 produced replacement characters (common in Arabic Windows-1256 CSV exported by Excel), fallback to windows-1256
  if (utf8Text.includes('\uFFFD')) {
    try {
      const win1256Text = new TextDecoder('windows-1256', { fatal: false }).decode(buffer);
      if (win1256Text && !win1256Text.includes('\uFFFD')) {
        return win1256Text;
      }
    } catch {
      // Ignore if environment lacks windows-1256 decoder
    }
  }

  return utf8Text;
}

/**
 * Normalizes CSV header labels (Arabic & English) for accurate column detection
 */
function normalizeCSVHeader(header: string): string {
  return header
    .replace(/^\uFEFF/, '')
    .replace(/^["']|["']$/g, '')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '') // Strip Arabic diacritics & tatweel
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .toLowerCase()
    .replace(/[\s_.\-():/\\]+/g, '');
}

/**
 * Detects the most likely CSV delimiter (comma, semicolon, or tab) outside of quoted strings
 */
function detectCSVDelimiter(text: string): string {
  let commaCount = 0;
  let semiCount = 0;
  let tabCount = 0;
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (inQuotes && text[i + 1] === '"') {
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (!inQuotes) {
      if (ch === '\n' || ch === '\r') break;
      if (ch === ',') commaCount++;
      else if (ch === ';') semiCount++;
      else if (ch === '\t') tabCount++;
    }
  }

  if (tabCount >= commaCount && tabCount >= semiCount && tabCount > 0) return '\t';
  if (semiCount > commaCount) return ';';
  return ',';
}

/**
 * Quote-aware RFC-4180 CSV parser supporting commas, semicolons, escaped quotes, and multiline notes
 */
function parseCSVRows(text: string, delimiter: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentCell = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (ch === '"') {
        if (next === '"') {
          currentCell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        currentCell += ch;
      }
    } else {
      if (ch === '"' && currentCell.trim() === '') {
        inQuotes = true;
      } else if (ch === delimiter) {
        currentRow.push(currentCell.trim());
        currentCell = '';
      } else if (ch === '\r' && next === '\n') {
        currentRow.push(currentCell.trim());
        if (currentRow.some((c) => c !== '')) rows.push(currentRow);
        currentRow = [];
        currentCell = '';
        i++;
      } else if (ch === '\n' || ch === '\r') {
        currentRow.push(currentCell.trim());
        if (currentRow.some((c) => c !== '')) rows.push(currentRow);
        currentRow = [];
        currentCell = '';
      } else {
        currentCell += ch;
      }
    }
  }

  if (currentCell !== '' || currentRow.length > 0) {
    currentRow.push(currentCell.trim());
    if (currentRow.some((c) => c !== '')) rows.push(currentRow);
  }

  return rows;
}

/**
 * Parses CSV, TSV, or Excel exported text into Customer objects with full Notes column metadata
 */
export function parseCSVWithMetadata(text: string): CSVParseResult {
  const emptyResult = (delimiter = ','): CSVParseResult => ({
    customers: [],
    detectedNotesColumn: false,
    notesColumnNames: [],
    customersWithNotesCount: 0,
    detectedFileNumberColumn: false,
    fileNumberColumnName: null,
    customersWithFileNumberCount: 0,
    delimiter,
  });

  if (!text || typeof text !== 'string') {
    return emptyResult(',');
  }

  // Clean UTF-8 BOM
  let cleanText = text.replace(/^\uFEFF/, '').trim();
  if (!cleanText) {
    return emptyResult(',');
  }

  // Handle optional Excel `sep=,` or `sep=;` directive on line 1
  let forcedDelimiter: string | null = null;
  const sepMatch = cleanText.match(/^sep=([,;\t])\r?\n/i);
  if (sepMatch) {
    forcedDelimiter = sepMatch[1];
    cleanText = cleanText.slice(sepMatch[0].length).trim();
  }

  const delimiter = forcedDelimiter || detectCSVDelimiter(cleanText);
  const rows = parseCSVRows(cleanText, delimiter);
  if (rows.length === 0) {
    return emptyResult(delimiter);
  }

  const results: ParsedImportCustomer[] = [];

  // Analyze header row
  const firstCells = rows[0].map((c) => c.replace(/^["']|["']$/g, '').trim());

  let nameColIdx = -1;
  let phoneColIdx = -1;
  let idColIdx = -1;
  let orderColIdx = -1;
  let fileNumberColumnName: string | null = null;
  let visaColIdx = -1;
  let salaryColIdx = -1;
  let amountColIdx = -1;
  let emailColIdx = -1;
  let statusColIdx = -1;
  let monthColIdx = -1;
  const notesColIndices: number[] = [];
  const notesColumnNames: string[] = [];
  let productTypeColIdx = -1;

  let hasHeader = false;

  firstCells.forEach((rawCell, idx) => {
    const c = normalizeCSVHeader(rawCell);
    if (!c) return;

    if (
      c.includes('note') ||
      c.includes('comment') ||
      c.includes('remark') ||
      c.includes('desc') ||
      c.includes('detail') ||
      c.includes('memo') ||
      c.includes('feedback') ||
      c.includes('ملاحظ') ||
      c.includes('ملاحض') ||
      c.includes('ملحوظ') ||
      c.includes('تعليق') ||
      c.includes('تفاصيل') ||
      c.includes('وصف') ||
      c.includes('بيان') ||
      c.includes('سبب')
    ) {
      notesColIndices.push(idx);
      notesColumnNames.push(rawCell);
      hasHeader = true;
    } else if (
      // Match Customer File Number / CIF / Order Number BEFORE generic name/phone/id columns
      c === 'file' ||
      c === 'cif' ||
      c === 'ref' ||
      c === 'order' ||
      c.includes('fileno') ||
      c.includes('filenum') ||
      c.includes('fileid') ||
      c.includes('filecode') ||
      c.includes('cifno') ||
      c.includes('cifnum') ||
      c.includes('customerfile') ||
      c.includes('clientfile') ||
      c.includes('customerid') ||
      c.includes('customerno') ||
      c.includes('custid') ||
      c.includes('custno') ||
      c.includes('clientid') ||
      c.includes('clientno') ||
      c.includes('accountno') ||
      c.includes('accountnum') ||
      c.includes('ordernumber') ||
      c.includes('orderno') ||
      c.includes('refno') ||
      c.includes('refnum') ||
      c.includes('reference') ||
      c.includes('رقمملف') ||
      c.includes('رقمالملف') ||
      c.includes('ملفالعميل') ||
      c.includes('ملفعميل') ||
      c === 'الملف' ||
      c === 'ملف' ||
      c.includes('رقمطلب') ||
      c.includes('رقمالطلب') ||
      c.includes('رقمالعميل') ||
      c.includes('رقمعميل') ||
      c.includes('كودالعميل') ||
      c.includes('كودعميل') ||
      c.includes('رقمالمرجع') ||
      c.includes('رقمالملفالبنكي') ||
      c.includes('رقمالملفالشخصي') ||
      c.includes('رقمحساب') ||
      c.includes('رقمالكود')
    ) {
      if (orderColIdx === -1) {
        orderColIdx = idx;
        fileNumberColumnName = rawCell;
      }
      hasHeader = true;
    } else if (
      c.includes('targetmonth') ||
      c === 'month' ||
      c.includes('workmonth') ||
      c === 'شهر' ||
      c === 'الشهر' ||
      c.includes('شهرالعمل') ||
      c.includes('الشهرالمستهدف')
    ) {
      monthColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('custname') ||
      c.includes('customer') ||
      c.includes('clientname') ||
      c.includes('fullname') ||
      c.includes('name') ||
      c.includes('اسم') ||
      c.includes('عميل')
    ) {
      nameColIdx = idx;
      hasHeader = true;
    } else if (
      c === 'id' ||
      c.includes('idnumber') ||
      c.includes('nationalid') ||
      c.includes('iqama') ||
      c.includes('هويه') ||
      c.includes('اقامه') ||
      c.includes('سجل')
    ) {
      idColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('mobile') ||
      c.includes('phone') ||
      c.includes('tel') ||
      c.includes('cell') ||
      c.includes('whatsapp') ||
      c.includes('جوال') ||
      c.includes('هاتف') ||
      c.includes('موبايل') ||
      c.includes('واتساب') ||
      c.includes('رقم')
    ) {
      phoneColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('visat') ||
      c.includes('visa') ||
      c.includes('cardtype') ||
      c.includes('card') ||
      c.includes('بطاق') ||
      c.includes('نوعالبطاق') ||
      c.includes('نوعفيزا')
    ) {
      visaColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('ssalary') ||
      c.includes('salary') ||
      c.includes('sal') ||
      c.includes('راتب') ||
      c.includes('دخل')
    ) {
      salaryColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('amount') ||
      c.includes('مبلغ') ||
      c.includes('تمويل')
    ) {
      amountColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('email') ||
      c.includes('بريد') ||
      c.includes('ايميل')
    ) {
      emailColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('status') ||
      c.includes('حاله')
    ) {
      statusColIdx = idx;
      hasHeader = true;
    } else if (
      c.includes('product') ||
      c.includes('منتج') ||
      c.includes('نوعالمنتج')
    ) {
      productTypeColIdx = idx;
      hasHeader = true;
    }
  });

  const parseCsvMonthKey = (rawVal: string): string | undefined => {
    const clean = rawVal.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).trim();
    const ym = clean.match(/^(20\d{2})[-/.](0?[1-9]|1[0-2])$/);
    if (ym) return `${ym[1]}-${ym[2].padStart(2, '0')}`;
    const my = clean.match(/^(0?[1-9]|1[0-2])[-/.](20\d{2})$/);
    if (my) return `${my[2]}-${my[1].padStart(2, '0')}`;
    const ymd = clean.match(/^(20\d{2})[-/.](0?[1-9]|1[0-2])[-/.]\d{1,2}$/);
    if (ymd) return `${ymd[1]}-${ymd[2].padStart(2, '0')}`;
    return undefined;
  };

  const startLineIdx = hasHeader ? 1 : 0;
  const lastHeaderIdx = firstCells.length - 1;

  for (let i = startLineIdx; i < rows.length; i++) {
    const cells = rows[i].map((c) => c.replace(/^["']|["']$/g, '').trim());
    if (cells.length === 0 || cells.every((c) => !c)) continue;

    let extractedName = '';
    let extractedPhone = '';
    let extractedIdNumber = '';
    let extractedOrderNumber = '';
    let extractedTargetMonth: string | undefined = undefined;
    let extractedVisa = '';
    let extractedSalary: number | undefined = undefined;
    let extractedAmount: number | undefined = undefined;
    let extractedEmail = '';
    let extractedStatus = '';
    const extractedNotesParts: string[] = [];
    let extractedProductType: 'visa' | 'finance' = 'visa';

    const usedIndices = new Set<number>();

    if (hasHeader) {
      if (nameColIdx >= 0 && cells[nameColIdx] !== undefined) {
        extractedName = cells[nameColIdx];
        usedIndices.add(nameColIdx);
      }
      if (phoneColIdx >= 0 && cells[phoneColIdx] !== undefined) {
        extractedPhone = cleanPhoneString(cells[phoneColIdx]);
        usedIndices.add(phoneColIdx);
      }
      if (idColIdx >= 0 && cells[idColIdx] !== undefined) {
        extractedIdNumber = cells[idColIdx].replace(/[^\d]/g, '');
        usedIndices.add(idColIdx);
      }
      if (orderColIdx >= 0 && cells[orderColIdx] !== undefined) {
        extractedOrderNumber = cells[orderColIdx].replace(/^#/, '').trim();
        usedIndices.add(orderColIdx);
      }
      if (monthColIdx >= 0 && cells[monthColIdx] !== undefined) {
        extractedTargetMonth = parseCsvMonthKey(cells[monthColIdx]);
        usedIndices.add(monthColIdx);
      }
      if (visaColIdx >= 0 && cells[visaColIdx] !== undefined) {
        extractedVisa = cells[visaColIdx];
        usedIndices.add(visaColIdx);
      }
      if (salaryColIdx >= 0 && cells[salaryColIdx] !== undefined) {
        const parsed = parseFloat(cells[salaryColIdx].replace(/[^\d.]/g, ''));
        if (!isNaN(parsed) && parsed > 0) extractedSalary = parsed;
        usedIndices.add(salaryColIdx);
      }
      if (amountColIdx >= 0 && cells[amountColIdx] !== undefined) {
        const parsed = parseFloat(cells[amountColIdx].replace(/[^\d.]/g, ''));
        if (!isNaN(parsed) && parsed > 0) extractedAmount = parsed;
        usedIndices.add(amountColIdx);
      }
      if (emailColIdx >= 0 && cells[emailColIdx] !== undefined) {
        extractedEmail = cells[emailColIdx];
        usedIndices.add(emailColIdx);
      }
      if (statusColIdx >= 0 && cells[statusColIdx] !== undefined) {
        extractedStatus = cells[statusColIdx];
        usedIndices.add(statusColIdx);
      }
      notesColIndices.forEach((nIdx) => {
        if (nIdx === lastHeaderIdx && cells.length > firstCells.length) {
          // Preserve unquoted commas that spilled past the final Notes column
          const combinedTrailing = cells
            .slice(nIdx)
            .map((part) => part.trim())
            .filter(Boolean)
            .join(', ');
          if (combinedTrailing) {
            extractedNotesParts.push(combinedTrailing);
          }
          for (let extraIdx = nIdx; extraIdx < cells.length; extraIdx++) {
            usedIndices.add(extraIdx);
          }
        } else {
          if (cells[nIdx]) {
            extractedNotesParts.push(cells[nIdx]);
          }
          usedIndices.add(nIdx);
        }
      });
      if (productTypeColIdx >= 0 && cells[productTypeColIdx] !== undefined) {
        const pt = cells[productTypeColIdx].toLowerCase();
        if (pt.includes('finance') || pt.includes('تمويل')) extractedProductType = 'finance';
        usedIndices.add(productTypeColIdx);
      }
    }

    // Secondary scan across cells if key fields are still missing (skip dedicated notes/status/id/order/product columns)
    cells.forEach((cell, idx) => {
      if (!cell || usedIndices.has(idx)) return;
      if (notesColIndices.includes(idx) || idx === statusColIdx || idx === idColIdx || idx === orderColIdx || idx === productTypeColIdx) return;

      const digitsOnly = cell.replace(/[^\d+]/g, '');
      const numVal = parseFloat(cell.replace(/[^\d.]/g, ''));

      // Check if phone was missed
      if (!extractedPhone && digitsOnly.length >= 8 && digitsOnly.length <= 15 && (digitsOnly.startsWith('05') || digitsOnly.startsWith('966') || digitsOnly.startsWith('5'))) {
        extractedPhone = digitsOnly;
        usedIndices.add(idx);
      }
      // Check if email was missed
      else if (!extractedEmail && cell.includes('@') && cell.includes('.')) {
        extractedEmail = cell;
        usedIndices.add(idx);
      }
      // Check if card type was missed
      else if (!extractedVisa && (cell.toUpperCase().includes('VISA') || cell.toLowerCase().includes('infinite') || cell.toLowerCase().includes('platinum') || cell.toLowerCase().includes('mazeed') || cell.includes('إنفينيت') || cell.includes('انفينيت') || cell.includes('بلاتينيوم') || cell.includes('بلاتينوم') || cell.includes('مزيد') || cell.includes('سيجنتشر') || cell.includes('رحالة') || cell.includes('فرسان') || cell.includes('بطاقة'))) {
        extractedVisa = cell;
        usedIndices.add(idx);
      }
      // Check if national ID / iqama was missed in headerless CSV (10 digits starting with 1 or 2)
      else if (!extractedIdNumber && digitsOnly.length === 10 && (digitsOnly.startsWith('1') || digitsOnly.startsWith('2')) && !usedIndices.has(idx)) {
        extractedIdNumber = digitsOnly;
        usedIndices.add(idx);
      }
      // Check if salary was missed (number between 1000 and 1,000,000)
      else if (extractedSalary === undefined && !isNaN(numVal) && numVal >= 1000 && numVal <= 1000000 && !digitsOnly.startsWith('05') && digitsOnly.length < 8 && idx !== phoneColIdx) {
        extractedSalary = numVal;
        usedIndices.add(idx);
      }
      // Fallback name
      else if (!extractedName && idx !== phoneColIdx && idx !== visaColIdx && idx !== salaryColIdx && /[a-zA-Z\u0600-\u06FF]/.test(cell)) {
        extractedName = cell;
        usedIndices.add(idx);
      }
    });

    // If no dedicated Notes column header was found, capture any extra trailing unconsumed text cell as notes
    if (notesColIndices.length === 0) {
      cells.forEach((cell, idx) => {
        if (!cell || usedIndices.has(idx)) return;
        if (/[a-zA-Z\u0600-\u06FF]/.test(cell)) {
          extractedNotesParts.push(cell);
        }
      });
    }

    const extractedNotes = extractedNotesParts.join(' | ').trim();

    if (extractedName || extractedPhone) {
      results.push({
        name: extractedName || extractedPhone || `عميل مستورد ${i}`,
        phone: extractedPhone || '0500000000',
        idNumber: extractedIdNumber || undefined,
        email: extractedEmail || undefined,
        salary: extractedSalary,
        amount: extractedAmount,
        notes: extractedNotes || undefined,
        hasNotesFromFile: Boolean(extractedNotes),
        status: extractedStatus ? (extractedStatus as any) : undefined,
        productType: extractedProductType,
        orderNumber: extractedOrderNumber || undefined,
        targetMonth: extractedTargetMonth || undefined,
        createdAt: new Date(),
        updatedAt: new Date(),
        cardTypeName: extractedVisa || undefined,
      });
    }
  }

  const customersWithNotesCount = results.filter((c) => Boolean(c.notes && String(c.notes).trim())).length;
  const customersWithFileNumberCount = results.filter((c) => Boolean(c.orderNumber && String(c.orderNumber).trim())).length;

  return {
    customers: results,
    detectedNotesColumn: notesColIndices.length > 0,
    notesColumnNames,
    customersWithNotesCount,
    detectedFileNumberColumn: orderColIdx >= 0,
    fileNumberColumnName,
    customersWithFileNumberCount,
    delimiter,
  };
}

/**
 * Parses CSV, TSV, or Excel exported text into Customer objects with full header recognition
 */
export function parseCSVToCustomers(text: string): ParsedImportCustomer[] {
  return parseCSVWithMetadata(text).customers;
}

/**
 * Generates and downloads a sample CSV file template for testing imports
 * Includes dedicated FileNo (رقم ملف العميل), Name, National ID, Mobile, Card Type, Salary, and Notes columns
 */
export function downloadSampleCSVTemplate(filename = 'نموذج_استيراد_العملاء.csv') {
  const sampleData = `رقم ملف العميل,الاسم,رقم الهوية,رقم الجوال,نوع البطاقة,الراتب,الملاحظات
FILE-1001,أحمد محمد العلي,1000000001,0500000011,VISA Platinum,15000,"عميل مهتم، يفضل التواصل مساءً"
FILE-1002,سارة خالد السعيد,1000000002,0500000012,VISA Infinite,24000,يتم إصدار البطاقة بتاريخ 2027-01-15
FILE-1003,فهد عبدالله الحربي,1000000003,0500000013,VISA Platinum,12500,تم إرسال الأوراق المطلوبة
FILE-1004,نورة سعد القحطاني,1000000004,0500000014,VISA Infinite,32000,عميل VIP - أولوية متابعة`;

  // UTF-8 BOM for Arabic/Excel compatibility
  const blob = new Blob(['\uFEFF' + sampleData], { type: 'text/csv;charset=utf-8;' });
  void saveOrShareBlob(blob, filename, {
    title: filename,
    fallbackName: 'customers_template.csv',
  });
}
