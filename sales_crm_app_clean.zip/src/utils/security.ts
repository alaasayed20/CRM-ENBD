import type { User } from '../types';

export interface RolePermissions {
  isAdmin: boolean;
  canAccessAdmin: boolean;
  canDeleteCustomer: boolean;
  canBulkDelete: boolean;
  canManageUsers: boolean;
  canManageBranding: boolean;
  canWipeOrRestoreDb: boolean;
  canEditCustomer: boolean;
  canBulkUpdateStatus: boolean;
  canExportData: boolean;
}

/**
 * Central RBAC permission resolver:
 * Strict separation between Admin and Sales Representative roles.
 */
export function getPermissions(user?: User | null): RolePermissions {
  const isAdmin = user?.role === 'admin';
  return {
    isAdmin,
    canAccessAdmin: isAdmin,
    canDeleteCustomer: isAdmin,
    canBulkDelete: isAdmin,
    canManageUsers: isAdmin,
    canManageBranding: isAdmin,
    canWipeOrRestoreDb: isAdmin,
    canEditCustomer: Boolean(user),
    canBulkUpdateStatus: Boolean(user),
    canExportData: Boolean(user),
  };
}

/**
 * Canonical phone normalizer for reliable duplicate detection across Arabic digits,
 * spaces, dashes, leading 0, and Saudi/international prefixes (+966 / 00966 / 966).
 */
export function normalizePhoneForMatch(phone?: string | null): string {
  if (!phone) return '';
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
  const normalized = String(phone).trim();
  let out = '';
  for (let i = 0; i < normalized.length; i++) {
    const ch = normalized[i];
    const arIdx = arabicDigits.indexOf(ch);
    const faIdx = persianDigits.indexOf(ch);
    if (arIdx !== -1) out += String(arIdx);
    else if (faIdx !== -1) out += String(faIdx);
    else if (ch >= '0' && ch <= '9') out += ch;
  }

  if (out.startsWith('00966') && out.length >= 14) {
    out = out.slice(5);
  } else if (out.startsWith('966') && out.length >= 12) {
    out = out.slice(3);
  }
  if (out.startsWith('0') && out.length === 10) {
    out = out.slice(1);
  }
  return out;
}

// ============================================================================
// CRYPTOGRAPHIC HELPERS (Web Crypto PBKDF2-SHA256 & AES-256-GCM)
// ============================================================================

const PBKDF2_ITERATIONS = 100000;
const BACKUP_PBKDF2_ITERATIONS = 150000;

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.trim();
  if (clean.length % 2 !== 0 || !/^[0-9a-fA-F]*$/.test(clean)) {
    return new Uint8Array(0);
  }
  const bytes = new Uint8Array(clean.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToBytes(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function getRandomBytes(length: number): Uint8Array {
  const arr = new Uint8Array(length);
  if (typeof window !== 'undefined' && window.crypto?.getRandomValues) {
    window.crypto.getRandomValues(arr);
  } else {
    for (let i = 0; i < length; i++) {
      arr[i] = Math.floor(Math.random() * 256);
    }
  }
  return arr;
}

/**
 * Constant-time string comparison to prevent timing side-channels.
 */
export function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

async function derivePbkdf2Bits(
  secret: string,
  salt: Uint8Array,
  iterations: number,
  lengthBits = 256
): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const derived = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations,
      hash: 'SHA-256',
    },
    keyMaterial,
    lengthBits
  );
  return new Uint8Array(derived);
}

/**
 * Returns true if the stored credential string is already hashed with PBKDF2.
 */
export function isPasswordHashed(stored?: string | null): boolean {
  return Boolean(stored && stored.startsWith('pbkdf2_v1$'));
}

/**
 * Hashes a user password with PBKDF2-SHA256 and a unique 16-byte random salt.
 */
export async function hashPassword(password: string): Promise<string> {
  const normalized = String(password);
  const salt = getRandomBytes(16);

  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const hashBytes = await derivePbkdf2Bits(normalized, salt, PBKDF2_ITERATIONS, 256);
    return `pbkdf2_v1$${PBKDF2_ITERATIONS}$${bytesToHex(salt)}$${bytesToHex(hashBytes)}`;
  }

  // Fallback for rare non-secure contexts without subtle crypto
  const saltHex = bytesToHex(salt);
  const fallback = await legacyHashFallback(`${saltHex}:${normalized}`);
  return `pbkdf2_fb$${saltHex}$${fallback}`;
}

/**
 * Verifies a password against a stored PBKDF2 hash (or legacy plaintext during migration).
 * Returns `{ valid, needsUpgrade }` so legacy accounts are upgraded transparently on login.
 */
export async function verifyPassword(
  inputPassword: string,
  storedCredential?: string | null
): Promise<{ valid: boolean; needsUpgrade: boolean }> {
  if (!storedCredential || !inputPassword) {
    return { valid: false, needsUpgrade: false };
  }

  if (storedCredential.startsWith('pbkdf2_v1$')) {
    const parts = storedCredential.split('$');
    if (parts.length !== 4) return { valid: false, needsUpgrade: false };
    const iterations = parseInt(parts[1], 10);
    const salt = hexToBytes(parts[2]);
    const expectedHash = parts[3];
    if (!iterations || iterations < 10000 || salt.length < 8 || !expectedHash) {
      return { valid: false, needsUpgrade: false };
    }
    if (typeof window === 'undefined' || !window.crypto?.subtle) {
      return { valid: false, needsUpgrade: false };
    }
    const candidateBytes = await derivePbkdf2Bits(inputPassword, salt, iterations, 256);
    const candidateHex = bytesToHex(candidateBytes);
    return {
      valid: constantTimeEqual(candidateHex, expectedHash),
      needsUpgrade: false,
    };
  }

  if (storedCredential.startsWith('pbkdf2_fb$')) {
    const parts = storedCredential.split('$');
    if (parts.length !== 3) return { valid: false, needsUpgrade: false };
    const candidate = await legacyHashFallback(`${parts[1]}:${inputPassword}`);
    const valid = constantTimeEqual(candidate, parts[2]);
    return { valid, needsUpgrade: valid && Boolean(window.crypto?.subtle) };
  }

  // Legacy plaintext record in existing local IndexedDB: constant-time compare + flag for immediate PBKDF2 upgrade
  const valid = constantTimeEqual(inputPassword, storedCredential);
  return { valid, needsUpgrade: valid };
}

async function legacyHashFallback(payload: string): Promise<string> {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < payload.length; i++) {
    const ch = payload.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

/**
 * Hashes a user PIN locally with salted PBKDF2-SHA256 (100,000 iterations)
 * to resist offline brute-force attacks over the 4-6 digit keyspace.
 */
export async function hashPin(pin: string): Promise<string> {
  const cleanPin = pin.trim();
  const salt = getRandomBytes(16);

  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const derived = await derivePbkdf2Bits(`pin:${cleanPin}`, salt, PBKDF2_ITERATIONS, 256);
    return `pbkdf2_pin_v2$${PBKDF2_ITERATIONS}$${bytesToHex(salt)}$${bytesToHex(derived)}`;
  }

  const saltHex = bytesToHex(salt);
  return `fnv_pin$${saltHex}$${await legacyHashFallback(`${saltHex}:${cleanPin}`)}`;
}

async function legacySha256Pin(pin: string, salt = 'sales_crm_pin_v1'): Promise<string> {
  const payload = `${salt}:${pin.trim()}`;
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const encoded = new TextEncoder().encode(payload);
    const digest = await window.crypto.subtle.digest('SHA-256', encoded);
    return 'sha256:' + bytesToHex(new Uint8Array(digest));
  }
  return 'fnv:' + (await legacyHashFallback(payload));
}

export function isLegacyPinHash(storedHash?: string | null): boolean {
  return Boolean(storedHash && (storedHash.startsWith('sha256:') || storedHash.startsWith('fnv:')));
}

/**
 * Constant-time verification for both modern PBKDF2 PINs and legacy SHA-256 PINs.
 */
export async function verifyPin(
  inputPin: string,
  storedHash?: string | null
): Promise<boolean> {
  if (!storedHash || !inputPin) return false;
  const cleanPin = inputPin.trim();

  if (storedHash.startsWith('pbkdf2_pin_v2$')) {
    const parts = storedHash.split('$');
    if (parts.length !== 4) return false;
    const iterations = parseInt(parts[1], 10);
    const salt = hexToBytes(parts[2]);
    const expected = parts[3];
    if (!iterations || salt.length < 8 || !expected) return false;
    if (typeof window === 'undefined' || !window.crypto?.subtle) return false;
    const derived = await derivePbkdf2Bits(`pin:${cleanPin}`, salt, iterations, 256);
    return constantTimeEqual(bytesToHex(derived), expected);
  }

  if (storedHash.startsWith('fnv_pin$')) {
    const parts = storedHash.split('$');
    if (parts.length !== 3) return false;
    const candidate = await legacyHashFallback(`${parts[1]}:${cleanPin}`);
    return constantTimeEqual(candidate, parts[2]);
  }

  // Legacy sha256: / fnv: PIN compatibility
  const candidate = await legacySha256Pin(cleanPin);
  return constantTimeEqual(candidate, storedHash);
}

// ============================================================================
// PROGRESSIVE BRUTE-FORCE LOCKOUT ENGINE (LOGIN & PIN)
// ============================================================================

export type LockoutScope = 'login' | 'pin';

export interface LockoutState {
  attempts: number;
  lockedUntil: number;
  remainingSeconds: number;
  isLocked: boolean;
}

const LOCKOUT_STORAGE_PREFIX = 'sales_crm_sec_lockout_v1_';
const MAX_FREE_ATTEMPTS = 5;

function computeLockoutDurationMs(attempts: number): number {
  if (attempts < MAX_FREE_ATTEMPTS) return 0;
  const over = attempts - MAX_FREE_ATTEMPTS;
  if (over === 0) return 30 * 1000;      // 30 seconds
  if (over === 1) return 60 * 1000;      // 1 minute
  if (over === 2) return 5 * 60 * 1000;  // 5 minutes
  return 15 * 60 * 1000;                 // 15 minutes max backoff
}

export function getLockoutState(scope: LockoutScope): LockoutState {
  if (typeof window === 'undefined') {
    return { attempts: 0, lockedUntil: 0, remainingSeconds: 0, isLocked: false };
  }
  try {
    const raw = localStorage.getItem(`${LOCKOUT_STORAGE_PREFIX}${scope}`);
    if (!raw) return { attempts: 0, lockedUntil: 0, remainingSeconds: 0, isLocked: false };
    const parsed = JSON.parse(raw);
    const attempts = Math.max(0, Number(parsed?.attempts) || 0);
    const lockedUntil = Math.max(0, Number(parsed?.lockedUntil) || 0);
    const now = Date.now();
    const remainingMs = Math.max(0, lockedUntil - now);
    return {
      attempts,
      lockedUntil,
      remainingSeconds: Math.ceil(remainingMs / 1000),
      isLocked: remainingMs > 0,
    };
  } catch {
    return { attempts: 0, lockedUntil: 0, remainingSeconds: 0, isLocked: false };
  }
}

export function recordFailedAttempt(scope: LockoutScope): LockoutState {
  const current = getLockoutState(scope);
  const nextAttempts = current.attempts + 1;
  const durationMs = computeLockoutDurationMs(nextAttempts);
  const lockedUntil = durationMs > 0 ? Date.now() + durationMs : 0;

  try {
    localStorage.setItem(
      `${LOCKOUT_STORAGE_PREFIX}${scope}`,
      JSON.stringify({ attempts: nextAttempts, lockedUntil })
    );
  } catch {
    // ignore storage quota errors
  }

  return {
    attempts: nextAttempts,
    lockedUntil,
    remainingSeconds: Math.ceil(durationMs / 1000),
    isLocked: durationMs > 0,
  };
}

export function clearLockoutAttempts(scope: LockoutScope): void {
  try {
    localStorage.removeItem(`${LOCKOUT_STORAGE_PREFIX}${scope}`);
  } catch {
    // ignore
  }
}

// ============================================================================
// AES-256-GCM ENCRYPTED BACKUP ENVELOPE + STRICT RESTORE SANITIZATION
// ============================================================================

export interface EncryptedBackupEnvelope {
  encrypted: true;
  format: 'sales-crm-aes-gcm-v1';
  iterations: number;
  salt: string;
  iv: string;
  ciphertext: string;
  createdAt: string;
}

export function isEncryptedBackup(data: unknown): data is EncryptedBackupEnvelope {
  if (!data || typeof data !== 'object') return false;
  const obj = data as Record<string, unknown>;
  return (
    obj.encrypted === true &&
    obj.format === 'sales-crm-aes-gcm-v1' &&
    typeof obj.salt === 'string' &&
    typeof obj.iv === 'string' &&
    typeof obj.ciphertext === 'string'
  );
}

async function deriveAesKeyFromPassphrase(
  passphrase: string,
  salt: Uint8Array,
  iterations: number,
  usages: KeyUsage[]
): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );
  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations,
      hash: 'SHA-256',
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    usages
  );
}

export async function encryptBackupPayload(
  payload: unknown,
  passphrase: string
): Promise<EncryptedBackupEnvelope> {
  if (!window.crypto?.subtle) {
    throw new Error('Web Crypto API is unavailable in this browser context');
  }
  if (!passphrase || passphrase.trim().length < 6) {
    throw new Error('Passphrase must be at least 6 characters');
  }
  const salt = getRandomBytes(16);
  const iv = getRandomBytes(12);
  const key = await deriveAesKeyFromPassphrase(passphrase, salt, BACKUP_PBKDF2_ITERATIONS, ['encrypt']);
  const encoded = new TextEncoder().encode(JSON.stringify(payload));
  const encryptedBuf = await window.crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    encoded
  );
  return {
    encrypted: true,
    format: 'sales-crm-aes-gcm-v1',
    iterations: BACKUP_PBKDF2_ITERATIONS,
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(new Uint8Array(encryptedBuf)),
    createdAt: new Date().toISOString(),
  };
}

export async function decryptBackupPayload(
  envelope: EncryptedBackupEnvelope,
  passphrase: string
): Promise<any> {
  if (!window.crypto?.subtle) {
    throw new Error('Web Crypto API is unavailable');
  }
  const salt = base64ToBytes(envelope.salt);
  const iv = base64ToBytes(envelope.iv);
  const ciphertext = base64ToBytes(envelope.ciphertext);
  const iterations = Math.min(500000, Math.max(50000, Number(envelope.iterations) || BACKUP_PBKDF2_ITERATIONS));
  const key = await deriveAesKeyFromPassphrase(passphrase, salt, iterations, ['decrypt']);
  const plainBuf = await window.crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    ciphertext as BufferSource
  );
  const jsonText = new TextDecoder().decode(plainBuf);
  return stripDangerousKeys(JSON.parse(jsonText));
}

const DANGEROUS_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

/**
 * Recursively strips prototype-pollution keys from untrusted JSON objects.
 */
export function stripDangerousKeys<T>(input: T, depth = 0): T {
  if (depth > 12 || input === null || typeof input !== 'object') {
    return input;
  }
  if (Array.isArray(input)) {
    return input.map((item) => stripDangerousKeys(item, depth + 1)) as unknown as T;
  }
  const clean: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (DANGEROUS_KEYS.has(key)) continue;
    clean[key] = stripDangerousKeys(value, depth + 1);
  }
  return clean as T;
}

const ALLOWED_BACKUP_TABLES = [
  'customers',
  'users',
  'cardTypes',
  'products',
  'statuses',
  'messageTemplates',
  'settings',
  'pointsLog',
  'operationsLog',
  'tasks',
  'salaryTiers',
] as const;

export function validateAndSanitizeBackupObject(raw: unknown): {
  valid: boolean;
  data?: Record<string, any[]>;
  error?: string;
} {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { valid: false, error: 'Invalid backup JSON structure' };
  }
  const cleaned = stripDangerousKeys(raw as Record<string, any>);
  if (!Array.isArray(cleaned.customers) || (!cleaned.version && !cleaned.exportDate)) {
    return { valid: false, error: 'Missing required Sales CRM backup metadata' };
  }
  const sanitizedTables: Record<string, any[]> = {};
  let totalRows = 0;

  for (const table of ALLOWED_BACKUP_TABLES) {
    const val = cleaned[table];
    if (val === undefined) continue;
    if (!Array.isArray(val)) {
      return { valid: false, error: `Invalid table format for ${table}` };
    }
    totalRows += val.length;
    if (totalRows > 50000) {
      return { valid: false, error: 'Backup exceeds safe record limit' };
    }
    sanitizedTables[table] = val.filter((row) => row && typeof row === 'object' && !Array.isArray(row));
  }

  return { valid: true, data: sanitizedTables };
}

// ============================================================================
// INPUT, EXPORT (CSV / EXCEL / PDF) & LINK SANITIZERS
// ============================================================================

const FORMULA_TRIGGERS = /^[=+\-@\t\r]/;

/**
 * Neutralizes CSV / Excel Formula Injection (DDE / spreadsheet execution).
 * Leaves clean numeric values untouched when used for XLSX typed numbers.
 */
export function sanitizeSpreadsheetValue(value: string | number | null | undefined): string | number {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : 0;
  }
  const str = sanitizePlainText(String(value), 2000);
  if (FORMULA_TRIGGERS.test(str)) {
    return `'${str}`;
  }
  return str;
}

/**
 * Escapes and neutralizes a cell value for safe RFC 4180 CSV export.
 */
export function sanitizeCsvCell(value: string | number | null | undefined): string {
  const safe = String(sanitizeSpreadsheetValue(value));
  return `"${safe.replace(/"/g, '""')}"`;
}

/**
 * Removes null bytes & unsafe control characters and bounds string length.
 */
export function sanitizePlainText(value: unknown, maxLength = 500): string {
  if (value === null || value === undefined) return '';
  const cleaned = String(value)
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
    .trim();
  return cleaned.length > maxLength ? cleaned.slice(0, maxLength) : cleaned;
}

/**
 * Sanitizes a download filename to prevent path separators or control chars.
 */
export function sanitizeDownloadFilename(name: string, fallback = 'report'): string {
  const clean = String(name || fallback)
    .replace(/[\x00-\x1F\x7F<>:"/\\|?*]+/g, '-')
    .replace(/\.{2,}/g, '.')
    .replace(/^-+|-+$/g, '')
    .trim();
  return (clean || fallback).slice(0, 120);
}

/**
 * Validates external URLs strictly against safe schemes (https:, or localhost http:).
 * Blocks javascript:, data:, vbscript:, file:, etc.
 */
export function sanitizeSafeExternalUrl(rawUrl?: string | null): string | null {
  if (!rawUrl) return null;
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:') {
      return parsed.toString();
    }
    if (
      parsed.protocol === 'http:' &&
      (parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1')
    ) {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Builds a sanitized tel: link containing only digits and optional leading +.
 */
export function buildSafeTelHref(phone?: string | null): string {
  const raw = String(phone || '').trim();
  const hasPlus = raw.startsWith('+');
  const digits = raw.replace(/\D/g, '').slice(0, 20);
  if (!digits) return '#';
  return `tel:${hasPlus ? '+' : ''}${digits}`;
}

/**
 * Builds a sanitized WhatsApp wa.me link with normalized digits only.
 */
export function buildSafeWhatsAppHref(phone?: string | null, message?: string): string {
  let digits = String(phone || '').replace(/\D/g, '').slice(0, 20);
  if (!digits) return '#';
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('05') && digits.length === 10) {
    digits = `966${digits.slice(1)}`;
  }
  const base = `https://wa.me/${digits}`;
  if (message && message.trim()) {
    return `${base}?text=${encodeURIComponent(sanitizePlainText(message, 2500))}`;
  }
  return base;
}

/**
 * Builds a validated mailto: href, blocking header injection characters.
 */
export function buildSafeMailtoHref(email?: string | null): string {
  const clean = String(email || '').trim();
  if (!clean || /[\r\n\s<>]/.test(clean) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) {
    return '#';
  }
  return `mailto:${encodeURIComponent(clean)}`;
}

/**
 * Opens an external URL safely with `noopener,noreferrer` after validating its scheme.
 */
export function safeOpenExternal(rawUrl?: string | null): boolean {
  const safe = sanitizeSafeExternalUrl(rawUrl);
  if (!safe || typeof window === 'undefined') return false;
  const win = window.open(safe, '_blank', 'noopener,noreferrer');
  if (win) {
    try {
      win.opener = null;
    } catch {
      // ignore cross-origin restrictions
    }
  }
  return true;
}

// ============================================================================
// IN-MEMORY SIGNED SESSION TOKEN FOR SERVER AI PROXY (/api/scan-customer)
// Never stored in localStorage or sessionStorage!
// ============================================================================

let inMemoryScanToken: { token: string; expiresAt: number } | null = null;

export function clearScanSessionToken(): void {
  inMemoryScanToken = null;
}

export async function getScanSessionToken(): Promise<string | null> {
  const now = Date.now();
  if (inMemoryScanToken && inMemoryScanToken.expiresAt - now > 30_000) {
    return inMemoryScanToken.token;
  }
  try {
    const res = await fetch('/api/auth/session', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'SalesCRM-Client',
      },
      body: JSON.stringify({ purpose: 'scan' }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data && typeof data.token === 'string' && typeof data.expiresInMs === 'number') {
      inMemoryScanToken = {
        token: data.token,
        expiresAt: now + Math.max(60_000, data.expiresInMs),
      };
      return inMemoryScanToken.token;
    }
    return null;
  } catch {
    return null;
  }
}

// ============================================================================
// WEBAUTHN BIOMETRIC HELPERS (LOCAL DEVICE UNLOCK)
// ============================================================================

function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBuffer(base64Url: string): ArrayBuffer {
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Checks whether platform biometric authentication (Fingerprint / FaceID) is available.
 */
export async function isBiometricSupported(): Promise<boolean> {
  if (
    typeof window === 'undefined' ||
    !window.PublicKeyCredential ||
    typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable !== 'function'
  ) {
    return false;
  }
  try {
    return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

/**
 * Registers a local WebAuthn platform credential for quick biometric unlock.
 */
export async function registerBiometricCredential(username: string): Promise<string | null> {
  try {
    const supported = await isBiometricSupported();
    if (!supported) return null;

    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const userIdBytes = new TextEncoder().encode(username || 'sales-crm-user');
    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: {
          name: 'Sales CRM',
          id: window.location.hostname,
        },
        user: {
          id: userIdBytes,
          name: username || 'sales-crm-user',
          displayName: username || 'Sales CRM User',
        },
        pubKeyCredParams: [
          { alg: -7, type: 'public-key' },
          { alg: -257, type: 'public-key' },
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
        },
        timeout: 60000,
      },
    })) as PublicKeyCredential | null;

    if (!credential) return null;
    return bufferToBase64Url(credential.rawId);
  } catch {
    return null;
  }
}

/**
 * Triggers device biometric prompt (Fingerprint / FaceID) to unlock the app.
 */
export async function authenticateBiometric(credentialId: string): Promise<boolean> {
  try {
    if (!credentialId || typeof navigator === 'undefined' || !navigator.credentials) {
      return false;
    }
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const assertion = await navigator.credentials.get({
      publicKey: {
        challenge,
        allowCredentials: [
          {
            id: base64UrlToBuffer(credentialId),
            type: 'public-key',
          },
        ],
        userVerification: 'required',
        timeout: 60000,
      },
    });

    return Boolean(assertion);
  } catch {
    return false;
  }
}
